# Stage 31 source and validation

The supplied current product scripts and C# controls are the implementation. The runtime starts from the verified Stage 30 archive (SHA-256 b2e1600f7eba57508dc3afa851a77b29ef644a96ae17a9394394d2475c423ade). Previous releases remain unchanged.

## Build

- EquipmentReader contains the complete read-only file decoder source, required upstream structures, crypto shim and vendor code. It has no save-output command. With Zig 0.14.1 available as `zig`, `MHW_ZIG_BIN`, or `stage31/build-deps/ziglang/zig`, run `build_equipment_reader.py`. The host build additionally needs a C++17 compiler and OpenSSL development libraries. Windows uses built-in BCrypt. The original write-capable save engine is not rebuilt or modified.
- `build_equipment_catalog.py` needs the separately supplied `restore31/inputs/common.zip` and the included `reference_data/awakening_ids.json`. The snapshot records the explicit upstream table's original commit/hash. Names must agree with original GMD labels; mismatches remain unmapped. Do not infer IDs from string-table row positions.
- `build_help.py` generates the 12-topic tutorials in five languages. `build_ui_localization.py` merges the supplied TSV into the included UI dictionaries and checks placeholders/key sets.
- PauseController retains the Stage 29 suspension/guard logic. Only visible button captions are uppercased with Windows Unicode casing. Build with Zig C++17 for x86_64-windows-gnu, -O2 -s -municode -static, GUI subsystem, and user32/gdi32/shell32/gdiplus. The portable ownership test runs the actual state header.
- Current guide code/data and localized dictionaries are supplied. Runtime artwork/audio are in the runtime package, not duplicated in this source archive. ImageAudit.json records the six additional MHWI source icons and the two reference icon-type/color matches.

## Checks

Product PowerShell/C# parsing; original localization, inventory and music fixtures; actual button-registration/uppercase events; centered bounds and canonical quest selection; all local item/monster image paths and tutorial topics; read-only equipment decoding and UI report; all-language Guide regression and English round trips; pause ownership transitions. See VALIDATION.json for results and limits.

EquipmentReader/test_fixture.cpp creates temporary encrypted fixtures only for testing. `tests/test_reader.py` needs an independently supplied PC Iceborne save at the documented fixture path. No real save, captured game executable, private equipment dump, or generated save fixture is included here. Fixtures must remain outside release packages.

The browser fixtures use a QA-host Chromium path; adapt it to your own host. Temporary browser screenshots are not release assets. Actual Windows Forms/MSHTML rendering, disabled-control tooltip behavior, native sound output and the rebuilt pause helper still require the separate Windows acceptance checklist. The actual in-game combined stat/slot calculation is intentionally not inferred.
