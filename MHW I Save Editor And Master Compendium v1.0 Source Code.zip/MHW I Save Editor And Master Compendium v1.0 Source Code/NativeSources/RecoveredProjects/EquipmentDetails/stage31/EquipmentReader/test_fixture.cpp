#define main reader_program_main
#include "main.cpp"
#undef main
#include <cstddef>
int main(int argc,char**argv){
 try{
  require(argc==3,"fixture input directory");auto d=decode(read(fs::u8path(argv[1])));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&e=s->section3.saves[0].equipment[0];
  e.category=Weapon;e.type=static_cast<mhw_equip_type>(0);e.id=1;e.level=12;e.points=13;
  for(auto&a:e.augments)a=0;e.augments[0]=4;e.augments[1]=4;e.augments[2]=1;
  e.extra_slots=3;e.attack_increase=4;e.affinity_increase=2;e.defense_increase=1;e.slot_upgrade=2;e.health_regen=1;e.element_status_effect_up=3;
  for(auto&a:e.custom_upgrades)a=0;e.custom_upgrades[0]=7;
  for(auto&a:e.awakens)a=0;e.awakens[0]=37;e.awakens[1]=40;e.awakens[2]=1;e.awakens[3]=999;
  auto encrypted=d;EncryptSave(encrypted.data(),int(encrypted.size()));auto check=decode(encrypted);require(reinterpret_cast<mhw_ib_save*>(check.data())->section3.saves[0].equipment[0].awakens[3]==999,"roundtrip");
  fs::create_directories(fs::u8path(argv[2]));std::ofstream out(fs::u8path(argv[2])/"effects-save",std::ios::binary);out.write(reinterpret_cast<const char*>(encrypted.data()),encrypted.size());out.close();
  std::cout<<"{\"equipment_size\":"<<sizeof(e)<<",\"augment_offset\":"<<offsetof(mhw_equipment,augments)<<",\"awakening_offset\":"<<offsetof(mhw_equipment,awakens)<<"}\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what();return 1;}
}
