#include <fstream>
#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <array>
#include <cstring>
#include <stdexcept>
#include <chrono>
#include "upstream/types/mhw_save.h"

#include "upstream/crypto/iceborne_crypt.h"



namespace fs=std::filesystem;
using Bytes=std::vector<u8>;
static fs::path dataRoot;
static void require(bool ok,const std::string& s){if(!ok)throw std::runtime_error(s);}
static Bytes read(const fs::path&p){std::ifstream f(p,std::ios::binary);require(bool(f),"Cannot open input file.");Bytes d((std::istreambuf_iterator<char>(f)),{});require(!f.bad(),"Cannot read input file.");return d;}
static std::string quote(const std::string&s){std::string o="\"";for(unsigned char c:s){if(c=='\\'||c=='\"'){o+='\\';o+=c;}else if(c<32){char b[7];snprintf(b,7,"\\u%04x",c);o+=b;}else o+=c;}return o+'\"';}
static Bytes decode(const Bytes&original){
 require(original.size()==sizeof(mhw_ib_save),"Unsupported save size; expected a PC Iceborne save.");auto d=original;
 blowfish_decrypt(d.data(),int(d.size()),KEY_SAVEDATA1000);
 auto h=GenerateHash(d.data(),int(d.size()),64);bool ok=CheckHash(d.data(),h);free(h);require(ok,"Save outer integrity check failed.");
 const int offsets[]={0x70,0x3010D8,0x50AB98,0x714658},lengths[]={0xDA50,0x2098C0,0x2098C0,0x2098C0},slots[]={3,0,1,2};
 for(int i=0;i<4;i++)require(DecryptRegion(d.data(),offsets[i],lengths[i],slots[i]),"Save region integrity check failed.");
 return d;
}

static int run(std::vector<std::string>a){
 require(a.size()==3,"Usage: EquipmentDetails save-file character-slot");
 size_t used=0;int n=std::stoi(a[2],&used);require(used==a[2].size()&&n>=1&&n<=3,"Character slot must be 1, 2 or 3.");
 auto d=decode(read(fs::u8path(a[1])));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&slot=s->section3.saves[n-1];
 std::cout<<"{\"slot\":"<<n<<",\"read_only\":true,\"equipment\":[";bool first=true;
 for(size_t i=0;i<COUNTOF(slot.equipment);i++){
  const auto&e=slot.equipment[i];if((e.category!=Weapon&&e.category!=Armor)||e.type<0)continue;
  if(!first)std::cout<<',';first=false;
  std::cout<<"{\"index\":"<<i<<",\"category\":"<<int(e.category)<<",\"type\":"<<int(e.type)<<",\"id\":"<<e.id<<",\"level\":"<<e.level<<",\"points\":"<<e.points<<",\"augments\":[";
  for(int j=0;j<3;j++){if(j)std::cout<<',';std::cout<<e.augments[j];}
  std::cout<<"],\"extra_slots\":"<<int(e.extra_slots)<<",\"attack_increase\":"<<int(e.attack_increase)<<",\"affinity_increase\":"<<int(e.affinity_increase)<<",\"defense_increase\":"<<int(e.defense_increase)<<",\"slot_upgrade\":"<<int(e.slot_upgrade)<<",\"health_regen\":"<<int(e.health_regen)<<",\"element_status_effect_up\":"<<int(e.element_status_effect_up)<<",\"custom_upgrades\":[";
  for(int j=0;j<12;j++){if(j)std::cout<<',';std::cout<<int(e.custom_upgrades[j]);}
  std::cout<<"],\"awakens\":[";for(int j=0;j<5;j++){if(j)std::cout<<',';std::cout<<e.awakens[j];}std::cout<<"]}";
 }
 std::cout<<"]}\n";return 0;
}
#ifdef _WIN32
int wmain(int argc,wchar_t**argv){std::vector<std::string>a;for(int i=0;i<argc;i++){int n=WideCharToMultiByte(CP_UTF8,0,argv[i],-1,nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,argv[i],-1,s.data(),n,nullptr,nullptr);s.pop_back();a.push_back(s);}try{return run(a);}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#else
int main(int argc,char**argv){try{return run(std::vector<std::string>(argv,argv+argc));}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#endif
