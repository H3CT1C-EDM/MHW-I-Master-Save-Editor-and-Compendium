#pragma once
#include <array>
#include <vector>
#include <string>
#include <cstring>
#include <cstddef>
#include "../types/file/sgpa.h"
#include "../types/file/wp_dat.h"
#include "../types/file/wp_dat_g.h"

namespace GameDataPatch {
inline bool ValidSlots(const std::array<u8,3>& sizes) {
  bool empty=false;
  for(auto size:sizes) {if(size>4)return false;if(!size)empty=true;else if(empty)return false;}
  return true;
}
template<class H,class E> bool Validate(const std::vector<u8>& data,std::string& error) {
  if(data.size()<sizeof(H)){error="Truncated game-data header.";return false;}
  u32 magic;std::memcpy(&magic,data.data(),4);
  if(magic!=0x18091001){error="Unrecognized game-data magic.";return false;}
  H h;std::memcpy(&h,data.data(),sizeof(h));
  if(!h.entry_count || h.entry_count>100000 || data.size()!=sizeof(H)+size_t(h.entry_count)*sizeof(E)) {
    error="Game-data size does not match its record count. Use an extracted matching table.";return false;
  }
  return true;
}
template<class H,class E> bool Weapon(std::vector<u8>& data,u32 id,const std::array<u8,3>& sizes,std::string& error) {
  if(!ValidSlots(sizes)){error="Slots must be levels 1-4 followed by empty slots.";return false;}
  if(!Validate<H,E>(data,error))return false;
  H h;std::memcpy(&h,data.data(),sizeof(h));
  size_t found=0,position=0;
  for(size_t i=0;i<h.entry_count;i++) {E e;std::memcpy(&e,data.data()+sizeof(H)+i*sizeof(E),sizeof(e));if(e.id==id){found++;position=sizeof(H)+i*sizeof(E);}}
  if(found!=1){error="Weapon ID is missing or ambiguous in this table.";return false;}
  E e;std::memcpy(&e,data.data()+position,sizeof(e));
  e.slot_count=(sizes[0]!=0)+(sizes[1]!=0)+(sizes[2]!=0);
  e.slot1_size=sizes[0];e.slot2_size=sizes[1];e.slot3_size=sizes[2];
  std::memcpy(data.data()+position,&e,sizeof(e));error.clear();return true;
}
inline bool AnyJewel(std::vector<u8>& data,std::string& error) {
  if(!Validate<sgpa_header,sgpa_entry>(data,error))return false;
  sgpa_header h;std::memcpy(&h,data.data(),sizeof(h));
  // Validate every row before touching the buffer.
  for(size_t i=0;i<h.entry_count;i++){sgpa_entry e;std::memcpy(&e,data.data()+sizeof(h)+i*sizeof(e),sizeof(e));if(e.id && e.size>4){error="Unexpected jewel-size encoding.";return false;}}
  for(size_t i=0;i<h.entry_count;i++) {sgpa_entry e;size_t p=sizeof(h)+i*sizeof(e);std::memcpy(&e,data.data()+p,sizeof(e));if(e.id && e.size>=1){e.size=1;std::memcpy(data.data()+p,&e,sizeof(e));}}
  error.clear();return true;
}
}
