#pragma once
#include <string>
#include "../types/mhw_save.h"
#include "../types/file/itm.h"

namespace SpecialItems {
inline bool Get(const mhw_save_slot& slot,u32 id) {
  return id<sizeof(slot.discovered_items.items)*8 && (slot.discovered_items.items[id/8] & u8(1u<<(id%8)));
}
// Furniture's native grant path uses this flag as ownership. For account items
// this edits discovery ONLY, not the temporary quest queue or research payout.
inline bool Set(mhw_save_slot& slot,const itm_entry& item,bool enabled,std::string& error) {
  if(item.type!=u32(itemCategory::Furniture) && item.type!=u32(itemCategory::Account)) {error="Not an account/furniture record.";return false;}
  if(!item.id || item.id>=sizeof(slot.discovered_items.items)*8){error="Item ID is outside the saved flag bank.";return false;}
  u8 mask=u8(1u<<(item.id%8));
  if(enabled)slot.discovered_items.items[item.id/8]|=mask;
  else slot.discovered_items.items[item.id/8]&=u8(~mask);
  error.clear();return true;
}
}
