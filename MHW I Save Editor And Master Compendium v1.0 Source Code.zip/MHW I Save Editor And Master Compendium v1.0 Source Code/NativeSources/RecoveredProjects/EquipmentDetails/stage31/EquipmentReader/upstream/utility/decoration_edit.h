#pragma once
#include <array>
#include <map>
#include <string>
#include <vector>
#include <cstring>
#include "../types/mhw_save.h"
#include "../types/file/sgpa.h"

namespace DecorationEdit {
// Equipment saves contain sgpa ROW indices, not inventory item IDs. Empty = -1.
inline bool Apply(mhw_save_slot& slot, size_t equipmentIndex,
    const std::array<i32,3>& desired, const std::array<u8,3>& capacities,
    bool ignoreSize, bool useBox, const std::vector<sgpa_entry>& gems,
    std::string& error) {
  auto fail=[&](const char*message){error=message;return false;};
  if(equipmentIndex>=COUNTOF(slot.equipment)) return fail("Invalid equipment index.");
  auto& equipment=slot.equipment[equipmentIndex];
  if(equipment.category!=Weapon && equipment.category!=Armor) return fail("Only hunter weapons and armor accept jewels.");
  std::map<u32,int> changes;
  for(size_t i=0;i<3;++i) {
    i32 before=equipment.decos[i], after=desired[i];
    // Preserve an unchanged existing assignment, including unknown original records.
    if(after==before) continue;
    if(after < -1 || (after>=0 && size_t(after)>=gems.size())) return fail("Unknown jewel selection.");
    if(after>=0) {
      const auto& gem=gems[after];
      if(!gem.id || gem.size<1 || gem.size>4) return fail("Invalid jewel data.");
      if(!capacities[i] || capacities[i]>4) return fail("This slot does not exist. Export weapon slots first.");
      if(!ignoreSize && gem.size>capacities[i]) return fail("Jewel level exceeds the slot level.");
      changes[gem.id]--;
    }
    if(before>=0) {
      if(size_t(before)>=gems.size() || !gems[before].id) {
        if(useBox) return fail("Existing jewel is unknown; cannot return it to the box.");
      } else changes[gems[before].id]++;
    }
  }
  // Work on a copy; a full box or missing stock leaves ALL data unchanged.
  std::array<mhw_item_slot,COUNTOF(mhw_storage::decorations)> box;
  std::memcpy(box.data(),slot.storage.decorations,sizeof(slot.storage.decorations));
  if(useBox) {
    // Consume first so a removed stack can free space for a returned jewel.
    for(const auto& change:changes) if(change.second<0) {
      unsigned need=unsigned(-change.second);
      unsigned available=0;
      for(auto& item:box) if(item.id==change.first) available+=item.amount;
      if(available<need) return fail("Not enough jewels in the decoration box.");
      for(auto& item:box) if(item.id==change.first && need) {
        unsigned take=item.amount<need?item.amount:need;
        item.amount-=take;need-=take;if(!item.amount)item.id=0;
      }
    }
    for(const auto& change:changes) if(change.second>0) {
      unsigned left=unsigned(change.second);
      for(auto& item:box) if(item.id==change.first && item.amount<9999) {
        unsigned n=9999-item.amount;if(n>left)n=left;item.amount+=n;left-=n;if(!left)break;
      }
      for(auto& item:box) if(!item.id && left) {item={change.first,left};left=0;}
      if(left) return fail("Decoration box is full; no changes were made.");
    }
  }
  if(useBox) std::memcpy(slot.storage.decorations,box.data(),sizeof(slot.storage.decorations));
  for(size_t i=0;i<3;++i) equipment.decos[i]=desired[i];
  error.clear();return true;
}
}
