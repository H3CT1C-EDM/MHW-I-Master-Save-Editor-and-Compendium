#pragma once
#include <cstring>
#include <stdexcept>
#include <type_traits>
extern "C" {
#include "../../vendor/aes.h"
#include "mbedtls/blowfish.h"
}
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#else
#include <openssl/sha.h>
#endif
namespace CryptoPP {
struct Blowfish{};struct AES{};
template<class Cipher,bool Encrypt> class ECBImpl {
  AES_ctx aes{};mbedtls_blowfish_context bf{};
public:
  void SetKey(const unsigned char*key,size_t length) {
    if constexpr(std::is_same<Cipher,AES>::value){if(length!=16)throw std::runtime_error("Invalid AES key.");AES_init_ctx(&aes,key);}
    else {mbedtls_blowfish_init(&bf);if(mbedtls_blowfish_setkey(&bf,key,unsigned(length*8)))throw std::runtime_error("Invalid Blowfish key.");}
  }
  void ProcessData(unsigned char*out,const unsigned char*in,size_t length) {
    constexpr size_t block=std::is_same<Cipher,AES>::value?16:8;
    if(length%block)throw std::runtime_error("Invalid cipher length.");
    for(size_t p=0;p<length;p+=block) {
      if constexpr(std::is_same<Cipher,AES>::value){std::memmove(out+p,in+p,16);if constexpr(Encrypt)AES_ECB_encrypt(&aes,out+p);else AES_ECB_decrypt(&aes,out+p);}
      else if(mbedtls_blowfish_crypt_ecb(&bf,Encrypt?1:0,in+p,out+p))throw std::runtime_error("Blowfish failure.");
    }
  }
};
template<class C>struct ECB_Mode {using Encryption=ECBImpl<C,true>;using Decryption=ECBImpl<C,false>;};
class SHA1 {public:void CalculateDigest(unsigned char*out,const unsigned char*in,size_t n){
#ifdef _WIN32
 BCRYPT_ALG_HANDLE alg=nullptr;NTSTATUS result=BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA1_ALGORITHM,nullptr,0);
 if(result<0)throw std::runtime_error("SHA1 initialization failed.");
 result=BCryptHash(alg,nullptr,0,const_cast<PUCHAR>(in),ULONG(n),out,20);BCryptCloseAlgorithmProvider(alg,0);
 if(result<0)throw std::runtime_error("SHA1 failed.");
#else
 ::SHA1(in,n,out);
#endif
}};
}
