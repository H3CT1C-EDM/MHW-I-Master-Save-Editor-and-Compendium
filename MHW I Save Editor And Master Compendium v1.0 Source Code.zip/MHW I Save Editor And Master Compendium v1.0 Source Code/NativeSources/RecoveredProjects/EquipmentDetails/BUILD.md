# EquipmentDetails build

Recovered complete native source and its original `stage31/build_equipment_reader.py` from `MHWI_Stage31_Source_and_Validation.zip`.

Set Zig 0.14.1 on PATH or `MHW_ZIG_BIN`. From **this directory**, run:

```
python3 stage31/build_equipment_reader.py
```

The script also tries to build host-side tooling with C++17/OpenSSL. Windows target uses BCrypt. See included `stage31/BUILD_AND_VALIDATION.md`.
