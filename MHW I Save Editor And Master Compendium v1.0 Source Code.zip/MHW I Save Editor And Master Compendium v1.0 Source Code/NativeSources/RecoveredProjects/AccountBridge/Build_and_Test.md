# Build and test records

Build with Zig 0.14.1:

```sh
zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -shared -fms-extensions -Wall -Wextra -Werror AccountBridge/src/AccountBridge.cpp -lbcrypt -o mhwi_account_bridge.dll
```

The C++ tests use relative `../AccountBridge/src` includes when run from this archive. Compile each with a C++17 compiler and run it. Python native-code tests require Unicorn 2.1.4, pefile, and the original executable/captured loaded text already supplied by the user. Those large binaries are not duplicated here. PowerShell tests use PowerShell 7.4.6 and the full Stage 21 runtime extracted at their declared workspace path. Adjust the input/runtime path declarations for a different checkout location; preserve the expected hashes/mappings. Validation results and the exact native excerpts are under `review`.

The UI files here are the changed source files; the complete editor is in the separate runtime ZIP. Original engine and FieldHarvest sources remain in earlier retained archives. No full first-clear material/payout engine is supplied by this stage.
