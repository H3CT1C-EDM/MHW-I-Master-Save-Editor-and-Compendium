$ErrorActionPreference='Stop'
$runtime=Join-Path (Get-Location) 'build_stage21/MHWI_Questbook_Stage21'
foreach($file in Get-ChildItem -LiteralPath $runtime -Filter '*.ps1'){
 $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
}
Add-Type -TypeDefinition 'namespace Windows.Forms { public static class MessageBox { public static int Show(string message,string title) { return 0; } } }'
function Run-Action([scriptblock]$action){&$action}
function Current-Slot {return [pscustomobject]@{number=1}}
$script:GameTestRoot=Join-Path ([IO.Path]::GetTempPath()) ('MHWI_Canteen_漢字_'+[guid]::NewGuid().ToString('N'))
function Get-GameFolder {return $script:GameTestRoot}
function Get-QuestbookText([string]$text){return $text}
$bridgeKey=[pscustomobject]@{SelectedItem='F9'}
$folder=Join-Path $script:GameTestRoot 'AsteraLoader/plugins/mhwi_account_bridge'
[void][IO.Directory]::CreateDirectory($folder)
[IO.File]::WriteAllBytes((Join-Path $folder 'mhwi_account_bridge.dll'),[byte[]]@(1))
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $runtime 'QuestbookTools.ps1'),[ref]$tokens,[ref]$errors)
$click=$ast.Find({param($node) $node -is [Management.Automation.Language.InvokeMemberExpressionAst] -and $node.Expression.Extent.Text -eq '$canteenUnlock' -and $node.Member.Extent.Text -eq 'Add_Click'},$true)
if(-not $click){throw 'Repair handler missing'}
$action=$click.Arguments[0].ScriptBlock.GetScriptBlock()
&$action
$path=Join-Path $folder 'request.txt'
if([IO.File]::ReadAllText($path) -cne "MHWI_CANTEEN_UNLOCK_V1 1`r`n"){throw 'Incorrect repair request'}
$blocked=$false
try {&$action} catch {$blocked=$true}
if(-not $blocked -or [IO.File]::ReadAllText($path) -cne "MHWI_CANTEEN_UNLOCK_V1 1`r`n"){throw 'Pending request overwritten'}
$locales=@(Get-ChildItem (Join-Path $runtime 'locales') -Filter '*.json'|ForEach-Object{Get-Content -Raw $_.FullName|ConvertFrom-Json -AsHashtable})
$expected=@($locales[0].Keys|Sort-Object)
foreach($locale in $locales){if(Compare-Object $expected @($locale.Keys|Sort-Object)){throw 'Locale keys differ'}}
. (Join-Path $runtime 'QuestbookLayout.ps1')
foreach($width in @(924,1116,1120,1366,1920,2560,3840)){
 $left=Get-QuestbookLayoutRect ([pscustomobject]@{X=15;Y=520;Width=515;Height=44}) ($width-24) 620
 $right=Get-QuestbookLayoutRect ([pscustomobject]@{X=545;Y=520;Width=515;Height=44}) ($width-24) 620
 $bounds=Get-QuestbookContentBounds $width
 if($left.X+12 -ne $bounds.Left -or [Math]::Abs($right.X+$right.Width+12-$bounds.Right) -gt 1){throw "Repair button margins mismatch at $width"}
 if(($left.X+$left.Width) -gt $right.X -or $left.Y -ne $right.Y -or $left.Height -ne $right.Height){throw "Repair button bounds overlap at $width"}
}
Write-Output 'PASS: all runtime scripts parse; actual repair click queues exact slot request, preserves pending requests, Unicode path; five locales; paired button bounds at seven widths'
