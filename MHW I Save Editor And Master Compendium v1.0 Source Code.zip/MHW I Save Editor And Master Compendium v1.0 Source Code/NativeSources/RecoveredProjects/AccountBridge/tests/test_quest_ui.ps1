$ErrorActionPreference='Stop'
$runtime=Join-Path (Get-Location) 'build_stage21/MHWI_Questbook_Stage21'
foreach($file in Get-ChildItem $runtime -Filter '*.ps1'){
 $tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
 if($errors.Count){throw ($errors|Out-String)}
}
Add-Type -TypeDefinition 'namespace Windows.Forms { public static class MessageBox { public static string Response="Yes"; public static string Preview=""; public static string Show(string message,string title,string buttons,string icon) { Preview=message;return Response; } public static string Show(string message,string title) { return "OK"; } } }'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $runtime 'QuestPanel.ps1'),[ref]$tokens,[ref]$errors)
foreach($name in @('Test-ModQuest','Test-QuestEditEligible','Get-QuestBenefit','Queue-QuestUnlock')){
 $node=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
 if(-not $node){throw "Missing function $name"};. ([scriptblock]::Create($node.Extent.Text))
}
$script:QuestBenefitsById=@{};foreach($b in (Get-Content -Raw (Join-Path $runtime 'catalog/QuestBenefits.json')|ConvertFrom-Json).Benefits){$script:QuestBenefitsById[[int64]$b.QuestId]=$b}
$script:FakeState=[pscustomobject]@{active=$true;ById=@{}}
foreach($id in @(364,452,683,684,694)){$script:FakeState.ById[[int64]$id]=[pscustomobject]@{flag=$true}}
function Get-QuestState {return $script:FakeState}
function Current-Slot {return [pscustomobject]@{number=1}}
function Get-QuestbookText([string]$v){return $v}
$script:TestGame=Join-Path ([IO.Path]::GetTempPath()) ('MHWI_Quest_漢字_'+[guid]::NewGuid().ToString('N'))
function Get-GameFolder {return $script:TestGame}
$folder=Join-Path $script:TestGame 'AsteraLoader/plugins/mhwi_account_bridge';[void][IO.Directory]::CreateDirectory($folder)
[IO.File]::WriteAllBytes((Join-Path $folder 'mhwi_account_bridge.dll'),[byte[]]@(1));$path=Join-Path $folder 'request.txt'
$q=[pscustomobject]@{Id=364;Key='game:364';Name="Gettin' Yolked in the Waste";Placeholder=$false;IdentityAmbiguous=$false;DuplicateDefinitionId=$false}
Queue-QuestUnlock $q
if([IO.File]::ReadAllText($path) -cne "MHWI_QUEST_UNLOCK_V1 1 364`r`n"){throw 'Wrong request'}
if([Windows.Forms.MessageBox]::Preview -notmatch 'Herbivore Egg' -or [Windows.Forms.MessageBox]::Preview -notmatch 'No materials'){throw 'Incomplete preview'}
$blocked=$false;try{Queue-QuestUnlock $q}catch{$blocked=$true}
if(-not $blocked -or [IO.File]::ReadAllText($path) -cne "MHWI_QUEST_UNLOCK_V1 1 364`r`n"){throw 'Pending request overwritten'}
[IO.File]::Delete($path)
$script:FakeState.ById[[int64]364].flag=$false
$blocked=$false;try{Queue-QuestUnlock $q}catch{$blocked=$true};if(-not $blocked -or (Test-Path $path)){throw 'Uncleared quest accepted'}
$script:FakeState.ById[[int64]364].flag=$true
foreach($property in @('Placeholder','IdentityAmbiguous','DuplicateDefinitionId')){
 $q.$property=$true;$blocked=$false;try{Queue-QuestUnlock $q}catch{$blocked=$true};if(-not $blocked -or (Test-Path $path)){throw "Invalid quest accepted: $property"};$q.$property=$false
}
$q.Key='definition:mod:test:364';$blocked=$false;try{Queue-QuestUnlock $q}catch{$blocked=$true};if(-not $blocked -or (Test-Path $path)){throw 'Mod quest accepted'};$q.Key='game:364'
[Windows.Forms.MessageBox]::Response='No';Queue-QuestUnlock $q;if(Test-Path $path){throw 'Canceled preview wrote request'}
$script:FakeState.active=$false;[Windows.Forms.MessageBox]::Response='Yes';$blocked=$false;try{Queue-QuestUnlock $q}catch{$blocked=$true};if(-not $blocked){throw 'Inactive character accepted'}
$locales=@(Get-ChildItem (Join-Path $runtime 'locales') -Filter '*.json'|ForEach-Object{Get-Content -Raw $_.FullName|ConvertFrom-Json -AsHashtable});$expected=@($locales[0].Keys|Sort-Object)
foreach($locale in $locales){if(Compare-Object $expected @($locale.Keys|Sort-Object)){throw 'Locale key mismatch'}}
$tokens=$null;$errors=$null;$layout=[Management.Automation.Language.Parser]::ParseFile((Join-Path $runtime 'QuestbookLayout.ps1'),[ref]$tokens,[ref]$errors)
foreach($name in @('Get-QuestbookContentBounds','Get-QuestbookLayoutRect')){$n=$layout.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true);. ([scriptblock]::Create($n.Extent.Text))}
foreach($width in @(924,1116,1120,1366,1920,2560,3840)){
 $bounds=Get-QuestbookContentBounds $width;$r=Get-QuestbookLayoutRect ([pscustomobject]@{X=810;Y=574;Width=250;Height=32}) ($width-24) 620
 if($r.X+12 -lt $bounds.Left -or [Math]::Abs($r.X+$r.Width+12-$bounds.Right) -gt 1){throw 'Quest unlock button overflows'}
}
'PASS: all runtime scripts parse; real preview/request path, cancel, uncleared, inactive, mod, ambiguous/placeholder guards, existing-request preservation, Unicode path, five locales and seven-width bounds'
