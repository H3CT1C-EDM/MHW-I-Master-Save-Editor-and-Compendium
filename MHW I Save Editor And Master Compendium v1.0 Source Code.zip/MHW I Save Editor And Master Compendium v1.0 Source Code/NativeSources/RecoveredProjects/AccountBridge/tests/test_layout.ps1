$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath('build_stage21/MHWI_Questbook_Stage21/QuestbookLayout.ps1'),[ref]$tokens,[ref]$errors)
foreach($name in @('Get-QuestbookContentBounds','Get-QuestbookLayoutRect','Get-QuestbookDialogRect')){$node=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true);. ([scriptblock]::Create($node.Extent.Text))}
$tokens=$null;$errors=$null;$ast=[Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath('build_stage21/MHWI_Questbook_Stage21/QuestbookNavigation.ps1'),[ref]$tokens,[ref]$errors)
$node=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Get-QuestbookNavigationRects'},$true);. ([scriptblock]::Create($node.Extent.Text))
foreach($width in @(924,1116,1120,1366,1920,2560,3840)){
 $c=Get-QuestbookContentBounds $width
 $r=Get-QuestbookLayoutRect ([pscustomobject]@{X=15;Y=15;Width=1045;Height=591}) ($width-24) 600
 if(12+$r.X -ne $c.Left -or 12+$r.X+$r.Width -ne $c.Right){throw "Shared margin mismatch at $width"}
 foreach($rect in @([pscustomobject]@{X=984;Y=140;Width=76;Height=32},[pscustomobject]@{X=810;Y=574;Width=250;Height=32},[pscustomobject]@{X=15;Y=520;Width=1045;Height=38})){
  $v=Get-QuestbookLayoutRect $rect ($width-24) 600
  if(12+$v.X -lt $c.Left -or 12+$v.X+$v.Width -gt $c.Right+1){throw "Control overflow at $width"}
 }
 $nav=@(Get-QuestbookNavigationRects $c.Width 5);$edge=0
 foreach($n in $nav){if($n.X -ne $edge -or $n.Width -lt 1){throw 'Navigation gap/overlap'};$edge=$n.X+$n.Width}
 if($edge -ne $c.Width){throw 'Navigation extends beyond content width'}
}
'PASS: shared toolbar/navigation/page margins and right-edge buttons at seven widths; five navigation segments tile exactly'

foreach($width in @(850,1000,1700)){
 $r=Get-QuestbookDialogRect ([pscustomobject]@{X=15;Y=15;Width=820;Height=500}) 850 530 $width 800
 if($r.X -ne 15 -or $r.X+$r.Width -ne $width-15 -or $r.Y+$r.Height -ne 785){throw 'Dialog bounds mismatch'}
}
'PASS: dialog edges preserved while resizing'
