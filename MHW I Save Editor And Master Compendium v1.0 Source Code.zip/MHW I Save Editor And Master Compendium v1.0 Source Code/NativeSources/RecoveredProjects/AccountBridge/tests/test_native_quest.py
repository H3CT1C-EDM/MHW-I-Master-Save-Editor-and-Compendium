import sys,struct,json,re,random
from pathlib import Path
sys.path.insert(0,'analysis_stage21/deps');sys.path.insert(0,'analysis_stage8/deps')
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64
from unicorn.x86_const import *
import pefile
raw=Path('trace_inputs/loaded_20261028/text.bin').read_bytes();base=0x140000000;pe=pefile.PE('trace_inputs/MonsterHunterWorld.exe',fast_load=True)
ids=json.loads(Path('analysis_stage21/QuestIndex.json').read_text());native=list(struct.unpack('<352I',pe.get_data(0x324fac0,352*4)));assert ids==native
benefits=json.loads(Path('analysis_stage21/BenefitMappings.json').read_text())
food=Path('stage20_source/reference/food.rfd').read_bytes();rows=list(struct.iter_unpack('<5I',food[10:]));assert len(rows)==114
for b in benefits:assert rows[b['FoodRow']]==tuple(b[k] for k in ['Page','Column','ConditionType','ConditionId','Color']) and ids[b['ClearIndex']]==b['QuestId']
u=Uc(UC_ARCH_X86,UC_MODE_64);start=0x134efb5;end=0x134efcd
u.mem_map((base+start)&~4095,4096);u.mem_write(base+start,raw[start-4096:end-4096])
save=0x300000;u.mem_map(save,0x26d000)
randomizer=random.Random(21)
for _ in range(500):
 words=[randomizer.getrandbits(32) for _ in range(16)];u.mem_write(save+0x104c20,struct.pack('<16I',*words))
 for b in benefits:
  index=b['ClearIndex'];u.reg_write(UC_X86_REG_RDI,save);u.reg_write(UC_X86_REG_RDX,index);u.emu_start(base+start,base+end,count=100)
  assert bool(u.reg_read(UC_X86_REG_RAX)&255)==bool(words[index//32]&(1<<(index%32)))
# Check strict profile bytes without invoking the patched public query entry.
src=Path('build_stage21/AccountBridge/src/profile.hpp').read_text()
for name,rva,code in re.findall(r'Point (\w+)\{(0x[0-9a-f]+),"([^"]+)"',src):
 if name=='Receipt':continue
 at=int(rva,16)-4096;code=bytes.fromhex(code);assert raw[at:at+len(code)]==code,name
assert raw[0x134ef50-4096]==0xe9
print('PASS: complete 352-ID native quest index and five food mappings match the compiled tables')
print('PASS: actual native clear-bank reader agrees on 2,500 cases; the patched public query entry is never invoked')
print('PASS: all native profiles match captured code; original account receipt hook checks remain separate')
