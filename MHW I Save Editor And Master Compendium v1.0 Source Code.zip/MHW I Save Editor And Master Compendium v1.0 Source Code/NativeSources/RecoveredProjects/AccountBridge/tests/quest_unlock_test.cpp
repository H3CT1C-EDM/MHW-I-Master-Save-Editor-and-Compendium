#include "../AccountBridge/src/quest_unlock.hpp"
#include "../AccountBridge/src/canteen_unlock.hpp"
#include <random>
#include <iostream>
#include <stdexcept>
void check(bool value){if(!value)throw std::runtime_error("quest unlock regression");}
int main(){try{
 using namespace quest_unlock;check(sizeof(Benefits)/sizeof(Benefits[0])==5&&sizeof(QuestIds)/sizeof(QuestIds[0])==352);
 std::mt19937 random(21);auto accountMask=canteen_unlock::mask();
 for(auto b:Benefits){
  check(b.row<114&&b.index<352&&QuestIds[b.index]==b.id&&b.condition==2&&b.flag==b.id);
  check((accountMask[b.row/32]&(1u<<(b.row%32)))==0);
  check(table(b,b.page,b.column,b.condition,b.flag,b.color));check(!table(b,b.page,b.column,b.condition,b.flag+1,b.color));
  check(cleared(1u<<(b.index%32),b)&&!cleared(~(1u<<(b.index%32)),b));
  Request parsed;check(parse("MHWI_QUEST_UNLOCK_V1 1 "+std::to_string(b.id)+"\r\n",parsed)&&parsed.slot==1&&parsed.id==b.id);
  for(unsigned n=0;n<100000;n++){
   Words before{};for(auto& w:before)w=random();auto after=desired(before,b);check(unlocked(after,b)&&desired(after,b)==after);
   for(unsigned i=0;i<4;i++){auto mask=i==b.row/32?(1u<<(b.row%32)):0u;check(after[i]==(before[i]|mask));}
  }
 }
 Request request;
 for(auto invalid:{"MHWI_QUEST_UNLOCK_V1 0 364","MHWI_QUEST_UNLOCK_V1 4 364","MHWI_QUEST_UNLOCK_V1 1 605","MHWI_QUEST_UNLOCK_V1 1 90001","MHWI_QUEST_UNLOCK_V1 1 364 extra","MHWI_QUEST_UNLOCK_V1 1 -1","MHWI_QUEST_UNLOCK_V1 1 4294967296","MHWI_CANTEEN_V1 1","MHWI_ACCOUNT_V1 1 611 1"})check(!parse(invalid,request));
 check(!parse(std::string(129,' '),request));
 std::cout<<"PASS: five optional-quest mappings; strict request parser; actual clear-bit guards; 500,000 one-row mask cases preserve unrelated and existing account-canteen bits\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
