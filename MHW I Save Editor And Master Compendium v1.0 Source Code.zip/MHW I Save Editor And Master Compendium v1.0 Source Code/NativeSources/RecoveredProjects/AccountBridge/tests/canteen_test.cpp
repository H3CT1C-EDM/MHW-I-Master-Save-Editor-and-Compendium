#include "../AccountBridge/src/canteen.hpp"
#include <stdexcept>
#include <iostream>
void check(bool b){if(!b)throw std::runtime_error("canteen regression");}
int main(){try{
 uint32_t slot=0;check(canteen::parse("MHWI_CANTEEN_V1 1\r\n",slot)&&slot==1);
 for(auto s:{"MHWI_CANTEEN_V1 0","MHWI_CANTEEN_V1 4","MHWI_CANTEEN_V1 1 611","MHWI_ACCOUNT_V1 1 611 1","MHWI_CANTEEN_V1 -1"})check(!canteen::parse(s,slot));
 std::set<uint32_t> ids;for(auto i:canteen::Ids){check(bridge::allowed(i));check(ids.insert(i).second);}check(ids.size()==36);
 canteen::State state;check(!state.begin(0));check(state.begin(3));check(!state.begin(2));
 for(unsigned i=0;i<canteen::Count;i++){
  check(state.id()==canteen::Ids[i]&&state.slot==3);
  state.pause();check(!state.advance()&&state.id()==canteen::Ids[i]);state.resume();check(state.advance()==(i==35));
 }
 check(!state.active&&state.id()==0&&!state.advance());
 for(uint32_t mode=0;mode<16;mode++)for(uint32_t phase=0;phase<5;phase++)check(canteen::field(mode,phase)==(mode>=2&&mode<=12&&phase>=2));
 check(canteen::field(3,2)&&!canteen::field(1,2)&&!canteen::field(2,1)&&!canteen::field(0xffffffffu,2));
 for(uint32_t mode=0;mode<32;mode++)for(uint32_t phase=0;phase<8;phase++)for(uint32_t flag=0;flag<256;flag++)check(canteen::field(mode,phase,uint8_t(flag))==((mode>=2&&mode<=12&&phase>=2)||(mode==13&&flag!=0)));
 check(canteen::field(13,0,1)&&!canteen::field(13,0,0));
 check(!canteen::field(0,0,1)&&!canteen::field(1,2,1)&&!canteen::field(14,0,1)&&!canteen::field(0xffffffffu,2,255));
 check(canteen::capacity(36,36)&&!canteen::capacity(35,36)&&canteen::capacity(0,0));
 std::cout<<"PASS: strict canteen request, 36 unique allowed IDs, serial/pause/resume/completion without replay, native field predicate boundaries, queue capacity\n";
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}}
