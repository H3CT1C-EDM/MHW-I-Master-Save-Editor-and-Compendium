#include "../AccountBridge/src/canteen.hpp"
#include "../AccountBridge/src/canteen_unlock.hpp"
#include <random>
#include <iostream>
#include <stdexcept>
void check(bool b){if(!b)throw std::runtime_error("canteen unlock regression");}
int main(){try{
 using namespace canteen_unlock;
 check(Count==36&&Count==canteen::Count);
 Words used{};unsigned n=0;
 for(auto m:Mappings){check(m.item==canteen::Ids[n++]);check(m.row<114&&m.condition==3);auto bit=1u<<(m.row%32);check(!(used[m.row/32]&bit));used[m.row/32]|=bit;check(table(m,m.page,m.column,m.condition,m.flag,m.color));check(!table(m,m.page,m.column,2,m.flag,m.color));check(!table(m,m.page,m.column,m.condition,m.flag+1,m.color));}
 check(used==mask()&&count(used)==36);
 std::mt19937 random(0x20ca);
 for(unsigned iteration=0;iteration<100000;iteration++){
  Words before{};for(auto& w:before)w=random();auto after=desired(before);check(count(after)==36&&desired(after)==after);
  for(unsigned i=0;i<4;i++){check((after[i]&~used[i])==(before[i]&~used[i]));check((after[i]&before[i])==before[i]);}
 }
 uint32_t slot=0;check(parse("MHWI_CANTEEN_UNLOCK_V1 1\r\n",slot)&&slot==1);check(parse("MHWI_CANTEEN_UNLOCK_V1 3",slot)&&slot==3);
 for(auto text:{"MHWI_CANTEEN_UNLOCK_V1 0","MHWI_CANTEEN_UNLOCK_V1 4","MHWI_CANTEEN_UNLOCK_V1 -1","MHWI_CANTEEN_UNLOCK_V1 1 extra","MHWI_CANTEEN_V1 1","MHWI_ACCOUNT_V1 1 611 1"})check(!parse(text,slot));
 check(!parse(std::string(129,' '),slot));
 std::cout<<"PASS: 36 row mappings and table guards; 100,000 masks preserve all unrelated bits and are idempotent; repair request validation\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
