#pragma once
#include "account_ids.hpp"
#include <sstream>
#include <string>
#include <cstdint>
namespace bridge {
struct Request { uint32_t slot=0,id=0,amount=0; };
inline bool parse(const std::string& text,Request& out) {
  // One explicitly selected character and item per request. Strict ASCII format.
  if(text.size()>128)return false;
  std::istringstream s(text);std::string magic,extra;uint64_t slot,id,amount;
  if(!(s>>magic>>slot>>id>>amount)||magic!="MHWI_ACCOUNT_V1"||(s>>extra))return false;
  if(slot<1||slot>3||id>UINT32_MAX||!allowed(uint32_t(id))||amount<1||amount>99)return false;
  out={uint32_t(slot),uint32_t(id),uint32_t(amount)};return true;
}
struct QueueState { bool readable=true; unsigned count=0,free=0; };
inline bool fits(const QueueState& q,unsigned amount){return q.readable && q.count<=99 && amount<=99-q.count && (q.count||q.free);}
}
