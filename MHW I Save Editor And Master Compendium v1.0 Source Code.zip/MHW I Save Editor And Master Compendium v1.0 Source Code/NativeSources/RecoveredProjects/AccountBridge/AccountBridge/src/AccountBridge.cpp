#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "al/al_plugin.h"
#include "profile.hpp"
#include "request.hpp"
#include "canteen.hpp"
#include "canteen_unlock.hpp"
#include "quest_unlock.hpp"
#include <cstdio>
#include <string>
#include <atomic>
#include <cmath>
#include <cstring>
#include <vector>
#include <cwchar>
#include <bcrypt.h>
#include "receipt_guard.hpp"
#include "field_receipt_bytes.hpp"
#include "selected_receipt_bytes.hpp"
#include "field_profiles.hpp"

namespace {
const al_api_t* api=nullptr;al_plugin_t* self=nullptr;
uintptr_t base=0;std::wstring folder;std::atomic<bool> ready{false},failed{false};bool keyDown=false;int hotkey=VK_F10;
using Receipt=void*(*)(void*,uint32_t,int32_t);
template<class T> bool load(uintptr_t p,T& v){SIZE_T n=0;return p>65535&&ReadProcessMemory(GetCurrentProcess(),(void*)p,&v,sizeof(v),&n)&&n==sizeof(v);}
template<class T> T get(uintptr_t p,T fallback={}){T v{};return load(p,v)?v:fallback;}
template<class F> F native(profile::Point p){return reinterpret_cast<F>(base+p.rva);}

bool memory_read(uint64_t address,void* output,size_t count){
 if(address<65536||!count||count>1024||address>0x00007fffffffffffULL-count)return false;
 SIZE_T got=0;return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),output,count,&got)&&got==count;
}
bool private_code(uint64_t address,size_t count){
 MEMORY_BASIC_INFORMATION info{};
 if(!count||address<65536||address>0x00007fffffffffffULL-count||VirtualQuery(reinterpret_cast<void*>(address),&info,sizeof(info))!=sizeof(info))return false;
 return info.State==MEM_COMMIT&&info.Type==MEM_PRIVATE&&!(info.Protect&(PAGE_GUARD|PAGE_NOACCESS))&&(info.Protect&(PAGE_EXECUTE|PAGE_EXECUTE_READ|PAGE_EXECUTE_READWRITE|PAGE_EXECUTE_WRITECOPY))&&address+count<=uintptr_t(info.BaseAddress)+info.RegionSize;
}
bool field_hash(const wchar_t* path,const uint8_t* expected){
 BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;HANDLE file=INVALID_HANDLE_VALUE;
 DWORD size=0,got=0;bool ok=false;std::vector<uint8_t> object,buffer(65536);uint8_t digest[32]{};
 if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)return false;
 do{
  if(BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),sizeof(size),&got,0)<0)break;
  object.resize(size);
  if(BCryptCreateHash(alg,&hash,object.data(),size,nullptr,0,0)<0)break;
  file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(file==INVALID_HANDLE_VALUE)break;
  bool readOK=true;
  for(;;){if(!ReadFile(file,buffer.data(),DWORD(buffer.size()),&got,nullptr)){readOK=false;break;}if(!got)break;if(BCryptHashData(hash,buffer.data(),got,0)<0){readOK=false;break;}}
  if(!readOK||BCryptFinishHash(hash,digest,32,0)<0)break;
  ok=std::memcmp(digest,expected,32)==0;
 }while(false);
 if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);if(hash)BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(alg,0);return ok;
}
receipt_guard::Owner field_owner(uint64_t callback){
 HMODULE module=nullptr;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(callback),&module))return {};
 uint64_t start=reinterpret_cast<uint64_t>(module);
 wchar_t path[32768];DWORD length=GetModuleFileNameW(module,path,32768);if(!length||length>=32768)return {};
 const wchar_t* leaf=std::wcsrchr(path,L'\\');leaf=leaf?leaf+1:path;
 for(const auto& profile:FieldProfiles){
  if(_wcsicmp(leaf,profile.name)||callback!=start+profile.entry||!field_hash(path,profile.hash))continue;
  uint8_t bytes[1024];if(profile.count>sizeof(bytes)||!memory_read(callback,bytes,profile.count)||std::memcmp(bytes,profile.bytes,profile.count))return {};
  return {start,profile.entry,profile.slot};
 }
 return {};
}
const char* receipt_path="unknown";
bool native_checks(){
 auto receipt=receipt_guard::validate(base,memory_read,private_code,field_owner);
 if(!receipt.accepted)return false;
 for(auto point:profile::Checks){
  if(point.rva==profile::Receipt.rva)continue;
  std::string bytes=point.bytes;
  for(size_t at=0,off=0;at<bytes.size();at+=3,off++){
   unsigned expected=0;uint8_t actual=0;
   if(std::sscanf(bytes.c_str()+at,"%2x",&expected)!=1||!load(base+point.rva+off,actual)||actual!=expected)return false;
  }
 }
 receipt_path=receipt.hooked?"fieldharvest_verified":"original";return true;
}
bool live(uintptr_t p){uint32_t f=0;return load(p+0xc,f)&&(f&0xe);}
struct SoloState {bool readable=false,local=false,matched=false;unsigned players=0;};
SoloState solo_state(){
 SoloState result;uintptr_t m=0;if(!load(base+0x500eca0,m)||!m)return result;
 auto player=native<uintptr_t(*)(uintptr_t)>(profile::FindPlayer)(m);result.local=live(player);if(!result.local)return result;
 for(unsigned i=0;i<24;i++){
  auto slot=m+0x40+i*0x740;int a=-1,b=-1;uintptr_t actor=0;
  if(!load(slot+0x10,a)||!load(slot+0x14,b))return result;
  if(a<0&&b<0)continue;
  if(!load(slot+0x18,actor))return result;
  if(!actor)continue;uint32_t flags=0;if(!load(actor+0xc,flags))return result;if(!(flags&0xe))continue;
  result.matched|=actor==player;result.players++;
 }
 result.readable=true;return result;
}
canteen::State canteenBatch;
void status(const char* text){
 api->log(self,AL_LOG_INFO,text);api->set_status(self,failed?AL_STATUS_DISABLED:AL_STATUS_ACTIVE,text);
 auto path=folder+L"\\status.txt";HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(h!=INVALID_HANDLE_VALUE){DWORD n=0;WriteFile(h,text,DWORD(std::strlen(text)),&n,nullptr);FlushFileBuffers(h);CloseHandle(h);}
}
void refuse(const char* text){canteenBatch.pause();status(text);}
bridge::QueueState queue(uintptr_t q,uint32_t id){bridge::QueueState r;
 for(unsigned i=0;i<64;i++){uint32_t n=0,c=0;auto p=q+0xf0+i*16;
  if(!load(p+8,n)||!load(p+12,c)){r.readable=false;return r;}
  if(!n)r.free++;if(n==id)r.count+=c;
 }return r;
}
bool durable(const std::wstring& path,const std::string& text){
 HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)return false;
 DWORD n=0;bool ok=WriteFile(h,text.data(),DWORD(text.size()),&n,nullptr)&&n==text.size()&&FlushFileBuffers(h);CloseHandle(h);return ok;
}
bool canteen_preflight(uintptr_t save,bool requireDiscovery=true){
 auto food=get<uintptr_t>(base+0x5012610);uint32_t count=0;
 if(!food||!load(food+0xb8,count)||count!=114){refuse("Canteen table unavailable or unsupported. No ingredient changes made.");return false;}
 for(auto m:canteen_unlock::Mappings){
  auto row=native<uintptr_t(*)(uintptr_t,uint32_t)>(profile::LookupRecord)(food,m.row);
  uint32_t page=0,column=0,condition=0,flag=0,color=0;
  if(!row||!load(row+8,page)||!load(row+12,column)||!load(row+16,condition)||!load(row+20,flag)||!load(row+24,color)||!canteen_unlock::table(m,page,column,condition,flag,color)){
   refuse("Canteen ingredient table differs. Repair refused before changes.");return false;
  }
  uint32_t discovery=0;
  if(requireDiscovery&&(!load(save+canteen_unlock::DiscoveryOffset+(m.item/32)*4,discovery)||!(discovery&(uint32_t(1)<<(m.item%32))))){
   refuse("Not all 36 canteen account items have discovery records on this character. Finish acquisition before using Unlock Acquired Ingredients.");return false;
  }
 }
 canteen_unlock::Words before{};
 if(!memory_read(save+canteen_unlock::FoodOffset,before.data(),sizeof(before))){refuse("Canteen ingredient flags unreadable. No changes made.");return false;}
 MEMORY_BASIC_INFORMATION region{};auto address=save+canteen_unlock::FoodOffset;
 if(VirtualQuery(reinterpret_cast<void*>(address),&region,sizeof(region))!=sizeof(region)||region.State!=MEM_COMMIT||(region.Protect&(PAGE_GUARD|PAGE_NOACCESS))||!(region.Protect&(PAGE_READWRITE|PAGE_WRITECOPY))||address+sizeof(before)>uintptr_t(region.BaseAddress)+region.RegionSize){refuse("Canteen ingredient flags are not writable. No changes made.");return false;}
 return true;
}
// The game writes this exact bitset under the save's critical section.
// Keep the same lock and OR only the 36 mapped ingredient bits; no story flags are changed.
bool canteen_commit(uintptr_t save,uint32_t slot,const std::wstring& journal){
 if(!canteen_preflight(save))return false;
 canteen_unlock::Words before{},after{};bool readOK=false,verified=false;
 auto lock=reinterpret_cast<LPCRITICAL_SECTION>(save+8);
 EnterCriticalSection(lock);
 __try {
  readOK=memory_read(save+canteen_unlock::FoodOffset,before.data(),sizeof(before));
  if(readOK){
   auto desired=canteen_unlock::desired(before);
   auto dest=reinterpret_cast<volatile uint32_t*>(save+canteen_unlock::FoodOffset);
   for(unsigned i=0;i<4;i++)dest[i]=desired[i];
   verified=memory_read(save+canteen_unlock::FoodOffset,after.data(),sizeof(after))&&after==desired;
  }
 } __finally {LeaveCriticalSection(lock);}
 if(!readOK||!verified){failed=true;status("Canteen flag verification failed. Preserve journals and do not replay blindly.");return false;}
 char report[700];std::snprintf(report,sizeof(report),"canteen_unlock_verified=1\nslot=%u\nexpected_ingredients=36\nunlocked_before=%u\nunlocked_after=%u\nnewly_unlocked=%u\nfood_before_0=%u\nfood_before_1=%u\nfood_before_2=%u\nfood_before_3=%u\nfood_after_0=%u\nfood_after_1=%u\nfood_after_2=%u\nfood_after_3=%u\naccount_items_added_by_unlock=0\nstory_flags_changed=0\nreturn_and_save_required=1\n",slot,canteen_unlock::count(before),canteen_unlock::count(after),canteen_unlock::count(after)-canteen_unlock::count(before),before[0],before[1],before[2],before[3],after[0],after[1],after[2],after[3]);
 if(!durable(journal+L".unlock-result.txt",report)){failed=true;status("Ingredient flags were updated but the result journal failed. Do not replay blindly.");return false;}
 return true;
}
bool quest_benefit_preflight(uintptr_t save,const quest_unlock::Benefit& benefit){
 // Read the actual saved bank. Public quest-query functions may be forced true by mods.
 for(unsigned i=0;i<sizeof(quest_unlock::QuestIds)/sizeof(quest_unlock::QuestIds[0]);i++){
  if(get<uint32_t>(base+quest_unlock::IndexRva+i*4,~0u)!=quest_unlock::QuestIds[i]){refuse("Quest index table differs. Ingredient request refused before changes.");return false;}
 }
 uint32_t clear=0;
 if(!load(save+quest_unlock::ClearOffset+(benefit.index/32)*4,clear)||!quest_unlock::cleared(clear,benefit)){
  refuse("The active character does not have this quest's saved clear flag. Load the cleared save first; forced quest-query results are not accepted.");return false;
 }
 auto food=get<uintptr_t>(base+0x5012610);uint32_t count=0;
 if(!food||!load(food+0xb8,count)||count!=114){refuse("Canteen table unavailable or unsupported. No quest ingredient changes made.");return false;}
 auto row=native<uintptr_t(*)(uintptr_t,uint32_t)>(profile::LookupRecord)(food,benefit.row);
 uint32_t page=0,column=0,condition=0,flag=0,color=0;
 if(!row||!load(row+8,page)||!load(row+12,column)||!load(row+16,condition)||!load(row+20,flag)||!load(row+24,color)||!quest_unlock::table(benefit,page,column,condition,flag,color)){
  refuse("Quest ingredient table differs. No quest ingredient changes made.");return false;
 }
 canteen_unlock::Words before{};auto address=save+canteen_unlock::FoodOffset;MEMORY_BASIC_INFORMATION region{};
 if(!memory_read(address,before.data(),sizeof(before))||VirtualQuery(reinterpret_cast<void*>(address),&region,sizeof(region))!=sizeof(region)||region.State!=MEM_COMMIT||(region.Protect&(PAGE_GUARD|PAGE_NOACCESS))||!(region.Protect&(PAGE_READWRITE|PAGE_WRITECOPY))||address+sizeof(before)>uintptr_t(region.BaseAddress)+region.RegionSize){refuse("Quest ingredient flags are unreadable or not writable. No changes made.");return false;}
 return true;
}
bool quest_benefit_commit(uintptr_t save,uint32_t slot,const quest_unlock::Benefit& benefit,const std::wstring& journal){
 if(!quest_benefit_preflight(save,benefit))return false;
 canteen_unlock::Words before{},after{};bool verified=false;
 uint32_t clearBefore=0,clearAfter=0;auto clearAddress=save+quest_unlock::ClearOffset+(benefit.index/32)*4;
 auto lock=reinterpret_cast<LPCRITICAL_SECTION>(save+8);EnterCriticalSection(lock);
 __try {
  if(memory_read(save+canteen_unlock::FoodOffset,before.data(),sizeof(before))&&load(clearAddress,clearBefore)&&quest_unlock::cleared(clearBefore,benefit)){
   auto desired=quest_unlock::desired(before,benefit);auto dest=reinterpret_cast<volatile uint32_t*>(save+canteen_unlock::FoodOffset);
   for(unsigned i=0;i<4;i++)dest[i]=desired[i];
   verified=memory_read(save+canteen_unlock::FoodOffset,after.data(),sizeof(after))&&after==desired&&load(clearAddress,clearAfter)&&clearAfter==clearBefore;
  }
 } __finally {LeaveCriticalSection(lock);}
 if(!verified){failed=true;status("Quest ingredient readback failed. Preserve journals; do not replay blindly.");return false;}
 char report[900];std::snprintf(report,sizeof(report),"quest_unlock_verified=1\nquest_id=%u\nslot=%u\nfood_row=%u\ningredient_unlocked_before=%u\ningredient_unlocked_after=1\nquest_clear_flag_before=1\nquest_clear_flag_after=1\nquest_clear_flag_changed=0\nquest_count_changed=0\nmaterials_added=0\nzenny_added=0\nstory_flags_changed=0\nfood_before_0=%u\nfood_before_1=%u\nfood_before_2=%u\nfood_before_3=%u\nfood_after_0=%u\nfood_after_1=%u\nfood_after_2=%u\nfood_after_3=%u\nreturn_and_save_required=1\n",benefit.id,slot,benefit.row,unsigned(quest_unlock::unlocked(before,benefit)),before[0],before[1],before[2],before[3],after[0],after[1],after[2],after[3]);
 if(!durable(journal+L".quest-unlock-result.txt",report)){failed=true;status("Quest ingredient changed but the result journal failed. Do not replay blindly.");return false;}
 return true;
}
// Journal is written BEFORE native mutation. A .running request is never replayed.
// A result means calls returned and postconditions passed, not that MHW saved to disk.
std::wstring running;
void process(){
 DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
 if(pid!=GetCurrentProcessId()){keyDown=false;return;}
 bool down=(GetAsyncKeyState(hotkey)&0x8000)!=0;bool edge=down&&!keyDown;keyDown=down;
 if(!ready||failed||(!edge&&!canteenBatch.active)||(canteenBatch.active&&canteenBatch.paused&&!edge))return;
 if(canteenBatch.active&&edge)canteenBatch.resume();
 auto pending=folder+L"\\request.txt";char text[129]{};DWORD n=0;bridge::Request request;bool startCanteen=false,repairCanteen=false,questBenefit=false;quest_unlock::Request questRequest;
 if(canteenBatch.active){
  request={canteenBatch.slot,canteenBatch.id(),1};
 }else{
  WIN32_FILE_ATTRIBUTE_DATA attr{};
  if(!GetFileAttributesExW(pending.c_str(),GetFileExInfoStandard,&attr)){status("No request.txt. Export an account request from the editor first.");return;}
  if(attr.nFileSizeHigh||attr.nFileSizeLow>128){status("Rejected oversized request.txt");return;}
  HANDLE h=CreateFileW(pending.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
  if(h==INVALID_HANDLE_VALUE)return;
  bool read=ReadFile(h,text,128,&n,nullptr)!=0;CloseHandle(h);uint32_t batchSlot=0;
  if(!read){status("Could not read request.txt");return;}
  if(quest_unlock::parse(std::string(text,n),questRequest)){questBenefit=true;request={questRequest.slot,0,0};}
  else if(canteen_unlock::parse(std::string(text,n),batchSlot)){repairCanteen=true;request={batchSlot,canteen::Ids[0],1};}
  else if(canteen::parse(std::string(text,n),batchSlot)){startCanteen=true;request={batchSlot,canteen::Ids[0],1};}
  else if(!bridge::parse(std::string(text,n),request)){status("Rejected malformed, unavailable or non-account request.");return;}
 }
 if(!native_checks()){refuse("Native function or receipt hook differs. Request refused before mutation.");return;}
 auto saveManager=get<uintptr_t>(base+0x5013950);auto quest=get<uintptr_t>(base+0x500ed30);
 auto itemManager=get<uintptr_t>(base+0x5012000);
 // Receipt's category lookup uses the item database singleton at 0x5012000.
 int activeSlot=-1;uint32_t mode=0,phase=0;uint8_t expedition=0;
 bool slotReadable=saveManager&&load(saveManager+0xa0,activeSlot);
 bool stateReadable=quest&&load(quest+0x38,mode)&&load(quest+0x54,phase)&&load(quest+0xae3b,expedition);
 auto players=solo_state();
 bool validField=stateReadable&&canteen::field(mode,phase,expedition);
 if(!slotReadable||activeSlot!=int(request.slot-1)||!validField||!players.readable||!players.local||!players.matched||players.players!=1){
  const char* reason=!slotReadable?"no_character":activeSlot!=int(request.slot-1)?"wrong_character":!stateReadable?"unreadable_quest_state":!validField?"not_in_field":!players.local?"no_live_player":!players.readable?"unreadable_player_slots":!players.matched?"local_player_not_matched":"not_solo";
  char detail[450];std::snprintf(detail,sizeof(detail),"Waiting: %s. Character=%d, requested=%u; field mode=%u, phase=%u, expedition_flag=%u; live players=%u, local=%u, matched=%u. Enter a solo quest/expedition and press the configured account key.",reason,activeSlot+1,request.slot,mode,phase,unsigned(expedition),players.players,unsigned(players.local),unsigned(players.matched));refuse(detail);return;
 }
 if(questBenefit){
  auto save=native<uintptr_t(*)(uintptr_t)>(profile::GetSave)(saveManager);auto benefit=quest_unlock::find(questRequest.id);
  if(!save||!benefit){refuse("Quest ingredient request has no active save or supported mapping.");return;}
  if(!quest_benefit_preflight(save,*benefit))return;
  auto token=std::to_wstring(GetTickCount64())+L"-"+std::to_wstring(GetCurrentProcessId());running=folder+L"\\"+token+L".quest-unlock.running";
  if(!MoveFileExW(pending.c_str(),running.c_str(),MOVEFILE_WRITE_THROUGH)){refuse("Could not claim quest ingredient request; no changes made.");running.clear();return;}
  if(!durable(running+L".started",std::string(text,n))){failed=true;status("Could not flush quest ingredient journal. No ingredient flags changed.");return;}
  if(!quest_benefit_commit(save,questRequest.slot,*benefit,running))return;
  if(!MoveFileExW(running.c_str(),(running+L".done").c_str(),MOVEFILE_WRITE_THROUGH)){failed=true;status("Quest ingredient verified but journal finalization failed. Preserve journals; do not replay blindly.");return;}
  running.clear();status("Quest ingredient unlock verified. Return normally, save, and check it after reloading. No quest flag/count, materials or zenny were changed.");return;
 }
 if(repairCanteen){
  auto save=native<uintptr_t(*)(uintptr_t)>(profile::GetSave)(saveManager);
  if(!save){refuse("Active save unavailable. No ingredient flags changed.");return;}
  if(!canteen_preflight(save))return;
  auto token=std::to_wstring(GetTickCount64())+L"-"+std::to_wstring(GetCurrentProcessId());
  running=folder+L"\\"+token+L".canteen-unlock.running";
  if(!MoveFileExW(pending.c_str(),running.c_str(),MOVEFILE_WRITE_THROUGH)){refuse("Could not claim ingredient repair; no changes made.");running.clear();return;}
  if(!durable(running+L".started",std::string(text,n))){failed=true;status("Could not flush ingredient repair journal. No ingredient flags were changed.");return;}
  if(!canteen_commit(save,request.slot,running))return;
  if(!MoveFileExW(running.c_str(),(running+L".done").c_str(),MOVEFILE_WRITE_THROUGH)){failed=true;status("Ingredient flags verified but journal finalization failed. Do not replay blindly.");return;}
  running.clear();status("All 36 collectible canteen ingredient flags verified. No account items added. Return normally, save, and check the canteen after reloading.");return;
 }
 if(!itemManager){refuse("Item database unavailable.");return;}
 if(startCanteen){
  unsigned needed=0,free=0;
  for(auto id:canteen::Ids){
   auto item=native<uintptr_t(*)(uintptr_t,uint32_t)>(profile::LookupItem)(itemManager,id);
   if(!item||get<uint32_t>(item+0xc,~0u)!=2){refuse("Canteen preset item category differs; batch refused before acquisition.");return;}
   uint32_t animal=0,variant=0;
   if(native<bool(*)(uint32_t,uint32_t*,uint32_t*)>(profile::ReverseAnimal)(id,&animal,&variant)){refuse("Canteen preset unexpectedly maps to wildlife; batch refused.");return;}
   auto state=queue(quest,id);if(!bridge::fits(state,1)){refuse("Canteen batch cannot fit the account queue. Return normally before retrying.");return;}
   if(!state.count)needed++;free=state.free;
  }
  if(!canteen::capacity(free,needed)){refuse("Not enough free account queue entries for the canteen batch. Return normally before retrying.");return;}
 }
 auto item=native<uintptr_t(*)(uintptr_t,uint32_t)>(profile::LookupItem)(itemManager,request.id);
 if(!item||get<uint32_t>(item+0xc,~0u)!=2){refuse("Runtime item is not Account; request refused.");return;}
 auto q=queue(quest,request.id);if(!bridge::fits(q,request.amount)){refuse("Account collection queue full. Return from the expedition before retrying.");return;}
 auto save=native<uintptr_t(*)(uintptr_t)>(profile::GetSave)(saveManager);if(!save){refuse("Active save unavailable. Request paused before acquisition.");return;}
 if(startCanteen&&!canteen_preflight(save,false))return;
 uint32_t animal=0,variant=0;
 bool wildlife=native<bool(*)(uint32_t,uint32_t*,uint32_t*)>(profile::ReverseAnimal)(request.id,&animal,&variant);
 auto recordManager=get<uintptr_t>(base+0x500ce00);
 if(wildlife&&(!recordManager||!get<uintptr_t>(base+0x5012740)||animal>=71||variant>=8)){refuse("Wildlife mapping/manager unavailable; no changes made.");return;}
 auto countFn=native<uint32_t(*)(uintptr_t,uint32_t,uint32_t)>(profile::CountAnimal);
 uint32_t before=wildlife?countFn(save,animal,variant):0;
 float size=1.0f;uint32_t rank=0;
 if(wildlife){
  if(native<bool(*)(uint32_t,uint32_t)>(profile::NeedsSizeAdjust)(animal,variant))native<void(*)(uint32_t,uint32_t,float*)>(profile::AdjustSize)(animal,variant,&size);
  rank=native<uint32_t(*)(uint32_t,uint32_t,float)>(profile::CrownRank)(animal,variant,size);
  if(!std::isfinite(size)||size<=0||size>655.0f||rank>2){refuse("Invalid native specimen size/rank; request refused.");return;}
  uint32_t bank=get<uint32_t>(save+0xf6f28+(rank*568+animal*8+variant)*4,1000);
  if(bank>999||request.amount>999-bank){refuse("Wildlife capture counter would exceed its native cap.");return;}
 }
 // Claim the original request once. A started batch is never replayed after restart.
 if(!canteenBatch.active){
  auto token=std::to_wstring(GetTickCount64())+L"-"+std::to_wstring(GetCurrentProcessId());
  running=folder+L"\\"+token+(startCanteen?L".canteen.running":L".running");
  if(!MoveFileExW(pending.c_str(),running.c_str(),MOVEFILE_WRITE_THROUGH)){refuse("Could not claim request; no changes made.");return;}
  if(!durable(running+L".started",std::string(text,n))){status("Could not flush transaction journal. Claimed request will not be replayed.");running.clear();return;}
  if(startCanteen&&!canteenBatch.begin(request.slot)){failed=true;status("Invalid canteen batch state; no acquisition performed.");return;}
 }
 alignas(16) unsigned char result[64]{};
 native<Receipt>(profile::Receipt)(result,request.id,int32_t(request.amount));
 auto afterQueue=queue(quest,request.id);
 // Receipt word 1 is amount minus immediate objective delivery (0x1898e66).
 // Check queue growth against that remainder, including fully delivered items.
 uint32_t receivedId=0,remainder=0;std::memcpy(&receivedId,result,4);std::memcpy(&remainder,result+4,4);
 uint32_t flag=get<uint32_t>(save+0xf6d98+(request.id/32)*4);
 if(receivedId!=request.id||remainder>request.amount||!afterQueue.readable||afterQueue.count!=q.count+remainder||!(flag&(1u<<(request.id%32)))){failed=true;status("Receipt postcondition failed. Transaction stopped; inspect .running, do not retry blindly.");return;}
 if(wildlife){
  // Item-specific fishing achievements from the native finalizer's switch.
  uint32_t fishFlag=0;
  switch(request.id){case 688:fishFlag=0x14;break;case 689:fishFlag=0x15;break;case 691:fishFlag=0x13;break;case 703:fishFlag=0x16;break;case 1456:fishFlag=0x41;break;case 1461:fishFlag=0x42;break;case 1462:fishFlag=0x43;break;case 1463:fishFlag=0x44;break;case 1465:fishFlag=0x45;break;case 1466:fishFlag=0x46;break;case 1467:case 1468:case 1469:case 1470:case 1471:case 1472:fishFlag=0x47;break;}
  if(fishFlag)native<void(*)(uintptr_t,uint32_t)>(profile::FishFlag)(save,fishFlag);
  // Native catch script event has no actor argument; call once per specimen.
  for(uint32_t i=0;i<request.amount;i++)native<void(*)(uint32_t,uint32_t,float)>(profile::AnimalEvent)(animal,variant,size);
  native<void(*)(uintptr_t,uint32_t,uint32_t,uint32_t,float,uint32_t)>(profile::RecordAnimal)(recordManager,animal,variant,request.amount,size,rank);
  if(rank==1||rank==2)native<void(*)(uintptr_t,uint32_t)>(profile::FishFlag)(save,rank==1?0x56:0x55);
  if(countFn(save,animal,variant)!=before+request.amount){failed=true;status("Wildlife record postcondition failed. Transaction is not replayable.");return;}
 }
 char report[600];std::snprintf(report,sizeof(report),"native_calls_returned=1\nreceipt_path=%s\nhotkey=%s\nitem=%u\namount=%u\nslot=%u\nwildlife=%u\nanimal=%u\nvariant=%u\nsize=%.6f\nrank=%u\nqueue_before=%u\nqueue_after=%u\ncaptures_before=%u\ncaptures_after=%u\ngameplay_validation_pending=1\nreturn_and_save_required=1\n",receipt_path,hotkey==VK_F9?"F9":"F10",request.id,request.amount,request.slot,unsigned(wildlife),animal,variant,size,rank,q.count,afterQueue.count,before,wildlife?countFn(save,animal,variant):0);
 auto resultPath=running+(canteenBatch.active?(L".item-"+std::to_wstring(request.id)+L".result.txt"):L".result.txt");
 if(!durable(resultPath,report)){failed=true;status("Result journal failed after native calls. Do not replay this request.");return;}
 if(canteenBatch.active){
  if(!canteenBatch.advance()){
   char progress[200];std::snprintf(progress,sizeof(progress),"Canteen account batch: %u/%u acquired; next item %u. Return and save after completion.",canteenBatch.index,canteen::Count,canteenBatch.id());status(progress);return;
  }
  if(!canteen_commit(save,canteenBatch.slot,running))return;
  char summary[260];std::snprintf(summary,sizeof(summary),"canteen_batch_complete=1\ncanteen_unlock_verified=1\ningredients_unlocked=36\nitems_completed=%u\namount_per_item=1\nslot=%u\nnative_calls_returned=1\nreturn_and_save_required=1\n",canteen::Count,canteenBatch.slot);
  if(!durable(running+L".batch-completed.txt",summary)){failed=true;status("All 36 native acquisitions completed, but the batch summary could not be written. Inspect per-item journals; do not replay.");return;}
  if(!MoveFileExW(running.c_str(),(running+L".done").c_str(),MOVEFILE_WRITE_THROUGH)){failed=true;status("All 36 native acquisitions completed, but the batch journal could not be finalized. Do not replay the batch.");return;}running.clear();status("All 36 canteen account items acquired and ingredient flags verified. Return normally, save, and check the canteen after reloading.");return;
 }
 MoveFileExW(running.c_str(),(running+L".done").c_str(),MOVEFILE_WRITE_THROUGH);running.clear();
 status("Account native calls returned. Return normally and save; inspect the result journal.");
}
void AL_CALL frame(al_plugin_t*,al_frame_event_t,const al_frame_info_t*,void*){
 __try {process();} __except(EXCEPTION_EXECUTE_HANDLER){failed=true;status("Native access fault: disabled. Claimed requests are never replayed. Restart and inspect logs.");}
}
void AL_CALL phase(al_plugin_t*,al_phase_t p,const void*){if(p==AL_PHASE_GAME_READY){ready=true;status(hotkey==VK_F9?"Ready: F9 processes one account request in a solo expedition.":"Ready: F10 processes one account request in a solo expedition.");}else if(p==AL_PHASE_EXITING||p==AL_PHASE_SHUTDOWN)ready=false;}
const char* const hashes[]={profile::ExeHash,nullptr};
const al_plugin_info_t info={sizeof(al_plugin_info_t),AL_API_VERSION,"mhwi_account_bridge","MHWI Account Acquisition","0.6.0",AL_PHASE_BIT(AL_PHASE_GAME_READY)|AL_PHASE_BIT(AL_PHASE_EXITING)|AL_PHASE_BIT(AL_PHASE_SHUTDOWN),0,nullptr,nullptr,hashes,phase,nullptr};
}
extern "C" AL_PLUGIN_EXPORT const al_plugin_info_t* AL_CALL al_plugin_info(){return &info;}
extern "C" AL_PLUGIN_EXPORT al_result_t AL_CALL al_plugin_init(const al_api_t* a,const al_init_t* i){
 api=a;self=i->self;base=reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));folder=i->folder?i->folder:L"";
 wchar_t key[16]{};GetPrivateProfileStringW(L"AccountBridge",L"Hotkey",L"F10",key,16,(folder+L"\\AccountBridge.ini").c_str());hotkey=(!_wcsicmp(key,L"F9"))?VK_F9:VK_F10;
 auto game=static_cast<const al_game_t*>(api->get_interface(self,AL_GAME_INTERFACE,AL_GAME_VERSION));
 auto frames=static_cast<const al_frame_t*>(api->get_interface(self,AL_FRAME_INTERFACE,AL_FRAME_VERSION));
 if(!game||!frames||!game->exe_sha256||std::string(game->exe_sha256)!=profile::ExeHash){status("Exact supported executable and Astera API 1.8 required.");return AL_ERROR;}
 if(!native_checks()){status("Native function or receipt hook differs. Bridge refused to start.");return AL_ERROR;}
 api->log(self,AL_LOG_INFO,(std::string("Receipt compatibility: ")+receipt_path).c_str());
 if(!frames->subscribe(self,AL_FRAME_END,frame,nullptr)){status("Could not register game-thread callback.");return AL_ERROR;}
 status("Waiting for title screen. Export request, load selected character solo, press the configured account key. Gameplay validation pending.");return AL_OK;
}
