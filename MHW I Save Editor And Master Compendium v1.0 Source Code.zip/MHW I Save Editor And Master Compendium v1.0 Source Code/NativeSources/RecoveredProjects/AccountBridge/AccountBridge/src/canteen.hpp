#pragma once
#include "request.hpp"
#include <sstream>
#include <set>
namespace canteen {
inline constexpr uint32_t Ids[]={654,641,652,642,651,644,645,629,650,630,636,655,632,633,623,648,624,620,647,621,617,646,618,638,653,639,626,649,627,635,1447,1448,1452,1450,1451,1453};
inline bool parse(const std::string& text,uint32_t& slot){
 if(text.size()>128)return false;
 std::istringstream in(text);std::string magic,extra;uint64_t n=0;
 if(!(in>>magic>>n)||magic!="MHWI_CANTEEN_V1"||n<1||n>3||(in>>extra))return false;
 slot=uint32_t(n);return true;
}
inline constexpr unsigned Count=sizeof(Ids)/sizeof(Ids[0]);
struct State {
 uint32_t slot=0;unsigned index=0;bool active=false,paused=false;
 bool begin(uint32_t n){if(active||n<1||n>3)return false;slot=n;index=0;active=true;paused=false;return true;}
 uint32_t id()const{return active&&index<Count?Ids[index]:0;}
 void pause(){if(active)paused=true;}
 void resume(){if(active)paused=false;}
 bool advance(){if(!active||paused||index>=Count)return false;++index;if(index==Count){active=false;paused=false;return true;}return false;}
};
inline bool field(uint32_t mode,uint32_t phase,uint8_t expedition=0){return (mode-2u<=10u&&phase>=2u)||(mode==13u&&expedition!=0);}
inline bool capacity(unsigned free,unsigned missing){return free>=missing;}
}
