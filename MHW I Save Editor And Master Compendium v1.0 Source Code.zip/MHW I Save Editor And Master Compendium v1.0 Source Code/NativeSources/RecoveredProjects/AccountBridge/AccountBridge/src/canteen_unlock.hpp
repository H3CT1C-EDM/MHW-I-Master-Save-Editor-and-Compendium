#pragma once
#include <array>
#include <cstdint>
#include <string>
#include <sstream>
namespace canteen_unlock {
inline constexpr uint32_t FoodOffset=0x102e60,DiscoveryOffset=0xf6d98;
struct Mapping {uint32_t item,row,page,column,condition,flag,color;};
inline constexpr Mapping Mappings[]={
 {654,5,0,0,3,605,8},
 {641,10,0,1,3,610,8},
 {652,16,0,2,3,616,1},
 {642,17,0,2,3,617,1},
 {651,21,0,3,3,621,14},
 {644,23,0,3,3,623,24},
 {645,29,0,4,3,629,1},
 {629,38,1,1,3,638,3},
 {650,39,1,1,3,639,5},
 {630,40,1,1,3,640,3},
 {636,41,1,1,3,641,0},
 {655,47,1,2,3,647,1},
 {632,51,1,3,3,651,24},
 {633,52,1,3,3,652,8},
 {623,62,2,0,3,662,2},
 {648,63,2,0,3,663,1},
 {624,64,2,0,3,664,2},
 {620,68,2,1,3,668,0},
 {647,69,2,1,3,669,5},
 {621,70,2,1,3,670,0},
 {617,74,2,2,3,674,8},
 {646,75,2,2,3,675,7},
 {618,76,2,2,3,676,8},
 {638,80,2,3,3,680,14},
 {653,81,2,3,3,681,7},
 {639,82,2,3,3,682,14},
 {626,86,2,4,3,686,7},
 {649,87,2,4,3,687,4},
 {627,88,2,4,3,688,7},
 {635,89,2,4,3,644,12},
 {1447,104,3,7,3,2638,2},
 {1448,105,3,7,3,2639,7},
 {1452,106,3,7,3,2640,4},
 {1450,110,3,8,3,2643,6},
 {1451,111,3,8,3,2644,10},
 {1453,112,3,8,3,2645,0},
};
inline constexpr unsigned Count=sizeof(Mappings)/sizeof(Mappings[0]);
using Words=std::array<uint32_t,4>;
inline Words mask(){Words words{};for(auto m:Mappings)words[m.row/32]|=uint32_t(1)<<(m.row%32);return words;}
inline unsigned count(const Words& words){unsigned n=0;for(auto m:Mappings)n+=(words[m.row/32]>>(m.row%32))&1u;return n;}
inline Words desired(Words words){auto bits=mask();for(unsigned i=0;i<4;i++)words[i]|=bits[i];return words;}
inline bool parse(const std::string& text,uint32_t& slot){
 if(text.size()>128)return false;
 std::istringstream in(text);std::string magic,extra;uint64_t n=0;
 if(!(in>>magic>>n)||magic!="MHWI_CANTEEN_UNLOCK_V1"||n<1||n>3||(in>>extra))return false;
 slot=uint32_t(n);return true;
}
inline bool table(const Mapping& m,uint32_t page,uint32_t column,uint32_t condition,uint32_t flag,uint32_t color){return m.page==page&&m.column==column&&m.condition==condition&&m.flag==flag&&m.color==color;}
}
