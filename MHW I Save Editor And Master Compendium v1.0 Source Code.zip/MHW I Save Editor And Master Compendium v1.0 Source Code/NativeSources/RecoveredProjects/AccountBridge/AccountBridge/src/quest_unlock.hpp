#pragma once
#include <array>
#include <cstdint>
#include <sstream>
#include <string>
namespace quest_unlock {
struct Benefit {uint32_t id,row,page,column,condition,flag,color,index;};
inline constexpr Benefit Benefits[]={
 {364,26,0,4,2,364,0,22},
 {452,2,0,0,2,452,0,32},
 {683,20,0,3,2,683,25,83},
 {684,9,0,1,2,684,8,84},
 {694,35,1,0,2,694,10,88},
};
inline constexpr uint32_t QuestIds[]={101,102,103,151,152,153,201,205,251,252,261,262,263,301,302,305,306,351,352,361,362,363,364,365,331,332,333,401,405,407,408,451,452,461,471,472,473,474,475,481,482,483,484,431,432,433,434,501,502,503,504,551,552,561,571,572,581,582,583,531,532,533,534,601,605,607,641,651,652,653,654,655,656,661,662,663,665,666,667,671,672,681,682,683,684,691,692,693,694,631,632,633,634,635,636,637,701,751,752,753,761,762,763,764,771,772,773,774,781,791,792,793,794,795,731,732,733,734,735,736,737,738,801,802,803,804,805,806,851,861,871,881,891,892,893,894,895,896,991,992,995,996,997,998,3101,3001,3002,3031,3032,3033,3034,3051,3052,5003,30000,30001,30002,30003,30004,30005,30006,30007,30008,30009,50701,50751,50901,50801,50802,50803,50891,50892,50861,50601,50905,50906,50991,50902,50910,1101,1102,1201,1202,1203,1301,1302,1303,1304,1305,1306,1401,1405,1402,1403,1404,1501,1502,1503,1504,1601,1602,1391,1521,1551,1552,1561,1571,1572,1591,1592,1121,1122,1151,1152,1153,1161,1162,1163,1171,1181,1191,1131,1132,1133,1134,1221,1251,1261,1262,1271,1272,1273,1281,1231,1232,1233,1234,1235,1236,1237,1238,1321,1351,1352,1361,1362,1371,1381,1382,1392,1393,1394,1331,1332,1333,1334,1335,1336,1337,1338,1339,1340,1435,1421,1461,1471,1481,1491,1431,1432,1433,1434,1593,1641,241,1224,1124,1125,1123,1154,1155,1164,1192,1222,1223,1252,1253,1263,1264,1274,1282,1291,1322,1323,1353,1354,1363,1372,1373,1383,1395,1422,1423,1424,1451,1452,1462,1482,1483,1492,1562,1581,1594,1642,1651,1661,1671,1691,1692,1631,1632,1633,1634,1635,1636,961,971,1603,1604,1605,1606,3171,3071,3072,3073,3074,3091,3092,1225,51602,51601,51603,51604,51605,51621,51606,51607,51622,51623,51611,51613,51612};
inline constexpr uint32_t ClearOffset=0x104c20,IndexRva=0x324fac0;
inline const Benefit* find(uint32_t id){for(const auto& benefit:Benefits)if(benefit.id==id)return &benefit;return nullptr;}
struct Request {uint32_t slot=0,id=0;};
inline bool parse(const std::string& text,Request& result){
 if(text.size()>128)return false;
 std::istringstream in(text);std::string magic,extra;uint64_t slot=0,id=0;
 if(!(in>>magic>>slot>>id)||magic!="MHWI_QUEST_UNLOCK_V1"||slot<1||slot>3||id>0xffffffffu||(in>>extra)||!find(uint32_t(id)))return false;
 result={uint32_t(slot),uint32_t(id)};return true;
}
using Words=std::array<uint32_t,4>;
inline Words desired(Words before,const Benefit& benefit){before[benefit.row/32]|=uint32_t(1)<<(benefit.row%32);return before;}
inline bool unlocked(const Words& words,const Benefit& benefit){return (words[benefit.row/32]&(uint32_t(1)<<(benefit.row%32)))!=0;}
inline bool cleared(uint32_t word,const Benefit& benefit){return (word&(uint32_t(1)<<(benefit.index%32)))!=0;}
inline bool table(const Benefit& b,uint32_t page,uint32_t column,uint32_t condition,uint32_t flag,uint32_t color){return b.page==page&&b.column==column&&b.condition==condition&&b.flag==flag&&b.color==color;}
}
