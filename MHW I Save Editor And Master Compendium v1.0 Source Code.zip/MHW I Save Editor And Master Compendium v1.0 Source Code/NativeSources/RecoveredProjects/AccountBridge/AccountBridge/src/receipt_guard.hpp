#pragma once
#include <cstdint>
#include <cstring>
namespace receipt_guard {
inline constexpr uint8_t Prologue[]={0x44,0x89,0x44,0x24,0x18,0x48,0x89,0x4c,0x24,0x08,0x55,0x57,0x41,0x54,0x41,0x56,0x48,0x8d,0x6c,0x24,0xc1,0x48,0x81,0xec};
struct Owner {uint64_t base=0;uint32_t callbackRva=0,originalSlotRva=0;};
struct Result {bool accepted=false,hooked=false;uint64_t original=0;};
// Read must enforce bounds. Owner verifies the exact module and live callback.
template<class Read,class PrivateExec,class Owner>
Result validate(uint64_t base,Read read,PrivateExec private_exec,Owner owner){
 uint8_t entry[24];const uint64_t address=base+0x18989e0;
 if(!read(address,entry,sizeof(entry)))return {};
 if(!std::memcmp(entry,Prologue,sizeof(entry)))return {true,false,address};
 if(entry[0]!=0xe9||std::memcmp(entry+5,Prologue+5,19))return {};
 int32_t delta;std::memcpy(&delta,entry+1,4);
 const uint64_t relay=address+5+int64_t(delta);uint8_t relayBytes[14];
 if(!private_exec(relay,sizeof(relayBytes))||!read(relay,relayBytes,sizeof(relayBytes)))return {};
 const uint8_t indirect[]={0xff,0x25,0,0,0,0};
 if(std::memcmp(relayBytes,indirect,6))return {};
 uint64_t stub;std::memcpy(&stub,relayBytes+6,8);uint8_t stubBytes[13];
 if(!private_exec(stub,sizeof(stubBytes))||!read(stub,stubBytes,sizeof(stubBytes)))return {};
 if(stubBytes[0]!=0x49||stubBytes[1]!=0xbb||stubBytes[10]!=0x41||stubBytes[11]!=0xff||stubBytes[12]!=0x23)return {};
 uint64_t slot,callback;std::memcpy(&slot,stubBytes+2,8);
 if(!read(slot,&callback,8))return {};
 auto module=owner(callback);if(!module.base||callback!=module.base+module.callbackRva)return {};
 uint64_t original;if(!read(module.base+module.originalSlotRva,&original,8))return {};
 uint8_t trampoline[19];
 if(!private_exec(original,sizeof(trampoline))||!read(original,trampoline,sizeof(trampoline)))return {};
 if(std::memcmp(trampoline,Prologue,5)||std::memcmp(trampoline+5,indirect,6))return {};
 uint64_t continuation;std::memcpy(&continuation,trampoline+11,8);
 if(continuation!=address+5)return {};
 return {true,true,original};
}
}
