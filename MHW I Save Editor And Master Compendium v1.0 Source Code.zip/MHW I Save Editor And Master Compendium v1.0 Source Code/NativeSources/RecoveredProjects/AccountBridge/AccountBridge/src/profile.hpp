#pragma once
#include <cstdint>
namespace profile {
inline constexpr const char* ExeHash="c2ebbbd2c49f216d484e31a5219bed419eb1e5e7d206d02cba040a3ab79d90ea";
struct Point{uint32_t rva;const char* bytes;};
inline constexpr Point Receipt{0x18989e0,"44 89 44 24 18 48 89 4C 24 08 55 57 41 54 41 56 48 8D 6C 24 C1 48 81 EC"};
inline constexpr Point FindPlayer{0x1b42010,"45 33 C9 4C 8D 41 50 66 0F 1F 84 00 00 00 00 00 33 D2 49 8B C0 83 38 00"};
inline constexpr Point GetSave{0x1b8dbb0,"48 63 81 A0 00 00 00 48 69 C0 00 CC 26 00 48 03 81 A8 00 00 00 C3 CC CC"};
inline constexpr Point LookupItem{0x462700,"48 8B C1 3B 91 B8 00 00 00 72 03 33 C0 C3 48 8B 80 C8 00 00 00 48 63 CA"};
inline constexpr Point ReverseAnimal{0x166c8e0,"44 8B 15 09 E0 83 02 45 33 C9 45 85 D2 74 18 48 8D 05 0A E0 83 02 39 48"};
inline constexpr Point RecordAnimal{0x1a45600,"40 57 48 83 EC 40 80 79 30 00 48 8B F9 48 89 6C 24 60 41 8B E8 48 89 74"};
inline constexpr Point CountAnimal{0x1353640,"48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 20"};
inline constexpr Point AdjustSize{0x1669ac0,"4C 8B DC 56 48 81 EC 80 00 00 00 49 89 5B 08 48 8D 05 02 88 8A 01 49 89"};
inline constexpr Point NeedsSizeAdjust{0x166c800,"48 8B 05 39 5F 9A 03 44 8B D1 8B 88 B8 00 00 00 85 C9 74 2D 48 8B 80 C8"};
inline constexpr Point CrownRank{0x16699f0,"48 89 5C 24 08 57 48 83 EC 40 0F 29 74 24 30 41 B1 01 0F 29 7C 24 20 41"};
inline constexpr Point AnimalEvent{0xf16310,"44 8B C2 0F 28 DA 8B D1 48 8D 0D 11 00 00 00 E9 7C FD FF FF CC CC CC CC"};
inline constexpr Point FishFlag{0x1367b60,"48 89 5C 24 18 48 89 74 24 20 57 48 83 EC 20 48 8B F9 8B F2 48 83 C1 08"};
inline constexpr Point InField{0x1b5a100,"8B 41 38 83 E8 02 83 F8 0A 77 09 83 79 54 02 72 03 B0 01 C3 32 C0 C3"};
inline constexpr Point Expedition{0x1b59a60,"80 B9 3B AE 00 00 00 74 09 83 79 38 0D 75 03 B0 01 C3 32 C0 C3"};
inline constexpr Point FoodResource{0xf15e60,"40 56 48 83 EC 20 48 8B 05 A3 C7 0F 04 33 F6 39 B0 B8 00 00 00 0F 86 1B 01 00 00"};
inline constexpr Point FoodUnlock{0xf18610,"48 8D 48 08 FF 15 E6 A9 EF 01 42 8B 84 B7 60 2E 10 00 48 8D 4F 08 44 0F AB F8 42 89 84 B7 60 2E 10 00 FF 15 D0 A9 EF 01"};
inline constexpr Point FoodMenuRead{0xf99160,"48 89 5C 24 08 57 48 83 EC 20 48 8B F9 8B DA 48 8B 0D DA A7 07 04 E8 35 4A BF 00 44 8B C3 8B CB 83 E1 1F 49 C1 E8 05 BA 01 00 00 00 D3 E2 42 85 94 80 60 2E 10 00 75 17"};
inline constexpr Point FoodSerialize{0x1363002,"48 8D 96 60 2E 10 00 45 8D 46 10 48 8B CF FF 50 70"};
inline constexpr Point FoodDeserialize{0x136d0b2,"48 8D 97 60 2E 10 00 45 8D 46 10 48 8B CB FF 50 60"};
inline constexpr Point LookupRecord{0x462040,"48 8B C1 3B 91 B8 00 00 00 72 03 33 C0 C3 48 8B 80 C8 00 00 00 8B CA 48"};
inline constexpr Point QuestClearBankRead{0x134efb0,"48 8B 5C 24 30 8B CA 8B C2 83 E1 1F 48 C1 E8 05 8B 84 87 20 4C 10 00 0F A3 C8 0F 92 C0 48 83 C4 20 5F C3"};
inline constexpr Point FoodQuestBranch{0xf15f06,"48 8B 0D 43 DA 0F 04 E8 9E 7C C7 00 48 8B C8 8B D3 E8 34 90 43 00 EB 16 48 8B 0D 2B DA 0F 04 E8 86 7C C7 00 48 8B C8 8B D3 E8 6C 98 43 00 3C 01 75 35"};
inline constexpr Point Checks[]={FoodQuestBranch,QuestClearBankRead,FoodResource,FoodUnlock,FoodMenuRead,FoodSerialize,FoodDeserialize,LookupRecord,Expedition,InField,Receipt,FindPlayer,GetSave,LookupItem,ReverseAnimal,RecordAnimal,CountAnimal,AdjustSize,NeedsSizeAdjust,CrownRank,AnimalEvent,FishFlag};
}
