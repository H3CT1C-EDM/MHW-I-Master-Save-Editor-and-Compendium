# Account Bridge build

This is the **Stage 21 v0.6.0** original source that matches the shipped bridge DLL hash in Stage 21's release manifest.

From **this directory** run:

```
zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -shared -fms-extensions -Wall -Wextra -Werror AccountBridge/src/AccountBridge.cpp -lbcrypt -o mhwi_account_bridge.dll
```

Zig 0.14.1 is the recorded toolchain. See `Build_and_Test.md` for tests and build requirements. Do not use the older preview or Stage 17/19/20 bridge sources for the final v0.6.0 DLL.
