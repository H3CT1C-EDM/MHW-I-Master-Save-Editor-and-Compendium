"""Build a read-only reference catalog, preserving source IDs and ambiguous matches.

The wiki's Quest IDs section supplies declared game IDs. MHWorldData's database
IDs are never silently promoted to game IDs. No save mapping is generated here.
"""
from pathlib import Path
import csv, json, hashlib, re, sys, unicodedata
from collections import defaultdict

def normalized(s):
    return ' '.join(unicodedata.normalize('NFKC',s).casefold().replace('’',"'").split())

def build(root):
    source=root/'quest_sources'
    text=(source/'Quest-IDs.md').read_text(encoding='utf-8')
    section=text.split('# Mission IDs',1)[0]
    wiki=[]
    for line in section.splitlines():
        m=re.match(r'^\|\s*(\d+)\s*\|\s*([^|]*)\|\s*([^|]*)\|',line)
        if m:wiki.append((int(m[1]),m[2].strip(),m[3].strip()))
    wiki_raw=wiki
    wiki=list(dict.fromkeys(wiki_raw))
    duplicate_rows=len(wiki_raw)-len(wiki)
    id_counts=defaultdict(int)
    for game_id,_,_ in wiki:id_counts[game_id]+=1
    db=list(csv.DictReader((source/'quest_base.csv').open(encoding='utf-8-sig',newline='')))
    rewards=defaultdict(list)
    for r in csv.DictReader((source/'quest_rewards.csv').open(encoding='utf-8-sig',newline='')):
        rewards[int(r['base_id'])].append({'Group':r['group'],'ItemName':r['item_en'],'Count':int(r['stack']),'ReferencePercent':float(r['percentage'])})
    by_name=defaultdict(list)
    for r in db:by_name[normalized(r['name_en'])].append(r)
    wiki_name_counts=defaultdict(int)
    for _,name,_ in wiki:wiki_name_counts[normalized(name)]+=1
    rows=[];linked=set();conflicts=[]
    def row(key,id,name,objective,meta=None,match='None'):
        placeholder=normalized(name) in ('unavailable','invalid message','')
        return {'Key':key,'Id':id,'Name':name,'Objective':objective,
            'Category':meta['category'] if meta else 'Unknown','Rank':meta['rank'] if meta else 'Unknown',
            'Stars':int(meta['stars']) if meta else None,'Zenny':int(meta['zenny']) if meta else None,
            'ReferenceId':int(meta['id']) if meta else None,'MetadataMatch':match,
            'Source':'Reference catalog','DefinitionSHA256':'','DefinitionPath':'',
            'Completion':'Unknown','Availability':'Unknown','CompletionSupport':'Placeholder' if placeholder else 'Unmapped',
            'RewardsSupport':'Read-only reference' if meta else 'Unmapped','UnlocksSupport':'Unmapped',
            'ReferenceRewards':rewards[int(meta['id'])] if meta else [],'RewardRefs':[],'RewardPools':[],
            'Placeholder':placeholder,'InstalledDefinitionVerified':False}
    seen_ids=set()
    for game_id,name,objective in wiki:
        seen_ids.add(game_id);candidates=by_name[normalized(name)];meta=None;match='None'
        exact=[x for x in candidates if int(x['id'])==game_id]
        if len(exact)==1:meta=exact[0];match='Same declared ID and title'
        elif len(candidates)==1 and wiki_name_counts[normalized(name)]==1:
            meta=candidates[0];match='Unique title only; database ID differs'
            if int(meta['id'])!=game_id:conflicts.append({'GameId':game_id,'ReferenceId':int(meta['id']),'Name':name})
        if meta:linked.add(int(meta['id']))
        key='game:'+str(game_id)
        if id_counts[game_id]>1:key+=':'+hashlib.sha256((name+'\0'+objective).encode()).hexdigest()[:12]
        entry=row(key,game_id,name,objective,meta,match)
        entry['IdentityAmbiguous']=id_counts[game_id]>1
        rows.append(entry)
    for meta in db:
        if int(meta['id']) not in linked:
            rows.append(row('reference:'+meta['id'],None,meta['name_en'],'',meta,'Unlinked database record; game ID unknown'))
    if not rows:raise ValueError('Quest reference sources are empty')
    mapping_path=root/'catalog/QuestCompletionMappings.json'
    mapped_ids=set()
    if mapping_path.exists():
        evidence=json.loads(mapping_path.read_text(encoding='utf-8-sig'))
        mapped_ids={int(x['quest_id']) for x in evidence['mappings']}
        definitions_path=root/'catalog/ExtractedQuestDefinitions.json'
        definitions={int(q['Id']):q for q in json.loads(definitions_path.read_text(encoding='utf-8-sig'))['Quests']} if definitions_path.exists() else {}
        for game_id in sorted(mapped_ids-seen_ids):
            definition=definitions.get(game_id,{})
            entry=row('game:'+str(game_id),game_id,definition.get('Name','Quest '+str(game_id)),definition.get('Objective',''))
            entry.update(Source='Executable quest index + extracted definition',MetadataMatch='Executable ID',IdentityAmbiguous=False)
            for key in ['Rank','Stars','Zenny','DefinitionPath','DefinitionSHA256','RewardRefs','RewardPools']:
                if key in definition:entry[key]=definition[key]
            rows.append(entry);seen_ids.add(game_id)
        for entry in rows:
            if entry['Id'] in mapped_ids:
                entry['CompletionSupport']='Code-derived flag / count (placeholder rows read-only)' if entry['Placeholder'] else 'Code-derived flag / count'
                entry['CodeDerivedMapping']=True
                entry['GameplayValidatedFlag']=entry['Id']==241
    else:
        for entry in rows:
            if entry['Key']=='game:241':
                entry['CompletionSupport']='Experimental flag-only reversal (opt-in)'
                entry['ExperimentalFlagMapping']=True
    rows.sort(key=lambda r:(r['Id'] is None,r['Id'] or 0,r['Key']))
    provenance=json.loads((source/'Provenance.json').read_text())
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.iterdir()) if p.is_file()}
    audit={'Format':'MHWI_QUEST_REFERENCE_V1','Rows':len(rows),'DeclaredGameIds':len(seen_ids),
        'DuplicateIdenticalSourceRows':duplicate_rows,'ConflictingGameIds':[k for k,v in id_counts.items() if v>1],
        'DatabaseRows':len(db),'UnlinkedDatabaseRows':sum(x['Id'] is None for x in rows),
        'PlaceholderRows':sum(x['Placeholder'] for x in rows),'VerifiedCompletionMappings':0,'CodeDerivedCompletionMappings':len(mapped_ids),'GameplayValidatedFlagMappings':1,
        'VerifiedRewardGrants':0,'VerifiedUnlockMappings':0,'ExperimentalFlagMappings':0 if mapped_ids else 1,'IdentityDifferences':conflicts,
        'SourceHashes':hashes,'Provenance':provenance,
        'Limit':'Reference data, not an installed-game inventory. A listed quest is not proof of availability or save mapping.'}
    out=root/'catalog';out.mkdir(exist_ok=True)
    (out/'Quests.json').write_text(json.dumps({'Format':'MHWI_QUEST_REFERENCE_V1','Quests':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'QuestCatalogAudit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (out/'QuestCoverage.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['Key','Id','Name','Category','Rank','ReferenceId','MetadataMatch','CompletionSupport','RewardsSupport','UnlocksSupport']
        w=csv.DictWriter(f,fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    return audit
if __name__=='__main__':
    audit=build(Path(sys.argv[1]));print(json.dumps({k:v for k,v in audit.items() if k in ('Rows','DeclaredGameIds','DatabaseRows','UnlinkedDatabaseRows','PlaceholderRows','VerifiedCompletionMappings')}))
