"""Decode the two original item TEX assets from an extracted ui ZIP.

Only TEX v16, a single 2D BC7 surface and the first mip are supported.
Uses Pillow's BC7 decoder. No executable or shader from the game is run.
Usage: python engine/import_original_icons.py UI_ZIP APP_ROOT
"""
import hashlib, json, struct, sys, zipfile
from pathlib import Path
from PIL import Image

def decode(b):
    if len(b) < 192 or b[:4] != b'TEX\0' or struct.unpack_from('<I', b, 4)[0] != 16:
        raise ValueError('Unsupported TEX header')
    mip, width, height, depth, fmt, surfaces = struct.unpack_from('<6I', b, 20)
    if not (1 <= mip <= 16 and width == height == 1024 and depth == surfaces == 1 and fmt == 0x1f):
        raise ValueError('Unsupported atlas geometry or BC7 format')
    offset = struct.unpack_from('<Q', b, 184)[0]
    size = ((width + 3)//4)*((height + 3)//4)*16
    if offset < 184 + mip*8 or offset + size > len(b):
        raise ValueError('Invalid first mip extent')
    return Image.frombytes('RGBA', (width,height), b[offset:offset+size], 'bcn', (7,'BC7'))

def main():
    archive, root = map(Path,sys.argv[1:]); dest=root/'data/icon_sources'
    dest.mkdir(parents=True,exist_ok=True)
    sources=[]
    with zipfile.ZipFile(archive) as z:
        for name, target in [('cmn_item00_ID','items'),('cmn_item00M_ID','items_mask')]:
            member='ui/common/tex/'+name+'.tex'
            if z.namelist().count(member)!=1 or z.getinfo(member).file_size>8*1024*1024:
                raise ValueError('Missing, duplicate or oversized source atlas')
            b=z.read(member); im=decode(b)
            (dest/(name+'.tex')).write_bytes(b)
            p=dest/(target+'.png');im.save(p)
            sources.append(dict(ArchiveMember=member,SourceSHA256=hashlib.sha256(b).hexdigest(),
                                DecodedPNG=p.name,DecodedSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),
                                Width=im.width,Height=im.height,Format='BC7',CellSize=64))
    report=dict(Source='User-supplied extracted ui.zip',
                ArchiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                Textures=sources,PaletteSource='data/icon_sources/ui_colortable.uct',
                PaletteSHA256=hashlib.sha256((dest/'ui_colortable.uct').read_bytes()).hexdigest(),
                Note='Original shared icon atlas and mask, tinted using game table palette; not one unique illustration per item.')
    (root/'catalog/OriginalIconSources.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Decoded 2 original 1024x1024 item atlas textures.')

if __name__=='__main__':main()
