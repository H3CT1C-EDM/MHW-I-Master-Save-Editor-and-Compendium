"""Extract original MHW UI textures for the editor. No AI images or executable code.
Usage: python build_questbook_theme.py UI_ZIP APP_ROOT (requires Pillow)
"""
from pathlib import Path
from PIL import Image
import json,hashlib,zipfile,struct,sys

def decode(b):
    if len(b)<192 or b[:4]!=b'TEX\0' or struct.unpack_from('<I',b,4)[0]!=16:raise ValueError('Unsupported TEX version')
    mip,w,h,depth,fmt,surfaces=struct.unpack_from('<6I',b,20)
    if not(1<=mip<=16 and 1<=w<=4096 and 1<=h<=4096 and depth==surfaces==1 and fmt==31):raise ValueError('Unsupported BC7 geometry')
    off=struct.unpack_from('<Q',b,184)[0];size=((w+3)//4)*((h+3)//4)*16
    if off<184+8*mip or off+size>len(b):raise ValueError('Invalid TEX extent')
    return Image.frombytes('RGBA',(w,h),b[off:off+size],'bcn',(7,'BC7'))

def build(archive,root):
    out=root/'theme';out.mkdir(parents=True,exist_ok=True);records=[]
    with zipfile.ZipFile(archive) as z:
        sources={}
        for member in ['ui/photo/tex/photo_paper03_ID.tex','ui/photo/tex/photo_paper04_ID.tex','ui/common/tex/cmn_other00_ID.tex','ui/common/tex/announce00_ID.tex']:
            if z.namelist().count(member)!=1:raise ValueError('Non-unique texture')
            b=z.read(member);sources[member]=(decode(b),hashlib.sha256(b).hexdigest())
        def save(name,member,box,tint=None):
            im,sha=sources[member];im=im.crop(box)
            if tint:
                colored=Image.new('RGBA',im.size,tint);colored.putalpha(im.getchannel('A'));im=colored
            target=out/(name+'.png');im.save(target)
            records.append({'file':target.relative_to(root).as_posix(),'archive_member':member,'source_sha256':sha,'crop_xyxy':list(box),'tint':tint,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'size':list(im.size)})
        save('questbook','ui/photo/tex/photo_paper03_ID.tex',(0,0,1024,736))
        save('teal_paper','ui/photo/tex/photo_paper04_ID.tex',(16,16,960,960))
        for name,col,row in [('book',2,0),('inventory',5,3),('equipment',4,1),('export',6,5),('hunter',4,2),('mod',2,7)]:
            for tone,color in [('ink','#29443C'),('gold','#E5C58B')]:
                save(name+'_'+tone,'ui/common/tex/cmn_other00_ID.tex',(col*64,row*64,(col+1)*64,(row+1)*64),color)
        save('commission','ui/common/tex/announce00_ID.tex',(680,296,776,390),'#E5C58B')
    report={'source':'User-supplied ui.zip, original MHW TEX assets','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'note':'Open-book parchment originates from photo_paper03; exact quest-acceptance-screen atlas not identified. Icons are original game silhouettes, tinted for contrast.','assets':records}
    (root/'catalog/QuestbookThemeSources.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Extracted',len(records),'theme assets')
if __name__=='__main__':build(*map(Path,sys.argv[1:]))
