#pragma once
// Read-only quest research. No bit in these banks is treated as a quest mapping.
#include <sstream>
#include <iomanip>
#include <regex>
#include <map>
#include <algorithm>
#include <cstddef>
#include <cctype>
namespace QuestResearch {
inline constexpr size_t PayloadSize=0x2098c0;
static_assert(sizeof(mhw_save_slot)==PayloadSize+512,"Slot checksum layout changed.");
inline std::string hex(const u8* p,size_t n){std::string s;s.reserve(n*2);const char* h="0123456789abcdef";for(size_t i=0;i<n;i++){s+=h[p[i]>>4];s+=h[p[i]&15];}return s;}
inline std::string sha256(const u8* p,size_t n){
 unsigned char hash[32]{};
#ifdef _WIN32
 BCRYPT_ALG_HANDLE alg=nullptr;require(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0,"SHA256 initialization failed.");
 auto result=BCryptHash(alg,nullptr,0,const_cast<PUCHAR>(p),ULONG(n),hash,32);BCryptCloseAlgorithmProvider(alg,0);require(result>=0,"SHA256 failed.");
#else
 ::SHA256(p,n,hash);
#endif
 return hex(hash,32);
}
inline std::string sha256(const Bytes& b){return sha256(b.data(),b.size());}
inline Bytes limitedRead(const fs::path& p,size_t max){std::error_code ec;auto n=fs::file_size(p,ec);require(!ec&&n<=max,"Unreadable or oversized file.");std::ifstream f(p,std::ios::binary);require(bool(f),"Cannot open import file.");Bytes b(size_t(n),0);if(n)f.read(reinterpret_cast<char*>(b.data()),std::streamsize(n));require(bool(f),"Import file was truncated during read.");char extra;require(!f.get(extra),"Import file changed size during read.");require(!f.bad(),"Import file read failed.");return b;}
inline u32 u32at(const Bytes& b,size_t p){require(p<=b.size()&&b.size()-p>=4,"Truncated quest metadata.");u32 v;std::memcpy(&v,b.data()+p,4);return v;}
inline std::string name(const mhw_save_slot& s){return std::string(s.hunter.name,strnlen(s.hunter.name,64));}
struct Bank {const char* key;size_t offset,length;const char* meaning;};
#define QUEST_BANK(F,K,M) {K,offsetof(mhw_save_slot,F),sizeof(mhw_save_slot::F),M}
inline const Bank banks[]={
 QUEST_BANK(unlocked_optionals,"optional_availability","Source-named availability bank; quest-to-bit mapping unverified"),
 QUEST_BANK(unknown12b,"optional_adjacent_unknown","Unidentified adjacent bank; NOT a verified completion bank"),
 QUEST_BANK(seen_optionals,"optional_seen","Source-named visibility bank; quest-to-bit mapping unverified"),
 QUEST_BANK(progress,"progress","Mixed progression flags; quest ownership unverified"),
 QUEST_BANK(npc_chat_progress,"npc_dialogue","NPC/dialogue records; raw differences are not quest completion proof"),
 QUEST_BANK(unknown10e,"pre_dialogue_unknown","Unidentified bytes before NPC records"),
 QUEST_BANK(unknown12d,"pre_investigation_unknown","Unidentified bytes before investigation records"),
 QUEST_BANK(tool_unlocks,"tool_unlocks","Tool flags; per-quest ownership unverified"),
 QUEST_BANK(platter_ingredient,"saved_meal_selections","Saved platter data; NOT a verified ingredient ownership bank"),
 QUEST_BANK(completed,"category_totals","Aggregate category counters; NOT individual quest completion"),
 QUEST_BANK(unknown20,"post_totals_unknown","Unidentified bytes after aggregate counters"),
 QUEST_BANK(gallery_unlocked,"gallery_unlocks","Gallery flags; per-quest ownership unverified")
};
#undef QUEST_BANK
inline void layout(std::ostream& o){o<<"[";bool first=true;for(auto b:banks){if(!first)o<<',';first=false;o<<"{\"key\":"<<quote(b.key)<<",\"slot_offset\":"<<b.offset<<",\"size\":"<<b.length<<",\"meaning\":"<<quote(b.meaning)<<'}';}o<<']';}
inline void identity(std::ostream& o,const mhw_ib_save& s,int slot){auto& c=s.section3.saves[slot-1];require(!name(c).empty(),"The selected character slot is empty.");o<<"\"slot\":"<<slot<<",\"character\":"<<quote(name(c))<<",\"account_fingerprint\":"<<quote(sha256(reinterpret_cast<const u8*>(&s.header.steam_id),8));}
inline std::string snapshot(const Bytes& original,const Bytes& decoded,int slot,u32 quest){auto& s=*reinterpret_cast<const mhw_ib_save*>(decoded.data());auto& c=s.section3.saves[slot-1];std::ostringstream o;
 o<<"{\"format\":\"MHWI_QUEST_SNAPSHOT_V1\",\"quest_id_context\":"<<quest<<",\"context_is_not_a_mapping\":true,\"input_sha256\":"<<quote(sha256(original))<<',';identity(o,s,slot);o<<",\"slot_sha256\":"<<quote(sha256(reinterpret_cast<const u8*>(&c),sizeof(c)))<<",\"payload_sha256\":"<<quote(sha256(reinterpret_cast<const u8*>(&c),PayloadSize))<<",\"payload_size\":"<<PayloadSize<<",\"banks\":[";
 bool first=true;for(auto b:banks){if(!first)o<<',';first=false;o<<"{\"key\":"<<quote(b.key)<<",\"slot_offset\":"<<b.offset<<",\"size\":"<<b.length<<",\"hex\":"<<quote(hex(reinterpret_cast<const u8*>(&c)+b.offset,b.length))<<",\"meaning\":"<<quote(b.meaning)<<'}';}o<<"]}";return o.str();
}
inline std::string compare(const Bytes& beforeOriginal,const Bytes& before,const Bytes& afterOriginal,const Bytes& after,int slot,u32 quest){
 auto& a=*reinterpret_cast<const mhw_ib_save*>(before.data());auto& z=*reinterpret_cast<const mhw_ib_save*>(after.data());auto& x=a.section3.saves[slot-1];auto& y=z.section3.saves[slot-1];
 require(a.header.steam_id==z.header.steam_id&&name(x)==name(y)&&!name(x).empty(),"Compare requires the same account, character name and slot.");
 const u8* p=reinterpret_cast<const u8*>(&x);const u8* q=reinterpret_cast<const u8*>(&y);size_t changed=0,payloadChanged=0;for(size_t i=0;i<sizeof(x);i++){changed+=p[i]!=q[i];if(i<PayloadSize)payloadChanged+=p[i]!=q[i];}
 std::ostringstream o;o<<"{\"format\":\"MHWI_QUEST_DIFF_V1\",\"quest_id_context\":"<<quest<<",\"context_is_not_a_mapping\":true,\"before_sha256\":"<<quote(sha256(beforeOriginal))<<",\"after_sha256\":"<<quote(sha256(afterOriginal))<<',';identity(o,a,slot);o<<",\"changed_slot_bytes\":"<<changed<<",\"payload_changed_slot_bytes\":"<<payloadChanged<<",\"checksum_changed_slot_bytes\":"<<changed-payloadChanged<<",\"payload_size\":"<<PayloadSize<<",\"other_slots_changed\":[";
 bool first=true;for(int i=0;i<3;i++)if(i!=slot-1&&std::memcmp(&a.section3.saves[i],&z.section3.saves[i],sizeof(x))){if(!first)o<<',';first=false;o<<i+1;}o<<"],\"other_slots_payload_changed\":[";first=true;for(int i=0;i<3;i++)if(i!=slot-1&&std::memcmp(&a.section3.saves[i],&z.section3.saves[i],PayloadSize)){if(!first)o<<',';first=false;o<<i+1;}
 o<<"],\"other_slots_checksum_changed\":[";first=true;for(int i=0;i<3;i++)if(i!=slot-1&&std::memcmp(reinterpret_cast<const u8*>(&a.section3.saves[i])+PayloadSize,reinterpret_cast<const u8*>(&z.section3.saves[i])+PayloadSize,512)){if(!first)o<<',';first=false;o<<i+1;}o<<"],\"banks\":[";
 first=true;for(auto b:banks){if(!first)o<<',';first=false;size_t bytes=0,bits=0,emitted=0;for(size_t i=0;i<b.length;i++){u8 flip=p[b.offset+i]^q[b.offset+i];bytes+=flip!=0;for(unsigned k=0;k<8;k++)bits+=(flip>>k)&1;}
  o<<"{\"key\":"<<quote(b.key)<<",\"slot_offset\":"<<b.offset<<",\"size\":"<<b.length<<",\"changed_bytes\":"<<bytes<<",\"changed_bits\":"<<bits<<",\"meaning\":"<<quote(b.meaning)<<",\"transitions\":[";
  for(size_t i=0;i<b.length;i++){u8 flip=p[b.offset+i]^q[b.offset+i];for(unsigned k=0;k<8;k++)if((flip>>k)&1){if(emitted>=512)continue;if(emitted++)o<<',';o<<"{\"bank_bit\":"<<i*8+k<<",\"slot_byte\":"<<b.offset+i<<",\"bit\":"<<k<<",\"before\":"<<((p[b.offset+i]>>k)&1)<<",\"after\":"<<((q[b.offset+i]>>k)&1)<<'}';}}
  o<<"],\"transitions_truncated\":"<<(bits>512?"true":"false")<<'}';
 }o<<"],\"changed_ranges\":[";size_t ranges=0,totalRanges=0;
 for(size_t i=0;i<sizeof(x);){if(p[i]==q[i]){i++;continue;}size_t start=i;while(i<sizeof(x)&&p[i]!=q[i]&&i-start<64&&((i<PayloadSize)==(start<PayloadSize)))i++;totalRanges++;if(ranges>=512)continue;if(ranges++)o<<',';o<<"{\"slot_offset\":"<<start<<",\"size\":"<<i-start<<",\"kind\":"<<quote(start<PayloadSize?"payload":"checksum")<<",\"before_hex\":"<<quote(hex(p+start,i-start))<<",\"after_hex\":"<<quote(hex(q+start,i-start))<<'}';}
 o<<"],\"ranges_truncated\":"<<(totalRanges>512?"true":"false")<<",\"warning\":\"Observed differences only. Other gameplay can change these fields; this report verifies no quest mapping.\"}";return o.str();
}
inline std::vector<std::string> gmdStrings(const Bytes& b){require(b.size()>=40&&std::memcmp(b.data(),"GMD\0",4)==0,"Unsupported GMD header.");require(u32at(b,4)==0x10302,"Unsupported GMD version.");u32 keys=u32at(b,20),count=u32at(b,24),keyBytes=u32at(b,28),stringBytes=u32at(b,32),nameBytes=u32at(b,36);require(count<=10000&&keys<=10000,"GMD counts exceed limits.");uint64_t start=40ull+nameBytes+1+uint64_t(keys)*32+256*8+keyBytes;require(start<=b.size()&&stringBytes<=b.size()-start,"GMD section is outside file.");
 std::vector<std::string> out;size_t at=size_t(start),end=at+stringBytes;for(u32 i=0;i<count;i++){size_t begin=at;while(at<end&&b[at])at++;require(at<end,"GMD string is not terminated.");out.emplace_back(reinterpret_cast<const char*>(b.data()+begin),at-begin);at++;}return out;
}
inline Bytes mibDecode(Bytes b,u32 expected){require(b.size()>=176&&b.size()%8==0,"MIB size is unsupported.");blowfish_decrypt(b.data(),int(b.size()),"TZNgJfzyD2WKiuV4SglmI6oN5jP2hhRJcBwzUooyfIUTM4ptDYGjuRTP");require(u32at(b,0)==0x18091001,"MIB Iceborne prefix not recognized.");require(u32at(b,10)==expected,"MIB header ID differs from filename ID.");require(u32at(b,23)<=2&&b[14]<=30,"MIB header fields do not match the supported schema.");return b;}
inline std::string remJson(const Bytes& b,u32 expected){require(b.size()==114&&u32at(b,0)==0x18091001,"Unsupported REM size/prefix.");require(u32at(b,10)==expected,"REM ID differs from its quest reference.");std::ostringstream o;o<<"{\"Id\":"<<expected<<",\"SHA256\":"<<quote(sha256(b))<<",\"MechanicRaw\":"<<u32at(b,14)<<",\"RollRulesVerified\":false,\"Items\":[";bool first=true;for(unsigned i=0;i<16;i++){u32 id=u32at(b,18+4*i);if(!id||!b[82+i]||!b[98+i])continue;if(!first)o<<',';first=false;o<<"{\"ItemId\":"<<id<<",\"Count\":"<<unsigned(b[82+i])<<",\"WeightRaw\":"<<unsigned(b[98+i])<<'}';}o<<"]}";return o.str();}
inline std::string definitions(const fs::path& root){require(fs::is_directory(root),"Choose a folder containing extracted quest definitions.");std::vector<fs::path> mibs;std::map<u32,std::vector<fs::path>> gmds,rems;std::vector<std::pair<std::string,std::string>> issues;
 std::regex mibPat("questData_([0-9]{1,8})\\.mib",std::regex::icase),gmdPat("q([0-9]{1,8})_eng\\.gmd",std::regex::icase),remPat("remData_([0-9]{1,8})\\.rem",std::regex::icase);size_t visited=0,unrecognized=0;
 for(auto it=fs::recursive_directory_iterator(root,fs::directory_options::skip_permission_denied);it!=fs::recursive_directory_iterator();++it){require(++visited<=200000,"Import tree exceeds 200000 entries; choose a narrower extracted-data folder.");if(it->is_symlink()){if(it->is_directory())it.disable_recursion_pending();continue;}if(!it->is_regular_file())continue;std::smatch m;auto filename=it->path().filename().u8string();if(std::regex_match(filename,m,mibPat)){require(mibs.size()<10000,"Too many quest definitions.");mibs.push_back(it->path());}else if(std::regex_match(filename,m,gmdPat))gmds[u32(std::stoul(m[1]))].push_back(it->path());else if(std::regex_match(filename,m,remPat))rems[u32(std::stoul(m[1]))].push_back(it->path());else {auto ext=it->path().extension().u8string();std::transform(ext.begin(),ext.end(),ext.begin(),[](unsigned char c){return char(std::tolower(c));});if(ext==".mib"){require(++unrecognized<=10000,"Too many unsupported quest filenames.");issues.emplace_back(fs::relative(it->path(),root).generic_u8string(),"Unsupported MIB filename; expected questData_ID.mib.");}}}
 std::sort(mibs.begin(),mibs.end());std::map<u32,size_t> counts;for(auto& p:mibs){std::smatch m;auto f=p.filename().u8string();std::regex_match(f,m,mibPat);counts[u32(std::stoul(m[1]))]++;}
 std::ostringstream o;o<<"{\"Format\":\"MHWI_QUEST_DEFINITIONS_V1\",\"ParserStatus\":\"Experimental; no save mappings\",\"Quests\":[";size_t accepted=0;
 for(auto& path:mibs){auto rel=fs::relative(path,root).generic_u8string();try{std::smatch match;auto f=path.filename().u8string();std::regex_match(f,match,mibPat);u32 id=u32(std::stoul(match[1]));auto raw=limitedRead(path,16*1024*1024);auto b=mibDecode(raw,id);std::string title="Quest "+std::to_string(id),objective;std::string textHash;
  if(gmds[id].size()==1){try{auto text=limitedRead(gmds[id][0],8*1024*1024);auto strings=gmdStrings(text);require(strings.size()>=2,"Quest GMD needs name and objective.");title=strings[0];objective=strings[1];textHash=sha256(text);}catch(const std::exception& e){issues.emplace_back(rel+" [text]",e.what());}}else issues.emplace_back(rel,gmds[id].empty()?"English quest GMD missing; numeric title used.":"Duplicate English GMDs; no text selected.");
  if(accepted++)o<<',';o<<"{\"Key\":"<<quote("definition:"+rel)<<",\"Id\":"<<id<<",\"Name\":"<<quote(title)<<",\"Objective\":"<<quote(objective)<<",\"Category\":\"Unknown\",\"Rank\":"<<quote(u32at(b,23)==0?"LR":u32at(b,23)==1?"HR":"MR")<<",\"Stars\":"<<(b[14]>10?unsigned(b[14])-10:unsigned(b[14]))<<",\"Zenny\":"<<u32at(b,55)<<",\"HrPoints\":"<<u32at(b,164)<<",\"DefinitionPath\":"<<quote(rel)<<",\"DefinitionSHA256\":"<<quote(sha256(raw))<<",\"TextSHA256\":"<<quote(textHash)<<",\"DuplicateDefinitionId\":"<<(counts[id]>1?"true":"false")<<",\"Source\":\"Extracted definition (experimental parser)\",\"Completion\":\"Unknown\",\"CompletionSupport\":\"Unmapped\",\"RewardsSupport\":\"Read-only\",\"UnlocksSupport\":\"Unmapped\",\"Availability\":\"Unknown\",\"ReferenceRewards\":[],\"RewardRefs\":[";
  for(unsigned k=0;k<3;k++){if(k)o<<',';o<<u32at(b,136+4*k);}o<<"],\"RewardPools\":[";bool first=true;
  for(unsigned k=0;k<3;k++){u32 rem=u32at(b,136+4*k);if(!rem)continue;if(rems[rem].size()!=1){issues.emplace_back(rel+" [REM "+std::to_string(rem)+"]",rems[rem].empty()?"Referenced reward table missing.":"Duplicate reward tables; no table selected.");continue;}try{auto pool=remJson(limitedRead(rems[rem][0],1024*1024),rem);if(!first)o<<',';first=false;o<<pool;}catch(const std::exception& e){issues.emplace_back(rel+" [REM "+std::to_string(rem)+"]",e.what());}}
  o<<"]}";
 }catch(const std::exception& e){issues.emplace_back(rel,e.what());}}
 o<<"],\"ScannedDefinitions\":"<<(mibs.size()+unrecognized)<<",\"ImportedDefinitions\":"<<accepted<<",\"Issues\":[";bool first=true;for(auto& issue:issues){if(!first)o<<',';first=false;o<<"{\"Path\":"<<quote(issue.first)<<",\"Reason\":"<<quote(issue.second)<<'}';}o<<"]}";return o.str();
}
} // namespace QuestResearch
