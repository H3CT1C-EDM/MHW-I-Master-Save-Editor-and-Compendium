"""Render the supplied editor's colored item/gear atlas into cached thumbnails.
Requires Pillow only for this optional regeneration step. Runtime uses PNGs.
"""
from pathlib import Path
import csv,struct,json,sys
from PIL import Image
root=Path(sys.argv[1]);source=root/'data/icon_sources';target=root/'thumbnails';target.mkdir(exist_ok=True)
atlas=Image.open(source/'items.png').convert('RGBA');mask=Image.open(source/'items_mask.png').convert('RGBA')
b=(source/'ui_colortable.uct').read_bytes();palettes=[];p=12
for _ in range(4):
 n=struct.unpack_from('<I',b,p)[0];p+=4
 palettes.append([tuple(b[p+j*28+4:p+j*28+8]) for j in range(n)]);p+=n*28
rendered={};fallbacks=[]
def render(icon,palette,color):
 key=f'{icon}_{palette}_{color}'
 if key in rendered:return key
 if not (0<=icon<256 and 0<=palette<len(palettes) and 0<=color<len(palettes[palette])):
  fallbacks.append(key);icon=icon if 0<=icon<256 else 63;palette=0;color=0
 tint=palettes[palette][color];box=(icon%16*64,icon//16*64,icon%16*64+64,icon//16*64+64)
 tile=atlas.crop(box);matte=mask.crop(box);out=Image.new('RGBA',(64,64));pixels=[]
 # Equivalent to the upstream QPainter DestinationOut(mask), then Multiply(atlas).
 for a,m in zip(tile.getdata(),matte.getdata()):
  sa=a[3]/255;da=(tint[3]/255)*(1-m[3]/255);oa=sa+da-sa*da
  if not oa:pixels.append((0,0,0,0));continue
  rgb=[round((a[c]/255*sa*(1-da)+tint[c]/255*da*(1-sa)+(a[c]/255)*(tint[c]/255)*sa*da)/oa*255) for c in range(3)]
  pixels.append(tuple(rgb)+(round(oa*255),))
 out.putdata(pixels);out.resize((32,32),Image.Resampling.LANCZOS).save(target/(key+'.png'));rendered[key]=True;return key
def readcsv(name):
 with (root/'catalog'/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def writecsv(name,rows):
 with (root/'catalog'/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
items=readcsv('Items.csv');data=(root/'data/common/item/itemData.itm').read_bytes()
for item in items:
 id=int(item['Id']);lookup={819:2270,2270:819,956:957,957:956}.get(id,id)
 # Color is one byte. The next byte is the large-carryable flag, not color data.
 icon,color=struct.unpack_from('<IB',data,10+lookup*32+18);item['ThumbKey']=render(icon,0,color)
writecsv('Items.csv',items)
gems=readcsv('Jewels.csv')
for gem in gems:gem['ThumbKey']=items[int(gem['Id'])]['ThumbKey']
writecsv('Jewels.csv',gems)
equipment=readcsv('Equipment.csv');gear={};names=['l_sword','sword','w_sword','tachi','hammer','whistle','lance','g_lance','s_axe','c_axe','rod','bow','hbg','lbg'];iconmap=[1,0,3,2,6,7,4,5,8,9,10,13,12,11]
for typ,name in enumerate(names):
 ranged=typ>=11;d=root/'data/common/equip'/(name+('.wp_dat_g' if ranged else '.wp_dat'))
 raw=d.read_bytes();stride=69 if ranged else 66
 for i in range(struct.unpack_from('<I',raw,6)[0]):
  p=10+i*stride;id=struct.unpack_from('<H',raw,p+(59 if ranged else 56))[0];gear[(1,typ,id)]=(240+iconmap[typ],raw[p+(24 if ranged else 20)])
raw=(root/'data/common/equip/armor.am_dat').read_bytes()
for i in range(struct.unpack_from('<I',raw,6)[0]):
 p=10+i*60;id=struct.unpack_from('<H',raw,p+53)[0];typ=raw[p+10];gear.setdefault((0,typ,id),(224+typ,raw[p+20]))
for e in equipment:
 icon,color=gear[(int(e['Category']),int(e['Type']),int(e['Id']))];e['ThumbKey']=render(icon,1,color)
writecsv('Equipment.csv',equipment)
(root/'catalog/ThumbnailAudit.json').write_text(json.dumps(dict(unique_thumbnails=len(rendered),item_rows=len(items),jewel_rows=len(gems),equipment_rows=len(equipment),fallbacks=fallbacks),indent=2))
print('Rendered',len(rendered),'thumbnails; fallbacks:',len(fallbacks))
