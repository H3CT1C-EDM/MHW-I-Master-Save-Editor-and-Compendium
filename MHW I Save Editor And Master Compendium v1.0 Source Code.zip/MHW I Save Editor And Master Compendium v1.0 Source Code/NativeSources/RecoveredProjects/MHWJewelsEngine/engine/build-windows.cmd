@echo off
setlocal
cd /d "%~dp0"
rem Requires Python with ziglang 0.14.1 installed: py -3 -m pip install ziglang==0.14.1
py -3 -m ziglang cc -target x86_64-windows-gnu -O2 -DECB=1 -DCBC=0 -DCTR=0 -Ivendor -c vendor/aes.c -o aes-win.o
if errorlevel 1 exit /b 1
py -3 -m ziglang cc -target x86_64-windows-gnu -O2 -Ivendor -c vendor/blowfish.c -o bf-win.o
if errorlevel 1 exit /b 1
py -3 -m ziglang c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -fwrapv -fno-strict-aliasing -municode -DECB=1 -DCBC=0 -DCTR=0 -Icrypto_shim -Ivendor main.cpp aes-win.o bf-win.o -lbcrypt -o ../MHWJewelsEngine.exe
exit /b %errorlevel%
