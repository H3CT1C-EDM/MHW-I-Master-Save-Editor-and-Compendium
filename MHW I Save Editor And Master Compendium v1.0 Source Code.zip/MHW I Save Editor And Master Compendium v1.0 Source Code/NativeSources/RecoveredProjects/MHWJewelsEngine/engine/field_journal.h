#pragma once
namespace FieldJournal {
inline const size_t XpOffsets[]={offsetof(mhw_save_slot,palico_xp),offsetof(mhw_save_slot,vigorwasp_spray),offsetof(mhw_save_slot,flashfly_cage),offsetof(mhw_save_slot,shieldspire),offsetof(mhw_save_slot,coral_orchestra),offsetof(mhw_save_slot,plunderblade),offsetof(mhw_save_slot,meowlotov_cocktail)};
inline u32 value(const mhw_save_slot&s,int i){u32 v;std::memcpy(&v,reinterpret_cast<const u8*>(&s)+XpOffsets[i],4);return v;}
inline void palico(mhw_save_slot&s,const std::string&name,const std::array<u32,7>&xp){
 require(!QuestResearch::name(s).empty(),"Empty character slot.");require(!name.empty()&&name.size()<64,"Palico name must use 1..63 UTF-8 bytes.");for(unsigned char c:name)require(c>=32&&c!=127,"Palico name contains control characters.");
 if(std::string(s.palico_name,strnlen(s.palico_name,64))!=name){std::memset(s.palico_name,0,64);std::memcpy(s.palico_name,name.data(),name.size());}for(int i=0;i<7;i++)std::memcpy(reinterpret_cast<u8*>(&s)+XpOffsets[i],&xp[i],4);
}
inline std::string info(const Bytes&raw,const mhw_save_slot&s){std::ostringstream o;o<<"{\"input_sha256\":"<<quote(QuestResearch::sha256(raw))<<",\"active\":"<<(!QuestResearch::name(s).empty()?"true":"false")<<",\"name\":"<<quote(std::string(s.palico_name,strnlen(s.palico_name,64)))<<",\"xp\":[";for(int i=0;i<7;i++){if(i)o<<',';o<<value(s,i);}o<<"],\"level_conversion_verified\":false,\"equipment_references\":[";const auto&e=s.guild_card.palico.equipment;bool first=true;for(auto r:{e.weapon,e.helmet,e.body,e.gadget}){if(!first)o<<',';first=false;o<<"{\"type\":"<<r.type<<",\"id\":"<<r.id<<'}';}o<<"]}";return o.str();}
struct Addition{u32 id,amount,before,after;};
inline std::vector<Addition> batch(mhw_save_slot&s,const std::string&spec){
 require(!QuestResearch::name(s).empty(),"Empty character slot.");std::vector<Addition> result;std::map<u32,bool> seen;std::istringstream in(spec);std::string part;
 while(std::getline(in,part,',')){
  require(result.size()<128,"Select at most 128 item IDs per batch.");auto split=part.find(':');require(split!=std::string::npos,"Invalid batch entry.");u32 id=u32(number(part.substr(0,split),1,65535));u32 amount=u32(number(part.substr(split+1),1,9999));require(!seen[id],"Duplicate batch ID.");seen[id]=true;
  auto meta=itemInfo(id);mhw_item_slot*box=nullptr;size_t length=0;
  switch(meta.type){case 0:box=s.storage.items;length=200;break;case 1:box=s.storage.materials;length=1250;break;case 3:box=s.storage.ammo;length=200;break;default:throw std::runtime_error("Batch additions support ordinary items, materials and ammo only. Jewels, account items and furniture are excluded.");}
  mhw_item_slot*target=nullptr,*empty=nullptr;
  for(size_t i=0;i<length;i++){if(box[i].id==id)target=&box[i];if(!box[i].id&&!empty)empty=&box[i];}
  if(!target)target=empty;require(target,"Storage capacity exceeded; no batch was saved.");u32 before=target->id?target->amount:0;require(before<=9999&&amount<=9999-before,"Batch would exceed 9999; no batch was saved.");target->id=id;target->amount=before+amount;
  if(id<sizeof(s.discovered_items.items)*8)s.discovered_items.items[id/8]|=u8(1u<<(id%8));result.push_back({id,amount,before,before+amount});
 }
 require(!result.empty(),"Empty batch.");return result;
}
inline std::string preview(const Bytes&raw,const std::vector<Addition>&rows){std::ostringstream o;o<<"{\"input_sha256\":"<<quote(QuestResearch::sha256(raw))<<",\"items\":[";bool first=true;for(auto r:rows){if(!first)o<<',';first=false;o<<"{\"id\":"<<r.id<<",\"amount\":"<<r.amount<<",\"before\":"<<r.before<<",\"after\":"<<r.after<<'}';}o<<"]}";return o.str();}
}
