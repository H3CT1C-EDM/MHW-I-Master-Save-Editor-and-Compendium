"""Optional Linux host build/test helper; Windows users use build-windows.cmd."""
from pathlib import Path
import subprocess, tempfile, argparse

parser=argparse.ArgumentParser();parser.add_argument('--flag-test-save',type=Path);args=parser.parse_args()
engine=Path(__file__).resolve().parent
root=engine.parent
with tempfile.TemporaryDirectory(prefix='mhwi-quest-build-') as d:
    aes=str(Path(d)/'aes.o');bf=str(Path(d)/'bf.o')
    subprocess.run(['cc','-O2','-DECB=1','-DCBC=0','-DCTR=0','-Ivendor','-c','vendor/aes.c','-o',aes],cwd=engine,check=True)
    subprocess.run(['cc','-O2','-Ivendor','-c','vendor/blowfish.c','-o',bf],cwd=engine,check=True)
    common=['c++','-std=c++17','-O2','-fwrapv','-fno-strict-aliasing','-Wno-attributes','-Icrypto_shim','-Ivendor']
    subprocess.run(common+['main.cpp',aes,bf,'-lcrypto','-o',str(root/'MHWJewelsEngine-linux')],cwd=engine,check=True)
    test=str(Path(d)/'quest-test')
    subprocess.run(common+[str(root/'tests/quest_research_test.cpp'),aes,bf,'-lcrypto','-o',test],cwd=engine,check=True)
    subprocess.run([test],check=True)

    if args.flag_test_save:
        cli=str(Path(d)/'flag-cli-test')
        subprocess.run(common+[str(root/'tests/quest_flag_cli_test.cpp'),aes,bf,'-lcrypto','-o',cli],cwd=engine,check=True)
        subprocess.run([cli,str(args.flag_test_save.resolve()),str(Path(d)/'flag-fixtures')],check=True)

# Stage 9 comprehensive mapped-quest test, using only temporary synthetic copies.
if args.flag_test_save:
    with tempfile.TemporaryDirectory(prefix='mhwi-mapped-build-') as d:
        aes=str(Path(d)/'aes.o');bf=str(Path(d)/'bf.o')
        subprocess.run(['cc','-O2','-DECB=1','-DCBC=0','-DCTR=0','-Ivendor','-c','vendor/aes.c','-o',aes],cwd=engine,check=True)
        subprocess.run(['cc','-O2','-Ivendor','-c','vendor/blowfish.c','-o',bf],cwd=engine,check=True)
        test=str(Path(d)/'mapped-test')
        subprocess.run(common+[str(root/'tests/quest_mapped_test.cpp'),aes,bf,'-lcrypto','-o',test],cwd=engine,check=True)
        subprocess.run([test,str(args.flag_test_save.resolve()),str(Path(d)/'fixtures')],check=True)

if args.flag_test_save:
    subprocess.run(['python3',str(root/'tests/run_field_journal_test.py'),str(args.flag_test_save.resolve())],check=True)
