#pragma once
// One observed quest flag, deliberately not a general quest/progression editor.
namespace QuestFlag {
inline constexpr u32 Id=241;
inline constexpr size_t Byte=274/8;
inline constexpr u8 Mask=1u<<(274%8);
static_assert(offsetof(mhw_save_slot,unknown12b)+Byte==0x1ad209,"Observed quest flag layout changed.");
static_assert(sizeof(mhw_save_slot::unknown12b)==64,"Observed quest bank size changed.");
inline bool available(const mhw_save_slot& s){return (s.unlocked_optionals[Byte]&Mask)!=0;}
inline bool seen(const mhw_save_slot& s){return (s.seen_optionals[Byte]&Mask)!=0;}
inline bool get(const mhw_save_slot& s){return (s.unknown12b[Byte]&Mask)!=0;}
inline bool apply(mhw_save_slot& s,u32 id,bool desired,bool accepted){
 require(accepted,"Explicit experimental flag opt-in is required.");
 require(id==Id,"Only original quest 241 (Learning the Clutch) has an experimental flag mapping.");
 require(!QuestResearch::name(s).empty(),"The selected character slot is empty.");
 require(available(s),"The observed availability bit is not set; this test does not unlock quests.");
 require(seen(s),"Use the post-clear save for this reversal test; the observed seen bit must already be set.");
 bool changed=get(s)!=desired;
 if(desired)s.unknown12b[Byte]|=Mask;else s.unknown12b[Byte]&=u8(~Mask);
 return changed;
}
inline std::string info(const Bytes& original,const mhw_save_slot& s,u32 id){
 bool supported=id==Id,active=!QuestResearch::name(s).empty();std::ostringstream o;
 o<<"{\"quest_id\":"<<id<<",\"mapping_status\":"<<quote(supported?"Experimental; one observed clear, gameplay reversal pending":"Unmapped")<<",\"supported\":"<<(supported?"true":"false")<<",\"input_sha256\":"<<quote(QuestResearch::sha256(original))<<",\"candidate_set\":";
 if(supported&&active)o<<(get(s)?"true":"false");else o<<"null";
 o<<",\"write_eligible\":"<<(supported&&active&&available(s)&&seen(s)?"true":"false")<<",\"availability_bit\":"<<(supported&&active&&available(s)?"true":"false")<<",\"seen_bit\":"<<(supported&&active&&seen(s)?"true":"false")<<",\"rewards_supported\":false,\"unlocks_supported\":false,\"reason\":"<<quote(!supported?"No mapping":!active?"Empty character slot":!available(s)?"Observed availability bit is clear":!seen(s)?"Use a post-clear save; observed seen bit is clear":"Flag-only reversal test; does not change rewards, seen flags, totals or progression")<<'}';return o.str();
}
}
