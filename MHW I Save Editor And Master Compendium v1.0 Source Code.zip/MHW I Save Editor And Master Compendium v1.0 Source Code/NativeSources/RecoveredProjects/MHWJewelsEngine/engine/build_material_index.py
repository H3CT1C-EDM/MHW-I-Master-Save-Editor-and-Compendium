"""Join community acquisition records to exact unique names in the supplied game item catalog.
Usage: build_material_index.py MHWorldDataCheckout APP_ROOT
"""
import csv,json,sys,struct,hashlib,subprocess,collections,re,shutil
from pathlib import Path
source,root=map(Path,sys.argv[1:]);base=source/'source_data'
def rows(p):return list(csv.DictReader((base/p).open(encoding='utf-8-sig')))
items=list(csv.DictReader((root/'catalog/Items.csv').open(encoding='utf-8-sig')));names=collections.defaultdict(list)
for q in items:names[q['Name']].append(int(q['Id']))
family={}
for parent,variants in {'Rathalos':['Azure Rathalos','Silver Rathalos'],'Rathian':['Pink Rathian','Gold Rathian'],'Tobi-Kadachi':['Viper Tobi-Kadachi'],'Paolumu':['Nightshade Paolumu'],'Pukei-Pukei':['Coral Pukei-Pukei'],'Legiana':['Shrieking Legiana'],'Anjanath':['Fulgur Anjanath'],'Glavenus':['Acidic Glavenus'],'Odogaron':['Ebony Odogaron'],'Bazelgeuse':['Seething Bazelgeuse'],'Vaal Hazak':['Blackveil Vaal Hazak'],'Deviljho':['Savage Deviljho'],'Nergigante':['Ruiner Nergigante'],'Yian Garuga':['Scarred Yian Garuga'],'Tigrex':['Brute Tigrex'],'Zinogre':['Stygian Zinogre'],'Barioth':['Frostfang Barioth'],'Rajang':['Furious Rajang'],'Brachydios':['Raging Brachydios'],'Leshen':['Ancient Leshen']}.items():
 for v in [parent]+variants:family[v]=parent
hab=collections.defaultdict(set)
for q in rows('monsters/monster_habitats.csv'):hab[q['base_name_en']].add(q['map_en'])
aff=collections.defaultdict(set)
for q in rows('monsters/monster_ailments.csv'):
 for key,v in q.items():
  if v.upper()=='TRUE' and key!='regional':aff[q['base_name_en']].add(key.replace('blight','').replace('_',' ').title())
raw=(root/'data/common/item/itemData.itm').read_bytes();index={int(q['Id']):{'Id':int(q['Id']),'Name':q['Name'],'Rarity':raw[10+int(q['Id'])*32+9]+1,'Monsters':set(),'Families':set(),'Ranks':set(),'Sources':set(),'Regions':set(),'Affinities':set(),'Details':set()} for q in items};unmatched=collections.Counter()
def target(name):
 ids=names.get(name,[])
 if len(ids)!=1:unmatched[name]+=1;return None
 return index[ids[0]]
for q in rows('monsters/monster_rewards.csv'):
 t=target(q['item_en'])
 if t is None:continue
 monster=q['base_name_en'];t['Monsters'].add(monster);t['Families'].add(family.get(monster,monster));t['Ranks'].add(q['rank']);t['Sources'].add(q['condition_en']);t['Regions']|=hab[monster];t['Affinities']|=aff[monster]
 t['Details'].add(f"{monster} / {q['rank']} / {q['condition_en']} (community reference)")
for q in rows('locations/location_items.csv'):
 if q['item_lang']!='en':continue
 t=target(q['item'])
 if t is None:continue
 t['Sources'].add('Gathering');t['Regions'].add(q['base_name_en'])
 if q['rank']:t['Ranks'].add(q['rank'])
 t['Details'].add(f"Gathering / {q['base_name_en']} / area {q['area']} / {q['rank'] or 'rank unspecified'}")
quests={q['id']:q['name_en'] for q in rows('quests/quest_base.csv')}
for q in rows('quests/quest_rewards.csv'):
 t=target(q['item_en'])
 if t is None:continue
 t['Sources'].add('Quest reward');t['Details'].add('Quest reward / '+quests.get(q['base_id'],'reference '+q['base_id']))
def kind(n):
 for k,pattern in [('Scales / shards',r'scale|shard'),('Shells / carapaces',r'shell|carapace|cortex'),('Claws / talons',r'claw|talon'),('Fangs / teeth',r'fang|tooth|teeth'),('Horns',r'horn'),('Wings',r'wing|webbing'),('Tails',r'tail|lash'),('Plates / gems / mantles',r'plate|gem|mantle'),('Hides / pelts',r'hide|pelt|fur')]:
  if re.search(pattern,n,re.I):return k
 return 'Other materials'
for t in index.values():
 for k in ['Monsters','Families','Ranks','Sources','Regions','Affinities','Details']:t[k]=sorted(x for x in t[k] if x)
 t['MaterialGroup']=kind(t['Name']);t['SourceKnown']=bool(t['Details'])
files=['monsters/monster_rewards.csv','monsters/monster_habitats.csv','monsters/monster_ailments.csv','locations/location_items.csv','quests/quest_base.csv','quests/quest_rewards.csv']
report={'Format':'MHWI_MATERIAL_INDEX_V1','Items':list(index.values()),'Provenance':{'Repository':'https://github.com/gatheringhallstudios/MHWorldData','Commit':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip(),'SourceSHA256':{p:hashlib.sha256((base/p).read_bytes()).hexdigest() for p in files},'Join':'Exact unique English name only; reference IDs are not game IDs','AffinityMeaning':'Ailment/blight inflicted by a source monster, not an intrinsic property of a material','Grouping':'Explicit monster lineage aliases and descriptive name-based material-kind groups; IDs and quantities never merged','UnmatchedNames':dict(unmatched)}}
(root/'catalog/MaterialIndex.json').write_text(json.dumps(report,indent=2))
shutil.copyfile(source/'LICENSE',(root/'quest_sources/LICENSE-MHWorldData'))
print('Indexed',len(index),'items;',sum(bool(t['Monsters']) for t in index.values()),'monster-associated;',sum(t['SourceKnown'] for t in index.values()),'known acquisition records')
