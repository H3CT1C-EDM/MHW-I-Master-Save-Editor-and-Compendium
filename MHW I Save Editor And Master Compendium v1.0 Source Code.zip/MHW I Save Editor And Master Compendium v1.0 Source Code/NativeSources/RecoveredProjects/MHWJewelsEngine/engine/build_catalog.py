"""Rebuild searchable catalogues from extracted common game-data tables (stdlib only)."""
from pathlib import Path
import struct,re,csv,sys,json,hashlib
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def table(path,stride):
 b=path.read_bytes();n=struct.unpack_from('<I',b,6)[0]
 if len(b)!=10+n*stride or b[:4]!=bytes.fromhex('01100918'):raise ValueError(f'Invalid table: {path}')
 return [b[10+i*stride:10+(i+1)*stride] for i in range(n)]
def strings(path):
 b=path.read_bytes();keyn,strn,keylen,strlen,namelen=struct.unpack_from('<5I',b,20)
 start=40+namelen+1+keyn*32+256*8+keylen
 ss=b[start:start+strlen].split(b'\0')[:strn]
 if len(ss)!=strn:raise ValueError('GMD string count mismatch')
 def clean(s):
  s=s.decode('utf-8').replace('<ICON BETA>',' β').replace('<ICON ALPHA>',' α').replace('<ICON GAMMA>',' γ')
  return re.sub(r'<[^>]*>','',s).strip()
 return [clean(s) for s in ss]
def text(s,i,fallback):return s[i] if i<len(s) and s[i] else fallback
def write(name,rows,fields):
 with (out/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
names=strings(root/'common/text/steam/item_eng.gmd');itemrows=table(root/'common/item/itemData.itm',32)
items=[];cats={0:'Item',1:'Material',2:'Account',3:'Ammo',4:'Decoration',5:'Furniture'}
for i,b in enumerate(itemrows):
 id=struct.unpack_from('<I',b)[0];cat=struct.unpack_from('<I',b,5)[0]
 if id!=i:raise ValueError('Non-sequential item IDs are unsupported')
 shown={819:2270,2270:819,956:957,957:956}.get(id,id)
 name=text(names,shown*2,f'Item #{id}')
 # Match the upstream special handling.
 if id==19:cat=0
 if id==179:cat=3
 items.append(dict(Id=id,Name=name,Category=cat,Label=f'{name} [ID {id}; {cats.get(cat,"Unknown")}]'))
write('Items.csv',items,['Id','Name','Category','Label'])
gems=[]
for i,b in enumerate(table(root/'common/item/skillGemParam.sgpa',28)):
 id,index,size,*_=struct.unpack('<7I',b)
 if not 0<=id<len(items):raise ValueError('Gem references missing item')
 gems.append(dict(Index=i,Id=id,Size=size,Label=f'{items[id]["Name"]} [level {size}; ID {id}]'))
write('Jewels.csv',gems,['Index','Id','Size','Label'])
equipment=[]
weapons=['l_sword','sword','w_sword','tachi','hammer','whistle','lance','g_lance','s_axe','c_axe','rod','bow','hbg','lbg']
for typ,base in enumerate(weapons):
 ranged=typ>=11;ext='wp_dat_g' if ranged else 'wp_dat';s=strings(root/f'common/text/steam/{base}_eng.gmd')
 for b in table(root/f'common/equip/{base}.{ext}',69 if ranged else 66):
  id,name=struct.unpack_from('<HH',b,59 if ranged else 56);cap=40 if ranged else 35
  equipment.append(dict(Category=1,Type=typ,Id=id,Name=text(s,name,f'Weapon #{id}'),Cap0=b[cap+1],Cap1=b[cap+2],Cap2=b[cap+3]))
s=strings(root/'common/text/steam/armor_eng.gmd')
for b in table(root/'common/equip/armor.am_dat',60):
 id,name=struct.unpack_from('<HH',b,53);equipment.append(dict(Category=0,Type=b[10],Id=id,Name=text(s,name,f'Armor #{id}'),Cap0=b[31],Cap1=b[32],Cap2=b[33]))
write('Equipment.csv',equipment,['Category','Type','Id','Name','Cap0','Cap1','Cap2'])
audit=dict(item_records=len(items),jewel_records=len(gems),equipment_records=len(equipment),source_files={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()})
(out/'CatalogAudit.json').write_text(json.dumps(audit,indent=2))
print(json.dumps({k:v for k,v in audit.items() if k!='source_files'}))
