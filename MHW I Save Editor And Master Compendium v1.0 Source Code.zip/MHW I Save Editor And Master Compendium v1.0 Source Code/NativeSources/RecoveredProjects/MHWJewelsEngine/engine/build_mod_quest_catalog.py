"""Read-only catalog builder for the three supplied custom quest packs.

Usage: python build_mod_quest_catalog.py EXTRACTED_PACK_ROOT BASE_DEFINITIONS OUTPUT
Pack folders: blacktuna13, guiding-lands, htpandemoniun. Requires PyCryptodome.
Filename IDs and embedded IDs are retained independently. No save bits are inferred.
"""
import collections, hashlib, json, re, struct, sys
from pathlib import Path
from Crypto.Cipher import Blowfish

PACKS=[('blacktuna13','Blacktuna13 Quest Pack','1.6'),
       ('guiding-lands','Guiding Lands Monster Quests','1.3'),
       ('htpandemoniun',"HTPandemoniun's Custom Quests",'1.9.0')]
def digest(b):return hashlib.sha256(b).hexdigest()
def u32(b,p):return struct.unpack_from('<I',b,p)[0]
def swap(b):return b''.join(b[i:i+4][::-1] for i in range(0,len(b),4))
def mib(b):
    if len(b)<176 or len(b)%8:raise ValueError('Unsupported MIB length')
    if b[:4]!=bytes.fromhex('01100918'):
        key=b'TZNgJfzyD2WKiuV4SglmI6oN5jP2hhRJcBwzUooyfIUTM4ptDYGjuRTP'
        b=swap(Blowfish.new(key,Blowfish.MODE_ECB).decrypt(swap(b)))
    if b[:4]!=bytes.fromhex('01100918') or u32(b,23)>2 or b[14]>30:raise ValueError('Unsupported MIB header')
    return b
def text(b):
    if len(b)<40 or b[:4]!=b'GMD\0' or u32(b,4)!=0x10302:raise ValueError('Unsupported GMD')
    kn,sn,kl,sl,nl=struct.unpack_from('<5I',b,20);start=40+nl+1+kn*32+2048+kl
    if start+sl>len(b):raise ValueError('GMD extent')
    ss=b[start:start+sl].split(b'\0')
    if len(ss)!=sn+1 or ss[-1]:raise ValueError('GMD terminator/count')
    return [re.sub(r'<[^>]*>','',s.decode('utf8')).strip() for s in ss[:-1]]
def rem(b,filename_id,path):
    if len(b)!=114 or b[:4]!=bytes.fromhex('01100918'):raise ValueError('Unsupported REM')
    return dict(Id=filename_id,HeaderId=u32(b,10),FilenameHeaderIdMatch=filename_id==u32(b,10),
                IdentityVerified=False,SourcePath=path,SHA256=digest(b),MechanicRaw=u32(b,14),RollRulesVerified=False,
                Items=[dict(ItemId=u32(b,18+i*4),Count=b[82+i],WeightRaw=b[98+i]) for i in range(16) if u32(b,18+i*4) and b[82+i] and b[98+i]])
def main():
    base,vanilla,out=map(Path,sys.argv[1:]);official={q['Id'] for q in json.loads(vanilla.read_text())['Quests']}
    rows=[];audit=[];issues=[];packdefs=[]
    for slug,label,version in PACKS:
        root=base/slug;category=f'Mods / {label} v{version}';packdefs.append(dict(Id=slug,Name=label,Version=version,Category=category))
        files=sorted(p for p in root.rglob('*') if p.is_file());gm=collections.defaultdict(list);rm=collections.defaultdict(list)
        for p in files:
            if p.is_symlink():raise ValueError('Symlink source')
            if p.stat().st_size>8*1024*1024:raise ValueError('Oversized source')
            g=re.fullmatch(r'q(\d+)_eng\.gmd',p.name,re.I);r=re.fullmatch(r'remData_(\d+)\.rem',p.name,re.I)
            if g:gm[int(g[1])].append(p)
            if r:rm[int(r[1])].append(p)
        start=len(rows);mid=[];rid=[];missing=[];ids=[]
        for p in files:
            match=re.fullmatch(r'questData_(\d+)\.mib',p.name,re.I)
            if not match:continue
            qid=int(match[1]);ids.append(qid);raw=p.read_bytes();b=mib(raw);header=u32(b,10);path=p.relative_to(root).as_posix()
            strings=[];th='';notes=[]
            if len(gm[qid])==1:
                tb=gm[qid][0].read_bytes();strings=text(tb);th=digest(tb)
            else:notes.append('Missing or ambiguous English text; numeric title retained.')
            if header!=qid:mid.append(dict(Path=path,FilenameId=qid,HeaderId=header));notes.append('Quest filename and embedded IDs differ. No identity is selected for save editing.')
            refs=[u32(b,136),u32(b,140),u32(b,144)];pools=[]
            for ref in refs:
                if not ref:continue
                if len(rm[ref])==1:
                    rp=rm[ref][0];pool=rem(rp.read_bytes(),ref,rp.relative_to(root).as_posix());pools.append(pool)
                    if not pool['FilenameHeaderIdMatch']:rid.append(dict(QuestId=qid,RewardFilenameId=ref,RewardHeaderId=pool['HeaderId']))
                else:missing.append(dict(QuestId=qid,RewardId=ref));notes.append(f'Reward table {ref} absent or ambiguous in this pack; no base-game substitution made.')
            if any(not pool['FilenameHeaderIdMatch'] for pool in pools):notes.append('Reward table filename/header IDs differ. Contents are shown as raw pack data only.')
            if qid in official:notes.append('Declared filename ID collides with an extracted base-game definition.')
            rows.append(dict(Key=f'definition:mod:{slug}:{path}',Id=qid,HeaderId=header,Name=strings[0] if strings and strings[0] else f'Quest {qid}',
                             Objective=strings[1] if len(strings)>1 else '',Category=category,Rank=['LR','HR','MR'][u32(b,23)],
                             Stars=b[14]-10 if b[14]>10 else b[14],Zenny=u32(b,55),HrPoints=u32(b,164),
                             ModPackId=slug,ModPack=label,ModVersion=version,IsModQuest=True,ReadOnly=True,Installed=None,
                             DefinitionPath=path,DefinitionSHA256=digest(raw),TextSHA256=th,Source=f'Mod pack: {label} v{version}',
                             Completion='Unknown',Availability='Unknown',CompletionSupport='Mod quest - read-only',RewardsSupport='Read-only',UnlocksSupport='Unmapped',
                             ReferenceRewards=[],RewardRefs=refs,RewardPools=pools,IdentityAmbiguous=header!=qid,DuplicateDefinitionId=False,
                             BaseGameIdCollision=qid in official,Notes=notes))
        duplicate={i for i,n in collections.Counter(ids).items() if n>1}
        for q in rows[start:]:q['DuplicateDefinitionId']=q['Id'] in duplicate
        audit.append(dict(Pack=label,Version=version,PackId=slug,Definitions=len(rows)-start,NamedDefinitions=sum(bool(q['TextSHA256']) for q in rows[start:]),
                          QuestIdentityMismatches=mid,RewardHeaderMismatches=rid,UnresolvedRewardReferences=missing,DuplicateIds=sorted(duplicate),
                          BaseGameIdCollisions=sorted(set(ids)&official),SourceFiles=[dict(Path=p.relative_to(root).as_posix(),SHA256=digest(p.read_bytes())) for p in files]))
    owners=collections.defaultdict(set)
    for q in rows:owners[q['Id']].add(q['ModPackId'])
    collisions={str(i):sorted(ps) for i,ps in owners.items() if len(ps)>1}
    result=dict(Format='MHWI_MOD_QUEST_CATALOG_V1',Packs=packdefs,Quests=rows,SaveWritesEnabled=False,
                Notes=['Catalog entries only: mod installation and quest completion are not inferred from save data.',
                       'Every mod row remains read-only, including IDs that match base-game quests.'])
    out.mkdir(parents=True,exist_ok=True)
    (out/'ModQuestDefinitions.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    (out/'ModQuestAudit.json').write_text(json.dumps(dict(Packs=audit,CrossPackIdCollisions=collisions,TotalDefinitions=len(rows),SaveMappingsAdded=0),ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(Total=len(rows),Packs=[{k:x[k] for k in ['Pack','Definitions','NamedDefinitions','BaseGameIdCollisions']} for x in audit],CrossPackIdCollisions=collisions)))
if __name__=='__main__':main()
