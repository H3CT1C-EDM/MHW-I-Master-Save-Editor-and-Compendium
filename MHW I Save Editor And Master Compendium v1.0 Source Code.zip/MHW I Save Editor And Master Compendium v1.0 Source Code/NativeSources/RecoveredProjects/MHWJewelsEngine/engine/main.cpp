#include <fstream>
#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <array>
#include <cstring>
#include <stdexcept>
#include <chrono>
#include "upstream/types/mhw_save.h"
#include "upstream/types/file/itm.h"
#include "upstream/crypto/iceborne_crypt.h"
#include "upstream/utility/decoration_edit.h"
#include "upstream/utility/game_data_patch.h"
#include "upstream/utility/special_items.h"
namespace fs=std::filesystem;
using Bytes=std::vector<u8>;
static fs::path dataRoot;
static void require(bool ok,const std::string& s){if(!ok)throw std::runtime_error(s);}
static Bytes read(const fs::path&p){std::ifstream f(p,std::ios::binary);require(bool(f),"Cannot open input file.");Bytes d((std::istreambuf_iterator<char>(f)),{});require(!f.bad(),"Cannot read input file.");return d;}
static std::string quote(const std::string&s){std::string o="\"";for(unsigned char c:s){if(c=='\\'||c=='\"'){o+='\\';o+=c;}else if(c<32){char b[7];snprintf(b,7,"\\u%04x",c);o+=b;}else o+=c;}return o+'\"';}
static Bytes decode(const Bytes&original){
 require(original.size()==sizeof(mhw_ib_save),"Unsupported save size; expected a PC Iceborne save.");auto d=original;
 blowfish_decrypt(d.data(),int(d.size()),KEY_SAVEDATA1000);
 auto h=GenerateHash(d.data(),int(d.size()),64);bool ok=CheckHash(d.data(),h);free(h);require(ok,"Save outer integrity check failed.");
 const int offsets[]={0x70,0x3010D8,0x50AB98,0x714658},lengths[]={0xDA50,0x2098C0,0x2098C0,0x2098C0},slots[]={3,0,1,2};
 for(int i=0;i<4;i++)require(DecryptRegion(d.data(),offsets[i],lengths[i],slots[i]),"Save region integrity check failed.");
 return d;
}
static void writeNew(const fs::path&path,const Bytes&d){
 require(!fs::exists(path),"Output already exists. Choose a new output filename.");
 fs::path temp=path;temp+=".partial";require(!fs::exists(temp),"Temporary output already exists.");
 try{
  {std::ofstream f(temp,std::ios::binary);require(bool(f),"Cannot create output.");f.write(reinterpret_cast<const char*>(d.data()),d.size());f.flush();require(bool(f),"Output write failed.");}
  require(read(temp)==d,"Output readback failed.");fs::rename(temp,path);
 }catch(...){std::error_code ec;fs::remove(temp,ec);throw;}
}
static void encodeNew(const fs::path&out,const Bytes&d){
 auto e=d;EncryptSave(e.data(),int(e.size()));auto check=decode(e);
 // Encryption refreshes the outer hash and four 512-byte region checksums.
 // All other decrypted bytes must match the intended edit exactly.
 std::memcpy(check.data()+12,d.data()+12,20);
 const size_t checksums[]={0x70+0xDA50,0x3010D8+0x2098C0,0x50AB98+0x2098C0,0x714658+0x2098C0};
 for(auto p:checksums)std::memcpy(check.data()+p,d.data()+p,512);
 require(check==d,"Output roundtrip failed; nothing was saved.");writeNew(out,e);
}
static void exportData(const fs::path&path,const Bytes&d){
 fs::create_directories(path.parent_path());
 if(fs::exists(path)){auto previous=read(path);if(previous==d)return;auto stamp=std::chrono::system_clock::now().time_since_epoch().count();fs::path backup=path;backup+=".bak-"+std::to_string(stamp);writeNew(backup,previous);fs::path temp=path;temp+=".new";writeNew(temp,d);fs::remove(path);fs::rename(temp,path);}else writeNew(path,d);
}
static long number(const std::string&s,long lo,long hi){size_t used=0;long n=std::stol(s,&used);require(used==s.size()&&n>=lo&&n<=hi,"Numeric value is out of range.");return n;}
static std::vector<sgpa_entry> gems(){auto b=read(dataRoot/"common/item/skillGemParam.sgpa");std::string error;require(GameDataPatch::Validate<sgpa_header,sgpa_entry>(b,error),error);sgpa_header h;memcpy(&h,b.data(),sizeof(h));std::vector<sgpa_entry> g(h.entry_count);memcpy(g.data(),b.data()+sizeof(h),g.size()*sizeof(sgpa_entry));return g;}
static const std::vector<itm_entry>& allItems(){
 static std::vector<itm_entry> items;
 if(items.empty()){auto b=read(dataRoot/"common/item/itemData.itm");std::string error;require(GameDataPatch::Validate<itm_header,itm_entry>(b,error),error);itm_header h;memcpy(&h,b.data(),sizeof(h));items.resize(h.entry_count);memcpy(items.data(),b.data()+sizeof(h),items.size()*sizeof(itm_entry));for(size_t i=0;i<items.size();i++)require(items[i].id==i,"Unsupported non-sequential item table.");if(items.size()>19)items[19].type=0;if(items.size()>179)items[179].type=3;}
 return items;
}
static itm_entry itemInfo(u32 id){const auto& items=allItems();require(id<items.size(),"Item ID is not in the loaded database.");return items[id];}
static const char* weaponFile(int type){static const char*names[]={"l_sword.wp_dat","sword.wp_dat","w_sword.wp_dat","tachi.wp_dat","hammer.wp_dat","whistle.wp_dat","lance.wp_dat","g_lance.wp_dat","s_axe.wp_dat","c_axe.wp_dat","rod.wp_dat","bow.wp_dat_g","hbg.wp_dat_g","lbg.wp_dat_g"};require(type>=0&&type<14,"Unknown weapon class.");return names[type];}
#include "quest_research.h"
#include "quest_flag.h"
#include "quest_mapped.h"
#include "field_journal.h"
static int run(std::vector<std::string>a){
 require(a.size()>=2,"No command.");dataRoot=fs::u8path(a[0]).parent_path()/"data";
 auto cmd=a[1];
 if(cmd=="palico-info"){
  require(a.size()==4,"palico-info input slot");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());std::cout<<FieldJournal::info(raw,s->section3.saves[number(a[3],1,3)-1])<<'\n';return 0;
 }
 if(cmd=="palico-edit"){
  require(a.size()==14,"palico-edit input output slot name xp gadgetXp1..6 expectedSHA256");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));require(QuestResearch::sha256(raw)==a[13],"Save changed after Palico preview.");auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());std::array<u32,7> xp;for(int i=0;i<7;i++)xp[i]=QuestMapped::parseCount(a[6+i]);FieldJournal::palico(s->section3.saves[number(a[4],1,3)-1],a[5],xp);encodeNew(fs::u8path(a[3]),d);std::cout<<"{\"ok\":true}\n";return 0;
 }
 if(cmd=="batch-preview"||cmd=="batch-add"){
  bool write=cmd=="batch-add";require(a.size()==(write?7:5),"batch-preview input slot id:amount,... OR batch-add input output slot id:amount,... expectedSHA256");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));if(write)require(QuestResearch::sha256(raw)==a[6],"Save changed after batch preview.");auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto rows=FieldJournal::batch(s->section3.saves[number(a[write?4:3],1,3)-1],a[write?5:4]);if(write)encodeNew(fs::u8path(a[3]),d);std::cout<<FieldJournal::preview(raw,rows)<<'\n';return 0;
 }
 if(cmd=="quest-states"){
  require(a.size()==4,"quest-states input slot");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto n=number(a[3],1,3);std::cout<<QuestMapped::states(raw,s->section3.saves[n-1])<<'\n';return 0;
 }
 if(cmd=="quest-edit-preview"){
  require(a.size()==8,"quest-edit-preview input slot id flag count includePair");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto n=number(a[3],1,3);auto id=u32(number(a[4],1,99999999));auto p=QuestMapped::plan(s->section3.saves[n-1],id,a[5],a[6],number(a[7],0,1)!=0);std::cout<<QuestMapped::preview(raw,p)<<'\n';return 0;
 }
 if(cmd=="quest-edit"){
  require(a.size()==11,"quest-edit input output slot id flag count includePair optIn expectedSHA256");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));require(QuestResearch::sha256(raw)==a[10],"Save changed since the quest preview. Refresh before applying.");auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto n=number(a[4],1,3);auto id=u32(number(a[5],1,99999999));auto p=QuestMapped::plan(s->section3.saves[n-1],id,a[6],a[7],number(a[8],0,1)!=0);QuestMapped::apply(s->section3.saves[n-1],p,number(a[9],0,1)!=0);encodeNew(fs::u8path(a[3]),d);std::cout<<QuestMapped::preview(raw,p)<<'\n';return 0;
 }
 if(cmd=="quest-flag-info"){
  require(a.size()==5,"quest-flag-info input slot questId");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto slot=number(a[3],1,3);auto id=u32(number(a[4],1,99999999));std::cout<<QuestFlag::info(raw,s->section3.saves[slot-1],id)<<'\n';return 0;
 }
 if(cmd=="quest-flag"){
  require(a.size()==9,"quest-flag input output slot questId desired optIn expectedInputSHA256");
  auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));require(QuestResearch::sha256(raw)==a[8],"Save changed since the flag preview; refresh before applying.");auto d=decode(raw);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto n=number(a[4],1,3);auto id=u32(number(a[5],1,99999999));bool desired=number(a[6],0,1)!=0,accepted=number(a[7],0,1)!=0;
  bool changed=QuestFlag::apply(s->section3.saves[n-1],id,desired,accepted);encodeNew(fs::u8path(a[3]),d);std::cout<<"{\"ok\":true,\"experimental\":true,\"quest_id\":241,\"changed\":"<<(changed?"true":"false")<<",\"rewards_changed\":false,\"unlocks_changed\":false}\n";return 0;
 }
 if(cmd=="quest-layout"){require(a.size()==2,"quest-layout");std::cout<<"{\"format\":\"MHWI_QUEST_LAYOUT_V1\",\"slot_size\":"<<sizeof(mhw_save_slot)<<",\"banks\":";QuestResearch::layout(std::cout);std::cout<<"}\n";return 0;}
 if(cmd=="quest-definitions"){
  require(a.size()==4,"quest-definitions extractedFolder newReport.json");auto report=QuestResearch::definitions(fs::u8path(a[2]));writeNew(fs::u8path(a[3]),Bytes(report.begin(),report.end()));std::cout<<report<<'\n';return 0;
 }
 if(cmd=="quest-snapshot"){
  require(a.size()==6,"quest-snapshot input output.json slot questId");auto raw=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save));auto d=decode(raw);int slot=int(number(a[4],1,3));u32 id=u32(number(a[5],1,99999999));auto report=QuestResearch::snapshot(raw,d,slot,id);writeNew(fs::u8path(a[3]),Bytes(report.begin(),report.end()));std::cout<<report<<'\n';return 0;
 }
 if(cmd=="quest-compare"){
  require(a.size()==7,"quest-compare before after slot questId output.json");auto before=QuestResearch::limitedRead(fs::u8path(a[2]),sizeof(mhw_ib_save)),after=QuestResearch::limitedRead(fs::u8path(a[3]),sizeof(mhw_ib_save));auto x=decode(before),y=decode(after);int slot=int(number(a[4],1,3));u32 id=u32(number(a[5],1,99999999));auto report=QuestResearch::compare(before,x,after,y,slot,id);writeNew(fs::u8path(a[6]),Bytes(report.begin(),report.end()));std::cout<<report<<'\n';return 0;
 }
 if(cmd=="quest-set"||cmd=="quest-reward"||cmd=="quest-unlock")throw std::runtime_error("Full quest completion/reward/unlock operations remain disabled; only the scoped experimental quest-flag test is available.");
 if(cmd=="inspect"){
  require(a.size()==3,"inspect input");auto d=decode(read(fs::u8path(a[2])));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());
  std::cout<<"{\"integrity\":true,\"slots\":[";
  for(int n=0;n<3;n++){auto&slot=s->section3.saves[n];if(n)std::cout<<',';std::cout<<"{\"number\":"<<n+1<<",\"name\":"<<quote(std::string(slot.hunter.name,strnlen(slot.hunter.name,64)))<<",\"hr\":"<<slot.hunter.hunter_rank<<",\"mr\":"<<slot.hunter.master_rank<<",\"inventory\":[";
   bool first=true;auto items=[&](mhw_item_slot*box,size_t count,int category){for(size_t i=0;i<count;i++)if(box[i].id&&box[i].amount){if(!first)std::cout<<',';first=false;std::cout<<"{\"id\":"<<box[i].id<<",\"amount\":"<<box[i].amount<<",\"category\":"<<category<<'}';}};
   items(slot.storage.items,200,0);items(slot.storage.materials,1250,1);items(slot.storage.ammo,200,3);items(slot.storage.decorations,500,4);
   for(const auto& info:allItems())if((info.type==2||info.type==5)&&SpecialItems::Get(slot,info.id)){
    if(!first)std::cout<<',';first=false;
    std::cout<<"{\"id\":"<<info.id<<",\"amount\":1,\"category\":"<<info.type<<",\"kind\":"<<quote(info.type==5?"furniture_unlock":"account_discovery")<<'}';
   }
   std::cout<<"],\"equipment\":[";first=true;
   for(size_t i=0;i<COUNTOF(slot.equipment);i++){auto&e=slot.equipment[i];if((e.category!=Weapon&&e.category!=Armor)||e.type<0)continue;if(!first)std::cout<<',';first=false;std::cout<<"{\"index\":"<<i<<",\"category\":"<<int(e.category)<<",\"type\":"<<int(e.type)<<",\"id\":"<<e.id<<",\"decos\":["<<e.decos[0]<<','<<e.decos[1]<<','<<e.decos[2]<<"]}";}
   std::cout<<"]}";
  }
  std::cout<<"]}\n";return 0;
 }
 if(cmd=="roundtrip"){require(a.size()==4,"roundtrip input output");auto original=read(fs::u8path(a[2]));auto d=decode(original);auto e=d;EncryptSave(e.data(),int(e.size()));require(e==original,"No-edit roundtrip mismatch.");writeNew(fs::u8path(a[3]),e);std::cout<<"{\"ok\":true}\n";return 0;}
 if(cmd=="inventory"||cmd=="fit"){
  require(a.size()>5,"Missing edit arguments.");auto input=fs::u8path(a[2]),output=fs::u8path(a[3]);auto d=decode(read(input));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&slot=s->section3.saves[number(a[4],1,3)-1];
  if(cmd=="inventory"){
   require(a.size()==7,"inventory input output slot item delta");u32 id=u32(number(a[5],1,65535));long delta=number(a[6],-9999,9999);require(delta!=0,"Quantity is zero.");auto item=itemInfo(id);
   if(item.type==2||item.type==5){
    require(delta==1||delta==-1,"Account/furniture flags have no quantity; use 1 to enable or -1 to clear.");
    std::string error;require(SpecialItems::Set(slot,item,delta>0,error),error);
    encodeNew(output,d);std::cout<<"{\"ok\":true,\"kind\":"<<quote(item.type==5?"furniture_unlock":"account_discovery")<<"}\n";return 0;
   }
   mhw_item_slot*box=nullptr;size_t count=0;
   switch(item.type){case 0:box=slot.storage.items;count=200;break;case 1:box=slot.storage.materials;count=1250;break;case 3:box=slot.storage.ammo;count=200;break;case 4:box=slot.storage.decorations;count=500;break;default:throw std::runtime_error("This record is not a storage item. Account/furniture data needs a separate editor.");}
   mhw_item_slot*target=nullptr,*empty=nullptr;for(size_t i=0;i<count;i++){if(!box[i].id&&!empty)empty=&box[i];if(box[i].id==id&&!target)target=&box[i];}
   if(delta>0){if(!target)target=empty;require(target,"Item storage is full.");if(!target->id)target->amount=0;require(target->amount<=9999 && delta<=9999-target->amount,"Quantity would exceed 9999.");target->id=id;target->amount+=u32(delta);
    if(id<sizeof(slot.discovered_items.items)*8)slot.discovered_items.items[id/8]|=u8(1<<(id%8));
   }else {require(target&&target->amount>=u32(-delta),"Not enough copies to remove.");target->amount-=u32(-delta);if(!target->amount)target->id=0;}
  }else{
   require(a.size()==14,"fit input output slot equipment deco0 deco1 deco2 ignoreSize useBox cap0 cap1 cap2");
   size_t eq=number(a[5],0,2499);std::array<i32,3>desired;std::array<u8,3>caps;for(int i=0;i<3;i++){desired[i]=i32(number(a[6+i],-1,100000));caps[i]=u8(number(a[11+i],0,4));}
   auto g=gems();std::string error;require(DecorationEdit::Apply(slot,eq,desired,caps,number(a[9],0,1),number(a[10],0,1),g,error),error);
  }
  encodeNew(output,d);std::cout<<"{\"ok\":true}\n";return 0;
 }
 if(cmd=="slot-info"){
  require(a.size()==5,"slot-info exportFolder type id");int type=int(number(a[3],0,13));u32 id=u32(number(a[4],0,65535));auto rel=fs::path("common/equip")/weaponFile(type);auto path=fs::u8path(a[2])/"nativePC"/rel;auto b=read(fs::exists(path)?path:dataRoot/rel);std::string error;
  size_t stride=type>=Bow?sizeof(wp_dat_g_entry):sizeof(wp_dat_entry),idpos=type>=Bow?offsetof(wp_dat_g_entry,id):offsetof(wp_dat_entry,id),slotpos=type>=Bow?offsetof(wp_dat_g_entry,slot_count):offsetof(wp_dat_entry,slot_count);
  bool valid=type>=Bow?GameDataPatch::Validate<wp_dat_g_header,wp_dat_g_entry>(b,error):GameDataPatch::Validate<wp_dat_header,wp_dat_entry>(b,error);require(valid,error);
  for(size_t pos=10;pos<b.size();pos+=stride){u16 found;memcpy(&found,b.data()+pos+idpos,2);if(found==id){std::cout<<"{\"sizes\":["<<int(b[pos+slotpos+1])<<','<<int(b[pos+slotpos+2])<<','<<int(b[pos+slotpos+3])<<"]}\n";return 0;}}
  throw std::runtime_error("Weapon ID was not found.");
 }
 if(cmd=="export-any"){
  require(a.size()==3,"export-any outputFolder");auto path=fs::u8path(a[2])/"nativePC/common/item/skillGemParam.sgpa";auto b=read(fs::exists(path)?path:dataRoot/"common/item/skillGemParam.sgpa");std::string error;require(GameDataPatch::AnyJewel(b,error),error);exportData(path,b);std::cout<<"{\"ok\":true}\n";return 0;
 }
 if(cmd=="export-slots"){
  require(a.size()==8,"export-slots outputFolder type id size0 size1 size2");int type=int(number(a[3],0,13));u32 id=u32(number(a[4],0,65535));std::array<u8,3>sizes;for(int i=0;i<3;i++)sizes[i]=u8(number(a[5+i],0,4));
  auto rel=fs::path("common/equip")/weaponFile(type);auto path=fs::u8path(a[2])/"nativePC"/rel;auto b=read(fs::exists(path)?path:dataRoot/rel);std::string error;
  bool ok=type>=Bow?GameDataPatch::Weapon<wp_dat_g_header,wp_dat_g_entry>(b,id,sizes,error):GameDataPatch::Weapon<wp_dat_header,wp_dat_entry>(b,id,sizes,error);require(ok,error);exportData(path,b);std::cout<<"{\"ok\":true}\n";return 0;
 }
 throw std::runtime_error("Unknown command.");
}
#ifdef _WIN32
int wmain(int argc,wchar_t**argv){std::vector<std::string>a;for(int i=0;i<argc;i++){int n=WideCharToMultiByte(CP_UTF8,0,argv[i],-1,nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,argv[i],-1,s.data(),n,nullptr,nullptr);s.pop_back();a.push_back(s);}try{return run(a);}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#else
int main(int argc,char**argv){try{return run(std::vector<std::string>(argv,argv+argc));}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#endif
