#pragma once
#include "quest_mapped_ids.h"
namespace QuestMapped {
static_assert(offsetof(mhw_save_slot,unknown12b)==1757671,"Clear bank moved");
static_assert(offsetof(mhw_save_slot,unknown20)==2008363,"Quest counters moved");
static_assert(sizeof(mhw_save_slot::unknown20)==2048,"Quest counter storage changed");
inline int index(u32 id){for(int i=0;i<352;i++)if(Ids[i]==id)return i;return -1;}
inline u32 paired(u32 id){switch(id){case 805:return 961;case 961:return 805;case 806:return 971;case 971:return 806;default:return 0;}}
inline bool flag(const mhw_save_slot& s,int i){return (s.unknown12b[i/8]&(1u<<(i%8)))!=0;}
inline u32 count(const mhw_save_slot& s,int i){u32 n;std::memcpy(&n,s.unknown20+4*i,4);return n;}
inline u32 parseCount(const std::string& s){
 require(!s.empty()&&std::all_of(s.begin(),s.end(),[](char c){return c>='0'&&c<='9';}),"Count must be keep or an unsigned integer.");
 size_t used=0;auto n=std::stoull(s,&used);require(used==s.size()&&n<=0xffffffffULL,"Count exceeds uint32 range.");return u32(n);
}
struct Change{u32 id;int i;bool beforeFlag,afterFlag;u32 beforeCount,afterCount;};
struct Plan{std::vector<Change> changes;bool changed=false;};
inline Plan plan(const mhw_save_slot& s,u32 id,const std::string& desired,const std::string& desiredCount,bool includePair){
 require(index(id)>=0,"No compiled base-game mapping for this ID. Custom quests are read-only.");
 require(!QuestResearch::name(s).empty(),"The selected character slot is empty.");
 require(desired=="keep"||desired=="0"||desired=="1","Flag must be keep, 0 or 1.");
 require(desired!="keep"||desiredCount!="keep","Select a flag or count change.");
 bool changeCount=desiredCount!="keep";u32 value=changeCount?parseCount(desiredCount):0;
 Plan p;
 for(u32 q:{id,includePair?paired(id):0}){
  if(!q)continue;int i=index(q);require(i>=0,"Paired quest has no compiled mapping.");
  Change c{q,i,flag(s,i),desired=="keep"?flag(s,i):desired=="1",count(s,i),changeCount?value:count(s,i)};
  p.changed|=c.beforeFlag!=c.afterFlag||c.beforeCount!=c.afterCount;p.changes.push_back(c);
 }
 return p;
}
inline void apply(mhw_save_slot& s,const Plan& p,bool accepted){
 require(accepted,"Explicit mapped quest edit opt-in is required.");
 for(const auto& c:p.changes){
  require(c.i==index(c.id)&&c.i>=0,"Invalid quest edit plan.");
  require(flag(s,c.i)==c.beforeFlag&&count(s,c.i)==c.beforeCount,"Quest state changed after preview.");
 }
 for(const auto& c:p.changes){
  u8 mask=u8(1u<<(c.i%8));if(c.afterFlag)s.unknown12b[c.i/8]|=mask;else s.unknown12b[c.i/8]&=u8(~mask);
  std::memcpy(s.unknown20+4*c.i,&c.afterCount,4);
 }
}
inline std::string preview(const Bytes& raw,const Plan& p){
 std::ostringstream o;o<<"{\"input_sha256\":"<<quote(QuestResearch::sha256(raw))<<",\"changed\":"<<(p.changed?"true":"false")<<",\"rewards_changed\":false,\"unlocks_changed\":false,\"changes\":[";
 bool first=true;for(const auto& c:p.changes){if(!first)o<<',';first=false;o<<"{\"id\":"<<c.id<<",\"before_flag\":"<<(c.beforeFlag?"true":"false")<<",\"after_flag\":"<<(c.afterFlag?"true":"false")<<",\"before_count\":"<<c.beforeCount<<",\"after_count\":"<<c.afterCount<<'}';}o<<"]}";return o.str();
}
inline std::string states(const Bytes& raw,const mhw_save_slot& s){
 bool active=!QuestResearch::name(s).empty();std::ostringstream o;o<<"{\"input_sha256\":"<<quote(QuestResearch::sha256(raw))<<",\"active\":"<<(active?"true":"false")<<",\"mapping_count\":352,\"quests\":[";
 for(int i=0;i<352;i++){if(i)o<<',';o<<"{\"id\":"<<Ids[i]<<",\"index\":"<<i<<",\"paired_id\":"<<paired(Ids[i])<<",\"flag\":";if(active)o<<(flag(s,i)?"true":"false");else o<<"null";o<<",\"count\":";if(active)o<<count(s,i);else o<<"null";o<<'}';}o<<"]}";return o.str();
}
}
