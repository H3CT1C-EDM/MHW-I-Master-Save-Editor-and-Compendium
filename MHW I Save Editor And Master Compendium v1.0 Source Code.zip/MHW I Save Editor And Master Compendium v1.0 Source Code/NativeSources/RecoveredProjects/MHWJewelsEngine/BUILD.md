# MHWJewelsEngine build

Recovered from `MHWI_Questbook_Stage11b.zip` **not** the older Preview3 engine (the old Preview3 binary differs from the shipped binary).

From this directory on Windows, run `engine\\build-windows.cmd`.
Requires Python 3 and `ziglang==0.14.1` per the original build script. The generated `MHWJewelsEngine.exe` is placed beside `engine/`.

The binary embedded in Stage 11b matches the final shipped binary SHA-256. This provides historical source association, but no fresh rebuild was run in this environment.
