#define main equipment_program_main
#include "main.cpp"
#undef main
int main(int argc,char**argv){try{
 require(argc>=4&&argc<=6,"fixture source output weapon-id");auto d=decode(read(argv[1]));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&e=s->section3.saves[0].equipment[0];e.level=argc>=5?number(argv[4],0,65535):0;for(auto&a:e.augments)a=0;if(argc==6)e.augments[0]=1;e.category=Weapon;e.type=static_cast<mhw_equip_type>(0);e.id=number(argv[3],0,65535);e.extra_slots=1;e.attack_increase=1;e.affinity_increase=0;e.defense_increase=0;e.slot_upgrade=0;e.health_regen=0;e.element_status_effect_up=0;encodeNew(argv[2],d);std::cout<<"fixture created\n";
 }catch(const std::exception&e){std::cerr<<e.what();return 1;}}
