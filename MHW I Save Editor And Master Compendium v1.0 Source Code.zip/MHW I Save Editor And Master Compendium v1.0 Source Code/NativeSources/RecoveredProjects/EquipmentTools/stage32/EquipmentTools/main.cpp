#include <fstream>
#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <array>
#include <cstring>
#include <stdexcept>
#include <chrono>
#include "upstream/types/mhw_save.h"

#include "upstream/crypto/iceborne_crypt.h"



namespace fs=std::filesystem;
using Bytes=std::vector<u8>;
static fs::path dataRoot;
static void require(bool ok,const std::string& s){if(!ok)throw std::runtime_error(s);}
static Bytes read(const fs::path&p){std::ifstream f(p,std::ios::binary);require(bool(f),"Cannot open input file.");Bytes d((std::istreambuf_iterator<char>(f)),{});require(!f.bad(),"Cannot read input file.");return d;}
static std::string quote(const std::string&s){std::string o="\"";for(unsigned char c:s){if(c=='\\'||c=='\"'){o+='\\';o+=c;}else if(c<32){char b[7];snprintf(b,7,"\\u%04x",c);o+=b;}else o+=c;}return o+'\"';}
static Bytes decode(const Bytes&original){
 require(original.size()==sizeof(mhw_ib_save),"Unsupported save size; expected a PC Iceborne save.");auto d=original;
 blowfish_decrypt(d.data(),int(d.size()),KEY_SAVEDATA1000);
 auto h=GenerateHash(d.data(),int(d.size()),64);bool ok=CheckHash(d.data(),h);free(h);require(ok,"Save outer integrity check failed.");
 const int offsets[]={0x70,0x3010D8,0x50AB98,0x714658},lengths[]={0xDA50,0x2098C0,0x2098C0,0x2098C0},slots[]={3,0,1,2};
 for(int i=0;i<4;i++)require(DecryptRegion(d.data(),offsets[i],lengths[i],slots[i]),"Save region integrity check failed.");
 return d;
}


static std::string sha256(const Bytes&b){unsigned char out[32];
#ifdef _WIN32
 BCRYPT_ALG_HANDLE alg=nullptr;require(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0,"SHA256 initialization failed.");auto status=BCryptHash(alg,nullptr,0,const_cast<PUCHAR>(b.data()),ULONG(b.size()),out,32);BCryptCloseAlgorithmProvider(alg,0);require(status>=0,"SHA256 failed.");
#else
 ::SHA256(b.data(),b.size(),out);
#endif
 const char*hex="0123456789abcdef";std::string text;for(auto c:out){text+=hex[c>>4];text+=hex[c&15];}return text;}
static long number(const std::string&s,long lo,long hi){size_t used=0;long n=std::stol(s,&used);require(used==s.size()&&n>=lo&&n<=hi,"Numeric value is out of range.");return n;}
static void encodeNew(const fs::path&out,const Bytes&d){
 require(!fs::exists(out),"Output already exists.");auto encrypted=d;EncryptSave(encrypted.data(),int(encrypted.size()));auto check=decode(encrypted);memcpy(check.data()+12,d.data()+12,20);const size_t checksums[]={0x70+0xDA50,0x3010D8+0x2098C0,0x50AB98+0x2098C0,0x714658+0x2098C0};for(auto p:checksums)memcpy(check.data()+p,d.data()+p,512);require(check==d,"Encrypted output roundtrip failed.");auto tmp=out;tmp+=".partial";require(!fs::exists(tmp),"Temporary output already exists.");
 try{{std::ofstream file(tmp,std::ios::binary);require(bool(file),"Cannot create output.");file.write(reinterpret_cast<const char*>(encrypted.data()),encrypted.size());file.flush();require(bool(file),"Output write failed.");}require(read(tmp)==encrypted,"Output readback failed.");fs::rename(tmp,out);}catch(...){std::error_code error;fs::remove(tmp,error);throw;}}

static int weaponRarity(const mhw_equipment&e,const std::string&exe){
 require(e.level==0,"Level-dependent weapon identities require an independently verified upgrade table; this weapon is read-only.");
 const char*names[]={"l_sword.wp_dat","sword.wp_dat","w_sword.wp_dat","tachi.wp_dat","hammer.wp_dat","whistle.wp_dat","lance.wp_dat","g_lance.wp_dat","s_axe.wp_dat","c_axe.wp_dat","rod.wp_dat","bow.wp_dat_g","hbg.wp_dat_g","lbg.wp_dat_g"};require(e.category==Weapon&&e.type>=0&&e.type<=13,"Select a supported weapon.");auto table=read(fs::u8path(exe).parent_path().parent_path()/"data/common/equip"/names[e.type]);int stride=e.type>=11?69:66,idOffset=e.type>=11?59:56,rarityOffset=e.type>=11?24:20;require(table.size()>=10,"Invalid weapon table.");u32 count=0;memcpy(&count,table.data()+6,4);require(table.size()==10+size_t(count)*stride,"Unsupported weapon table layout.");int rarity=-1;for(size_t p=10;p<table.size();p+=stride){u16 id;memcpy(&id,table.data()+p+idOffset,2);if(id==e.id){require(rarity==-1,"Ambiguous weapon identity.");rarity=table[p+rarityOffset]+1;}}return rarity;
}
static int applyMaster(const std::vector<std::string>&a){
 require(a.size()==14,"apply-mr input output slot index input-sha256 extra attack affinity defense slot health element");
 auto original=read(fs::u8path(a[2]));require(sha256(original)==a[6],"The save changed after preview. Reopen the equipment editor.");auto d=decode(original),before=d;int slot=number(a[4],1,3);size_t index=number(a[5],0,2499);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&entries=s->section3.saves[slot-1].equipment;require(index<COUNTOF(entries),"Equipment index is out of range.");auto&e=entries[index];require(e.category==Weapon&&e.type>=0&&e.type<=13,"Select a Master Rank weapon.");
 int rarity=weaponRarity(e,a[0]);require(!e.augments[0]&&!e.augments[1]&&!e.augments[2],"Mixed legacy and Master Rank augments are unsupported.");
 require(rarity>=10&&rarity<=12,"This operation supports rarity 10–12 weapons only.");
 bool already=e.extra_slots||e.attack_increase||e.affinity_increase||e.defense_increase||e.slot_upgrade||e.health_regen||e.element_status_effect_up;require(already,"First augment this weapon normally in-game, then reopen the saved character.");
 int values[7];for(int j=0;j<7;j++)values[j]=number(a[7+j],0,j?4:3);require(values[0]==3,"This operation requires Extra Slots III, so capacity has a verified upper bound.");
 const int costs[6][5]={{0,3,5,7,9},{0,2,4,6,8},{0,1,2,3,5},{0,3,6,7,8},{0,3,5,7,9},{0,1,3,5,7}};int cost=0;for(int j=0;j<6;j++)cost+=costs[j][values[j+1]];int capacity=rarity==10?10:rarity==11?8:6;require(cost<=capacity,"Selected augments exceed this weapon's maximum capacity.");
 u8*fields[]={&e.extra_slots,&e.attack_increase,&e.affinity_increase,&e.defense_increase,&e.slot_upgrade,&e.health_regen,&e.element_status_effect_up};for(int j=0;j<7;j++)*fields[j]=u8(values[j]);
 size_t begin=reinterpret_cast<u8*>(&e.extra_slots)-d.data();for(size_t p=0;p<d.size();p++)require(d[p]==before[p]||(p>=begin&&p<begin+7),"Unexpected equipment change.");require(read(fs::u8path(a[2]))==original,"The save changed while preparing the edit.");encodeNew(fs::u8path(a[3]),d);std::cout<<"{\"ok\":true,\"slot\":"<<slot<<",\"index\":"<<index<<",\"cost\":"<<cost<<",\"capacity\":"<<capacity<<",\"verified_roundtrip\":true}\n";return 0;}
static int run(std::vector<std::string>a){
 if(a.size()>1&&a[1]=="apply-mr")return applyMaster(a);
 if(a.size()>1&&a[1]=="augment-profile"){
 require(a.size()==5,"augment-profile input slot index");auto d=decode(read(fs::u8path(a[2])));int slot=number(a[3],1,3);size_t index=number(a[4],0,2499);auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&entries=s->section3.saves[slot-1].equipment;require(index<COUNTOF(entries),"Equipment index is out of range.");auto&e=entries[index];int rarity=weaponRarity(e,a[0]);require(rarity>=10&&rarity<=12,"This operation supports rarity 10–12 weapons only.");require(!e.augments[0]&&!e.augments[1]&&!e.augments[2],"Mixed legacy and Master Rank augments are unsupported.");std::cout<<"{\"rarity\":"<<rarity<<",\"capacity\":"<<(rarity==10?10:rarity==11?8:6)<<"}\n";return 0;
 }
 require(a.size()==3,"Usage: EquipmentDetails save-file character-slot");
 size_t used=0;int n=std::stoi(a[2],&used);require(used==a[2].size()&&n>=1&&n<=3,"Character slot must be 1, 2 or 3.");
 auto d=decode(read(fs::u8path(a[1])));auto*s=reinterpret_cast<mhw_ib_save*>(d.data());auto&slot=s->section3.saves[n-1];
 std::cout<<"{\"slot\":"<<n<<",\"read_only\":true,\"equipment\":[";bool first=true;
 for(size_t i=0;i<COUNTOF(slot.equipment);i++){
  const auto&e=slot.equipment[i];if((e.category!=Weapon&&e.category!=Armor)||e.type<0)continue;
  if(!first)std::cout<<',';first=false;
  std::cout<<"{\"index\":"<<i<<",\"category\":"<<int(e.category)<<",\"type\":"<<int(e.type)<<",\"id\":"<<e.id<<",\"level\":"<<e.level<<",\"points\":"<<e.points<<",\"augments\":[";
  for(int j=0;j<3;j++){if(j)std::cout<<',';std::cout<<e.augments[j];}
  std::cout<<"],\"extra_slots\":"<<int(e.extra_slots)<<",\"attack_increase\":"<<int(e.attack_increase)<<",\"affinity_increase\":"<<int(e.affinity_increase)<<",\"defense_increase\":"<<int(e.defense_increase)<<",\"slot_upgrade\":"<<int(e.slot_upgrade)<<",\"health_regen\":"<<int(e.health_regen)<<",\"element_status_effect_up\":"<<int(e.element_status_effect_up)<<",\"custom_upgrades\":[";
  for(int j=0;j<12;j++){if(j)std::cout<<',';std::cout<<int(e.custom_upgrades[j]);}
  std::cout<<"],\"awakens\":[";for(int j=0;j<5;j++){if(j)std::cout<<',';std::cout<<e.awakens[j];}std::cout<<"]}";
 }
 std::cout<<"]}\n";return 0;
}
#ifdef _WIN32
int wmain(int argc,wchar_t**argv){std::vector<std::string>a;for(int i=0;i<argc;i++){int n=WideCharToMultiByte(CP_UTF8,0,argv[i],-1,nullptr,0,nullptr,nullptr);std::string s(n,'\0');WideCharToMultiByte(CP_UTF8,0,argv[i],-1,s.data(),n,nullptr,nullptr);s.pop_back();a.push_back(s);}try{return run(a);}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#else
int main(int argc,char**argv){try{return run(std::vector<std::string>(argv,argv+argc));}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
#endif
