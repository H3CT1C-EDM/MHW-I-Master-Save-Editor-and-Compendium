from pathlib import Path
import shutil,subprocess
out=Path('stage32/EquipmentTools');assert (out/'main.cpp').is_file(), 'Extract the complete source archive first.'
zig=__import__('os').environ.get('MHW_ZIG_BIN') or shutil.which('zig') or str(Path('stage32/build-deps/ziglang/zig').resolve());args=['-O2','-DECB=1','-DCBC=0','-DCTR=0','-Ivendor']
for target,name in [('x86_64-windows-gnu','win'),(None,'host')]:
 for file,obj in [('aes','aes-'+name+'.o'),('blowfish','bf-'+name+'.o')]:
  compiler=[zig,'cc','-target',target] if target else ['cc']
  subprocess.run(compiler+args+['-c','vendor/'+file+'.c','-o',obj],cwd=out,check=True)
 compiler=[zig,'c++','-target',target,'-static','-municode','-s'] if target else ['c++']
 destination=Path('stage32/MHWI_Hunters_Companion/tools/EquipmentTools.exe') if target else Path('stage32/MHWI_Hunters_Companion/tools/EquipmentTools-linux')
 subprocess.run(compiler+['-std=c++17','-O2','-fwrapv','-fno-strict-aliasing','-Wno-attributes','-Icrypto_shim','-Ivendor','main.cpp','aes-'+name+'.o','bf-'+name+'.o','-lbcrypt' if target else '-lcrypto','-o',str(destination.resolve())],cwd=out,check=True)
print('Built bounded MR augment editor and compatible equipment reader.')
