# Stage 32 source and validation

The runtime ZIP contains the authoritative final PowerShell, managed-control, HTML/CSS/JavaScript, data and asset files. The separate source archive contains the Stage 32 native helper, build scripts, changed UI source, migration/data-generation scripts and test audits. Unchanged earlier native engines/plugins are retained as binaries; their earlier source archives are retained separately.

## Working layout

Commands assume a project root containing `stage32/MHWI_Hunters_Companion` and `stage32/EquipmentTools`. Extract the runtime into that location before running source checks. Do not overwrite the tested release with generated/research output without comparing manifests.

The source archive excludes private saves, synthetic save fixtures, game executables/process dumps, downloaded compilers, Linux binaries, cached web pages and internal screenshots. Tests needing a real save require a separate disposable private input. They never belong in a release archive.

## Native equipment helper

Use Zig 0.14.1 for the Windows target, a host C++17 compiler/OpenSSL development files for host-only tests, and Python 3. Set `MHW_ZIG_BIN` to the absolute Zig executable or place Zig in PATH. Run:

```sh
python3 stage32/build_equipment_tools.py
```

This builds the statically linked Windows `tools/EquipmentTools.exe` and a host-only `tools/EquipmentTools-linux`. Exclude the host binary and object/PDB files when packaging. The Windows build uses BCrypt plus bundled tiny-AES-c/Mbed TLS Blowfish; notices are retained in LICENSES.

`apply-mr` is the only exposed write command. `augment-profile` is read-only. Legacy writes are not exposed. Input integrity, source digest binding, field allowlisting and encrypt/decode/readback checks are mandatory. Preserve those checks when extending the helper.

Compile `EquipmentTools/test_augments.cpp` against the same host crypto objects to make the disposable fixture utility used by `test_augments.py`. The fixture input expected by the current test is `test_inputs/Monster/SAVEDATA1000(3)`, which must be supplied privately. It is deliberately absent from this archive.

## Data regeneration

Reference CSVs come from:

- https://github.com/gatheringhallstudios/MHWorldData
- Pinned commit: `be7362213d7d1e30b794e3b58d3f87712035658d`

Place that source at `stage32/references/MHWorldData` and run `build_reference_data.py` to regenerate searchable weapon/armor/skill/kinsect/melody/set data. `build_guide_articles.py` uses `article_translations.tsv`; `update_new_locales.py` uses `new_ui_translations.tsv` and retains all five existing locale dictionaries. Existing text/data/image payloads remain in the runtime.

`enrich_items.py` uses the original supplied native English GMD/itemData table and Clarity 1.8 ZIP. It resolves exact unique names/IDs; it does not adopt every mod claim. Its release audit records the initial enrichment against Stage 31. Running it against an already-enriched payload can legitimately report zero newly filled fields. Preserve the original release audit rather than misreporting a regeneration as the initial import.

`finish_guides.py`, `update_maps.py`, `update_help.py` and `extend_help.py` are historical one-time migrations, **not an idempotent build pipeline**. The shipped final files are authoritative. Do not run every script blindly against a finished release: some migrations assert the prior file shape or append content.

`MapArtworkAudit.json` identifies image URLs and hashes. `restore_map_images.py` can retrieve missing map art; `upgrade_map_images.py` records the linked high-resolution originals. Network retrieval is optional at runtime. `find_special_maps.py` records an unsuccessful supplemental-source search, not missing-map proof. Native terrain-patch decoding/layout research remains separate and incomplete.

## Checks

- `validate_product.ps1`: product PowerShell syntax, locale key consistency, managed syntax. Requires PowerShell with Roslyn assemblies; set its executable path for your environment.
- `validate_managed_compile.ps1`: compile managed controls against .NET Framework 4.8 reference assemblies. The reference package is external build tooling, not a shipped dependency.
- `test_slot_export.ps1`: binary slot-field allowlist, valid output, idempotence and malformed layouts.
- `test_armor_slots.ps1`: original and exported armor identity/capacity mapping; excludes charms.
- `test_augments.py`: private synthetic-fixture save tests for bounded MR writes and rejected cases.
- `test_all_languages.js` and `test_new_guides.js`: Playwright browser checks. They currently point at the test environment's Chromium path; select your installed browser before running elsewhere. Chromium is not native MSHTML/Windows Forms validation.
- `validate_release.py`: final data/resource, translation-placeholder, image, baseline-component and package checks.

Acceptance on Windows and in-game is in the separate Instructions and Remaining Plan. Neither successful cross-compilation nor a receipt saying a native call returned proves gameplay persistence.
