# EquipmentTools build

Recovered complete native source and its original `stage32/build_equipment_tools.py` from `MHWI_Stage32_Source_and_Validation.zip`.

Set Zig 0.14.1 on PATH or `MHW_ZIG_BIN`. From **this directory**, run:

```
python3 stage32/build_equipment_tools.py
```

The script also builds a host-side executable which requires C++17 and OpenSSL. Windows target uses BCrypt. See Stage 32 guide in this folder.
