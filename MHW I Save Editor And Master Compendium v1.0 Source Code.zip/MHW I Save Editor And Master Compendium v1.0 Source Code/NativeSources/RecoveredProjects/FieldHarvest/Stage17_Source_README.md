# Stage 17 retained source and tests

Base runtime: Stage 16, SHA-256 5b0c231c8193d3c4ec65fbcd821c5e2e78badbaf44ac99ec2260c43cda0b96d3. The unchanged engine/catalog/assets are in that runtime and its earlier retained source archives; they are not duplicated here.

Build the account DLL with Zig 0.14.1: `zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -shared -fms-extensions -Wall -Wextra -Werror AccountBridge/src/AccountBridge.cpp -lbcrypt -o mhwi_account_bridge.dll`.

Build the FieldHarvest editions with the same flags and `-DFIELD_SWEEP=0` (selected) or `=1` (nearby field), using FieldHarvest/src/FieldHarvest.cpp. They change only the version/status classification relative to the supplied source. Readiness and fault gates are preserved.

Build the C++17 bridge tests with the source directory available at AccountBridge/src. The receipt test takes the extracted Stage 15 capture directory. The four FieldHarvest tests use the matching retained headers. test_tools.ps1 is the host test harness from the staged workspace; it uses PowerShell 7 and a host build of the unchanged native engine (earlier retained engine source). Adjust its workspace paths when running elsewhere. It mocks only the dialog display; actual plugin file operations and native table exports run in a temporary folder. parse_ps.py additionally uses tree_sitter and tree_sitter_powershell.

Windows visual rendering, native plugin loading and actual acquisition/persistence remain pending. Validation records distinguish host checks from Windows/in-game checks.
