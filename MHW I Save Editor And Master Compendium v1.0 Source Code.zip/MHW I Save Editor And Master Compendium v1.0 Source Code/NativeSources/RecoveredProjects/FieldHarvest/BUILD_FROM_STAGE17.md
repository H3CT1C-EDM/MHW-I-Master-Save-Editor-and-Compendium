# FieldHarvest builds: selected and nearby-field

This source is recovered unchanged from `MHWI_Stage17_Archive.zip`.
The two **original** targets are generated from one source file.

Prerequisites: Zig 0.14.1 for x86_64-windows-gnu and C++17.

Run each from the directory containing the `FieldHarvest/` folder:

```sh
zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -shared -fms-extensions -Wall -Wextra -Werror -DFIELD_SWEEP=0 FieldHarvest/src/FieldHarvest.cpp -o fieldharvest_selected.dll
zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -static -shared -fms-extensions -Wall -Wextra -Werror -DFIELD_SWEEP=1 FieldHarvest/src/FieldHarvest.cpp -o fieldharvest_field.dll
```

These flags are taken from the contemporaneous Stage 17 README, not invented.
The historical Stage 17 release hashes match the shipped Stage 47/final binaries.
Byte-identical reproducibility has NOT been checked by recompiling here.

Do not mix the selected-target and nearby-field DLLs in one active game install.
