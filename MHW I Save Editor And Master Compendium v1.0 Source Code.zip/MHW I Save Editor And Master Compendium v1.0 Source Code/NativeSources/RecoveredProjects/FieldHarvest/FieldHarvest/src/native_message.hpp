#pragma once
#include <cstdint>
#include <cstddef>
namespace fh {
struct GatherMessage {
  uintptr_t vtable = 0, actor = 0, payload = 0;
  uint8_t flags[8]{};
};
static_assert(sizeof(GatherMessage) == 32);
static_assert(offsetof(GatherMessage, actor) == 8);
static_assert(offsetof(GatherMessage, payload) == 0x10);
static_assert(offsetof(GatherMessage, flags) == 0x18);
}
