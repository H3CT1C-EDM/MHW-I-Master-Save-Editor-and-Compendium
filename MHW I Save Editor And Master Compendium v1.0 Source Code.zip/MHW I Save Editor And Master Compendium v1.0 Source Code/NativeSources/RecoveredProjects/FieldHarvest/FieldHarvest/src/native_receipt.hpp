#pragma once
#include <cstdint>
#include <cstddef>
namespace fh {
// Independently checked against captured MHW .text at RVA 0x18989e0.
struct NativeReceipt {
  uint32_t item, quantity, unstored;
  uint32_t secondary_item, secondary_quantity, secondary_unstored, extra;
  uint8_t flag0, special, flag2, reserved0, reserved1;
  uint8_t padding[3];
};
static_assert(sizeof(NativeReceipt) == 36);
static_assert(offsetof(NativeReceipt, special) == 0x1d);
inline bool ordinary_receipt_complete(const NativeReceipt &r,
                                      uint32_t item, int32_t amount) {
  return item && item != UINT32_MAX && amount > 0 &&
         r.item == item && r.quantity == uint32_t(amount) && !r.unstored &&
         !r.secondary_item && !r.secondary_quantity && !r.secondary_unstored &&
         !r.extra && r.flag0 <= 1 && !r.special && r.flag2 <= 1 &&
         !r.reserved0 && !r.reserved1;
}
}
