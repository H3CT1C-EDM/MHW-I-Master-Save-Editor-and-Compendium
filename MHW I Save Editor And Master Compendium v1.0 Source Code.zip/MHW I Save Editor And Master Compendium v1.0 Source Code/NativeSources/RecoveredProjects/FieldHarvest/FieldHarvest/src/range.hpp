#pragma once
#include <cmath>
namespace fh {
struct Position { float x, y, z; };
inline bool finite_position(Position p) {
  return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
}
inline bool within_radius(Position a, Position b, float radius) {
  if (!finite_position(a) || !finite_position(b) ||
      !std::isfinite(radius) || radius <= 0) return false;
  const double x = double(a.x) - b.x;
  const double y = double(a.y) - b.y;
  const double z = double(a.z) - b.z;
  return x*x + y*y + z*z <= double(radius)*radius;
}
}
