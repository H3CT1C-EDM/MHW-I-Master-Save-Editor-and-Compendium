#pragma once
#include <cmath>
#include <cstdint>
namespace fh {
inline bool life_eligible(uint64_t actor_flags, uint8_t deactivated, uint32_t id, float size) {
  return (actor_flags & 8u) && deactivated == 0 && id < 128 &&
      std::isfinite(size) && size > 0 && size <= 20;
}
inline bool trace_eligible(uint32_t category, uint32_t flags, uint32_t availability) {
  // Standard monster traces only; special quest/event trace systems stay native.
  return category == 2 && (availability & 3u) == 3u &&
      !(flags & ((1u << 15) | (1u << 17)));
}
}
