#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "al/al_plugin.h"
#include "drain.hpp"
#include "extras.hpp"
#include "range.hpp"
#include "profile.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_set>
#include <vector>
#include <windows.h>
#ifndef FIELD_SWEEP
#define FIELD_SWEEP 0
#endif
namespace {
constexpr const char *Name =
    FIELD_SWEEP ? "fieldharvest_field" : "fieldharvest_selected";
const al_api_t *api = nullptr;
al_plugin_t *self = nullptr;
const al_hooks_t *hooks = nullptr;
const al_frame_t *frames = nullptr;
uintptr_t base = 0, node_dti = 0, enemy_dti = 0, tail_dti = 0;
uintptr_t fish_dti = 0, trace_dti = 0;
bool collect_fish = true, collect_wildlife = true, collect_tracks = true;
thread_local bool extra_native_work = false;
using FinalizeFn = void (*)(uintptr_t, uint8_t);
using NativeOne = void (*)(uintptr_t);
FinalizeFn next_finalize = nullptr;
NativeOne next_trace_complete = nullptr;
std::atomic<bool> failed{false}, exiting{false}, enabled{true}, ready{false};
std::atomic<uintptr_t> units{0};
std::atomic<bool> cancel_requested{false};
unsigned max_targets = 32, max_per_frame = 1, batch_seconds = 30;
float collection_radius = 1000.0f;
thread_local const char *operation = "idle";
thread_local uintptr_t diagnostic_target = 0;
thread_local unsigned diagnostic_kind = 0;
uint64_t tick = 0;
uint32_t frame_handle = 0;
std::vector<uint32_t> hook_handles;
void say(al_log_level_t level, const char *fmt, ...) {
  if (!api)
    return;
  char b[768];
  va_list a;
  va_start(a, fmt);
  vsnprintf(b, sizeof(b), fmt, a);
  va_end(a);
  api->log(self, level, b);
}
LONG fault_details(EXCEPTION_POINTERS *ep) {
  auto r = ep ? ep->ExceptionRecord : nullptr;
  say(AL_LOG_ERROR, "FAULT_DETAIL operation=%s target=%p kind=%u thread=%lu code=0x%08lx instruction=%p access=%llu address=%p",
      operation, reinterpret_cast<void *>(diagnostic_target), diagnostic_kind,
      GetCurrentThreadId(), r ? r->ExceptionCode : 0,
      r ? r->ExceptionAddress : nullptr,
      static_cast<unsigned long long>(r && r->NumberParameters > 0 ? r->ExceptionInformation[0] : 0),
      reinterpret_cast<void *>(r && r->NumberParameters > 1 ? r->ExceptionInformation[1] : 0));
  return EXCEPTION_EXECUTE_HANDLER;
}
void fault() {
  failed.store(true);
  say(AL_LOG_ERROR, "STOP native_access_fault; no completed award is replayed; "
                    "restart before retesting");
  api->set_status(self, AL_STATUS_DISABLED,
                  "Native access fault; inspect log and restart");
}
bool active() {
  return ready.load() && enabled.load() && !failed.load() && !exiting.load();
}
template <class T> bool load(uintptr_t p, T &v) {
  SIZE_T n = 0;
  return p > 65535 &&
         ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<void *>(p), &v,
                           sizeof(v), &n) &&
         n == sizeof(v);
}
template <class T> T get(uintptr_t p, T fallback = {}) {
  T v{};
  return load(p, v) ? v : fallback;
}
bool live(uintptr_t p) {
  uint32_t flags;
  return load(p + 0xc, flags) && (flags & 0xe) != 0;
}
bool code(uintptr_t p) { return p >= base + 0x1000 && p < base + 0x2e1202c; }
uintptr_t dti_from_getter(uintptr_t fn) {
  uint8_t b[8];
  SIZE_T n = 0;
  if (!code(fn) ||
      !ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<void *>(fn), b,
                         8, &n) ||
      n != 8 || b[0] != 0x48 || b[1] != 0x8d || b[2] != 5 || b[7] != 0xc3)
    return 0;
  int32_t disp;
  memcpy(&disp, b + 3, 4);
  return fn + 7 + disp;
}
uintptr_t dti(uintptr_t p) {
  auto vt = get<uintptr_t>(p);
  if (vt < base + 0x2e13000 || vt >= base + 0x3e77f8e)
    return 0;
  return dti_from_getter(get<uintptr_t>(vt + 0x20));
}
bool inherits(uintptr_t p, uintptr_t expected) {
  auto at = dti(p);
  for (unsigned i = 0; at && i < 32; ++i) {
    if (at == expected)
      return true;
    if (at < base + 0x3e78000 || at >= base + 0x5216000)
      return false;
    auto next = get<uintptr_t>(at + 0x20);
    if (next == at)
      return false;
    at = next;
  }
  return false;
}
using FindPlayer = uintptr_t (*)(uintptr_t);
using VoidOne = void (*)(uintptr_t);
using ReceiptFn = void *(*)(void *, uint32_t, int32_t);
using UnitAddFn = bool (*)(uintptr_t, int, uintptr_t, uint64_t);
ReceiptFn next_receipt = nullptr;
UnitAddFn next_top = nullptr, next_bottom = nullptr;
uintptr_t player() {
  auto manager = get<uintptr_t>(base + 0x500eca0);
  if (!manager)
    return 0;
  auto p =
      reinterpret_cast<FindPlayer>(base + profile::FindPlayer.rva)(manager);
  return live(p) ? p : 0;
}
bool solo(uintptr_t p) {
  auto manager = get<uintptr_t>(base + 0x500eca0);
  if (!manager || !live(p))
    return false;
  unsigned count = 0;
  bool found = false;
  for (unsigned i = 0; i < 24; ++i) {
    auto slot = manager + 0x40 + i * 0x740;
    int a = get<int>(slot + 0x10, -1), b = get<int>(slot + 0x14, -1);
    if (a < 0 && b < 0)
      continue;
    auto other = get<uintptr_t>(slot + 0x18);
    if (!live(other))
      continue;
    if (other == p)
      found = true;
    if (++count > 1)
      return false;
  }
  return found && count == 1;
}
uint32_t location() {
  auto main = get<uintptr_t>(base + 0x51c42b8);
  return get<uint32_t>(main + 0xd328, 0xffffffffu);
}
struct Receipt {
  unsigned calls = 0;
  bool ok = true;
};
thread_local Receipt *telemetry = nullptr;
struct TelemetryScope {
  Receipt *old;
  explicit TelemetryScope(Receipt &r) : old(telemetry) { telemetry = &r; }
  ~TelemetryScope() { telemetry = old; }
};
void *receipt_hook(void *out, uint32_t item, int32_t amount) {
  auto r = next_receipt(out, item, amount);
  if (telemetry) {
    ++telemetry->calls;
    fh::NativeReceipt result{};
    SIZE_T n = 0;
    bool valid = r &&
                 ReadProcessMemory(GetCurrentProcess(), r, &result, sizeof(result), &n) &&
                 n == sizeof(result);
    bool complete = valid && fh::ordinary_receipt_complete(result, item, amount);
    say(AL_LOG_INFO, "RECEIPT input_item=%u qty=%d item=%u qty=%u unstored=%u secondary=%u,%u,%u extra=%u flags=%u,%u,%u complete=%d",
        item, amount, result.item, result.quantity, result.unstored,
        result.secondary_item, result.secondary_quantity, result.secondary_unstored,
        result.extra, result.flag0, result.special, result.flag2, complete);
    telemetry->ok = telemetry->ok && complete;
  }
  return r;
}
enum class Kind { None, Node, Body, Tail, Fish, Wildlife, Track };
// uMhModel::Position is an inline Vector3 at +0x160 (SPL Model.cs).
bool read_position(uintptr_t object, fh::Position &out) {
  return live(object) && load(object + 0x160, out) && fh::finite_position(out);
}
bool in_range(uintptr_t target, uintptr_t p) {
  fh::Position a{}, b{};
  return read_position(target, a) && read_position(p, b) &&
         fh::within_radius(a, b, collection_radius);
}
struct Target {
  uintptr_t ptr = 0, vt = 0, queue = 0;
  uint32_t rno = 0;
  Kind kind = Kind::None;
  uint64_t token = 0;
};
uint64_t identity(uintptr_t ptr, uintptr_t vt, uint32_t rno) {
  return uint64_t(ptr) ^ ((uint64_t(vt) << 19) | (uint64_t(vt) >> 45)) ^
         (uint64_t(rno) << 32);
}
Target classify(uintptr_t p) {
  Target t;
  if (!live(p))
    return t;
  t.ptr = p;
  t.vt = get<uintptr_t>(p);
  t.rno = get<uint32_t>(p + 8);
  t.token = identity(p, t.vt, t.rno);
  if (inherits(p, trace_dti)) {
    t.kind = Kind::Track;
    t.queue = get<uintptr_t>(p + 0x260);
  } else if (inherits(p, base + 0x5029758)) {
    t.kind = inherits(p, fish_dti) ? Kind::Fish : Kind::Wildlife;
  } else if (inherits(p, node_dti)) {
    t.kind = Kind::Node;
    t.queue = p + 0xcc0;
  } else if (inherits(p, tail_dti)) {
    t.kind = Kind::Tail;
    t.queue = p + 0x7640 + 0xa20;
  } else if (inherits(p, enemy_dti)) {
    t.kind = Kind::Body;
    t.queue = p + 0x1de70 + 0xa20;
  } else
    return {};
  return t;
}
fh::Snapshot snapshot(const Target &t) {
  fh::Snapshot s;
  if (!t.ptr || !live(t.ptr) || get<uintptr_t>(t.ptr) != t.vt ||
      get<uint32_t>(t.ptr + 8) != t.rno)
    return s;
  if (t.kind == Kind::Fish || t.kind == Kind::Wildlife) {
    uint8_t done = 0xff;
    uint64_t flags = 0;
    uint32_t id = 0xffffffffu;
    float size = 0;
    if (!load(t.ptr + 0x11b6, done) || !load(t.ptr + 0x60, flags) ||
        !load(t.ptr + 0x1af0, id) || !load(t.ptr + 0x11bc, size)) return {};
    s = {t.token, done ? 0u : 1u, true,
         fh::life_eligible(flags, done, id, size) &&
             (t.kind == Kind::Fish ? collect_fish : collect_wildlife)};
    return s;
  }
  if (t.kind == Kind::Track) {
    if (!t.queue || get<uintptr_t>(t.ptr + 0x260) != t.queue ||
        get<uintptr_t>(t.queue + 8) != t.ptr) return {};
    uint32_t flags = 0, available = 0, category = 0xffffffffu;
    if (!load(t.queue + 0xa4, flags) || !load(t.queue + 0xa8, available) ||
        !load(t.queue + 0x88, category)) return {};
    s = {t.token, (available & 2u) ? 1u : 0u, true,
         collect_tracks && fh::trace_eligible(category, flags, available)};
    return s;
  }
  uint64_t index = 0, queued = 0;
  uint32_t remaining = 0;
  uint8_t dynamic = 0;
  if (!load(t.queue + 0xc8, index) || !load(t.queue + 0xd0, queued) ||
      !load(t.queue + 0xdc, remaining) || !load(t.queue + 0xe0, dynamic) ||
      !fh::queue_sane(index, queued, remaining, dynamic))
    return s;
  s = {t.token, remaining, true, true};
  if (t.kind == Kind::Node) {
    auto flags = get<uint32_t>(t.ptr + 0xe14);
    auto id = get<uint32_t>(t.ptr + 0xdd0);
    auto kind = get<uint32_t>(t.ptr + 0x8d8);
    s.eligible = (get<uint32_t>(t.ptr + 0x928) & 4) != 0 &&
                 get<int>(t.ptr + 0xbfc, -1) == 0 &&
                 (flags & ((1u << 13) | (1u << 10))) == 0 &&
                 get<uint8_t>(t.ptr + 0x282) != 0x3b && !fh::slinger(id, kind);
    if (!dynamic && queued) {
      auto peek = t.queue + 8 + index * 12;
      uint32_t next_id = get<uint32_t>(peek);
      if (fh::slinger(next_id, 0))
        s.eligible = false;
    }
  } else {
    uintptr_t context = t.queue - 0xa20;
    auto owner = get<uintptr_t>(context + 0xb28);
    if (!live(owner))
      s.eligible = false;
    if (t.kind == Kind::Body) {
      auto health = get<uintptr_t>(t.ptr + 0x7670);
      float hp = get<float>(health + 0x64, 1);
      if (owner != t.ptr || !health || !std::isfinite(hp) || hp > 0)
        s.eligible = false;
    }
    if (t.kind == Kind::Tail && get<uintptr_t>(context + 0xb40) != t.ptr)
      s.eligible = false;
  }
  return s;
}
struct Message99 {
  uintptr_t *vt;
  uintptr_t actor;
  uint8_t reserved[240]{};
};
void *message_destroy(void *m, uint32_t) { return m; }
uint32_t message_id(void *) { return 99; }
uintptr_t message_vt[2] = {reinterpret_cast<uintptr_t>(&message_destroy),
                           reinterpret_cast<uintptr_t>(&message_id)};
void send(uintptr_t target, uintptr_t p, uint32_t id) {
  diagnostic_target = target;
  operation = id == 99 ? "prepare_message_99" : id == 15 ? "native_message_15" : "native_message_14";
  auto vt = get<uintptr_t>(target);
  auto fn = get<uintptr_t>(vt + 0xa0);
  if (!code(fn)) throw std::runtime_error("Invalid native receiver");
  using Dispatch = void (*)(uintptr_t, void *);
  if (id == 99) {
    Message99 m{message_vt, p, {}};
    reinterpret_cast<Dispatch>(fn)(target, &m);
    return;
  }
  // The native commit payload is zero, not a pointer to a temporary array.
  // Both layouts are 32 bytes; preparation alone carries an info pointer.
  fh::GatherMessage m{};
  m.vtable = base + (id == 15 ? 0x336dad0 : 0x336dac0);
  m.actor = p;
  // Prepare receivers used here read actor; keep a valid scratch info block
  // matching the native collect context's inline information size (0x90).
  std::array<uint8_t, 0x90> info{};
  if (id == 15) m.payload = reinterpret_cast<uintptr_t>(info.data());
  reinterpret_cast<Dispatch>(fn)(target, &m);
}
struct NativeWorkScope {
  bool old;
  NativeWorkScope() : old(extra_native_work) { extra_native_work = true; }
  ~NativeWorkScope() { extra_native_work = old; }
};
struct TrackMessage {
  uintptr_t vtable = 0, actor = 0;
  float before = 0, after = 0;
  uint8_t increased = 0, padding[7]{};
};
static_assert(sizeof(TrackMessage) == 32);
static_assert(offsetof(TrackMessage, before) == 0x10);
static_assert(offsetof(TrackMessage, increased) == 0x18);
bool native_capture(const Target &t) {
  operation = "native_capture";
  NativeWorkScope scope;
  auto quests = get<uintptr_t>(base + 0x51c4638);
  auto stats = get<uintptr_t>(base + 0x500ed30);
  if (!quests || !stats) return false;
  uint32_t mode = t.kind == Kind::Fish ? 0u : 1u;
  auto save_manager = get<uintptr_t>(base + 0x5013948);
  if (t.kind == Kind::Fish && !save_manager)
    return false;
  // Net completion resets its transient result category before finalization.
  if (mode == 1)
    reinterpret_cast<void (*)(uintptr_t, uint32_t)>(base + profile::CatchReset.rva)(quests + 0x15a50, mode);
  reinterpret_cast<FinalizeFn>(base + profile::CaptureFinalize.rva)(t.ptr, 0);
  if (t.kind == Kind::Fish) {
    auto save = reinterpret_cast<uintptr_t (*)(uintptr_t)>(base + profile::GetSave.rva)(save_manager);
    if (save) reinterpret_cast<void (*)(uintptr_t, uint32_t)>(base + profile::FishFlag.rva)(save, 0x10);
    reinterpret_cast<NativeOne>(base + profile::FishStat.rva)(stats);
  }
  reinterpret_cast<NativeOne>(base + profile::CaptureStat.rva)(stats);
  if (reinterpret_cast<bool (*)(uintptr_t)>(base + profile::RareCapture.rva)(t.ptr))
    reinterpret_cast<void (*)(uintptr_t, uint32_t)>(base + profile::RareStat.rva)(stats, 1);
  // Native mode zero is rod fishing; mode one is capture net. Reset the same
  // transient result category as the native completion helper before enqueue.
  if (mode == 0)
    reinterpret_cast<void (*)(uintptr_t, uint32_t)>(base + profile::CatchReset.rva)(quests + 0x15a50, mode);
  reinterpret_cast<void (*)(uintptr_t, uintptr_t, uint32_t)>(base + profile::CatchQueue.rva)(quests, t.ptr, mode);
  reinterpret_cast<NativeOne>(base + profile::CreatureDeactivate.rva)(t.ptr);
  return true;
}
bool native_track(const Target &t, uintptr_t p) {
  operation = "native_track";
  NativeWorkScope scope;
  auto manager = get<uintptr_t>(base + 0x5013880);
  auto stats = get<uintptr_t>(base + 0x500ed30);
  if (!manager || !stats) return false;
  auto owner = get<uintptr_t>(t.queue + 0x68);
  if (!live(owner)) owner = 0;
  auto count = reinterpret_cast<uint32_t (*)(uintptr_t, uintptr_t)>(base + profile::TraceCount.rva);
  auto progress = reinterpret_cast<float (*)(uintptr_t, uintptr_t)>(base + profile::TraceProgress.rva);
  uint32_t before = count(manager, owner);
  TrackMessage message{};
  message.vtable = base + 0x336dac0;
  message.actor = p;
  message.before = progress(manager, owner);
  reinterpret_cast<NativeOne>(base + profile::TraceDeactivate.rva)(t.ptr);
  reinterpret_cast<void (*)(uintptr_t, uintptr_t)>(base + profile::TraceRecord.rva)(manager, t.queue);
  uint32_t after = count(manager, owner);
  message.after = progress(manager, owner);
  message.increased = before < after;
  reinterpret_cast<void (*)(uintptr_t, void *)>(base + profile::TraceDispatch.rva)(t.queue, &message);
  reinterpret_cast<NativeOne>(base + profile::TrackStat.rva)(stats);
  return true;
}
struct Pending {
  Target t;
  uintptr_t p = 0;
  uint64_t stage = 0;
  bool complete = false;
};
std::mutex pending_mutex;
Pending pending;
struct Sweep {
  bool running = false;
  uintptr_t p = 0;
  uint64_t stage = 0, expires = 0;
  std::vector<Target> targets;
  size_t cursor = 0;
  unsigned commits = 0, blocked = 0;
};
Sweep sweep;
void trigger_special(uintptr_t p, const char *source) {
  if (!FIELD_SWEEP || extra_native_work || !active() || !solo(p) || p != player()) return;
  std::lock_guard<std::mutex> lock(pending_mutex);
  pending = {{}, p, location(), true};
  say(AL_LOG_INFO, "SPECIAL_TRIGGER source=%s", source);
}
void finalize_hook(uintptr_t creature, uint8_t flag) {
  next_finalize(creature, flag);
  trigger_special(player(), "native_capture");
}
void trace_complete_hook(uintptr_t p) {
  next_trace_complete(p);
  trigger_special(p, "native_track");
}
using AwardFn = void (*)(uintptr_t);
AwardFn next_node_award = nullptr, next_carve_award = nullptr;
void observed_award(uintptr_t context, bool carving) {
  auto next = carving ? next_carve_award : next_node_award;
  if (extra_native_work || !active()) { next(context); return; }
  const auto p = player();
  if (!p || !solo(p)) { next(context); return; }
  Target t;
  if (carving) {
    auto tail = get<uintptr_t>(context + 0xb40);
    auto body = get<uintptr_t>(context + 0xb28);
    t = classify(live(tail) ? tail : body);
    if ((t.kind != Kind::Body && t.kind != Kind::Tail) ||
        t.queue != context + 0xa20) t = {};
  } else t = classify(context);
  auto before = snapshot(t);
  Receipt receipt;
  {
    TelemetryScope observe(receipt);
    next(context);
  }
  if (!before.valid || !before.eligible || !before.remaining) return;
  auto after = snapshot(t);
  const bool progress = after.valid && before.remaining == after.remaining + 1;
  const bool complete = receipt.calls == 1 && receipt.ok;
  say(AL_LOG_INFO, "NATIVE_AWARD source=%s kind=%u rno=%u remaining=%u->%u receipts=%u complete=%d progress=%d",
      carving ? "carve" : "node", unsigned(t.kind), t.rno,
      before.remaining, after.remaining, receipt.calls, complete, progress);
  if (!progress || !complete) {
    cancel_requested = true;
    return;
  }
  std::lock_guard<std::mutex> lock(pending_mutex);
  pending = {t, p, location(), true};
}
void node_award_hook(uintptr_t node) {
  __try { observed_award(node, false); }
  __except (fault_details(GetExceptionInformation())) { telemetry = nullptr; fault(); }
}
void carve_award_hook(uintptr_t context) {
  __try { observed_award(context, true); }
  __except (fault_details(GetExceptionInformation())) { telemetry = nullptr; fault(); }
}
bool add_top_hook(uintptr_t manager, int line, uintptr_t unit, uint64_t group) {
  if (dti(manager) == base + 0x500ea38)
    units = manager;
  return next_top(manager, line, unit, group);
}
bool add_bottom_hook(uintptr_t manager, int line, uintptr_t unit,
                     uint64_t group) {
  if (dti(manager) == base + 0x500ea38)
    units = manager;
  return next_bottom(manager, line, unit, group);
}
bool cancelled(uintptr_t p, uint64_t stage) {
  return !active() || player() != p || !solo(p) || location() != stage;
}
struct Backend {
  Target t;
  uintptr_t p;
  uint64_t stage;
  bool cancelled() { return ::cancelled(p, stage); }
  fh::Snapshot snapshot() {
    auto s = ::snapshot(t);
    if (FIELD_SWEEP && !in_range(t.ptr, p)) s.eligible = false;
    return s;
  }
  fh::Award commit() {
    if (t.kind == Kind::Fish || t.kind == Kind::Wildlife) {
      if (!native_capture(t)) return {false};
      auto after = ::snapshot(t);
      // Catch-result UI builder returns false even for user-verified normal
      // catches. Native deactivation is the once-only progress predicate here.
      return {after.valid && after.remaining == 0};
    }
    if (t.kind == Kind::Track) {
      if (!native_track(t, p)) return {false};
      auto after = ::snapshot(t);
      return {after.valid && after.remaining == 0};
    }
    Receipt r;
    {
      TelemetryScope observe(r);
      NativeWorkScope suppress_retrigger;
      send(t.ptr, p, 15);
      send(t.ptr, p, 14);
    }
    return {r.calls == 1 && r.ok};
  }
};
void enumerate(std::vector<Target> &out, uintptr_t p, size_t capacity) {
  operation = "enumerate";
  size_t scanned = 0, nearby = 0, rejected = 0;
  uintptr_t manager = units.load();
  if (!manager) {
    say(AL_LOG_WARNING, "SWEEP native_unit_manager_not_observed");
    return;
  }
  uint32_t lines = get<uint32_t>(manager + 0x3e38);
  if (lines == 0 || lines > 64) {
    say(AL_LOG_WARNING, "SWEEP no_valid_unit_manager");
    return;
  }
  std::unordered_set<uintptr_t> seen;
  seen.reserve(8192);
  for (uint32_t i = 0; i < lines; ++i) {
    uintptr_t at = get<uintptr_t>(manager + 0x38 + i * 0xf8 + 0x48);
    unsigned traversed = 0;
    while (at && traversed++ < 16384 && out.size() < capacity) {
      if (!seen.insert(at).second)
        break;
      if (seen.size() > 16384) {
        say(AL_LOG_WARNING, "SWEEP enumeration_cap reached=16384");
        return;
      }
      auto next = get<uintptr_t>(at + 0x30);
      ++scanned;
      diagnostic_target = at;
      diagnostic_kind = 0;
      // Range rejection precedes classification, queue reads and preparation.
      if (!in_range(at, p)) { ++rejected; at = next; continue; }
      ++nearby;
      auto t = classify(at);
      diagnostic_kind = unsigned(t.kind);
      auto s = snapshot(t);
      if (s.valid && s.eligible) {
        // Native message 99 initializes an untouched finite queue with the
        // game's own skill rules. The native handler refuses this once the node
        // is collected or already prepared.
        if (!s.remaining && t.kind == Kind::Node &&
            (get<uint32_t>(at + 0xe14) & 0x110) == 0) {
          send(at, p, 99);
          s = snapshot(t);
        }
        if (s.valid && s.eligible && s.remaining)
          out.push_back(t);
      }
      at = next;
    }
  }
  say(AL_LOG_INFO, "RANGE_FILTER radius_units=%.0f scanned=%zu nearby=%zu rejected=%zu queued=%zu cap=%zu",
      collection_radius, scanned, nearby, rejected, out.size(), capacity);
}
void process_frame() {
  ++tick;
  if (!active())
    return;
  if (cancel_requested.exchange(false)) {
    sweep.running = false;
    std::lock_guard<std::mutex> lock(pending_mutex);
    pending = {};
    say(AL_LOG_WARNING, "BATCH_CANCEL reason=incomplete_native_receipt");
    return;
  }
  Pending work;
  {
    std::lock_guard<std::mutex> lock(pending_mutex);
    work = pending;
    pending = {};
  }
  if (work.complete) {
    if (cancelled(work.p, work.stage)) {
      say(AL_LOG_WARNING, "ABORT player_or_stage_changed");
      return;
    }
    sweep = {};
    sweep.running = true;
    sweep.p = work.p;
    sweep.stage = work.stage;
    sweep.expires = GetTickCount64() + uint64_t(batch_seconds) * 1000;
    if (work.t.ptr && (!FIELD_SWEEP || in_range(work.t.ptr, work.p))) sweep.targets.push_back(work.t);
    if (FIELD_SWEEP) {
      std::vector<Target> extra;
      enumerate(extra, work.p, max_targets - sweep.targets.size());
      for (auto &t : extra)
        if (t.ptr != work.t.ptr)
          sweep.targets.push_back(t);
    }
    say(AL_LOG_INFO, "BATCH_START mode=%s targets=%zu loaded_objects_only=1",
        FIELD_SWEEP ? "field" : "selected", sweep.targets.size());
  }
  if (!sweep.running)
    return;
  if (GetTickCount64() > sweep.expires || cancelled(sweep.p, sweep.stage)) {
    say(AL_LOG_WARNING,
        "BATCH_CANCEL processed=%zu reason=timeout_or_player_or_stage",
        sweep.cursor);
    sweep.running = false;
    return;
  }
  unsigned budget = max_per_frame;
  while (budget && sweep.cursor < sweep.targets.size()) {
    auto &t = sweep.targets[sweep.cursor];
    diagnostic_target = t.ptr;
    diagnostic_kind = unsigned(t.kind);
    operation = "target_snapshot";
    say(AL_LOG_INFO, "TARGET_BEGIN index=%zu kind=%u rno=%u ptr=%p in_range=%d",
        sweep.cursor, unsigned(t.kind), t.rno, reinterpret_cast<void *>(t.ptr),
        in_range(t.ptr, sweep.p));
    Backend backend{t, sweep.p, sweep.stage};
    auto result = fh::drain(backend, t.token, budget);
    budget -= result.commits;
    sweep.commits += result.commits;
    say(AL_LOG_INFO, "TARGET kind=%u rno=%u extra_commits=%u stop=%u",
        unsigned(t.kind), t.rno, result.commits, unsigned(result.stop));
    if (result.stop == fh::Stop::ReceiptIncomplete ||
        result.stop == fh::Stop::UnexpectedProgress ||
        result.stop == fh::Stop::Cancelled) {
      sweep.running = false;
      break;
    }
    if (result.stop == fh::Stop::Budget)
      break;
    ++sweep.cursor;
    if (result.stop != fh::Stop::Empty)
      ++sweep.blocked;
    // Empty/blocked objects do not consume native-commit budget; cap target
    // iteration separately.
    if (sweep.cursor % 64 == 0)
      break;
  }
  if (sweep.cursor >= sweep.targets.size()) {
    say(AL_LOG_INFO, "BATCH_DONE targets=%zu extra_commits=%u skipped=%u",
        sweep.targets.size(), sweep.commits, sweep.blocked);
    sweep.running = false;
  }
}
void AL_CALL on_frame(al_plugin_t *, al_frame_event_t, const al_frame_info_t *,
                      void *) {
  __try {
    process_frame();
  } __except (fault_details(GetExceptionInformation())) {
    telemetry = nullptr;
    sweep.running = false;
    fault();
  }
}
void AL_CALL on_phase(al_plugin_t *, al_phase_t phase, const void *) {
  if (phase == AL_PHASE_GAME_READY && !failed.load()) {
    bool ok = true;
    for (auto h : hook_handles)
      if (hooks->state(self, h) != AL_HOOK_ACTIVE)
        ok = false;
    if (GetModuleHandleW(L"fieldharvest_discovery.dll") ||
        GetModuleHandleW(L"OneTouchGathering.dll") ||
        GetModuleHandleW(L"OneTouchGatheringProbe.dll"))
      ok = false;
    if (!ok) {
      failed = true;
      for (auto h : hook_handles)
        hooks->set_enabled(self, h, 0);
      say(AL_LOG_ERROR,
          "STARTUP_FAILED hook inactive or conflicting example plugin loaded");
      api->set_status(
          self, AL_STATUS_DISABLED,
          "A hook failed or the old gathering plugin is still installed");
      return;
    }
    ready = true;
    say(AL_LOG_INFO, "READY all_hooks_active=1 runtime_profile_verified=1 "
                     "gameplay_validation_pending=1");
    api->set_status(self, enabled ? AL_STATUS_ACTIVE : AL_STATUS_DISABLED,
                    enabled ? nullptr : "Disabled in FieldHarvest.ini");
  }
  if (phase == AL_PHASE_EXITING || phase == AL_PHASE_SHUTDOWN) {
    exiting = true;
  }
}
bool attach(const profile::Point &point, const char *name, void *detour,
            void **next) {
  al_hook_t h{};
  h.size = sizeof(h);
  h.name = name;
  h.pattern = point.bytes;
  h.address = reinterpret_cast<void *>(base + point.rva);
  h.detour = detour;
  h.next = next;
  auto handle = hooks->hook(self, &h);
  if (!handle)
    return false;
  hook_handles.push_back(handle);
  return true;
}
void rollback() {
  for (auto h : hook_handles)
    hooks->set_enabled(self, h, 0);
}
const char *const exe_hashes[] = {profile::ExeHash, nullptr};
const al_plugin_info_t info = {sizeof(al_plugin_info_t),
                               AL_API_VERSION,
                               Name,
                               FIELD_SWEEP ? "FieldHarvest — Loaded Field"
                                           : "FieldHarvest — Selected Target",
                               "0.4.3",
                               AL_PHASE_BIT(AL_PHASE_GAME_READY) |
                                   AL_PHASE_BIT(AL_PHASE_EXITING) |
                                   AL_PHASE_BIT(AL_PHASE_SHUTDOWN),
                               0,
                               nullptr,
                               nullptr,
                               exe_hashes,
                               on_phase,
                               nullptr};
} // namespace
extern "C" AL_PLUGIN_EXPORT const al_plugin_info_t *AL_CALL al_plugin_info() {
  return &info;
}
extern "C" AL_PLUGIN_EXPORT al_result_t AL_CALL
al_plugin_init(const al_api_t *a, const al_init_t *i) {
  api = a;
  self = i->self;
  base = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
  if (GetModuleHandleW(FIELD_SWEEP ? L"fieldharvest_selected.dll"
                                   : L"fieldharvest_field.dll")) {
    api->set_status(self, AL_STATUS_DISABLED,
                    "Install only one FieldHarvest edition");
    return AL_ERROR;
  }
  if (GetModuleHandleW(L"fieldharvest_discovery.dll") ||
        GetModuleHandleW(L"OneTouchGathering.dll") ||
      GetModuleHandleW(L"OneTouchGatheringProbe.dll")) {
    api->set_status(self, AL_STATUS_DISABLED,
                    "Disable the old OneTouchGathering/Probe plugin before "
                    "using FieldHarvest");
    return AL_ERROR;
  }
  hooks = static_cast<const al_hooks_t *>(
      api->get_interface(self, AL_HOOKS_INTERFACE, AL_HOOKS_VERSION));
  frames = static_cast<const al_frame_t *>(
      api->get_interface(self, AL_FRAME_INTERFACE, AL_FRAME_VERSION));
  auto game = static_cast<const al_game_t *>(
      api->get_interface(self, AL_GAME_INTERFACE, AL_GAME_VERSION));
  if (!hooks || !frames || !game || !game->exe_sha256 ||
      strcmp(game->exe_sha256, profile::ExeHash)) {
    api->set_status(self, AL_STATUS_DISABLED,
                    "Required Astera services or exact MHW build unavailable");
    return AL_ERROR;
  }
  std::wstring config = (i->folder ? i->folder : L"");
  config += L"\\FieldHarvest.ini";
  enabled = GetPrivateProfileIntW(L"FieldHarvest", L"Enabled", 1,
                                  config.c_str()) != 0;
  // AnimationSpeed from older INIs is deliberately ignored.
  max_targets = std::clamp(GetPrivateProfileIntW(L"FieldHarvest", L"MaxTargets",
                                                 32, config.c_str()),
                           1u, 128u);
  batch_seconds =
      std::clamp(GetPrivateProfileIntW(L"FieldHarvest", L"BatchTimeoutSeconds",
                                       30, config.c_str()),
                 1u, 120u);
  max_per_frame =
      std::clamp(GetPrivateProfileIntW(L"FieldHarvest", L"CommitsPerFrame", 1,
                                       config.c_str()),
                 1u, 16u);
  collection_radius = static_cast<float>(std::clamp(
      GetPrivateProfileIntW(L"FieldHarvest", L"CollectionRadiusUnits", 1000, config.c_str()),
      100u, 5000u));
  say(AL_LOG_INFO, "LIMITS radius_units=%.0f max_targets=%u commits_per_frame=%u position_offset=0x160",
      collection_radius, max_targets, max_per_frame);
  collect_fish = GetPrivateProfileIntW(L"FieldHarvest", L"CollectFish", 1, config.c_str()) != 0;
  collect_wildlife = GetPrivateProfileIntW(L"FieldHarvest", L"CollectWildlife", 1, config.c_str()) != 0;
  collect_tracks = GetPrivateProfileIntW(L"FieldHarvest", L"CollectTracks", 1, config.c_str()) != 0;
  fish_dti = dti_from_getter(base + profile::FishDTI.rva);
  trace_dti = dti_from_getter(base + profile::TraceDTI.rva);
  for (auto point : profile::ExtraChecks) {
    std::string pattern(point.bytes);
    size_t at = 0;
    for (uint32_t off = 0; at < pattern.size(); ++off, at += 3) {
      unsigned expected = 0;
      if (sscanf(pattern.c_str() + at, "%2x", &expected) != 1 ||
          get<uint8_t>(base + point.rva + off) != expected) {
        api->set_status(self, AL_STATUS_DISABLED, "Special collection native profile differs");
        return AL_ERROR;
      }
    }
  }
  if (get<uintptr_t>(base + 0x336dac8) != base + profile::TrackMessageID.rva ||
      get<uintptr_t>(base + 0x336dad8) != base + profile::PrepareMessageID.rva ||
      get<uint8_t>(base + profile::PrepareMessageID.rva) != 0xb8 ||
      get<uint32_t>(base + profile::PrepareMessageID.rva + 1) != 15 ||
      get<uint8_t>(base + profile::PrepareMessageID.rva + 5) != 0xc3) {
    api->set_status(self, AL_STATUS_DISABLED, "Native trace message profile differs");
    return AL_ERROR;
  }
  node_dti = dti_from_getter(base + profile::NodeDTI.rva);
  enemy_dti = dti_from_getter(base + profile::EnemyDTI.rva);
  tail_dti = dti_from_getter(base + profile::TailDTI.rva);
  if (!node_dti || !enemy_dti || !tail_dti || !fish_dti || !trace_dti) {
    api->set_status(self, AL_STATUS_DISABLED, "Native class profile differs");
    return AL_ERROR;
  }
  bool ok = attach(profile::NodeAward, "Gather:NodeAward",
                   reinterpret_cast<void *>(&node_award_hook),
                   reinterpret_cast<void **>(&next_node_award)) &&
            attach(profile::CarveAward, "Gather:CarveAward",
                   reinterpret_cast<void *>(&carve_award_hook),
                   reinterpret_cast<void **>(&next_carve_award)) &&
            attach(profile::Receipt, "Gather:Receipt",
                   reinterpret_cast<void *>(&receipt_hook),
                   reinterpret_cast<void **>(&next_receipt));
  if (FIELD_SWEEP)
    ok = ok &&
         attach(profile::AddTop, "Units:AddTop",
                reinterpret_cast<void *>(&add_top_hook),
                reinterpret_cast<void **>(&next_top)) &&
         attach(profile::AddBottom, "Units:AddBottom",
                reinterpret_cast<void *>(&add_bottom_hook),
                reinterpret_cast<void **>(&next_bottom));
  if (FIELD_SWEEP)
    ok = ok && attach(profile::CaptureFinalize, "Special:CaptureFinalize",
        reinterpret_cast<void *>(&finalize_hook), reinterpret_cast<void **>(&next_finalize)) &&
        attach(profile::TrackComplete, "Special:TrackComplete",
        reinterpret_cast<void *>(&trace_complete_hook), reinterpret_cast<void **>(&next_trace_complete));
  if (ok) {
    frame_handle = frames->subscribe(self, AL_FRAME_END, on_frame, nullptr);
    ok = frame_handle != 0;
  }
  if (!ok) {
    failed = true;
    rollback();
    api->set_status(self, AL_STATUS_DISABLED,
                    "Could not register native hooks or frame callback");
    return AL_ERROR;
  }
  say(AL_LOG_INFO,
      "FieldHarvest 0.4.3 native-receipt candidate mode=%s animation_override=removed solo_gate=1 "
      "source_receipts=1 special_automation=experimental game_tested=0",
      FIELD_SWEEP ? "loaded_field" : "selected");
  api->set_status(self, AL_STATUS_ACTIVE,
                  "Waiting for the title screen and hook activation");
  return AL_OK;
}
