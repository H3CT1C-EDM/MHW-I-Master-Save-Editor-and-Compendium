#pragma once
#include <cstdint>
#include "native_receipt.hpp"
#include "native_message.hpp"
namespace fh {
enum class Stop {
  Empty,
  Blocked,
  Stale,
  NoProgress,
  UnexpectedProgress,
  ReceiptIncomplete,
  Cancelled,
  Budget
};
struct Snapshot {
  uint64_t token = 0;
  uint32_t remaining = 0;
  bool valid = false, eligible = false;
};
struct Award {
  bool receipt_ok = false;
};
struct Result {
  Stop stop;
  uint32_t commits;
};
// Backend must revalidate identity and native eligibility on every snapshot.
// A partially completed native commit is never retried or rolled back.
template <class Backend>
Result drain(Backend &b, uint64_t token, uint32_t max_commits) {
  uint32_t done = 0;
  while (done < max_commits) {
    if (b.cancelled())
      return {Stop::Cancelled, done};
    auto before = b.snapshot();
    if (!before.valid || before.token != token)
      return {Stop::Stale, done};
    if (!before.remaining)
      return {Stop::Empty, done};
    if (!before.eligible)
      return {Stop::Blocked, done};
    auto award = b.commit();
    ++done;
    auto after = b.snapshot();
    if (!award.receipt_ok)
      return {Stop::ReceiptIncomplete, done};
    if (!after.valid || after.token != token)
      return {Stop::Stale, done};
    if (after.remaining >= before.remaining)
      return {Stop::NoProgress, done};
    if (before.remaining - after.remaining != 1)
      return {Stop::UnexpectedProgress, done};
  }
  return {Stop::Budget, done};
}
inline bool slinger(uint32_t id, uint32_t kind) {
  return kind == 0x84 || (id >= 0x290 && id <= 0x292) || id == 0x702 ||
         id == 0xcc || id == 0x6f5;
}
inline bool queue_sane(uint64_t index, uint64_t queued, uint32_t remaining,
                       uint8_t dynamic) {
  return index < 16 && queued <= 16 && remaining <= 64 && dynamic <= 1;
}
} // namespace fh
