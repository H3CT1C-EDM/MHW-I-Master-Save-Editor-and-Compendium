#pragma once
#include <cstdint>
namespace profile {
struct Point {
  uint32_t rva;
  const char *bytes;
};
inline constexpr Point Commit{
    0x179fbb0,
    "40 53 48 83 EC 40 83 B9 34 02 00 00 00 48 8B D9 74 69 48 8B 89 70 01 00"};
inline constexpr Point Receipt{
    0x18989e0,
    "44 89 44 24 18 48 89 4C 24 08 55 57 41 54 41 56 48 8D 6C 24 C1 48 81 EC"};
inline constexpr Point FindPlayer{
    0x1b42010,
    "45 33 C9 4C 8D 41 50 66 0F 1F 84 00 00 00 00 00 33 D2 49 8B C0 83 38 00"};
inline constexpr Point EnemyDead{
    0x1cb94f0,
    "48 8B 81 70 76 00 00 0F 57 C0 0F 2F 40 64 73 10 8B 81 80 EA 01 00 C1 E8"};
inline constexpr Point NodeDTI{0x1cf2510, "48 8D 05 29 66 33 03 C3"};
inline constexpr Point EnemyDTI{0x1cb4500, "48 8D 05 B1 3E 37 03 C3"};
inline constexpr Point TailDTI{0x1c88900, "48 8D 05 49 96 39 03 C3"};
inline constexpr Point AddTop{
    0x2219430,
    "48 89 5C 24 20 55 57 41 57 48 83 EC 30 48 63 EA 4D 8B F9 49 8B D8 48 8B"};
inline constexpr Point AddBottom{
    0x2219070,
    "48 89 5C 24 20 55 57 41 57 48 83 EC 30 48 63 EA 4D 8B F9 49 8B D8 48 8B"};
inline constexpr Point FishDTI{0x1d32b80, "48 8D 05 21 6C 2F 03 C3"};
inline constexpr Point TraceDTI{0x1a7cb70, "48 8D 05 B1 16 5B 03 C3"};
inline constexpr Point CaptureFinalize{0x1d28c00, "48 8B C4 48 89 58 10 55 56 57 41 54 41 55 41 56 41 57 48 8D A8 A8 FE FF"};
inline constexpr Point CreatureDeactivate{0x1d2c090, "40 53 48 83 EC 20 80 B9 B6 11 00 00 00 48 8B D9 0F 85 AA 01 00 00 C6 81"};
inline constexpr Point CatchQueue{0x1ae4d30, "48 89 74 24 18 55 57 41 56 48 8D AC 24 60 FF FF FF 48 81 EC A0 01 00 00"};
inline constexpr Point CatchReset{0x303bd0, "48 63 C2 4C 8D 05 36 BC C1 02 48 8D 14 81 8B 4C 81 08 41 3B 0C 80 73 06"};
inline constexpr Point GetSave{0x1b8dbb0, "48 63 81 A0 00 00 00 48 69 C0 00 CC 26 00 48 03 81 A8 00 00 00 C3 CC CC"};
inline constexpr Point FishFlag{0x1367b60, "48 89 5C 24 18 48 89 74 24 20 57 48 83 EC 20 48 8B F9 8B F2 48 83 C1 08"};
inline constexpr Point FishStat{0x1b4d6d0, "83 79 38 02 75 11 83 79 54 02 75 0B FF 81 F4 70 01 00 E9 49 08 02 00 C3"};
inline constexpr Point CaptureStat{0x1b4d4d0, "83 79 38 02 75 11 83 79 54 02 75 0B FF 81 F8 70 01 00 E9 49 0A 02 00 C3"};
inline constexpr Point RareCapture{0x1d2c3e0, "48 8B 81 A0 0F 00 00 0F B6 80 D3 01 00 00 C3 CC 80 B9 88 11 00 00 00 74"};
inline constexpr Point RareStat{0x1b4d7d0, "83 79 38 02 75 11 83 79 54 02 75 0B 01 91 D8 70 01 00 E9 49 07 02 00 C3"};
inline constexpr Point TraceDeactivate{0x205ced0, "48 8B C4 48 89 48 08 41 56 48 83 EC 50 4C 8B F1 48 8B 89 60 02 00 00 48"};
inline constexpr Point TraceRecord{0x1b87c00, "40 56 41 57 48 83 EC 48 48 8B F1 4C 8B FA 48 8B 0D 1B 71 48 03 F7 41 7C"};
inline constexpr Point TraceCount{0x1b88680, "40 53 48 83 EC 20 48 8B D9 48 85 D2 74 1E E8 2D FF FF FF 48 85 C0 74 14"};
inline constexpr Point TraceProgress{0x1b88900, "48 89 5C 24 08 57 48 83 EC 20 48 8B F9 48 8B DA 48 8B 0D 89 63 48 03 E8"};
inline constexpr Point TraceDispatch{0x1341fe0, "48 8B 49 08 48 85 C9 74 10 F6 41 0C 0E 74 0A 48 8B 01 48 FF A0 A0 00 00"};
inline constexpr Point TrackStat{0x1b4d8e0, "83 79 38 02 75 11 83 79 54 02 75 0B FF 81 DC 70 01 00 E9 39 06 02 00 C3"};
inline constexpr Point TrackMessageID{0x2684e0, "B8 0E 00 00 00 C3"};
inline constexpr Point TrackComplete{0x2046d70, "40 57 48 83 EC 50 48 8B F9 48 8B 89 E0 7A 00 00 48 85 C9 0F 84 C1 02 00"};
inline constexpr Point NodeAward{0x1cf37e0, "40 55 56 48 8D AC 24 B8 FD FF FF 48 81 EC 48 03 00 00"};
inline constexpr Point CarveAward{0xafe790, "48 89 5C 24 20 57 48 81 EC B0 01 00 00 C6 81 98 0B 00 00 00"};
inline constexpr Point PrepareMessageID{0x2684f0, "B8 0F 00 00 00 C3"};
inline constexpr const char *ExeHash =
    "c2ebbbd2c49f216d484e31a5219bed419eb1e5e7d206d02cba040a3ab79d90ea";
inline constexpr Point ExtraChecks[] = {FishDTI, TraceDTI, CaptureFinalize, CreatureDeactivate, CatchQueue, CatchReset, GetSave, FishFlag, FishStat, CaptureStat, RareCapture, RareStat, TraceDeactivate, TraceRecord, TraceCount, TraceProgress, TraceDispatch, TrackStat, TrackMessageID, TrackComplete};
} // namespace profile
