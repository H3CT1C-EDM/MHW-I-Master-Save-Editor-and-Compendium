#include "../src/range.hpp"
#include <cassert>
#include <limits>
int main() {
  using fh::within_radius;
  const fh::Position origin{0,0,0};
  assert(within_radius(origin, {600,0,800}, 1000));
  assert(!within_radius(origin, {600,1,800}, 1000));
  assert(!within_radius(origin, {0,1001,0}, 1000));
  assert(within_radius({-2000,100,500}, {-2000,100,500}, 1000));
  assert(!within_radius(origin, {std::numeric_limits<float>::quiet_NaN(),0,0}, 1000));
  assert(!within_radius(origin, origin, 0));
  assert(!within_radius(origin, {std::numeric_limits<float>::infinity(),0,0}, 1000));
}
