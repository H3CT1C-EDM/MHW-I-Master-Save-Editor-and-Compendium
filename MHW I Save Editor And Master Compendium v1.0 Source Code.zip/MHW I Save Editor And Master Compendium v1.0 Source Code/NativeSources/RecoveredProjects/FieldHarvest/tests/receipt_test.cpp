#include "../src/native_receipt.hpp"
#include "../src/native_message.hpp"
#include <cassert>
#include <cstdio>
int main() {
  fh::NativeReceipt r{100,2,0,0,0,0,0,0,0,1,0,0,{}};
  assert(fh::ordinary_receipt_complete(r,100,2));
  r.unstored=1; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.unstored=2; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.unstored=0; r.quantity=1; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.quantity=2; r.item=101; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.item=100; r.special=1; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.special=0; r.secondary_item=500; assert(!fh::ordinary_receipt_complete(r,100,2));
  r.secondary_item=0; assert(!fh::ordinary_receipt_complete(r,100,0));
  assert(!fh::ordinary_receipt_complete(r,100,-1));
  r.item=0; assert(!fh::ordinary_receipt_complete(r,0,2));
  r.item=UINT32_MAX; assert(!fh::ordinary_receipt_complete(r,UINT32_MAX,2));
  fh::GatherMessage m{};
  assert(m.payload == 0 && m.flags[0] == 0 && m.flags[7] == 0);
  std::puts("PASS: native receipt full/partial/full-inventory/mismatch/special cases; native message layout");
}
