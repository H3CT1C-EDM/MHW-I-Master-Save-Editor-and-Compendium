#include "../src/drain.hpp"
#include <cassert>
#include <cstdio>
#include <initializer_list>
struct Fake {
  fh::Snapshot state{7, 3, true, true};
  unsigned calls = 0;
  bool cancel = false, full = false, no_progress = false, respawn = false,
       extra = false;
  bool cancelled() { return cancel; }
  fh::Snapshot snapshot() { return state; }
  fh::Award commit() {
    ++calls;
    if (!no_progress)
      state.remaining -= extra ? 2 : 1;
    if (respawn)
      state.token = 8;
    return {!full};
  }
};
int main() {
  {
    Fake f;
    auto r = fh::drain(f, 7, 64);
    assert(r.stop == fh::Stop::Empty && f.calls == 3 && r.commits == 3);
  }
  {
    Fake f;
    f.state.remaining = 0;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::Empty && f.calls == 0);
  }
  {
    Fake f;
    f.full = true;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::ReceiptIncomplete &&
           f.calls == 1);
  }
  {
    Fake f;
    f.no_progress = true;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::NoProgress && f.calls == 1);
  }
  {
    Fake f;
    f.respawn = true;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::Stale && f.calls == 1);
  }
  {
    Fake f;
    f.state.valid = false;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::Stale && f.calls == 0);
  }
  {
    Fake f;
    f.state.eligible = false;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::Blocked && f.calls == 0);
  }
  {
    Fake f;
    f.cancel = true;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::Cancelled && f.calls == 0);
  }
  {
    Fake f;
    assert(fh::drain(f, 7, 1).stop == fh::Stop::Budget && f.calls == 1 &&
           f.state.remaining == 2);
  }
  {
    Fake f;
    f.extra = true;
    assert(fh::drain(f, 7, 64).stop == fh::Stop::UnexpectedProgress &&
           f.calls == 1);
  }
  for (auto id : {0x290u, 0x291u, 0x292u, 0x702u, 0xccu, 0x6f5u})
    assert(fh::slinger(id, 0));
  assert(fh::slinger(1, 0x84) && !fh::slinger(1, 1));
  assert(fh::queue_sane(15, 16, 64, 1));
  assert(!fh::queue_sane(16, 1, 1, 0));
  assert(!fh::queue_sane(0, 17, 1, 0));
  assert(!fh::queue_sane(0, 0, 65, 0));
  assert(!fh::queue_sane(0, 0, 1, 2));
  std::puts("PASS: 10 transaction scenarios, slinger exclusions and queue bounds");
}
