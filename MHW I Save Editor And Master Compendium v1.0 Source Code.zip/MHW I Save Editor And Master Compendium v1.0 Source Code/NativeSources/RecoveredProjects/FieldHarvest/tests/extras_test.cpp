#include "../src/extras.hpp"
#include "../src/drain.hpp"
#include <cassert>
#include <limits>
#include <cstdio>
struct OneShot {
  fh::Snapshot s{1,1,true,true}; unsigned calls=0; bool progress=true;
  bool cancelled(){return false;}
  fh::Snapshot snapshot(){return s;}
  fh::Award commit(){++calls;if(progress)s.remaining=0;return {true};}
};
int main(){
  assert(fh::life_eligible(8,0,39,0.9f));
  assert(!fh::life_eligible(0,0,39,0.9f));
  assert(!fh::life_eligible(8,1,39,0.9f));
  assert(!fh::life_eligible(8,0,128,0.9f));
  assert(!fh::life_eligible(8,0,1,0));
  assert(!fh::life_eligible(8,0,1,-1));
  assert(!fh::life_eligible(8,0,1,21));
  assert(!fh::life_eligible(8,0,1,std::numeric_limits<float>::infinity()));
  assert(!fh::life_eligible(8,0,1,std::numeric_limits<float>::quiet_NaN()));
  assert(fh::trace_eligible(2,0,3));
  assert(!fh::trace_eligible(1,0,3));
  assert(!fh::trace_eligible(2,0,1));
  assert(!fh::trace_eligible(2,0,2));
  assert(!fh::trace_eligible(2,1u<<15,3));
  assert(!fh::trace_eligible(2,1u<<17,3));
  OneShot a; assert(fh::drain(a,1,8).stop==fh::Stop::Empty && a.calls==1);
  assert(fh::drain(a,1,8).commits==0 && a.calls==1);
  OneShot b;b.progress=false;assert(fh::drain(b,1,8).stop==fh::Stop::NoProgress && b.calls==1);
  std::puts("PASS: 15 eligibility cases; single-consumption, exhausted-target no replay, stalled-target stop");
}
