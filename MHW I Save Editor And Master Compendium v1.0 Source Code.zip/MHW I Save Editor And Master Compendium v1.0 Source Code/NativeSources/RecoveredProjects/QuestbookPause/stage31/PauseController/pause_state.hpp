#pragma once
namespace pause_state {
enum Phase { Running=0, Arming=1, Paused=2, Resuming=3 };
struct State {
 Phase phase=Running;
 template<class F> bool pause(F call){if(phase!=Running)return false;phase=Arming;if(!call()){phase=Running;return false;}phase=Paused;return true;}
 template<class F> bool resume(F call){if(phase==Running)return true;phase=Resuming;if(!call()){phase=Paused;return false;}phase=Running;return true;}
 bool owns_pause()const{return phase!=Running;}
};
}
