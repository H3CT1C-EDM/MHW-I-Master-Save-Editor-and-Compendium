#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601
#endif
#include <windows.h>
#include <shellapi.h>
#include <objidl.h>
#include <gdiplus.h>
#include <string>
#include <vector>
#include <cwchar>
#include <cstdint>
#include "pause_state.hpp"
using NtProcess=LONG(NTAPI*)(HANDLE);
struct Shared { volatile LONG phase; };
NtProcess suspendProcess=nullptr,resumeProcess=nullptr;
std::wstring exePath,statusPath,keyName;HANDLE owner=nullptr,target=nullptr,guard=nullptr,done=nullptr,ready=nullptr,mapping=nullptr;Shared* shared=nullptr;
pause_state::State state;HWND window=nullptr,label=nullptr;HFONT font=nullptr;HBRUSH parchment=nullptr;DWORD gamePid=0;bool closing=false;UINT modifiers=0,key=0;
HFONT titleFont=nullptr,warningFont=nullptr;std::wstring displayStatus;ULONG_PTR graphicsToken=0;Gdiplus::Image* background=nullptr;
#include "pause_i18n.hpp"
std::wstring Upper(std::wstring text){if(!text.empty())CharUpperBuffW(&text[0],static_cast<DWORD>(text.size()));return text;}
void closeHandle(HANDLE& h){if(h&&h!=INVALID_HANDLE_VALUE)CloseHandle(h);h=nullptr;}
void report(const std::wstring& value){
 displayStatus=value;
 if(window)InvalidateRect(window,nullptr,FALSE);
 if(statusPath.empty())return;
 int size=WideCharToMultiByte(CP_UTF8,0,value.c_str(),-1,nullptr,0,nullptr,nullptr);if(size<=1)return;std::string text(size-1,'\0');WideCharToMultiByte(CP_UTF8,0,value.c_str(),int(value.size()),text.data(),size-1,nullptr,nullptr);
 HANDLE f=CreateFileW(statusPath.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(f!=INVALID_HANDLE_VALUE){DWORD written;WriteFile(f,text.data(),DWORD(text.size()),&written,nullptr);FlushFileBuffers(f);CloseHandle(f);}
}
bool parseKey(const std::wstring& value){
 modifiers=MOD_NOREPEAT;
 if(value==L"Ctrl+Shift+P"){modifiers|=MOD_CONTROL|MOD_SHIFT;key='P';return true;}
 if(value==L"Ctrl+Alt+P"){modifiers|=MOD_CONTROL|MOD_ALT;key='P';return true;}
 if(value==L"F6"||value==L"F7"||value==L"F11"){key=VK_F1+std::wcstoul(value.c_str()+1,nullptr,10)-1;return true;}
 return false;
}
HANDLE inherited(HANDLE original){HANDLE result=nullptr;if(!DuplicateHandle(GetCurrentProcess(),original,GetCurrentProcess(),&result,0,TRUE,DUPLICATE_SAME_ACCESS))return nullptr;return result;}
std::wstring number(HANDLE h){return std::to_wstring(reinterpret_cast<uintptr_t>(h));}
void releaseGuard(){
 if(shared)InterlockedExchange(&shared->phase,pause_state::Running);
 if(done)SetEvent(done);
 if(guard){WaitForSingleObject(guard,1500);closeHandle(guard);}
 if(shared){UnmapViewOfFile(shared);shared=nullptr;}
 closeHandle(mapping);closeHandle(done);closeHandle(ready);closeHandle(target);gamePid=0;
}
bool startGuard(){
 SECURITY_ATTRIBUTES sa{sizeof(sa),nullptr,TRUE};done=CreateEventW(&sa,TRUE,FALSE,nullptr);ready=CreateEventW(&sa,TRUE,FALSE,nullptr);mapping=CreateFileMappingW(INVALID_HANDLE_VALUE,&sa,PAGE_READWRITE,0,sizeof(Shared),nullptr);
 if(!done||!ready||!mapping)return false;
 shared=static_cast<Shared*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared)));if(!shared)return false;shared->phase=0;
 HANDLE self=OpenProcess(SYNCHRONIZE,TRUE,GetCurrentProcessId());HANDLE game=inherited(target);
 if(!self||!game){closeHandle(self);closeHandle(game);return false;}
 HANDLE list[]={self,game,mapping,done,ready};SIZE_T bytes=0;InitializeProcThreadAttributeList(nullptr,1,0,&bytes);std::vector<unsigned char> buffer(bytes);auto attrs=reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(buffer.data());
 bool initialized=InitializeProcThreadAttributeList(attrs,1,0,&bytes)!=FALSE;bool ok=false;
 if(initialized&&UpdateProcThreadAttribute(attrs,0,PROC_THREAD_ATTRIBUTE_HANDLE_LIST,list,sizeof(list),nullptr,nullptr)){
  wchar_t ownExe[32768];DWORD n=GetModuleFileNameW(nullptr,ownExe,32768);
  if(n&&n<32768){std::wstring command=L"\""+std::wstring(ownExe)+L"\" --guard "+number(self)+L" "+number(game)+L" "+number(mapping)+L" "+number(done)+L" "+number(ready)+L" \""+statusPath+L"\"";
   STARTUPINFOEXW si{};si.StartupInfo.cb=sizeof(si);si.lpAttributeList=attrs;PROCESS_INFORMATION pi{};
   ok=CreateProcessW(ownExe,command.data(),nullptr,nullptr,TRUE,EXTENDED_STARTUPINFO_PRESENT|CREATE_NO_WINDOW,nullptr,nullptr,&si.StartupInfo,&pi)!=FALSE;
   if(ok){guard=pi.hProcess;CloseHandle(pi.hThread);HANDLE waits[]={ready,guard};ok=WaitForMultipleObjects(2,waits,FALSE,3000)==WAIT_OBJECT_0;}
  }
 }
 if(initialized)DeleteProcThreadAttributeList(attrs);closeHandle(self);closeHandle(game);return ok;
}
bool resume(){
 if(!state.owns_pause()){report(L"Ready. Focus the offline game and press "+keyName+L" to pause.");return true;}
 if(WaitForSingleObject(target,0)==WAIT_OBJECT_0){state.phase=pause_state::Running;releaseGuard();report(L"The game has exited. Pause is ready for the next game session.");return true;}
 bool ok=state.resume([]{InterlockedExchange(&shared->phase,pause_state::Resuming);return resumeProcess(target)>=0;});
 if(!ok){InterlockedExchange(&shared->phase,pause_state::Paused);report(L"Resume failed. Keep this controller open and try Resume again. Check process permissions.");return false;}
 releaseGuard();report(L"Running. Press "+keyName+L" in the offline game to pause again.");return true;
}
void toggle(){
 if(state.owns_pause()){resume();return;}
 DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);if(!pid||pid==GetCurrentProcessId()){report(L"Focus Monster Hunter: World before pausing. Resume works from any window.");return;}
 HANDLE candidate=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_SUSPEND_RESUME|SYNCHRONIZE,FALSE,pid);
 if(!candidate){report(L"Cannot open the focused game. Run the editor at the same permission level as the game.");return;}
 wchar_t path[32768];DWORD size=32768;
 if(!QueryFullProcessImageNameW(candidate,0,path,&size)||_wcsicmp(path,exePath.c_str())){CloseHandle(candidate);report(L"Only the configured MonsterHunterWorld.exe can be paused. Focus that game window.");return;}
 target=candidate;gamePid=pid;
 if(!startGuard()){releaseGuard();report(L"Recovery monitor could not start. The game was not paused.");return;}
 bool ok=state.pause([]{InterlockedExchange(&shared->phase,pause_state::Arming);LONG status=suspendProcess(target);if(status>=0)InterlockedExchange(&shared->phase,pause_state::Paused);return status>=0;});
 if(!ok){releaseGuard();report(L"Pause failed. Check permissions. The controller did not confirm suspension.");return;}
 report(L"PAUSED — press "+keyName+L" again, or select Resume.\r\nOffline use only. The entire game process is suspended.");
}
LRESULT CALLBACK proc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp){
 switch(msg){
 case WM_CREATE:
  for(int i=0;i<2;i++){HWND button=CreateWindowW(L"BUTTON",Upper(T(i?L"Resume and Disable":L"Resume")).c_str(),WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW,55+i*245,220,230,40,hwnd,reinterpret_cast<HMENU>(INT_PTR(i+1)),nullptr,nullptr);SendMessageW(button,WM_SETFONT,reinterpret_cast<WPARAM>(font),TRUE);}return 0;
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{
  PAINTSTRUCT ps{};HDC dc=BeginPaint(hwnd,&ps);RECT bounds{};GetClientRect(hwnd,&bounds);
  HDC mem=CreateCompatibleDC(dc);HBITMAP bitmap=CreateCompatibleBitmap(dc,bounds.right,bounds.bottom);auto previous=SelectObject(mem,bitmap);FillRect(mem,&bounds,parchment);
  if(background){Gdiplus::Graphics graphics(mem);graphics.DrawImage(background,0,0,bounds.right,bounds.bottom);}
  HBRUSH border=CreateSolidBrush(RGB(108,82,40));RECT frame=bounds;InflateRect(&frame,-8,-8);FrameRect(mem,&frame,border);InflateRect(&frame,-4,-4);FrameRect(mem,&frame,border);DeleteObject(border);
  SetBkMode(mem,TRANSPARENT);SetTextColor(mem,RGB(25,51,41));SelectObject(mem,titleFont);RECT title{25,26,bounds.right-25,65};DrawTextW(mem,T(state.owns_pause()?L"PAUSED":L"NOT PAUSED").c_str(),-1,&title,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
  SelectObject(mem,font);std::wstring detail=displayStatus;if(detail.rfind(L"PAUSED — ",0)==0)detail.erase(0,9);if(!detail.empty()&&detail[0]>=L'a'&&detail[0]<=L'z')detail[0]-=L'a'-L'A';
  detail=T(detail);RECT measured{0,0,bounds.right-90,0};DrawTextW(mem,detail.c_str(),-1,&measured,DT_CENTER|DT_WORDBREAK|DT_CALCRECT|DT_NOPREFIX);int top=90+((115-(measured.bottom-measured.top))/2);RECT body{45,top,bounds.right-45,215};DrawTextW(mem,detail.c_str(),-1,&body,DT_CENTER|DT_WORDBREAK|DT_NOPREFIX);
  SelectObject(mem,warningFont);SetTextColor(mem,RGB(133,34,27));RECT warning{35,280,bounds.right-35,bounds.bottom-20};DrawTextW(mem,T(L"(Using while online will not pause the game for everyone! You may die in-game, disconnect, or face a ban.)").c_str(),-1,&warning,DT_CENTER|DT_WORDBREAK|DT_NOPREFIX);
  BitBlt(dc,0,0,bounds.right,bounds.bottom,mem,0,0,SRCCOPY);SelectObject(mem,previous);DeleteObject(bitmap);DeleteDC(mem);EndPaint(hwnd,&ps);return 0;
 }
 case WM_DRAWITEM:{
  auto item=reinterpret_cast<DRAWITEMSTRUCT*>(lp);if(item->CtlType!=ODT_BUTTON)break;int saved=SaveDC(item->hDC);
  HBRUSH brush=CreateSolidBrush((item->itemState&ODS_SELECTED)?RGB(25,48,42):RGB(31,66,57));FillRect(item->hDC,&item->rcItem,brush);DeleteObject(brush);
  HBRUSH border=CreateSolidBrush(RGB(202,169,94));FrameRect(item->hDC,&item->rcItem,border);DeleteObject(border);
  SetBkMode(item->hDC,TRANSPARENT);SetTextColor(item->hDC,RGB(255,245,214));SelectObject(item->hDC,font);wchar_t text[64];GetWindowTextW(item->hwndItem,text,64);RECT rect=item->rcItem;DrawTextW(item->hDC,text,-1,&rect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
  if(item->itemState&ODS_FOCUS){InflateRect(&rect,-4,-4);DrawFocusRect(item->hDC,&rect);}RestoreDC(item->hDC,saved);return TRUE;
 }
 case WM_QUERYENDSESSION:resume();return TRUE;
 case WM_CTLCOLORSTATIC:SetTextColor(reinterpret_cast<HDC>(wp),RGB(32,48,39));SetBkColor(reinterpret_cast<HDC>(wp),RGB(247,236,210));return reinterpret_cast<LRESULT>(parchment);
 case WM_APP+3:if(wp<=4){languageIndex=unsigned(wp);SetWindowTextW(hwnd,(L"Hunters Companion | "+T(L"Offline Pause")).c_str());SetWindowTextW(GetDlgItem(hwnd,1),Upper(T(L"Resume")).c_str());SetWindowTextW(GetDlgItem(hwnd,2),Upper(T(L"Resume and Disable")).c_str());InvalidateRect(hwnd,nullptr,FALSE);}return 0;
 case WM_HOTKEY:if(wp==1)toggle();return 0;
 case WM_COMMAND:if(LOWORD(wp)==1)resume();else if(LOWORD(wp)==2)SendMessageW(hwnd,WM_CLOSE,0,0);return 0;
 case WM_TIMER:
  if(WaitForSingleObject(owner,0)==WAIT_OBJECT_0){if(resume())DestroyWindow(hwnd);}
  else if(state.owns_pause()&&WaitForSingleObject(target,0)==WAIT_OBJECT_0)resume();
  else if(state.owns_pause()&&guard&&WaitForSingleObject(guard,0)==WAIT_OBJECT_0){if(resume())report(L"Recovery monitor stopped. Pause has been released; close and restart this controller.");}
  return 0;
 case WM_CLOSE:if(resume())DestroyWindow(hwnd);return 0;
 case WM_DESTROY:UnregisterHotKey(hwnd,1);PostQuitMessage(0);return 0;
 }return DefWindowProcW(hwnd,msg,wp,lp);
}
int guardMain(int count,wchar_t** args){
 if(count!=8)return 20;
 HANDLE h[5];for(int i=0;i<5;i++){wchar_t* end=nullptr;auto value=std::wcstoull(args[i+2],&end,10);if(!value||!end||*end)return 21;h[i]=reinterpret_cast<HANDLE>(uintptr_t(value));}
 statusPath=args[7];auto block=static_cast<Shared*>(MapViewOfFile(h[2],FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared)));if(!block)return 22;
 SetEvent(h[4]);HANDLE waits[]={h[0],h[3],h[1]};DWORD result=WaitForMultipleObjects(3,waits,FALSE,INFINITE);
 if(result==WAIT_OBJECT_0&&InterlockedCompareExchange(&block->phase,0,0)!=0&&WaitForSingleObject(h[1],0)!=WAIT_OBJECT_0){
  bool ok=false;for(int i=0;i<3&&!ok;i++){ok=resumeProcess(h[1])>=0;if(!ok)Sleep(50);}if(ok){InterlockedExchange(&block->phase,0);report(L"Recovery monitor requested resume after the pause controller exited unexpectedly. Check the game before continuing.");}else report(L"Recovery monitor could not resume the game. Use Task Manager or Process Explorer to inspect the process.");
 }
 UnmapViewOfFile(block);for(auto handle:h)CloseHandle(handle);return 0;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int){
 auto nt=GetModuleHandleW(L"ntdll.dll");suspendProcess=reinterpret_cast<NtProcess>(GetProcAddress(nt,"NtSuspendProcess"));resumeProcess=reinterpret_cast<NtProcess>(GetProcAddress(nt,"NtResumeProcess"));if(!suspendProcess||!resumeProcess)return 10;
 int argc=0;wchar_t** argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(!argv)return 11;
 if(argc>1&&std::wstring(argv[1])==L"--guard"){int result=guardMain(argc,argv);LocalFree(argv);return result;}
 if((argc!=11&&argc!=13)||std::wstring(argv[1])!=L"--owner"||std::wstring(argv[3])!=L"--game"||std::wstring(argv[5])!=L"--key"||std::wstring(argv[7])!=L"--status"||std::wstring(argv[9])!=L"--offline-confirmed"||std::wstring(argv[10])!=L"yes"){LocalFree(argv);return 12;}
 if(argc==13){if(std::wstring(argv[11])!=L"--lang"){LocalFree(argv);return 12;}std::wstring locale=argv[12];languageIndex=locale==L"zh-CN"?1:locale==L"ja"?2:locale==L"ko"?3:locale==L"ru"?4:0;}
 DWORD ownerId=std::wcstoul(argv[2],nullptr,10);exePath=argv[4];keyName=argv[6];statusPath=argv[8];LocalFree(argv);
 size_t slash=exePath.find_last_of(L"\\/");if(slash==std::wstring::npos||_wcsicmp(exePath.c_str()+slash+1,L"MonsterHunterWorld.exe")||!parseKey(keyName)){report(L"Invalid pause configuration.");return 13;}
 HANDLE singleton=CreateMutexW(nullptr,FALSE,L"Local\\MHWIQuestbookOfflinePause");if(!singleton||GetLastError()==ERROR_ALREADY_EXISTS){report(L"Another pause controller is already running. Close it before changing settings.");closeHandle(singleton);return 14;}
 owner=OpenProcess(SYNCHRONIZE,FALSE,ownerId);if(!owner){report(L"The editor is no longer running.");closeHandle(singleton);return 15;}
 parchment=CreateSolidBrush(RGB(247,236,210));font=CreateFontW(-16,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Palatino Linotype");
 titleFont=CreateFontW(-30,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Georgia");warningFont=CreateFontW(-15,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Palatino Linotype");
 Gdiplus::GdiplusStartupInput graphicsInput;Gdiplus::GdiplusStartup(&graphicsToken,&graphicsInput,nullptr);
 wchar_t iconFile[32768];HICON icon=nullptr;DWORD iconLength=GetModuleFileNameW(nullptr,iconFile,32768);
 if(iconLength&&iconLength<32768){std::wstring path=iconFile;auto at=path.find_last_of(L"\\/");if(at!=std::wstring::npos){path.resize(at);at=path.find_last_of(L"\\/");if(at!=std::wstring::npos){path.resize(at+1);std::wstring texture=path+L"theme\\questbook.png";background=Gdiplus::Image::FromFile(texture.c_str());if(background->GetLastStatus()!=Gdiplus::Ok){delete background;background=nullptr;}path+=L"Questbook.ico";icon=static_cast<HICON>(LoadImageW(nullptr,path.c_str(),IMAGE_ICON,32,32,LR_LOADFROMFILE));}}}
 WNDCLASSW wc{};wc.hIcon=icon;wc.lpfnWndProc=proc;wc.hInstance=instance;wc.lpszClassName=L"QuestbookOfflinePause";wc.hbrBackground=parchment;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassW(&wc);
 window=CreateWindowW(wc.lpszClassName,(L"Hunters Companion | "+T(L"Offline Pause")).c_str(),WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,616,390,nullptr,nullptr,instance,nullptr);
 if(!window||!RegisterHotKey(window,1,modifiers,key)){report(L"The pause hotkey is unavailable. Choose another key in Options.");if(window)DestroyWindow(window);closeHandle(owner);closeHandle(singleton);return 16;}
 SetTimer(window,1,250,nullptr);report(L"Ready. Focus the offline game and press "+keyName+L" to pause.\r\nKeep the editor open. Resume works from any window.");ShowWindow(window,SW_SHOWNOACTIVATE);MSG message{};while(GetMessageW(&message,nullptr,0,0)>0){if(!IsDialogMessageW(window,&message)){TranslateMessage(&message);DispatchMessageW(&message);}}
 if(state.owns_pause()&&!resume())return 17;releaseGuard();closeHandle(owner);closeHandle(singleton);DeleteObject(font);DeleteObject(titleFont);DeleteObject(warningFont);delete background;if(graphicsToken)Gdiplus::GdiplusShutdown(graphicsToken);DeleteObject(parchment);if(icon)DestroyIcon(icon);return 0;
}
