# QuestbookPause build

This is the Stage 31 C++ source, which superseded Stage 29's captions.
Use Zig 0.14.1 on a Windows build host (or target Windows x64).
From this project's directory run:

```
zig c++ -target x86_64-windows-gnu -std=c++17 -O2 -s -municode -Wl,--subsystem,windows stage31/PauseController/PauseController.cpp -luser32 -lgdi32 -lshell32 -lgdiplus -static -o stage31/MHWI_Hunters_Companion/tools/QuestbookPause.exe
```

This command is the original Stage 29 recorded build command applied to the Stage 31 source; it was not separately validated here. The Stage 31 validation record identifies the final binary hash.
