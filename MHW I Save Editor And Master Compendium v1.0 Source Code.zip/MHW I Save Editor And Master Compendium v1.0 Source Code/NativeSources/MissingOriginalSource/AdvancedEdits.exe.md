# AdvancedEdits.exe — original source NOT recovered

SHA-256: `d758a73af9c2a2283d1fbb9c540bcee10664187636fa0f38b9fee4b407dbd457`

Provenance: first shipped in `MHWI_Hunters_Companion_Stage47.zip` and unchanged in the user-provided Nexus ZIP.

The Stage 47 release ZIP contains the EXE only; no original `AdvancedEdits` C++ source, build files, solution or project were found in the checked historical archives.

To recover exactly, seek the original Stage 47 build workspace/source checkout, private Git history or build worker artifacts. Decompilation would be a **new reconstruction**, not the original build project.
