# ArmorProgress.exe — original source NOT recovered

SHA-256: `9407c3e891fcf253f5a9686b384b7d6b0798a89a3833729ea7afd76ecef5f146`

Provenance: first shipped in `MHWI_Hunters_Companion_Stage45.zip` and unchanged through Stage 47 and the user-provided Nexus ZIP.

The Stage 45/47 release ZIPs contain the EXE only; no original `ArmorProgress` C++ source, build files, solution or project were found in the checked historical archives. There is no basis to claim that the recovered `EquipmentTools` or `MHWJewelsEngine` source can rebuild it.

To recover exactly, seek the original Stage 45 build workspace/source checkout (`ArmorProgress` C++ implementation and build command), its private Git repository or the original build worker outputs. Decompilation would produce a **new reconstruction**, not the original build project.
