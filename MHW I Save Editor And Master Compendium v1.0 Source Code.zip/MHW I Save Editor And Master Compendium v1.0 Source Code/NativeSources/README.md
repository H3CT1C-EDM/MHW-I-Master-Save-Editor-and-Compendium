# MHWI - recovered original native build sources (7 of 9 components)

This package was assembled from the user's retained Monster Hunter World: Iceborne editor archives. It includes **six historical native C++ source trees** for **seven native binaries**: FieldHarvest produces two DLL variants. It does not distribute the nine compiled runtime binaries.

**Found source projects (6):** MHWJewelsEngine, EquipmentDetails, EquipmentTools, QuestbookPause, AccountBridge, FieldHarvest (selected+field variants).
**Not found (2):** ArmorProgress.exe (Stage45) and AdvancedEdits.exe (Stage47). Their recorded stage, SHA-256, and missing-source caveat are in `MissingOriginalSource`.

For each recovered project, look in `RecoveredProjects/<name>/BUILD.md` or `BUILD_FROM_STAGE*.md`, then consult the untouched original scripts/build notes. Original code is copied unchanged from the historical source archives; README/build notes at the project root are newly authored recovery instructions.

The current ZIP's nine PE files **all match byte-for-byte** the binaries in the historical Stage47 runtime ZIP. Historical release manifests confirm SHA-256 equivalence for five older components and separate historical runtime binaries confirm the other two. These matches establish strong source/version provenance, **not verified fresh, bit-for-bit recompilation**. No original project was executed or recompiled as part of this recovery.

**Build toolchain:** Zig 0.14.1 (Windows x64 GNU target), C++17, Python 3; some scripts also build host helpers using C++/OpenSSL. Source is mostly command-line native C++ projects rather than `.sln`/`.vcxproj`. Windows and in-game QA remain required.

**Licensing:** Archived third-party license texts are retained where present. Audit redistribution rights and attribute upstream sources before publishing code. Do not bundle proprietary Monster Hunter game assets in public source archives.

**Do not replace** the release's executables with newly rebuilt ones until Windows/game validation and checksums are recorded.

See `Binary_Source_Inventory.csv`, `Evidence/`, and `Source_SHA256.csv`.
