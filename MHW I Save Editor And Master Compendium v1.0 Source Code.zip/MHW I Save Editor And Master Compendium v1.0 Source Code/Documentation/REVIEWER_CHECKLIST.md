# Review/validation checklist — CMD launcher

- [ ] Verify ZIP CRC, SHA-256 and absence of nested archives.
- [ ] Compare `SOURCE_MANIFEST.sha256` against extracted source files.
- [ ] Match source to the release using `Evidence/RUNTIME_SOURCE_HASHES.csv` and `Evidence/BINARY_TO_SOURCE_MAP.csv`.
- [ ] Review `Bootstrap.ps1`, `JewelsEditor.ps1`, the launcher and optional native modules.
- [ ] Review process hooks, memory access, file operations and any network use in the actual source, not just documentation.
- [ ] Review redistributed third-party headers/libraries and game-derived reference data for licences.
- [ ] Note missing original sources for `ArmorProgress.exe` and `AdvancedEdits.exe`; request original build trees before asserting complete coverage.
- [ ] Rebuild native components on Windows with documented toolchain if validation is required; compare behavior and digests.
- [ ] Test signed runtime separately, if supplied; the original unsigned runtimes can trigger Windows warnings.
- [ ] Validate release on a fresh Windows environment; the source-only archive is not installable.
