# Startup flow and security distinctions

## Original CMD launch

The archived `Launch.cmd` uses `-WindowStyle Hidden` and `-ExecutionPolicy Bypass`. This is disclosed for faithful historical review. It is **not** a recommended security configuration. The newer portable launcher avoids these options; do not confuse the two releases.

1. Startup entrypoint: `Launch.cmd`.
2. Windows PowerShell 5.1 runs `Bootstrap.ps1` in a single-threaded apartment (`-STA`).
3. `Bootstrap.ps1` loads WinForms, shows splash and calls `JewelsEditor.ps1`.
4. `JewelsEditor.ps1` loads editor components and uses `MHWJewelsEngine.exe` for some save handling.
5. Optional Account Bridge/FieldHarvest DLLs are game plugins, not required to open a normal editor UI.
6. Additional tools are separate helper processes invoked by explicit editor features.

The code may use file I/O and game-process integration as a modding editor. Those operations must be reviewed against published Nexus rules. Do not assert that downloaded code is safe solely because it is readable.

## Binary and source parity

The file hashes in `Evidence/RUNTIME_SOURCE_HASHES.csv` were computed from the release archive, then those exact bytes were copied into this source package. No refactoring was performed. The launcher source represents only this release variant. See `Evidence/BINARY_TO_SOURCE_MAP.csv` for original compiled binary names, hashes and source availability.
