# Nexus Mods moderation handoff

**Mod:** MHW:I Save Editor & Master Compendium
**Author branding:** H3CT1C | Frank Sidor | Nihilist Kvlt Mods
**Source archive:** MHWI_Nexus_Source_LaunchCMD_v1.0.zip
**Matching runtime:** MHW-I Save Editor and Master Compendium.zip
**Launch method:** Launch.cmd (legacy)

## Submit with the review request

Provide to `support@nexusmods.com`:

1. The **actual Nexus mod URL** and the name/version of the quarantined runtime file (fill in yourself; not supplied here).
2. This matching **source-only** ZIP, *not* a runtime replacement.
3. The corresponding runtime package already uploaded, or its hash as identified by Nexus.
4. `Evidence/BINARY_TO_SOURCE_MAP.csv` and `NativeSources/README.md` describing 7 components with historical source and 2 components still unavailable.
5. The purpose and installation scope of game-process DLLs (`Documentation/GAME_PLUGIN_INTERACTIONS.md`).
6. Evidence of current antivirus detections, if any, and steps taken to address them, without disabling security tools.
7. Third-party source licenses and rights to redistribute assets; consult the original distribution licence notes in the `LICENSES` subtree.

**Do not claim** source equivalence has been demonstrated for all compiled binaries. This package intentionally excludes the compiled runtime binaries and media; it cannot, by itself, establish the absence of malware. Nexus approval remains at staff discretion.

Nexus quarantine documentation: https://help.nexusmods.com/article/117-why-has-my-mod-been-quarantined
Submission guidelines: https://help.nexusmods.com/article/28-file-submission-guidelines
