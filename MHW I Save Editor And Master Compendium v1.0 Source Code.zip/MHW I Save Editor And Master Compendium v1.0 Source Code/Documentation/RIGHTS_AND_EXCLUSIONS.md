# Copyright, licence and excluded asset policy

Code files are copied from the user-provided runtime and recovered historical archives. Files in `LICENSES/` and bundled recovered native source licence directories preserve relevant original licence notices. They are not a blanket right to redistribute third-party assets.

Excluded on purpose: compiled EXE/DLL binaries (to keep this a source-only review package), all PNG/JPEG images including game renders, thumbnail collections, sound/WAV, binary game data (`data/common/...`, GMD and weapon data), Windows shortcut files, unrelated mod packages, private saves, and all inner archives. The launcher icon `.ico` is included only in the EXE variant because the original native build script requires it; verify its rights prior to public redistribution.

Some readable `Guides/*.js` files and `catalog/*` files contain game-derived reference data, not merely application code; verify their distribution rights separately with Nexus. They are included to permit review of offline guide functionality, but may need a separate licensing decision for public distribution.
