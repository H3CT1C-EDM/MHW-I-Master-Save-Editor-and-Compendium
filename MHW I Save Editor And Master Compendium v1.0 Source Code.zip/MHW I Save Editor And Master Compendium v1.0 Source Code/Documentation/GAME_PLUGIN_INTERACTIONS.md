# Native game integration — why process access exists

This source bundle is for an *offline PC Monster Hunter World: Iceborne modding utility*. Game process access, plugin hooks and save editing are security-relevant and must be assessed by Nexus reviewers. They are not generic Windows networking or remote administration capabilities.

## Account Bridge (`mhwi_account_bridge.dll`)

Source: `NativeSources/RecoveredProjects/AccountBridge/` — original recovered Stage 21 implementation. The DLL is installed as an optional AsteraLoader game plugin for in-game state changes that cannot be reliably simulated by save-file editing alone, such as bounded account-item acquisition, canteen ingredient unlocks, and quest-flag operations. Its request/receipt headers document one-request-at-a-time guards and observed state; successful native calls do not guarantee saved persistence. Installation, game actions, saving and reloading must be tested separately.

## FieldHarvest (`fieldharvest_selected.dll` / `fieldharvest_field.dll`)

Source: `NativeSources/RecoveredProjects/FieldHarvest/` — original recovered Stage 17 implementation. Both variants modify harvesting/gathering game events through AsteraLoader. `FIELD_SWEEP=0` is selected/targeted gathering; `FIELD_SWEEP=1` is a nearby field sweep. They are alternate builds, not intended to be installed simultaneously. A DLL is loaded in the game process to observe/alter eligible gather/carve/receipt events. This is normal *for this type of game mod* but is sensitive antivirus behavior and warrants security review.

## Other native binaries

- `MHWJewelsEngine.exe`: off-game PC save handling, game data editing helpers.
- `EquipmentDetails.exe` and `EquipmentTools.exe`: read/edit equipment and augment structures.
- `QuestbookPause.exe`: pause-related game process helper.
- `ArmorProgress.exe` / `AdvancedEdits.exe`: original compiled implementations not recovered; shipped PowerShell integration sources alone do not expose their full internal behavior.

## Reviewer caveats

No DLLs, EXEs, injected binaries, cheat-engine tables, scripts that modify Windows Defender, or nested archives are included here. The original runtime does contain native plugins and helper executables; this source bundle exists precisely to make those security-relevant parts auditable. Users are responsible for respecting the game's online play rules and the permissions of third-party code authors.
