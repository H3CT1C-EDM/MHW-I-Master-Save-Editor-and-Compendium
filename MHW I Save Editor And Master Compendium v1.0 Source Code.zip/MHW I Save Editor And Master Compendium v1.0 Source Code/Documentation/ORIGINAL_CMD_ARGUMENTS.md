# Exact original Launch.cmd semantics

The `Launch.cmd` copied from the original v1.0 release intentionally has its historical contents unchanged. It invokes `powershell.exe` with `-NoProfile`, `-STA`, `-WindowStyle Hidden`, and `-ExecutionPolicy Bypass`, targeting `Bootstrap.ps1` relative to the script's own folder (`%~dp0`). This is exactly the launcher behavior Nexus is reviewing. The reviewer archive does **not** recommend bypassing Windows execution policy; the v1.0.1 EXE build is designed to respect RemoteSigned and show PowerShell errors instead of hiding them.
