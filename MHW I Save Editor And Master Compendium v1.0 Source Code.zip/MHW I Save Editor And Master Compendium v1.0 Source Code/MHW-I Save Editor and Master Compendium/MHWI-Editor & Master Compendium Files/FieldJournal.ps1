﻿
$script:MaterialById=@{}
$materialIndex=Get-Content -LiteralPath (Join-Path $script:Root 'catalog\MaterialIndex.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach($entry in $materialIndex.Items){$script:MaterialById[[int]$entry.Id]=$entry}
$script:JournalFilling=$false;$script:JournalInitializing=$true
$script:JournalFavorites=[Collections.Generic.HashSet[int]]::new()
$script:JournalRecentIds=[Collections.Generic.List[int]]::new()
$script:JournalPreferencePath=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\preferences.json'

$box.MultiSelect=$false
$catalog.Top=140;$qty.Top=141;$add.Top=140;$remove.Top=140
$coverage.Top=182;$coverage.Height=36;$box.Top=290;$box.Height=270
$journalOwned=Add-Control $inv ComboBox '' 580 18 170 30
$journalOwned.DropDownStyle='DropDownList';[void]$journalOwned.Items.AddRange([object[]]@('All ownership','Owned only','Missing only','Favorites only'))
$journalSort=Add-Control $inv ComboBox '' 760 18 300 30
$journalSort.DropDownStyle='DropDownList';[void]$journalSort.Items.AddRange([object[]]@('Monster family / material / rank','Monster / material / rank','Name','Rarity','Item ID'))
$journalFamily=Add-Control $inv ComboBox '' 15 58 240 30
$journalMonster=Add-Control $inv ComboBox '' 265 58 240 30
$journalRank=Add-Control $inv ComboBox '' 515 58 115 30
$journalRegion=Add-Control $inv ComboBox '' 640 58 195 30
$journalSource=Add-Control $inv ComboBox '' 845 58 215 30
$journalAffinity=Add-Control $inv ComboBox '' 15 98 240 30
$journalRarity=Add-Control $inv ComboBox '' 265 98 130 30
$journalFavorite=Add-Control $inv Button 'Favorite / unfavorite' 405 98 180 30
$journalRecent=Add-Control $inv ComboBox '' 595 98 300 30
$journalRecent.DropDownStyle='DropDownList';$journalRecent.DisplayMember='Label'
$journalSources=Add-Control $inv Button 'Sources...' 905 98 155 30
$journalDetails=Add-Control $inv TextBox '' 15 225 1045 55
$journalDetails.Multiline=$true;$journalDetails.ReadOnly=$true;$journalDetails.ScrollBars='Vertical'
$journalBatch=Add-Control $inv Button 'Batch add...' 810 574 250 32
function Initialize-JournalFilter($control,[string]$label,[string]$field){
 $control.DropDownStyle='DropDownList';[void]$control.Items.Add($label);[void]$control.Items.Add('Unknown')
 foreach($value in @($materialIndex.Items | ForEach-Object { $_.$field } | Sort-Object -Unique)){[void]$control.Items.Add([string]$value)}
 $control.SelectedIndex=0;$control.DropDownWidth=[Math]::Max(320,$control.Width)
}
Initialize-JournalFilter $journalFamily 'All monster families' 'Families'
Initialize-JournalFilter $journalMonster 'All monsters' 'Monsters'
Initialize-JournalFilter $journalRank 'All ranks' 'Ranks'
Initialize-JournalFilter $journalRegion 'All regions' 'Regions'
Initialize-JournalFilter $journalSource 'All sources' 'Sources'
Initialize-JournalFilter $journalAffinity 'Source element / status' 'Affinities'
$journalRarity.DropDownStyle='DropDownList';[void]$journalRarity.Items.Add('All rarities');foreach($n in 1..12){[void]$journalRarity.Items.Add([string]$n)}
foreach($c in @($journalRarity,$journalOwned,$journalSort)){$c.SelectedIndex=0}
function Get-JournalOwned {
 $owned=@{}
 if($script:State -and $slot.SelectedIndex -ge 0){foreach($v in (Current-Slot).inventory){$owned[[int]$v.id]=$v}}
 return $owned
}
function Test-JournalFilter($control,$values){
 if($control.SelectedIndex -le 0){return $true}
 if([string]$control.SelectedItem -eq 'Unknown'){return @($values).Count -eq 0}
 return @($values) -contains [string]$control.SelectedItem
}
$script:JournalSortCache=@{}
$script:JournalHeaderColumn=-1
$script:JournalHeaderDescending=$false
function Get-JournalSortKey($item){
 $key="$($journalSort.SelectedIndex):$($item.Id)"
 if($script:JournalSortCache.ContainsKey($key)){return $script:JournalSortCache[$key]}
 $m=$script:MaterialById[[int]$item.Id]
 $rank=if(@($m.Ranks) -contains 'LR'){'1'}elseif(@($m.Ranks) -contains 'HR'){'2'}elseif(@($m.Ranks) -contains 'MR'){'3'}else{'9'}
 $result=switch($journalSort.SelectedIndex){
  0 {"$(if(@($m.Families).Count){$m.Families[0]}else{'~Unassigned'})|$($m.MaterialGroup)|$rank|$($item.Name)"}
  1 {"$(if(@($m.Monsters).Count){$m.Monsters[0]}else{'~Unassigned'})|$($m.MaterialGroup)|$rank|$($item.Name)"}
  2 {[string]$item.Name}
  3 {('{0:D2}|{1}' -f [int]$m.Rarity,$item.Name)}
  4 {('{0:D6}' -f [int]$item.Id)}
 }
 $script:JournalSortCache[$key]=$result;return $result
}
function Sort-JournalResults($items,$owned) {
 $column=$script:JournalHeaderColumn
 if($column -lt 0){return $items | Sort-Object {Get-JournalSortKey $_}}
 $desc=$script:JournalHeaderDescending
 $idSort=@{Expression={[int]$_.Id};Descending=$false}
 if($column -eq 2){
  return $items | Sort-Object -Property @{Expression={
   $record=$owned[[int]$_.Id]
   if(-not $record){2}elseif($record.kind -in @('furniture_unlock','account_discovery')){1}else{0}
  };Descending=$false},@{Expression={
   $record=$owned[[int]$_.Id]
   if(-not $record){0}elseif($record.kind -eq 'furniture_unlock'){1}elseif($record.kind -eq 'account_discovery'){0}else{[long]$record.amount}
  };Descending=$desc},$idSort
 }
 $primary=switch($column){
  0 {{Get-QuestbookGameText $_.Name 'item_name'}}
  1 {{[int]$_.Id}}
  3 {{[int]$_.Category}}
 }
 return $items | Sort-Object -Property @{Expression=$primary;Descending=$desc},$idSort
}
function Set-JournalHeaderSort([int]$column) {
 if($column -notin 0,1,2,3){return}
 if($script:JournalHeaderColumn -eq $column){$script:JournalHeaderDescending=-not $script:JournalHeaderDescending}
 else{$script:JournalHeaderColumn=$column;$script:JournalHeaderDescending=$false}
 Fill-Catalog
}
function Fill-Catalog {
 if($script:JournalFilling -or $script:JournalInitializing){return}
 $previousIndex=$catalog.SelectedIndex
 $script:JournalFilling=$true;$previous=if($catalog.SelectedItem){[int]$catalog.SelectedItem.Id}else{-1}
 $catalog.BeginUpdate()
 try {
  $catalog.Items.Clear();$pattern=[regex]::Escape($search.Text);$cat=@(-1,4,0,1,3,5,2)[$filter.SelectedIndex];$owned=Get-JournalOwned
  $hasSave=($null -ne $script:State -and $slot.SelectedIndex -ge 0)
  if(-not $hasSave -and $journalOwned.SelectedIndex -in @(1,2)){$journalOwned.SelectedIndex=0}
  $results=@(foreach($item in $script:Items){
   $id=[int]$item.Id;$m=$script:MaterialById[$id]
   if($cat -ne -1 -and [int]$item.Category -ne $cat){continue}
   if($pattern -and "$($item.Name) $(Get-QuestbookGameText $item.Name) $id $($m.Monsters -join ' ') $($m.Families -join ' ')" -notmatch $pattern){continue}
   if(-not (Test-JournalFilter $journalFamily $m.Families) -or -not (Test-JournalFilter $journalMonster $m.Monsters) -or -not (Test-JournalFilter $journalRank $m.Ranks) -or -not (Test-JournalFilter $journalRegion $m.Regions) -or -not (Test-JournalFilter $journalSource $m.Sources) -or -not (Test-JournalFilter $journalAffinity $m.Affinities)){continue}
   if($journalRarity.SelectedIndex -gt 0 -and [int]$journalRarity.SelectedItem -ne [int]$m.Rarity){continue}
   if($journalOwned.SelectedIndex -eq 1 -and -not $owned.ContainsKey($id)){continue}
   if($journalOwned.SelectedIndex -eq 2 -and $owned.ContainsKey($id)){continue}
   if($journalOwned.SelectedIndex -eq 3 -and -not $script:JournalFavorites.Contains($id)){continue}
   $item
  })
  $results=@(Sort-JournalResults $results $owned)
  if($results.Count){$catalog.Items.AddRange([object[]]$results)}
  if($catalog.Items.Count){$found=-1;for($i=0;$i -lt $catalog.Items.Count;$i++){if([int]$catalog.Items[$i].Id -eq $previous){$found=$i;break}};$catalog.SelectedIndex=if($found -ge 0){$found}else{[Math]::Max(0,[Math]::Min($previousIndex,$catalog.Items.Count-1))}}
  Set-JournalResultRows $results $owned
 } finally {$catalog.EndUpdate();$script:JournalFilling=$false}
 Update-InventoryActions
 Update-JournalDetails
}
function Get-JournalQuantityText($record) {
 if(-not $record){return '—'}
 if($record.kind -eq 'furniture_unlock'){return 'Unlocked'}
 if($record.kind -eq 'account_discovery'){return 'Discovered'}
 return [string]$record.amount
}
function Update-JournalResultQuantities {
 if($journalOwned.SelectedIndex -in @(1,2) -or $script:JournalHeaderColumn -eq 2){Fill-Catalog;return}
 $owned=Get-JournalOwned
 $box.BeginUpdate()
 try{
  foreach($row in $box.Items){
   $value=Get-JournalQuantityText $owned[[int]$row.Tag.Id]
   if($row.SubItems[2].Text -ne $value){$row.SubItems[2].Text=$value}
  }
 }finally{$box.EndUpdate()}
}
function Set-JournalResultRows($results,$owned) {
 $rows=[Collections.Generic.List[Windows.Forms.ListViewItem]]::new()
 foreach($item in $results){
  $id=[int]$item.Id;$record=$owned[$id]
  $statusText=Get-JournalQuantityText $record
  $row=[Windows.Forms.ListViewItem]::new([string]$item.Name)
  [void]$row.SubItems.Add([string]$id);[void]$row.SubItems.Add($statusText);[void]$row.SubItems.Add([string]$item.Category)
  $row.Tag=$item
  $annotation=Get-CompanionItemAnnotation $item
  if($annotation){$row.ForeColor=Get-CompanionItemColor $item $row.ForeColor;$row.ToolTipText=$annotation.reason}
  $rows.Add($row)
 }
 $box.BeginUpdate()
 try{
  $box.Items.Clear()
  if($rows.Count){$box.Items.AddRange($rows.ToArray())}
  if($catalog.SelectedIndex -ge 0 -and $catalog.SelectedIndex -lt $box.Items.Count){$box.Items[$catalog.SelectedIndex].Selected=$true;$box.EnsureVisible($catalog.SelectedIndex)}
 }finally{$box.EndUpdate()}
}
function Update-JournalDetails {
 $hasSelection=$null -ne $catalog.SelectedItem
 $journalFavorite.Enabled=$hasSelection;$journalSources.Enabled=$hasSelection
 if(-not $catalog.SelectedItem){$journalDetails.Text='No matching items. Clear a filter to broaden the results.';return}
 $m=$script:MaterialById[[int]$catalog.SelectedItem.Id];$families=if(@($m.Families).Count){$m.Families -join ', '}else{'Unknown / not linked'}
 $journalFavorite.Text=if($script:JournalFavorites.Contains([int]$m.Id)){'Remove favorite'}else{'Add favorite'}
 $journalDetails.Text=(Format-QuestbookText 'Family: {0} | Rarity {1} | {2}
Sources: {3} | Regions: {4}
Source-monster element/status: {5} (not an intrinsic item property). {6} results.' @(($families),($($m.Rarity)),($($m.MaterialGroup)),($(if(@($m.Sources).Count){$m.Sources -join ', '}else{'Unknown'})),($($m.Regions -join ', ')),($($m.Affinities -join ', ')),($($catalog.Items.Count))))
 $lines=$journalDetails.Text -split '\r?\n',3
 if($lines.Count -eq 3){$journalDetails.Text=$lines[0]+' | '+$lines[1]+[Environment]::NewLine+$lines[2]}
}
function Save-JournalPreferences {
 if($script:JournalInitializing){return}
 try {
  $folder=Split-Path -Parent $script:JournalPreferencePath;[void][IO.Directory]::CreateDirectory($folder)
  $data=[pscustomobject]@{Format='MHWI_JOURNAL_PREFS_V1';Favorites=@($script:JournalFavorites);Recent=@($script:JournalRecentIds);Filters=@{Sort=[string]$journalSort.SelectedItem}}
  $temp=$script:JournalPreferencePath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
  [IO.File]::WriteAllText($temp,($data | ConvertTo-Json -Depth 5),[Text.Encoding]::UTF8)
  if([IO.File]::Exists($script:JournalPreferencePath)){[IO.File]::Replace($temp,$script:JournalPreferencePath,$script:JournalPreferencePath+'.bak')}else{[IO.File]::Move($temp,$script:JournalPreferencePath)}
 }catch{$journalDetails.Text=(Get-QuestbookText 'Preferences could not be saved. Game save files were not affected.')+' '+$_.Exception.Message}
}
function Refresh-JournalRecent {
 $journalRecent.Items.Clear();[void]$journalRecent.Items.Add([pscustomobject]@{Id=-1;Label='Recent selections'})
 foreach($id in $script:JournalRecentIds){[void]$journalRecent.Items.Add([pscustomobject]@{Id=$id;Label=$script:Items[$id].Name})};$journalRecent.SelectedIndex=0
}
function Show-JournalSources {
 if(-not $catalog.SelectedItem){return};$m=$script:MaterialById[[int]$catalog.SelectedItem.Id]
 $dialog=[Windows.Forms.Form]::new()
 try {$dialog.Text='Material field guide — '+$m.Name;$dialog.ClientSize=[Drawing.Size]::new(800,520);$text=Add-Control $dialog TextBox '' 15 15 770 485;$text.Multiline=$true;$text.ReadOnly=$true;$text.ScrollBars='Vertical';$text.Text=(Format-QuestbookText '{0} [ID {1}]

' @(($($m.Name)),($($m.Id))))+($m.Details -join "`r`n")+"`r`n`r`nMonster habitats show possible locations, not guaranteed drop points. Items without location information are listed as Unknown.";Set-QuestbookTree $dialog;[void]$dialog.ShowDialog($form)}finally{$dialog.Dispose()}
}
function Open-JournalBatchWait {
 $wait=[Windows.Forms.Form]::new()
 try{
  $wait.Text=Get-QuestbookText 'Wait...Adding';$wait.ClientSize=[Drawing.Size]::new(400,120)
  $wait.StartPosition='CenterParent';$wait.FormBorderStyle='FixedDialog'
  $wait.ControlBox=$false;$wait.ShowInTaskbar=$false;$wait.UseWaitCursor=$true
  [void](Add-Control $wait Label 'Wait...Adding' 18 14 364 40)
  $progress=Add-Control $wait ProgressBar '' 24 66 352 20;$progress.Style='Marquee';$progress.MarqueeAnimationSpeed=25
  $wait.Add_FormClosing({param($sender,$event) if($sender.Tag -ne 'done'){$event.Cancel=$true}})
  Set-QuestbookTree $wait;$wait.Show($form);$wait.Refresh()
  return $wait
 }catch{$wait.Dispose();throw}
}
function Close-JournalBatchWait($wait) {
 if($wait -and -not $wait.IsDisposed){$wait.Tag='done';$wait.Close();$wait.Dispose()}
}
function Confirm-JournalBatch([string]$summary,$wait){
 $review=[Windows.Forms.Form]::new()
 try {
  $review.Text='Review entire batch';$review.ClientSize=[Drawing.Size]::new(800,590);$review.TopMost=$true
  $review.Tag=$wait
  $review.Add_Shown({param($sender,$event) $sender.Activate();Close-JournalBatchWait $sender.Tag;$sender.Tag=$null})
  $text=Add-Control $review TextBox $summary 15 15 770 475;$text.Multiline=$true;$text.ReadOnly=$true;$text.ScrollBars='Vertical'
  [void](Add-Control $review Label 'Every listed addition is applied together to the working copy. Undo restores the previous copy.' 15 495 770 35)
  $ok=Add-Control $review Button 'Apply batch' 15 540 180 32;$ok.DialogResult='Yes'
  $cancel=Add-Control $review Button 'Cancel' 210 540 180 32;$cancel.DialogResult='Cancel';$review.CancelButton=$cancel
  Set-QuestbookTree $review
  return $review.ShowDialog($form) -eq 'Yes'
 }finally{$review.Dispose()}
}
function Get-JournalBatchCatalog {
 $labels=@{0='Item';1='Material';3='Ammo';4='Jewel';5='Furniture'}
 foreach($item in $script:Items){
  $id=[int]$item.Id;$category=[int]$item.Category
  if($id -le 0 -or -not $labels.ContainsKey($category) -or [string]$item.Name -match '^\s*(?:-+|Unavailable|\(None\))?\s*$'){continue}
  $name=Get-QuestbookGameText $item.Name 'item_name'
  $kind=Get-QuestbookText $labels[$category]
  [pscustomobject]@{Id=$id;Category=$category;Name=$name;Kind=$kind;Search="$name $($item.Name) $id $kind $($labels[$category])"}
 }
}
function Search-JournalBatchCatalog($rows,[string]$query) {
 $query=$query.Trim()
 if(-not $query){return $rows}
 if($query -match '^(?:ID\s*:?\s*)?(\d+)$'){
  $id=0;if([int]::TryParse($Matches[1],[ref]$id)){return $rows | Where-Object Id -eq $id}
  return
 }
 $tokens=$query -split '\s+'
 foreach($row in $rows){
  $match=$true
  foreach($token in $tokens){if($row.Search.IndexOf($token,[StringComparison]::CurrentCultureIgnoreCase) -lt 0){$match=$false;break}}
  if($match){$row}
 }
}
function New-JournalBatchRow($item){
 $row=[Windows.Forms.ListViewItem]::new([string]$item.Name)
 [void]$row.SubItems.Add([string]$item.Id);[void]$row.SubItems.Add([string]$item.Kind)
 $row.Tag=$item
 return $row
}
function Update-JournalBatchSearch($ui) {
 $items=@(Search-JournalBatchCatalog $ui.Rows $ui.Search.Text)
 $ui.Pick.BeginUpdate()
 try{
  $ui.Pick.Items.Clear()
  $result=@(foreach($item in $items){New-JournalBatchRow $item})
  if($result.Count){$ui.Pick.Items.AddRange([Windows.Forms.ListViewItem[]]$result)}
 }finally{$ui.Pick.EndUpdate()}
 $ui.Count.Text="$($items.Count) results"
}
function Update-JournalBatchQueue($ui) {
 $ui.Queue.BeginUpdate()
 try{
  $ui.Queue.Items.Clear()
  foreach($item in $ui.Pending.Values){[void]$ui.Queue.Items.Add((New-JournalBatchRow $item))}
 }finally{$ui.Queue.EndUpdate()}
 $ui.Go.Enabled=$ui.Pending.Count -gt 0
 $ui.QueueCount.Text="$($ui.Pending.Count) / 128 queued"
}
function Add-JournalBatchSelection($ui) {
 $new=@($ui.Pick.SelectedItems | ForEach-Object {$_.Tag} | Where-Object {-not $ui.Pending.Contains([string]$_.Id)})
 if($ui.Pending.Count+$new.Count -gt 128){throw 'You can queue up to 128 different item IDs.'}
 foreach($item in $new){$ui.Pending.Add([string]$item.Id,$item)}
 Update-JournalBatchQueue $ui
}
function Get-JournalBatchRecords($inventory) {
 $byId=@{};foreach($record in $inventory){$byId[[int]$record.id]=$record}
 return $byId
}
function New-JournalBatchPreview([string]$inputSave,[int]$slotNumber,$beforeInventory,$selected,[int]$quantity,[switch]$KeepUiResponsive) {
 if(@($selected).Count -lt 1 -or @($selected).Count -gt 128 -or $quantity -lt 1 -or $quantity -gt 9999){throw 'Invalid batch size or quantity.'}
 $before=Get-JournalBatchRecords $beforeInventory
 $latest=$inputSave;$next=$null;$keep=$false
 try {
  $ordinary=@($selected | Where-Object {$_.Category -in @(0,1,3)})
  if($ordinary.Count){
   $spec=($ordinary | ForEach-Object {"$($_.Id):$quantity"}) -join ','
   $preview=Invoke-Engine -KeepUiResponsive:$KeepUiResponsive -Arguments @('batch-preview',$latest,[string]$slotNumber,$spec)
   $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
   [void](Invoke-Engine -KeepUiResponsive:$KeepUiResponsive -Arguments @('batch-add',$latest,$next,[string]$slotNumber,$spec,[string]$preview.input_sha256))
   $latest=$next;$next=$null
  }
  foreach($item in @($selected | Where-Object {$_.Category -in @(4,5)})){
   if($item.Category -eq 5 -and $before.ContainsKey($item.Id)){continue}
   $delta=if($item.Category -eq 5){1}else{$quantity}
   $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
   try{[void](Invoke-Engine -KeepUiResponsive:$KeepUiResponsive -Arguments @('inventory',$latest,$next,[string]$slotNumber,[string]$item.Id,[string]$delta))}
   catch{throw "$($item.Name) [ID $($item.Id)]: $($_.Exception.Message)"}
   if($latest -ne $inputSave){Remove-Item -LiteralPath $latest -Force}
   $latest=$next;$next=$null
  }
  $newState=Invoke-Engine -KeepUiResponsive:$KeepUiResponsive -Arguments @('inspect',$latest)
  $slotInfo=$newState.slots | Where-Object {[int]$_.number -eq $slotNumber} | Select-Object -First 1
  if(-not $slotInfo){throw 'The selected save slot was not found in the batch preview.'}
  $after=Get-JournalBatchRecords $slotInfo.inventory
  $summary=@(foreach($item in $selected){
   $old=$before[$item.Id];$new=$after[$item.Id]
   if($item.Category -eq 5){
    if(-not $new -or $new.kind -ne 'furniture_unlock'){throw "$($item.Name) did not unlock. No batch was applied."}
    "$($item.Name) [ID $($item.Id)]: $(if($old){'Already unlocked'}else{'Locked → Unlocked'})"
   }else{
    $oldAmount=if($old){[int]$old.amount}else{0}
    if(-not $new -or [int]$new.amount -ne $oldAmount+$quantity){throw "$($item.Name) could not receive the full quantity. No batch was applied."}
    "$($item.Name) [ID $($item.Id)]: $oldAmount → $($new.amount)"
   }
  }) -join "`r`n"
  $keep=$true
  return [pscustomobject]@{Path=$latest;State=$newState;Summary=$summary}
 }finally{
  if($next -and (Test-Path -LiteralPath $next)){Remove-Item -LiteralPath $next -Force}
  if(-not $keep -and $latest -ne $inputSave -and (Test-Path -LiteralPath $latest)){Remove-Item -LiteralPath $latest -Force}
 }
}
. (Join-Path $script:Root 'BatchPresets.ps1')
function Show-JournalBatch {
 $current=Current-Slot;$source=$script:Working;$dialog=[Windows.Forms.Form]::new();$preview=$null;$wait=$null;$ownerEnabled=$form.Enabled
 try {
  $dialog.Text='Batch add';$dialog.ClientSize=[Drawing.Size]::new(950,685)
  [void](Add-Control $dialog Label 'Search by item name or ID' 15 12 205 30)
  $find=Add-Control $dialog TextBox '' 225 12 510 30
  $count=Add-Control $dialog Label '' 745 12 190 30
  [void](Add-Control $dialog Label 'Select items with Ctrl / Shift, then queue them. Search again to add more.' 15 53 580 32)
  $queueCount=Add-Control $dialog Label '' 610 53 325 32
  $preset=Add-Control $dialog ComboBox '' 15 93 300 34;$preset.DropDownStyle='DropDownList';$preset.AccessibleName=Get-QuestbookText 'Batch Add presets'
  $queuePreset=Add-Control $dialog Button 'Queue preset' 325 93 175 34
  $savePreset=Add-Control $dialog Button 'Save preset' 510 93 190 34
  $deletePreset=Add-Control $dialog Button 'Delete preset' 710 93 225 34
  $pick=Add-Control $dialog ListView '' 15 140 580 380
  $queue=Add-Control $dialog ListView '' 610 140 325 380
  foreach($list in @($pick,$queue)){
   $list.View='Details';$list.FullRowSelect=$true;$list.MultiSelect=$true;$list.HideSelection=$false
   [void]$list.Columns.Add('Item',$(if($list -eq $pick){390}else{174}))
   [void]$list.Columns.Add('ID',56);[void]$list.Columns.Add('Category',$(if($list -eq $pick){105}else{70}))
  }
  $addRows=Add-Control $dialog Button 'Queue selected' 15 532 225 35
  $removeRows=Add-Control $dialog Button 'Remove selected' 610 532 325 35
  [void](Add-Control $dialog Label 'Quantity per item:' 15 580 180 30)
  $amount=Add-Control $dialog NumericUpDown '' 200 580 100 30;$amount.Minimum=1;$amount.Maximum=9999;$amount.Value=1
  $go=Add-Control $dialog Button 'Preview batch...' 685 580 250 35;$go.DialogResult='OK'
  [void](Add-Control $dialog Label 'Furniture unlocks once. Account items are acquired separately through the in-game bridge.' 15 628 920 35)
  $ui=[pscustomobject]@{Rows=@(Get-JournalBatchCatalog | Sort-Object Name,Id);Search=$find;Pick=$pick;Queue=$queue;Count=$count;QueueCount=$queueCount;Pending=[ordered]@{};Go=$go}
  $ui | Add-Member NoteProperty Dialog $dialog
  $ui | Add-Member NoteProperty Preset $preset
  $ui | Add-Member NoteProperty Presets @()
  $ui | Add-Member NoteProperty DeletePreset $deletePreset
  $byId=@{};foreach($item in $ui.Rows){$byId[[int]$item.Id]=$item}
  $ui | Add-Member NoteProperty ById $byId
  foreach($control in @($find,$pick,$addRows,$removeRows,$preset,$queuePreset,$savePreset,$deletePreset)){$control.Tag=$ui}
  $preset.Add_SelectedIndexChanged({param($sender,$event) $entry=Get-SelectedBatchPreset $sender.Tag;$sender.Tag.DeletePreset.Enabled=($null -ne $entry -and -not $entry.BuiltIn)})
  $queuePreset.Add_Click({param($sender,$event) Run-Action {$u=$sender.Tag;if($entry=Get-SelectedBatchPreset $u){Add-BatchPresetItems $u.Pending $u.ById $entry.Ids;Update-JournalBatchQueue $u}}})
  $savePreset.Add_Click({param($sender,$event) Run-Action {Save-JournalBatchPreset $sender.Tag}})
  $deletePreset.Add_Click({param($sender,$event) Run-Action {Remove-JournalBatchPreset $sender.Tag}})
  Run-Action {Update-BatchPresetChoices $ui}
  $find.Add_TextChanged({param($sender,$event) Run-Action {Update-JournalBatchSearch $sender.Tag}})
  $addRows.Add_Click({param($sender,$event) Run-Action {Add-JournalBatchSelection $sender.Tag}})
  $pick.Add_DoubleClick({param($sender,$event) Run-Action {Add-JournalBatchSelection $sender.Tag}})
  $removeRows.Add_Click({param($sender,$event) Run-Action {$state=$sender.Tag;foreach($row in @($state.Queue.SelectedItems)){$state.Pending.Remove([string]$row.Tag.Id)};Update-JournalBatchQueue $state}})
  Set-QuestbookTree $dialog;Enable-QuestbookList $pick;Enable-QuestbookList $queue
  Update-JournalBatchSearch $ui;Update-JournalBatchQueue $ui
  $dialog.ActiveControl=$find
  if($dialog.ShowDialog($form) -ne 'OK'){return}
  $wait=Open-JournalBatchWait
  $form.Enabled=$false
  try{
   $preview=New-JournalBatchPreview $source ([int]$current.number) $current.inventory @($ui.Pending.Values) ([int]$amount.Value) -KeepUiResponsive
  }finally{$form.Enabled=$ownerEnabled}
  if($preview.Path -eq $source){Close-JournalBatchWait $wait;[HuntersCompanion.Messages]::Show($preview.Summary,'No changes needed')|Out-Null;return}
  if(-not (Confirm-JournalBatch $preview.Summary $wait)){return}
  $wait=Open-JournalBatchWait
  if($script:Working -ne $source -or [int](Current-Slot).number -ne [int]$current.number){throw 'The active save changed after the preview.'}
  $script:History.Add($source);$script:Working=$preview.Path;$script:State=$preview.State
  Refresh-Slot -InventoryOnly $true
 }finally{
  $form.Enabled=$ownerEnabled
  Close-JournalBatchWait $wait
  if($preview -and $preview.Path -ne $source -and $preview.Path -ne $script:Working -and (Test-Path -LiteralPath $preview.Path)){Remove-Item -LiteralPath $preview.Path -Force}
  $dialog.Dispose()
 }
}
$journalFavorite.Add_Click({Run-Action {if($catalog.SelectedItem){$id=[int]$catalog.SelectedItem.Id;if($script:JournalFavorites.Contains($id)){[void]$script:JournalFavorites.Remove($id)}else{[void]$script:JournalFavorites.Add($id)};Request-JournalSave;Request-JournalRefresh}}})
$journalSources.Add_Click({Run-Action {Show-JournalSources}});$journalBatch.Add_Click({Run-Action {Show-JournalBatch}})
$catalog.Add_SelectedIndexChanged({if(-not $script:JournalInitializing -and -not $script:JournalFilling -and $catalog.SelectedItem){Run-Action {$id=[int]$catalog.SelectedItem.Id;$index=$catalog.SelectedIndex;if($index -lt $box.Items.Count -and -not $box.Items[$index].Selected){$script:JournalFilling=$true;try{foreach($selectedRow in @($box.SelectedItems)){$selectedRow.Selected=$false};$box.Items[$index].Selected=$true;$box.EnsureVisible($index)}finally{$script:JournalFilling=$false}};[void]$script:JournalRecentIds.Remove($id);$script:JournalRecentIds.Insert(0,$id);while($script:JournalRecentIds.Count -gt 20){$script:JournalRecentIds.RemoveAt(20)};Refresh-JournalRecent;Request-JournalSave;Update-JournalDetails}}})
$journalRecent.Add_SelectedIndexChanged({if($journalRecent.SelectedIndex -gt 0){Run-Action {$id=[int]$journalRecent.SelectedItem.Id;for($i=0;$i -lt $catalog.Items.Count;$i++){if([int]$catalog.Items[$i].Id -eq $id){$catalog.SelectedIndex=$i;return}};$journalDetails.Text='That recent item is hidden by current filters. Clear filters to find it.'}}})
foreach($c in @($journalFamily,$journalMonster,$journalRank,$journalRegion,$journalSource,$journalAffinity,$journalRarity,$journalOwned)){$c.Add_SelectedIndexChanged({if(-not $script:JournalInitializing){Run-Action {Request-JournalRefresh;Request-JournalSave}}})}
$box.HeaderStyle='Clickable'
$box.Add_ColumnClick({param($sender,$event) Run-Action {Set-JournalHeaderSort $event.Column}})
$journalSort.Add_SelectionChangeCommitted({
 if(-not $script:JournalInitializing){$script:JournalHeaderColumn=-1;$script:JournalHeaderDescending=$false;Request-JournalRefresh;Request-JournalSave}
})
if(Test-Path -LiteralPath $script:JournalPreferencePath){try{if((Get-Item -LiteralPath $script:JournalPreferencePath).Length -gt 1048576){throw 'Preferences too large'};$prefs=Get-Content -LiteralPath $script:JournalPreferencePath -Raw | ConvertFrom-Json;if($prefs.Format -eq 'MHWI_JOURNAL_PREFS_V1'){foreach($v in $prefs.Favorites){if([int]$v -ge 0 -and [int]$v -lt $script:Items.Count){[void]$script:JournalFavorites.Add([int]$v)}};foreach($v in @($prefs.Recent | Select-Object -First 20)){if([int]$v -ge 0 -and [int]$v -lt $script:Items.Count){$script:JournalRecentIds.Add([int]$v)}};$sort=[string]$prefs.Filters.Sort;if($journalSort.Items.Contains($sort)){$journalSort.SelectedItem=$sort}}}catch{$journalDetails.Text=(Get-QuestbookText 'Preferences reset:')+' '+$_.Exception.Message}}
Refresh-JournalRecent;$script:JournalInitializing=$false
$search.Add_TextChanged({if(-not $script:JournalInitializing){Request-JournalSave}})
$filter.Add_SelectedIndexChanged({if(-not $script:JournalInitializing){Request-JournalSave}})
$journalRecent.Width=220;$journalSources.Left=945;$journalSources.Width=115
$journalReset=Add-Control $inv Button 'Reset filters' 825 98 110 30
$journalReset.Add_Click({Run-Action {$script:JournalInitializing=$true;try{$script:JournalHeaderColumn=-1;$script:JournalHeaderDescending=$false;$search.Text='';$filter.SelectedIndex=0;$journalRecent.SelectedIndex=0;foreach($c in @($journalFamily,$journalMonster,$journalRank,$journalRegion,$journalSource,$journalAffinity,$journalRarity,$journalOwned,$journalSort)){$c.SelectedIndex=0}}finally{$script:JournalInitializing=$false};Request-JournalRefresh;Request-JournalSave}})
foreach($pair in @(@($journalFamily,'book'),@($journalMonster,'hunter'),@($journalRank,'hunter'),@($journalRegion,'book'),@($journalSource,'inventory'),@($journalAffinity,'hunter'),@($journalRarity,'inventory'),@($journalOwned,'inventory'),@($journalSort,'book'),@($journalRecent,'book'))){Enable-QuestbookCombo $pair[0] $pair[1]}
$script:QuestbookTips.SetToolTip($journalAffinity,'Blights and ailments inflicted by a source monster; this is not a material element or a monster weakness filter.')
$palicoTab=[Windows.Forms.TabPage]::new('Palico');[void]$tabs.TabPages.Add($palicoTab)
[void](Add-Control $palicoTab Label 'Palico name and saved experience' 15 18 1045 45)
[void](Add-Control $palicoTab Label 'Palico name:' 15 75 140 30)
$palicoName=Add-Control $palicoTab TextBox '' 160 72 510 32;$palicoName.MaxLength=63
$palicoRead=Add-Control $palicoTab Button 'Read current' 690 72 170 32
$palicoApply=Add-Control $palicoTab Button 'Preview changes...' 880 72 180 32
$palicoStatus=Add-Control $palicoTab Label 'Open a save and choose an active character.' 15 120 1045 40
$script:PalicoXpNames=@('Palico XP','Vigorwasp Spray XP','Flashfly Cage XP','Shieldspire XP','Coral Orchestra XP','Plunderblade XP','Meowlotov Cocktail XP')
$script:PalicoSpins=@()
for($i=0;$i -lt 7;$i++){
 [void](Add-Control $palicoTab Label $script:PalicoXpNames[$i] 15 (180+45*$i) 270 30)
 $spin=Add-Control $palicoTab NumericUpDown '' 300 (178+45*$i) 220 32;$spin.Minimum=0;$spin.Maximum=[decimal]4294967295;$script:PalicoSpins+=$spin
}
$palicoReferences=Add-Control $palicoTab TextBox 'Cached guild-card equipment references will appear here (read-only).' 565 178 495 240
$palicoReferences.Multiline=$true;$palicoReferences.ReadOnly=$true;$palicoReferences.ScrollBars='Vertical'
[void](Add-Control $palicoTab Label 'XP values are shown as saved. Editing XP does not unlock gadgets. Equipment and appearance cannot be changed here.' 565 440 495 120)
$script:PalicoInfo=$null
function Refresh-Palico {
 $journalBatch.Enabled=$false
 $palicoApply.Enabled=$false;$palicoRead.Enabled=($null -ne $script:State -and $slot.SelectedIndex -ge 0)
 if(-not $palicoRead.Enabled){$script:PalicoInfo=$null;return}
 $current=Current-Slot;$script:PalicoInfo=Invoke-Engine -Arguments @('palico-info',$script:Working,[string]$current.number)
 $palicoName.Text=[string]$script:PalicoInfo.name
 for($i=0;$i -lt 7;$i++){$script:PalicoSpins[$i].Value=[decimal]$script:PalicoInfo.xp[$i]}
 $palicoApply.Enabled=[bool]$script:PalicoInfo.active;$journalBatch.Enabled=[bool]$script:PalicoInfo.active
 $palicoStatus.Text='Edit saved XP values. Preview lists each change; Undo restores the previous values.'
 $labels=@('Weapon','Helmet','Body','Gadget');$lines=@('Guild-card equipment references (cached / read-only):','')
 for($i=0;$i -lt 4;$i++){$ref=$script:PalicoInfo.equipment_references[$i];$lines+=(Format-QuestbookText '{0}: type {1}, ID {2}' @($labels[$i],$ref.type,$ref.id))}
 $palicoReferences.Text=$lines -join "`r`n"
}
$palicoRead.Enabled=$false;$palicoApply.Enabled=$false;$journalBatch.Enabled=$false
$palicoRead.Add_Click({Run-Action {Refresh-Palico}})
$palicoApply.Add_Click({Run-Action {
 if(-not $script:PalicoInfo -or -not $script:PalicoInfo.active){throw 'Open an active character slot first.'}
 $bytes=[Text.Encoding]::UTF8.GetByteCount($palicoName.Text);if($bytes -lt 1 -or $bytes -gt 63){throw 'The Palico name must occupy 1..63 UTF-8 bytes.'}
 $changes=[Collections.Generic.List[string]]::new()
 if($palicoName.Text -ne $script:PalicoInfo.name){$changes.Add((Format-QuestbookText 'Name: {0} -> {1}' @(($($script:PalicoInfo.name)),($($palicoName.Text)))))}
 $values=@();for($i=0;$i -lt 7;$i++){$v=$script:PalicoSpins[$i].Value.ToString('0',[Globalization.CultureInfo]::InvariantCulture);$values+=$v;if([decimal]$script:PalicoInfo.xp[$i] -ne [decimal]$v){$changes.Add((Format-QuestbookText '{0}: {1} -> {2}' @(($($script:PalicoXpNames[$i])),($($script:PalicoInfo.xp[$i])),($v))))}}
 if(-not $changes.Count){return}
 if([HuntersCompanion.Messages]::Show(($changes -join "`r`n")+"`r`n`r`nApply only these name/XP fields to the working copy? Equipment, appearance and unlock flags are preserved.",'Palico change preview','YesNo') -ne 'Yes'){return}
 Apply-Edit 'palico-edit' (@($palicoName.Text)+$values+@([string]$script:PalicoInfo.input_sha256))
}})
