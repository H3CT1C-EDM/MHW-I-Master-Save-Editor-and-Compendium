﻿$script:QuestRewardAnalysisById=@{}
foreach($entry in @((Get-Content -LiteralPath (Join-Path $script:Root 'catalog\QuestRewardAnalysis.json') -Raw -Encoding UTF8|ConvertFrom-Json).Quests)){
    $script:QuestRewardAnalysisById[[int64]$entry.QuestId]=$entry
}
function Get-QuestRewardAnalysis($q){
    if(-not $q -or $null -eq $q.Id -or $q.Key -ne "game:$($q.Id)" -or $q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){return $null}
    return $script:QuestRewardAnalysisById[[int64]$q.Id]
}
function Get-QuestRewardLines($analysis){
    if(-not $analysis){return}
    Get-QuestbookText 'Reward Table Details (View Only)'
    Get-QuestbookText 'These entries describe reward generation. No materials, Zenny, or rank points are granted.'
    foreach($pool in @($analysis.Pools)){
        (Get-QuestbookText 'Reward Pool')+" $($pool.Id)"
        foreach($item in @($pool.Items)){
            $name=if([int]$item.ItemId -ge 0 -and [int]$item.ItemId -lt $script:Items.Count){$script:Items[[int]$item.ItemId].Name}else{(Get-QuestbookText 'Unknown Item')}
            $chance=(100.0*[double]$item.Weight/[double]$pool.TotalWeight).ToString('0.##',[Globalization.CultureInfo]::InvariantCulture)
            $prefix=if($item.Index -eq $pool.FirstSlotIndex){(Get-QuestbookText 'First generated slot')+'; '}else{''}
            "  $name [ID $($item.ItemId)] x$($item.Count) | $prefix"+(Get-QuestbookText 'Random draw')+": $chance%"
        }
    }
    Get-QuestbookText 'The first generated slot selects the fixed entry. Later slots use the listed random-draw chances; that entry may be selected again.'
    Get-QuestbookText 'Slot counts depend on the quest and player conditions. A saved clear flag does not record whether rewards were collected.'
}
