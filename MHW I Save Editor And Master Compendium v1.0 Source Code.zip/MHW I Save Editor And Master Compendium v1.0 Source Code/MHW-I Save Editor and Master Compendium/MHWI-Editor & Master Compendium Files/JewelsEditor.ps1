﻿param($LoadingSplash=$null,[scriptblock]$StartupTrace=$null)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:Root = $PSScriptRoot
if($LoadingSplash){$LoadingSplash.Refresh();[Windows.Forms.Application]::DoEvents()}
Add-Type -Path (Join-Path $PSScriptRoot 'CompanionControls.cs') -ReferencedAssemblies @('System.Windows.Forms','System.Drawing')
. (Join-Path $PSScriptRoot 'QuestbookTheme.ps1')
. (Join-Path $PSScriptRoot 'QuestbookLayout.ps1')
. (Join-Path $PSScriptRoot 'QuestbookNavigation.ps1')
. (Join-Path $PSScriptRoot 'QuestbookLocalization.ps1')
. (Join-Path $PSScriptRoot 'CompanionUserInterface.ps1')
$script:Working = $null
$script:State = $null
$script:Source = $null
$script:History = [System.Collections.Generic.List[string]]::new()
$script:Session = Join-Path ([IO.Path]::GetTempPath()) ('MHWJewels-' + [guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($script:Session) | Out-Null
$script:Items = @(Import-Csv (Join-Path $script:Root 'catalog\Items.csv'))
$script:Gems = @(Import-Csv (Join-Path $script:Root 'catalog\Jewels.csv'))
$script:EquipmentNames = @{}
foreach($e in (Import-Csv (Join-Path $script:Root 'catalog\Equipment.csv'))) {
    $key = "$($e.Category):$($e.Type):$($e.Id)"
    if(-not $script:EquipmentNames.ContainsKey($key)) { $script:EquipmentNames[$key] = $e }
}
function Invoke-Engine([string[]]$Arguments,[switch]$KeepUiResponsive) {
    $quoted = foreach($arg in $Arguments) {
        if($arg.Contains('"')) { throw 'A command argument contains an unsupported quote.' }
        '"' + ($arg -replace '(\\+)$','$1$1') + '"'
    }
    $si = [Diagnostics.ProcessStartInfo]::new()
    $si.FileName = Join-Path $script:Root 'MHWJewelsEngine.exe'
    $si.Arguments = $quoted -join ' '
    $si.UseShellExecute = $false
    $si.CreateNoWindow = $true
    $si.RedirectStandardOutput = $true
    $si.RedirectStandardError = $true
    $si.StandardOutputEncoding = [Text.Encoding]::UTF8
    $p = [Diagnostics.Process]::Start($si)
    try {
        $output=$p.StandardOutput.ReadToEndAsync()
        $errors=$p.StandardError.ReadToEndAsync()
        if($KeepUiResponsive){
            while(-not $p.WaitForExit(40)){[Windows.Forms.Application]::DoEvents()}
        }else{$p.WaitForExit()}
        $stdout=$output.GetAwaiter().GetResult()
        $stderr=$errors.GetAwaiter().GetResult()
        if($p.ExitCode -ne 0) { throw $stderr.Trim() }
        return ($stdout | ConvertFrom-Json)
    }finally{$p.Dispose()}
}
function Run-Action([scriptblock]$action) {
    $previousCursor=$form.UseWaitCursor
    try {$form.UseWaitCursor=$true;$form.Update();& $action} catch {$failure=$_.Exception;while($failure.InnerException){$failure=$failure.InnerException};[HuntersCompanion.Messages]::Show($failure.Message,'Hunters Companion')|Out-Null}finally{$form.UseWaitCursor=$previousCursor}
}
function Add-Control($parent,[string]$type,[string]$text,[int]$x,[int]$y,[int]$w,[int]$h) {
    $c = if($type -eq 'ComboBox'){[HuntersCompanion.RememberedComboBox]::new()}elseif($type -eq 'ListView'){[HuntersCompanion.ParchmentListView]::new()}else{New-Object ('System.Windows.Forms.' + $type)}
    $c.Text=if($script:LocalizationReady){Get-QuestbookText $text}else{$text}; $c.SetBounds($x,$y,$w,$h); $parent.Controls.Add($c)
    Set-QuestbookControl $c
    if($script:LocalizationReady){Register-CompanionControl $c}
    return $c
}
$script:ThumbnailCache = @{}
$script:ItemOverrideIds=[Collections.Generic.HashSet[int]]::new()
foreach($file in Get-ChildItem -LiteralPath (Join-Path $script:Root 'item-images') -Filter '*.png' -File -ErrorAction SilentlyContinue){$id=0;if([int]::TryParse($file.BaseName,[ref]$id)){[void]$script:ItemOverrideIds.Add($id)}}
$script:InventoryImages = [Windows.Forms.ImageList]::new()
$script:InventoryImages.ImageSize = [Drawing.Size]::new(24,24)
$script:InventoryImages.ColorDepth = 'Depth32Bit'
function Get-ThumbnailKey($entry) {
    if(-not $entry){return $null}
    if($entry.PSObject.Properties['Id']){
        $id=[int]$entry.Id
        if($script:ItemOverrideIds.Contains($id)){return ('item-'+$id)}
    }
    if($entry.PSObject.Properties['ThumbKey']){return [string]$entry.ThumbKey}
    if($entry.PSObject.Properties['Meta'] -and $entry.Meta.PSObject.Properties['ThumbKey']){return [string]$entry.Meta.ThumbKey}
    return $null
}
function Get-Thumbnail([string]$key) {
    if(-not $key){return $null}
    if(-not $script:ThumbnailCache.ContainsKey($key)){
        $relative=if($key -match '^item-([0-9]+)$'){"item-images\"+$Matches[1]+'.png'}else{"thumbnails\"+$key+'.png'}
        $path=Join-Path $script:Root $relative
        if(-not (Test-Path -LiteralPath $path)){return $null}
        $source=[Drawing.Image]::FromFile($path)
        $script:ThumbnailCache[$key]=[Drawing.Bitmap]::new($source)
        $source.Dispose()
    }
    return $script:ThumbnailCache[$key]
}
function Enable-ThumbnailCombo($combo) {
    $combo.DrawMode='OwnerDrawFixed';$combo.ItemHeight=30;$combo.IntegralHeight=$false;$combo.MaxDropDownItems=12
    $combo.Add_DrawItem({param($sender,$event)
        $colors=Get-QuestbookComboColors $sender $event
        $brush=[Drawing.SolidBrush]::new($colors.Back)
        try {$event.Graphics.FillRectangle($brush,$event.Bounds)}finally{$brush.Dispose()}
        if($event.Index -ge 0 -and $event.Index -lt $sender.Items.Count){
            $entry=$sender.Items[$event.Index];$image=Get-Thumbnail (Get-ThumbnailKey $entry)
            $iconSize=[int](24*[Math]::Max(1.0,[Math]::Min(1.5,$sender.Font.SizeInPoints/9.5)))
            if($image){$event.Graphics.DrawImage($image,$event.Bounds.X+4,$event.Bounds.Y+[int](($event.Bounds.Height-$iconSize)/2),$iconSize,$iconSize)}
            $rect=[Drawing.Rectangle]::new($event.Bounds.X+$iconSize+10,$event.Bounds.Y,$event.Bounds.Width-$iconSize-12,$event.Bounds.Height)
            $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::EndEllipsis -bor [Windows.Forms.TextFormatFlags]::NoPrefix
            [Windows.Forms.TextRenderer]::DrawText($event.Graphics,(Get-QuestbookText ([string]$entry.Label)),$sender.Font,$rect,(Get-CompanionItemColor $entry $colors.Fore),$flags)
        }
        $event.DrawFocusRectangle()
    })
}
$form = [Windows.Forms.Form]::new()
$form.Text = 'MHWI Save Editor - Hunter''s Questbook'
$form.AutoScaleMode='Dpi'
$form.AutoScaleDimensions=[Drawing.SizeF]::new(96,96)
$form.ClientSize = [Drawing.Size]::new(1120,760)
$form.MinimumSize = [Drawing.Size]::new(1136,799)
$form.Font = [Drawing.Font]::new('Segoe UI',10)
$open = Add-Control $form Button 'Open save' 15 12 120 32
$save = Add-Control $form Button 'Save As...' 145 12 120 32
$undo = Add-Control $form Button 'Undo edit' 275 12 120 32
$slot = Add-Control $form ComboBox '' 410 13 350 32
$slot.DropDownStyle = 'DropDownList'
$status = Add-Control $form Label 'Open a PC Iceborne save. Original files are never overwritten.' 15 52 1090 38
$tabs = Add-Control $form TabControl '' 15 96 1090 640
$inv = [Windows.Forms.TabPage]::new('Inventory / jewels'); [void]$tabs.TabPages.Add($inv)
$eqtab = [Windows.Forms.TabPage]::new('Fitted jewels / weapon slots'); [void]$tabs.TabPages.Add($eqtab)
$modtab = [Windows.Forms.TabPage]::new('Game-data exports'); [void]$tabs.TabPages.Add($modtab)
$search = Add-Control $inv TextBox '' 15 18 350 30
$filter = Add-Control $inv ComboBox '' 380 18 190 30
$filter.DropDownStyle='DropDownList'; [void]$filter.Items.AddRange([object[]]@('All game records','Jewels','Items','Materials','Ammo','Furniture unlocks','Account items')); $filter.SelectedIndex=0
$catalog = Add-Control $inv ComboBox '' 15 60 800 32
$catalog.DropDownStyle='DropDownList';$catalog.DisplayMember='Label';$catalog.DropDownWidth=950
$qty = Add-Control $inv NumericUpDown '' 825 61 70 32
$qty.Minimum=1;$qty.Maximum=9999;$qty.Value=1
$add = Add-Control $inv Button 'Add' 902 60 76 32
$remove = Add-Control $inv Button 'Remove' 984 60 76 32
$coverage = Add-Control $inv Label ("$($script:Items.Count) records / $($script:Gems.Count) jewels. Account acquisition uses the optional in-game bridge.") 15 104 1045 42
$box = Add-Control $inv ListView '' 15 154 1045 410
$box.View='Details';$box.FullRowSelect=$true;$box.GridLines=$false;$box.SmallImageList=$script:InventoryImages
[void]$box.Columns.Add('Item',660);[void]$box.Columns.Add('ID',90);[void]$box.Columns.Add('Qty / status',110);[void]$box.Columns.Add('Category',140)
$markFound = Add-Control $inv Button 'Account: discovery flag only' 15 574 270 32
$installBridge = Add-Control $inv Button 'Export account bridge...' 300 574 240 32
$importIcons = Add-Control $inv Button 'Import game item PNGs...' 555 574 240 32
$equipList = Add-Control $eqtab ComboBox '' 15 18 1045 32
$equipList.DropDownStyle='DropDownList';$equipList.DisplayMember='Label';$equipList.DropDownWidth=1000
$eqnote = Add-Control $eqtab Label 'Base slot levels are shown. Augment and awakening changes are not included.' 15 62 1045 38
$gemCombos=@();$sizeSpins=@()
for($i=0;$i -lt 3;$i++) {
    [void](Add-Control $eqtab Label ("Slot " + ($i+1)) 15 (115+$i*48) 70 30)
    $g=Add-Control $eqtab ComboBox '' 95 (112+$i*48) 770 32
    $g.DropDownStyle='DropDownList';$g.DisplayMember='Label';$g.DropDownWidth=900
    [void]$g.Items.Add([pscustomobject]@{Index=-1;Id=0;Size=0;Label='None (remove jewel)'})
    foreach($j in $script:Gems){[void]$g.Items.Add($j)}
    $gemCombos += $g
    [void](Add-Control $eqtab Label 'Slot level:' 875 (115+$i*48) 85 30)
    $s=Add-Control $eqtab NumericUpDown '' 965 (112+$i*48) 90 32
    $s.Minimum=0;$s.Maximum=4;$sizeSpins += $s
}
$stock = Add-Control $eqtab CheckBox 'Use box stock / return removed jewels (uncheck to create or delete fitted jewels)' 15 270 1045 30
$stock.Checked=$true
$ignore = Add-Control $eqtab CheckBox 'Allow larger jewels in existing slots (install the any-jewel game-data export)' 15 310 1045 30
$apply = Add-Control $eqtab Button 'Apply fitted jewels' 15 365 200 38
$slotExport = Add-Control $eqtab Button 'Export weapon slot levels...' 235 365 275 38
[void](Add-Control $eqtab Label 'Slot-level changes install game data directly into the selected game folder. They affect every copy of that weapon ID, not only this character. Missing slots remain unavailable until installed. Existing loadouts are preserved and may replace jewels when loaded in-game.' 15 430 1045 95)
$anyExport = Add-Control $modtab Button 'Install Any Jewel Fits' 15 72 490 40

function Current-Slot {
    if(-not $script:State -or $slot.SelectedIndex -lt 0) { throw 'Open a save first.' }
    return $script:State.slots[$slot.SelectedIndex]
}
function Update-InventoryActions {
    $entry=$catalog.SelectedItem
    $hasSave=($null -ne $script:State -and $slot.SelectedIndex -ge 0)
    $add.Enabled=$hasSave -and ($null -ne $entry)
    $remove.Enabled=$add.Enabled
    $qty.Enabled=$false
    $markFound.Enabled=$false
    if(-not $entry){return}
    $category=[int]$entry.Category
    $qty.Enabled=$hasSave -and ($category -ne 5)
    $qty.Maximum=if($category -eq 2){99}else{9999}
    $markFound.Enabled=$hasSave -and ($category -eq 2)
    if($category -eq 5){
        $qty.Value=1;$add.Text='Unlock';$remove.Text='Lock'
        $coverage.Text='Furniture ownership flag only (one unlock, no quantity). Placed furniture and room loadouts are preserved.'
    }elseif($category -eq 2){
        $add.Text='Acquire';$remove.Text='Clear'
        $coverage.Text='Acquire creates an account request. Use your configured bridge key in a solo expedition, then return and save. Clear removes discovery only.'
    }else{
        $add.Text='Add';$remove.Text='Remove'
        $coverage.Text=(Format-QuestbookText '{0} item records / {1} jewels. Furniture uses unlocks; account records use discovery flags.' @(($($script:Items.Count)),($($script:Gems.Count))))
    }
}
function Fill-Catalog {
    $catalog.BeginUpdate();$catalog.Items.Clear()
    $pattern=[regex]::Escape($search.Text)
    $cat=@(-1,4,0,1,3,5,2)[$filter.SelectedIndex]
    foreach($item in $script:Items) {
        if(($cat -eq -1 -or [int]$item.Category -eq $cat) -and $item.Label -match $pattern) {[void]$catalog.Items.Add($item)}
    }
    if($catalog.Items.Count -gt 0){$catalog.SelectedIndex=0};$catalog.EndUpdate()
}
function Refresh-Equipment {
    $e=$equipList.SelectedItem
    Reset-CompanionMrEligibility
    if($script:armorProgressButton){$script:armorProgressButton.Enabled=$false}
    if(-not $e) { return }
    if([int]$e.Record.category -eq 1) {
        $pendingKey="$($e.Record.type):$($e.Record.id)"
        if($script:WeaponEdits -and $script:WeaponEdits.Contains($pendingKey)){$levels=[pscustomobject]@{sizes=$script:WeaponEdits[$pendingKey].Sizes}}else{$levels=Invoke-Engine -Arguments @('slot-info',(Get-EquipmentTableRoot),[string]$e.Record.type,[string]$e.Record.id)}
        for($k=0;$k -lt 3;$k++){$e.Meta.("Cap$k")=[string]$levels.sizes[$k]}
    }elseif([int]$e.Record.category -eq 0 -and [int]$e.Record.type -ge 0 -and [int]$e.Record.type -le 4){
        $armorSizes=Read-CompanionArmorExportSlots ([int]$e.Record.type) ([int]$e.Record.id)
        for($k=0;$k -lt 3;$k++){$e.Meta.("Cap$k")=[string]$armorSizes[$k]}
    }
    for($i=0;$i -lt 3;$i++) {
        $wanted=[int]$e.Record.decos[$i];$found=-1
        for($j=0;$j -lt $gemCombos[$i].Items.Count;$j++){if([int]$gemCombos[$i].Items[$j].Index -eq $wanted){$found=$j;break}}
        if($found -lt 0) {$found=$gemCombos[$i].Items.Add([pscustomobject]@{Index=$wanted;Id=0;Size=0;Label=(Format-QuestbookText 'Unknown original jewel {0}' @(($wanted)))})}
        $gemCombos[$i].SelectedIndex=$found
        $sizeSpins[$i].Value=[int]$e.Meta.("Cap$i")
        $sizeSpins[$i].Enabled=([int]$e.Record.category -eq 1)
    }
    $slotExport.Enabled=([int]$e.Record.category -eq 1)
    if($script:armorProgressButton){$script:armorProgressButton.Enabled=([int]$e.Record.category -eq 0 -and [int]$e.Record.type -in (0..4))}
    Show-CompanionEquipmentEffects $e
}
function Refresh-Slot([bool]$InventoryOnly=$false) {
    if(-not $script:State -or $slot.SelectedIndex -lt 0){return}
    $current=Current-Slot
    if(-not $InventoryOnly){
    $previous=if($equipList.SelectedItem){[int]$equipList.SelectedItem.Record.index}else{-1}
    $equipList.Items.Clear();$select=0
    foreach($e in $current.equipment) {
        $key="$($e.category):$($e.type):$($e.id)";$meta=$script:EquipmentNames[$key]
        if(-not $meta){$meta=[pscustomobject]@{Name="Unknown equipment $($e.id)";Cap0=0;Cap1=0;Cap2=0}}
        $idx=$equipList.Items.Add([pscustomobject]@{Label=(Format-QuestbookText '{0} [equipment {1}; ID {2}]' @(($($meta.Name)),($($e.index)),($($e.id))));Record=$e;Meta=$meta})
        if([int]$e.index -eq $previous){$select=$idx}
    }
    if($equipList.Items.Count -gt 0){$equipList.SelectedIndex=$select}
    }
    $status.Text=(Format-QuestbookText 'Integrity verified. {0} | Slot {1}: {2} | Unsaved edits: {3}' @(($($script:Source)),($($current.number)),($($current.name)),($($script:History.Count))))
    if($InventoryOnly){Update-JournalResultQuantities;return}
    Fill-Catalog
    if(Get-Command Refresh-QuestState -ErrorAction SilentlyContinue){Refresh-QuestState}
    if(Get-Command Refresh-Palico -ErrorAction SilentlyContinue){Refresh-Palico}
}
function Apply-Edit([string]$command,[string[]]$extra) {
    $current=Current-Slot
    $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
    [void](Invoke-Engine -Arguments (@($command,$script:Working,$next,[string]$current.number)+$extra))
    $newState=Invoke-Engine -Arguments @('inspect',$next)
    $script:History.Add($script:Working);$script:Working=$next;$script:State=$newState
    Refresh-Slot -InventoryOnly ($command -eq 'inventory')
}
$search.Add_TextChanged({if(Get-Command Request-JournalRefresh -ErrorAction SilentlyContinue){Request-JournalRefresh}else{Fill-Catalog}});$filter.Add_SelectedIndexChanged({if(Get-Command Request-JournalRefresh -ErrorAction SilentlyContinue){Request-JournalRefresh}else{Fill-Catalog}})
$catalog.Add_SelectedIndexChanged({Update-InventoryActions})
$slot.Add_SelectedIndexChanged({Run-Action {Refresh-Slot}})
$equipList.Add_SelectedIndexChanged({Run-Action {Refresh-Equipment}})
$open.Add_Click({Run-Action {
    $d=[Windows.Forms.OpenFileDialog]::new();$d.Title=(Get-QuestbookText 'Open PC Iceborne SAVEDATA1000');$d.Filter=(Get-QuestbookFileFilter 'All files|*.*')
    if($d.ShowDialog() -ne 'OK'){return}
    if($script:History.Count -gt 0 -and [HuntersCompanion.Messages]::Show('Discard the unsaved edits?','Open another save','YesNo') -ne 'Yes'){return}
    $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
    [IO.File]::Copy($d.FileName,$next,$false)
    $newState=Invoke-Engine -Arguments @('inspect',$next)
    $script:Source=$d.FileName;$script:Working=$next;$script:State=$null;$script:History.Clear();$slot.Items.Clear()
    foreach($s in $newState.slots){[void]$slot.Items.Add((Format-QuestbookText 'Slot {0}: {1} (HR {2}, MR {3})' @(($($s.number)),($($s.name)),($($s.hr)),($($s.mr)))))}
    $script:State=$newState;$slot.SelectedIndex=0
}})
$save.Add_Click({Run-Action {
    [void](Current-Slot)
    $d=[Windows.Forms.SaveFileDialog]::new();$d.Title=(Get-QuestbookText 'Save an edited copy (choose a NEW file)');$d.FileName='SAVEDATA1000_edited';$d.Filter=(Get-QuestbookFileFilter 'All files|*.*');$d.OverwritePrompt=$false
    if($d.ShowDialog() -ne 'OK'){return}
    [void](Invoke-Engine -Arguments @('roundtrip',$script:Working,$d.FileName))
    if(Get-Command Record-FixedRewardExport -ErrorAction SilentlyContinue){try{Record-FixedRewardExport $d.FileName}catch{[HuntersCompanion.Messages]::Show(((Get-QuestbookText 'The save copy was exported, but its reward receipt could not be updated:')+' '+$_.Exception.Message),'Reward Receipt','OK','Warning')|Out-Null}}
    if(Get-Command Record-ExperimentalPayoutExport -ErrorAction SilentlyContinue){try{Record-ExperimentalPayoutExport $d.FileName}catch{[HuntersCompanion.Messages]::Show(('The save copy was exported, but its experimental payout receipt could not be updated: '+$_.Exception.Message),'Hunters Companion')|Out-Null}}
    [HuntersCompanion.Messages]::Show((Format-QuestbookText 'Saved and verified: {0}

Your original remains unchanged. Test the copy after backing up your game save.' @(($($d.FileName)))),'Saved copy') | Out-Null
}})
$undo.Add_Click({Run-Action {
    if($script:History.Count -eq 0){return}
    $last=$script:History.Count-1;$script:Working=$script:History[$last];$script:History.RemoveAt($last)
    $script:State=Invoke-Engine -Arguments @('inspect',$script:Working);Refresh-Slot
}})
$add.Add_Click({Run-Action {
    if(-not $catalog.SelectedItem){return}
    if([int]$catalog.SelectedItem.Category -ne 2){Apply-Edit 'inventory' @([string]$catalog.SelectedItem.Id,[string]$qty.Value);return}
    $current=Current-Slot;$id=[int]$catalog.SelectedItem.Id
    if($id -in @(615,1457)){throw 'This is an Unavailable placeholder record, not an acquirable item.'}
    $d=[Windows.Forms.SaveFileDialog]::new();$d.Title=(Get-QuestbookText 'Export into AsteraLoader\plugins\mhwi_account_bridge');if(Get-Command Get-GameFolder -ErrorAction SilentlyContinue){try{$d.InitialDirectory=Join-Path (Get-GameFolder) 'AsteraLoader\plugins\mhwi_account_bridge'}catch{}};$d.FileName='request.txt';$d.Filter=(Get-QuestbookFileFilter 'Bridge request|request.txt');$d.OverwritePrompt=$false
    if($d.ShowDialog() -ne 'OK'){return}
    if([IO.Path]::GetFileName($d.FileName) -ne 'request.txt'){throw 'The bridge reads the filename request.txt.'}
    if(Test-Path -LiteralPath $d.FileName){throw 'A request already exists. Use or delete that request before exporting another.'}
    $content="MHWI_ACCOUNT_V1 $($current.number) $id $([int]$qty.Value)`r`n"
    $bytes=[Text.Encoding]::ASCII.GetBytes($content)
    $f=[IO.File]::Open($d.FileName,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
    [HuntersCompanion.Messages]::Show((Format-QuestbookText 'Exported: {0} x{1}, character slot {2}.

In MHW, load that character in a solo quest/expedition and press the configured bridge key (F10 by default). Return normally and save. Do not replace the live save with an older editor copy afterward.

The bridge requires the supported MHW executable and your existing Astera API 1.8 installation.' @(($($catalog.SelectedItem.Name)),($([int]$qty.Value)),($($current.number)))),'Account request exported') | Out-Null
}})
$markFound.Add_Click({Run-Action {if($catalog.SelectedItem -and [int]$catalog.SelectedItem.Category -eq 2){Apply-Edit 'inventory' @([string]$catalog.SelectedItem.Id,'1')}}})
$installBridge.Add_Click({Run-Action {
    $d=[Windows.Forms.FolderBrowserDialog]::new();$d.Description='Choose an export folder. Copy its AsteraLoader folder into MHW while the game is closed.'
    if($d.ShowDialog() -ne 'OK'){return}
    $target=Join-Path $d.SelectedPath 'AsteraLoader\plugins\mhwi_account_bridge'
    [IO.Directory]::CreateDirectory($target) | Out-Null
    $dest=Join-Path $target 'mhwi_account_bridge.dll'
    if(Test-Path -LiteralPath $dest){throw 'Bridge DLL already exists at that destination. Choose an empty export folder.'}
    [IO.File]::Copy((Join-Path $script:Root 'AccountBridge\mhwi_account_bridge.dll'),$dest,$false)
    [HuntersCompanion.Messages]::Show((Format-QuestbookText 'Exported to {0}
Install while MHW is closed. Restart MHW, then export an Account request into the installed plugin folder.' @(($target))),'Bridge exported') | Out-Null
}})
$importIcons.Add_Click({Run-Action {
    $d=[Windows.Forms.FolderBrowserDialog]::new();$d.Description='Choose exported game PNGs named item-ID.png, for example item-1.png for Potion. Only supplied IDs are replaced.'
    if($d.ShowDialog() -ne 'OK'){return}
    $count=0
    foreach($file in (Get-ChildItem -LiteralPath $d.SelectedPath -Filter 'item-*.png' -File)){
        if($file.BaseName -notmatch '^item-([0-9]+)$'){continue};$id=[int]$Matches[1]
        if($id -lt 0 -or $id -ge $script:Items.Count){continue}
        $image=[Drawing.Image]::FromFile($file.FullName)
        try{
            if($image.Width -lt 16 -or $image.Height -lt 16 -or $image.Width -gt 1024 -or $image.Height -gt 1024){throw (Format-QuestbookText 'Unsupported image size: {0}' @(($($file.Name))))}
            $target=Join-Path $script:Root ('item-images\'+$id+'.png');[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
            $image.Save($target,[Drawing.Imaging.ImageFormat]::Png);[void]$script:ItemOverrideIds.Add($id);$count++
        }finally{$image.Dispose()}
    }
    foreach($image in $script:ThumbnailCache.Values){$image.Dispose()};$script:ThumbnailCache.Clear();$script:InventoryImages.Images.Clear()
    Fill-Catalog;Refresh-Slot
    [HuntersCompanion.Messages]::Show((Format-QuestbookText 'Imported {0} item images. These override atlas thumbnails everywhere that item is shown.' @(($count))),'Item images imported') | Out-Null
}})
$remove.Add_Click({Run-Action {if(-not $catalog.SelectedItem){return};$delta=if([int]$catalog.SelectedItem.Category -in @(2,5)){-1}else{-[int]$qty.Value};Apply-Edit 'inventory' @([string]$catalog.SelectedItem.Id,[string]$delta)}})
$box.Add_SelectedIndexChanged({if(-not $script:JournalFilling -and $box.SelectedIndices.Count -gt 0){$catalog.SelectedIndex=$box.SelectedIndices[0]}})
$apply.Add_Click({Run-Action {
    if(-not $equipList.SelectedItem){return}
    $extra=@([string]$equipList.SelectedItem.Record.index)
    for($i=0;$i -lt 3;$i++){if(-not $gemCombos[$i].SelectedItem){throw 'Select every jewel field.'};$extra += [string]$gemCombos[$i].SelectedItem.Index}
    $extra += [string][int]$ignore.Checked;$extra += [string][int]$stock.Checked
    for($i=0;$i -lt 3;$i++){$extra += [string]$equipList.SelectedItem.Meta.("Cap$i")}
    
    Apply-Edit 'fit' $extra
}})
$anyExport.Add_Click({Run-Action {Install-AnyJewel}})
$slotExport.Add_Click({Run-Action {Add-WeaponSlotEdit}})
$form.Add_FormClosing({param($sender,$e)
    if($script:History.Count -gt 0 -and [HuntersCompanion.Messages]::Show('Close the editor? Keep any copies already saved with Save As.','Close editor','YesNo') -ne 'Yes'){$e.Cancel=$true}
})
. (Join-Path $PSScriptRoot 'QuestPanel.ps1')
. (Join-Path $PSScriptRoot 'FieldJournal.ps1')
Enable-ThumbnailCombo $catalog
Enable-ThumbnailCombo $equipList
foreach($combo in $gemCombos){Enable-ThumbnailCombo $combo}
. (Join-Path $PSScriptRoot 'QuestbookTools.ps1')
. (Join-Path $PSScriptRoot 'CompanionAbout.ps1')
. (Join-Path $PSScriptRoot 'CompanionGuides.ps1')
. (Join-Path $PSScriptRoot 'CompanionHelp.ps1')
. (Join-Path $PSScriptRoot 'CompanionEquipment.ps1')
. (Join-Path $PSScriptRoot 'CompanionArmorProgress.ps1')
. (Join-Path $PSScriptRoot 'CompanionAdvancedEdits.ps1')
Initialize-CompanionText
Prepare-CompanionUserInterface
Complete-QuestbookTheme
Set-CompanionUserTooltips
Initialize-CompanionCanvas
Initialize-QuestbookPolish
Initialize-QuestbookLocalization
$form.Add_Shown({
    if($LoadingSplash -and -not $LoadingSplash.IsDisposed){$LoadingSplash.Hide()}
    if($StartupTrace){& $StartupTrace 'Editor window shown.'}
})
try {
    if($StartupTrace){& $StartupTrace 'Filling the item catalog.'}
    Fill-Catalog
    if($LoadingSplash -and -not $LoadingSplash.IsDisposed){$LoadingSplash.Refresh()}
    if($StartupTrace){& $StartupTrace 'Starting the editor message loop.'}
    [Windows.Forms.Application]::Run($form)
} finally {
    $form.Dispose()
    $script:QuestRowImages.Dispose()
    Dispose-QuestbookTheme
    $script:InventoryImages.Dispose()
    foreach($image in $script:ThumbnailCache.Values){$image.Dispose()}
    if(Test-Path $script:Session){Remove-Item -LiteralPath $script:Session -Recurse -Force}
}

