﻿$script:QuestEligibilityLabels=@('Any eligibility','Flag / count edits','Ingredient unlock ready','Fixed reward candidate','No matching action')
function Get-QuestEditBlockReason($q,$state,[bool]$enabled){
 if($null -eq $q){return 'Select a quest first.'}
 if((Test-ModQuest $q) -or $null -eq $q.Id -or [string]$q.Key -ne "game:$($q.Id)"){return 'This row is not an editable base-game catalog entry.'}
 if($q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){return 'This quest has an unavailable or conflicting identity.'}
 if(-not $script:QuestMappingIds.ContainsKey([int64]$q.Id)){return 'No verified save mapping is available for this quest.'}
 if(-not $state -or -not $state.active){return 'Open your latest save and select an active character slot first.'}
 if(-not $state.ById.ContainsKey([int64]$q.Id)){return 'No saved clear-state mapping is available for this row.'}
 if(-not $enabled){return 'Turn on Enable mapped quest edits to change flags or counts.'}
 return ''
}
function Get-FixedRewardEligibilityReason($q,$state){
 if(-not $q -or $null -eq $q.Id -or -not $script:FixedRewardMap.ContainsKey([int]$q.Id) -or -not (Get-QuestBenefit $q)){return 'This quest has no supported fixed reward.'}
 if(-not $state -or -not $state.active){return 'Open your latest save and select an active character slot first.'}
 if(-not $state.ById.ContainsKey([int64]$q.Id) -or -not $state.ById[[int64]$q.Id].flag){return 'The opened character must have the saved clear flag for this quest set.'}
 return ''
}
function Test-QuestEligibilityFilter([int]$filter,$q,$state,[bool]$enabled){
 switch($filter){
  1 {return -not (Get-QuestEditBlockReason $q $state $enabled)}
  2 {return -not (Get-QuestUnlockBlockReason $q $state)}
  3 {return -not (Get-FixedRewardEligibilityReason $q $state)}
  4 {return [bool]((Get-QuestEditBlockReason $q $state $enabled) -and (Get-QuestUnlockBlockReason $q $state) -and (Get-FixedRewardEligibilityReason $q $state))}
  default {return $true}
 }
}
function Update-QuestEligibilityLabels {
 $previous=$questEligibility.SelectedIndex
 $script:QuestEligibilityUpdating=$true
 try{
  $questEligibility.Items.Clear()
  [void]$questEligibility.Items.AddRange([object[]]@($script:QuestEligibilityLabels | ForEach-Object {Get-QuestbookText $_}))
  $questEligibility.SelectedIndex=[Math]::Max(0,$previous)
 }finally{$script:QuestEligibilityUpdating=$false}
}
