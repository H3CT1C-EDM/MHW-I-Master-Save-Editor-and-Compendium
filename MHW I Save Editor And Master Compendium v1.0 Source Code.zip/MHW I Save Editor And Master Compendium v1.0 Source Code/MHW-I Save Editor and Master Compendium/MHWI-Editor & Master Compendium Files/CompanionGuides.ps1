﻿$script:GuideBrowser=$null
$guideTab=[Windows.Forms.TabPage]::new('Guides')
[void]$tabs.TabPages.Add($guideTab)
$script:GuideBrowser=[Windows.Forms.WebBrowser]::new()
$script:GuideBrowser.SetBounds(15,15,1045,591)
$script:GuideBrowser.AllowWebBrowserDrop=$false
$script:GuideBrowser.IsWebBrowserContextMenuEnabled=$false
$script:GuideBrowser.WebBrowserShortcutsEnabled=$true
$script:GuideBrowser.ScriptErrorsSuppressed=$false
$script:GuideBrowser.ScrollBarsEnabled=$false
$script:GuideBrowser.AllowNavigation=$true
$guideTab.Controls.Add($script:GuideBrowser)
$script:GuideLoaded=$false
$script:GuideOpening=$false
$script:GuideUri=[uri]::new((Join-Path $script:Root 'Guides\index.html'))
$script:GuideLoadingLabel=Add-Control $guideTab Label 'Loading Guides…' 15 15 1045 591
$script:GuideLoadingLabel.Dock='Fill'
$script:GuideLoadingLabel.BackColor=$script:QuestbookColors.Paper
$script:GuideLoadingLabel.BringToFront()
function Update-CompanionGuideLanguage {
 if($script:GuideLoaded -and $script:GuideBrowser.Document){
  [void]$script:GuideBrowser.Document.InvokeScript('setGuideLanguage',[object[]]@([string]$script:ToolSettings.Language))
 }
}
function Update-CompanionGuideBackground {
 if($script:GuideLoaded -and $script:GuideBrowser.Document){
  $origin=$form.PointToClient($script:GuideBrowser.PointToScreen([Drawing.Point]::Empty))
  [void]$script:GuideBrowser.Document.InvokeScript('setGuideBackground',[object[]]@($form.ClientSize.Width,$form.ClientSize.Height,$origin.X,$origin.Y))
 }
}
$script:GuideBrowser.Add_Navigating({param($sender,$event)
 if($event.Url.Scheme -eq 'about'){return}
 $allowed=[IO.Path]::GetFullPath((Join-Path $script:Root 'Guides'))+[IO.Path]::DirectorySeparatorChar
 if(-not $event.Url.IsFile -or -not $event.Url.LocalPath.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase)){$event.Cancel=$true}
})
$script:GuideBrowser.Add_NewWindow({param($sender,$event)
 $event.Cancel=$true
 if(-not $sender.Document -or -not $sender.Document.ActiveElement){return}
 $href=$sender.Document.ActiveElement.GetAttribute('href');$uri=$null
 if([uri]::TryCreate($href,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -eq 'https' -and $uri.Host -in @('mhworld.kiranico.com','game8.co','monsterhunterworld.wiki.fextralife.com','www.highgroundgaming.com','gamerant.com','gamesfuze.com')){
  $start=[Diagnostics.ProcessStartInfo]::new($uri.AbsoluteUri);$start.UseShellExecute=$true;[void][Diagnostics.Process]::Start($start)
 }
})
$script:GuideBrowser.Add_DocumentCompleted({param($sender,$event)
 if($event.Url -ne $script:GuideUri -or $script:GuideLoaded){return}
 $script:GuideLoaded=$true;$script:GuideOpening=$false
 Update-CompanionGuideLanguage;Update-CompanionGuideBackground
 $script:GuideLoadingLabel.Hide()
})
$tabs.Add_SelectedIndexChanged({
 if($tabs.SelectedTab -eq $guideTab -and -not $script:GuideLoaded -and -not $script:GuideOpening){
  $script:GuideOpening=$true
  try{$script:GuideBrowser.Navigate($script:GuideUri)}catch{$script:GuideOpening=$false;throw}
 }
})
function Initialize-CompanionText {
 foreach($name in @('questDetails','journalDetails','palicoReferences')){
  $old=Get-Variable -Name $name -ValueOnly -Scope Script
  $new=[HuntersCompanion.ParchmentText]::new();$new.Bounds=$old.Bounds;$new.Font=$old.Font;$new.ForeColor=$script:QuestbookColors.Ink;$new.Text=$old.Text
  $parent=$old.Parent;$order=$parent.Controls.GetChildIndex($old);$parent.Controls.Remove($old);$parent.Controls.Add($new);$parent.Controls.SetChildIndex($new,$order)
  Set-Variable -Name $name -Value $new -Scope Script
  $old.Dispose()
 }
}
function Initialize-CompanionCanvas {
 foreach($control in @($script:QuestbookHeader,$script:QuestbookPageHost)+@($tabs.TabPages)){
  [HuntersCompanion.ParchmentCanvas]::Attach($control,$form)
 }
}
$script:ItemAnnotations=@{}
$annotationPath=Join-Path $script:Root 'catalog\ItemAnnotations.json'
if(Test-Path -LiteralPath $annotationPath){
 $annotations=Get-Content -LiteralPath $annotationPath -Raw -Encoding UTF8 | ConvertFrom-Json
 foreach($property in $annotations.PSObject.Properties){$script:ItemAnnotations[[int]$property.Name]=$property.Value}
}
function Get-CompanionItemAnnotation($entry){
 if(-not $entry){return $null}
 $id=if($entry.PSObject.Properties['Id']){[int]$entry.Id}elseif($entry.PSObject.Properties['id']){[int]$entry.id}else{-1}
 return $script:ItemAnnotations[$id]
}
function Get-CompanionItemColor($entry,$fallback){
 $annotation=Get-CompanionItemAnnotation $entry
 if($annotation){if($annotation.kind -eq 'mod'){return [Drawing.Color]::FromArgb(214,173,30)};if($fallback.GetBrightness() -gt 0.8){return [Drawing.Color]::FromArgb(255,155,144)};return [Drawing.Color]::FromArgb(185,32,32)}
 return $fallback
}
$catalog.Add_SelectedIndexChanged({
 $annotation=Get-CompanionItemAnnotation $catalog.SelectedItem
 $script:QuestbookTips.SetToolTip($catalog,$(if($annotation){$annotation.reason}else{[string]$catalog.SelectedItem.Name}))
})
$box.ShowItemToolTips=$true
