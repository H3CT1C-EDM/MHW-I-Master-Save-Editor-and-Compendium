﻿. (Join-Path $script:Root 'QuestRewards.ps1')
. (Join-Path $script:Root 'QuestRewardTransactions.ps1')
. (Join-Path $script:Root 'QuestEligibility.ps1')

$script:QuestReferences = @((Get-Content -LiteralPath (Join-Path $script:Root 'catalog\Quests.json') -Raw -Encoding UTF8 | ConvertFrom-Json).Quests)
$script:QuestBenefitsById=@{}
foreach($benefit in @((Get-Content -LiteralPath (Join-Path $script:Root 'catalog\QuestBenefits.json') -Raw -Encoding UTF8|ConvertFrom-Json).Benefits)){$script:QuestBenefitsById[[int64]$benefit.QuestId]=$benefit}
$script:QuestDefinitions = @()
$script:QuestModDefinitions = @()
$script:QuestMappingIds=@{}
foreach($entry in @((Get-Content -LiteralPath (Join-Path $script:Root 'catalog\QuestCompletionMappings.json') -Raw -Encoding UTF8 | ConvertFrom-Json).mappings)){$script:QuestMappingIds[[int64]$entry.quest_id]=$true}
$script:QuestFlagCacheKey = ''
$script:QuestFlagCache = $null
$questTab = [Windows.Forms.TabPage]::new('Quests')
[void]$tabs.TabPages.Add($questTab)
$questSearch = Add-Control $questTab TextBox '' 15 15 285 30
$questSearch.AccessibleName='Search quests by title, game ID or reference ID'
$questCategory = Add-Control $questTab ComboBox '' 310 15 155 30
$questCategory.DropDownStyle='DropDownList'
$questCategory.DropDownWidth=460
$questCategory.AccessibleName='Quest type or mod pack'
[void]$questCategory.Items.AddRange([object[]]@('All types / packs','assigned','optional','event','special','arena','challenge','Unknown'))
$questCategory.SelectedIndex=0
$questRank = Add-Control $questTab ComboBox '' 475 15 110 30
$questRank.DropDownStyle='DropDownList';[void]$questRank.Items.AddRange([object[]]@('All ranks','LR','HR','MR','Unknown'));$questRank.SelectedIndex=0
$questSource = Add-Control $questTab ComboBox '' 595 15 230 30
$questSource.DropDownStyle='DropDownList';[void]$questSource.Items.AddRange([object[]]@('All sources','Quest catalog','Imported definitions','Mod packs only','Mapped base-game','Ingredient unlocks'));$questSource.SelectedIndex=0
$questEligibility=Add-Control $questTab ComboBox '' 835 15 225 30
$questEligibility.DropDownStyle='DropDownList';$questEligibility.DropDownWidth=330
$questEligibility.AccessibleName='Quest action eligibility'
Update-QuestEligibilityLabels
$script:QuestbookTips.SetToolTip($questEligibility,'Filters by the active save and the mapped edits checkbox. Fixed rewards still require preview checks.')
$questSummary = Add-Control $questTab Label '' 15 52 1045 38
$questList = Add-Control $questTab ListView '' 15 95 1045 220
$script:QuestRowImages=[Windows.Forms.ImageList]::new()
$script:QuestRowImages.ImageSize=[Drawing.Size]::new(24,24);$script:QuestRowImages.ColorDepth='Depth32Bit'
$script:QuestRowImages.Images.Add('book',(Get-QuestbookImage 'book_ink'))
$script:QuestRowImages.Images.Add('mod',(Get-QuestbookImage 'mod_ink'))
$questList.SmallImageList=$script:QuestRowImages
$questList.View='Details';$questList.FullRowSelect=$true;$questList.MultiSelect=$false;$questList.HideSelection=$false
[void]$questList.Columns.Add('Quest',335);[void]$questList.Columns.Add('Game ID',85);[void]$questList.Columns.Add('Rank',55);[void]$questList.Columns.Add('Category',105);[void]$questList.Columns.Add('Clear flag',90);[void]$questList.Columns.Add('Saved count',110);[void]$questList.Columns.Add('Support',250)
$questDetails = Add-Control $questTab TextBox 'Select a quest. Completion remains Unknown until its save mapping is verified.' 15 325 1045 160
$questDetails.Multiline=$true;$questDetails.ReadOnly=$true;$questDetails.ScrollBars='Vertical';$questDetails.WordWrap=$true
$questComplete = Add-Control $questTab Button 'Set clear flag' 15 495 185 32
$questIncomplete = Add-Control $questTab Button 'Clear flag' 210 495 185 32
$questRepair = Add-Control $questTab Button 'Edit count...' 405 495 165 32
$questComplete.Enabled=$false;$questIncomplete.Enabled=$false;$questRepair.Enabled=$false
$questFlagTest = Add-Control $questTab CheckBox 'Enable mapped quest edits (flags / counts only)' 15 535 550 30
$questPair = Add-Control $questTab CheckBox 'Also edit the paired quest (when present)' 585 495 475 32
$questPair.Enabled=$false
$questImport = Add-Control $questTab Button 'Import files...' 15 574 165 32
$questLoadImport = Add-Control $questTab Button 'Load report...' 190 574 165 32
$questExport = Add-Control $questTab Button 'Export catalog' 365 574 155 32
$fixedReward=Add-Control $questTab Button 'Fixed Reward...' 530 574 270 32
$rewardReceipt=Add-Control $questTab Button 'Reward Receipt...' 825 535 235 30
$fixedReward.Add_Click({Run-Action {Show-FixedRewardPreview}})
$rewardReceipt.Add_Click({Run-Action {Show-FixedRewardReceipt}})
$questUnlockStatus=Add-Control $questTab Button 'Quest Unlock Status...' 570 535 245 30
$questUnlockStatus.Enabled=$false
$questUnlockStatus.Add_Click({Run-Action {if($questList.SelectedItems.Count){Show-QuestUnlockStatus $questList.SelectedItems[0].Tag}}})
$questUnlock=Add-Control $questTab Button 'Apply Quest Unlocks...' 810 574 250 32;$questUnlock.Enabled=$false

function Get-QuestState {
    if(-not $script:State -or -not $script:Working -or $slot.SelectedIndex -lt 0){
        $script:QuestFlagCache=$null;$script:QuestFlagCacheKey='';return $null
    }
    $current=Current-Slot;$key="$($script:Working):$($current.number)"
    if($script:QuestFlagCacheKey -ne $key){
        $script:QuestFlagCache=$null;$script:QuestFlagCacheKey=''
        $data=Invoke-Engine -Arguments @('quest-states',$script:Working,[string]$current.number)
        $byId=@{};foreach($v in @($data.quests)){$byId[[int64]$v.id]=$v}
        $script:QuestFlagCache=[pscustomobject]@{active=$data.active;input_sha256=$data.input_sha256;ById=$byId}
        $script:QuestFlagCacheKey=$key
    }
    return $script:QuestFlagCache
}
function Get-SelectedQuestInfo {
    $state=Get-QuestState
    if(-not $state -or -not $questList.SelectedItems.Count){return $null}
    $q=$questList.SelectedItems[0].Tag
    if((Test-ModQuest $q) -or $null -eq $q.Id -or -not $state.ById.ContainsKey([int64]$q.Id)){return $null}
    return $state.ById[[int64]$q.Id]
}
function Test-QuestEditEligible($q){
    if($null -eq $q -or (Test-ModQuest $q) -or $q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){return $false}
    if([string]$q.Key -ne "game:$($q.Id)"){return $false}
    $state=Get-QuestState
    return ($null -ne $state -and $state.active -and $state.ById.ContainsKey([int64]$q.Id))
}
function Refresh-QuestState([switch]$FromFill) {
    if(-not $FromFill -and $questEligibility.SelectedIndex -gt 0){Fill-Quests;return}
    $state=Get-QuestState
    foreach($row in $questList.Items){
        $row.SubItems[4].Text='Unknown';$row.SubItems[5].Text='Unknown'
        if($state -and $state.active -and -not (Test-ModQuest $row.Tag) -and $null -ne $row.Tag.Id -and $state.ById.ContainsKey([int64]$row.Tag.Id)){
            $v=$state.ById[[int64]$row.Tag.Id]
            $row.SubItems[4].Text=if($v.flag){'Set'}else{'Unset'}
            $row.SubItems[5].Text=[string]$v.count
        }
    }
    Show-QuestDetails;Update-QuestActions
}
function Test-ModQuest($q){
    return ($null -ne $q -and ($q.IsModQuest -eq $true -or ([string]$q.Key).StartsWith('definition:mod:') -or -not [string]::IsNullOrEmpty([string]$q.ModPackId)))
}
function Get-QuestBenefit($q){
    if($null -eq $q -or (Test-ModQuest $q) -or $q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId -or [string]$q.Key -ne "game:$($q.Id)"){return $null}
    if($script:QuestBenefitsById.ContainsKey([int64]$q.Id)){return $script:QuestBenefitsById[[int64]$q.Id]}
    return $null
}
function Get-QuestUnlockBlockReason($q,$state){
    if($null -eq $q){return 'Select a quest first.'}
    if(Test-ModQuest $q){return 'Mod-pack quests are read-only. Select Ingredient unlocks in the source dropdown to show the five supported base-game quests.'}
    if($q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){return 'This quest has an unavailable or conflicting identity. Select Ingredient unlocks in the source dropdown and choose its supported base-game catalog row.'}
    if([string]$q.Key -ne "game:$($q.Id)"){return 'You selected an imported definition. Select Ingredient unlocks in the source dropdown, then choose the base-game catalog row. Imported copies remain read-only even when their quest IDs match.'}
    if($null -eq $q.Id -or -not $script:QuestBenefitsById.ContainsKey([int64]$q.Id)){return 'Ingredient unlocks are supported for quest IDs 364, 452, 683, 684 and 694 only. Select Ingredient unlocks in the source dropdown to show them.'}
    if(-not $PSBoundParameters.ContainsKey('state')){$state=Get-QuestState}
    if($null -eq $state -or -not $state.active){return 'Open your latest save and select an active character slot first.'}
    if(-not $state.ById.ContainsKey([int64]$q.Id)){return 'No saved clear-state mapping is available for this row. Select its supported base-game catalog row.'}
    $info=$state.ById[[int64]$q.Id]
    if(-not $info.flag -and $PSBoundParameters.ContainsKey('state')){return 'The opened character must have the saved clear flag for this quest set.'}
    if(-not $info.flag){return (Format-QuestbookText 'Quest {0} does not have a saved clear flag. Open the latest manual save, or review and export mapped flag/count edits, then load that save in-game. Apply Quest Unlocks unlocks the ingredient only.' @($q.Id))}
    return ''
}
function Review-QuestUnlockSelection {
    $q=if($questList.SelectedItems.Count){$questList.SelectedItems[0].Tag}else{$null}
    $reason=Get-QuestUnlockBlockReason $q
    if(-not [string]::IsNullOrEmpty($reason)){
        [HuntersCompanion.Messages]::Show($reason,(Get-QuestbookText 'Quest Unlock Requirements'),'OK','Information')|Out-Null
        return
    }
    Queue-QuestUnlock $q
}
function Queue-QuestUnlock($q){
    $reason=Get-QuestUnlockBlockReason $q
    if(-not [string]::IsNullOrEmpty($reason)){throw $reason}
    $benefit=Get-QuestBenefit $q
    $current=Current-Slot
    $message=Format-QuestbookText '{0} [ID {1}]
Ingredient reward: {2}
Slot: {3}

This queues one ingredient unlock. The bridge requires the actual saved quest clear flag on the loaded character. No materials, Zenny, rank points, quest flags/counts or story progression are changed.

Create the request?' @($q.Name,$q.Id,$benefit.IngredientName,$current.number)
    if([HuntersCompanion.Messages]::Show($message,(Get-QuestbookText 'Quest Unlock Preview'),'YesNo','Question') -ne 'Yes'){return}
    $folder=Join-Path (Get-GameFolder -RequireLoader) 'AsteraLoader\plugins\mhwi_account_bridge'
    if(-not (Test-Path -LiteralPath (Join-Path $folder 'mhwi_account_bridge.dll'))){throw 'Install the updated account bridge in Game Data Exports first.'}
    Publish-CompanionBridgeRequest $folder "MHWI_QUEST_UNLOCK_V1 $($current.number) $($q.Id)"
    [HuntersCompanion.Messages]::Show((Get-QuestbookText 'Quest Unlock Request Queued')+(Format-QuestbookText '
{0}
Enter a solo expedition with the cleared character, press your configured Account Request Key once, then return normally, save and reload. View the result with Quest Unlock Status on the same quest.' @(($($benefit.IngredientName)))),'MHWI Questbook')|Out-Null
}
function Apply-QuestMappedEdit([string]$desiredFlag,[string]$desiredCount){
    if(-not $questList.SelectedItems.Count){throw 'Select a mapped base-game quest.'}
    $q=$questList.SelectedItems[0].Tag
    if(Test-ModQuest $q){throw 'Mod-pack quests are read-only. Plugin-forced query results are not saved completion.'}
    if(-not $questFlagTest.Checked){throw 'Enable mapped quest edits first.'}
    if(-not (Test-QuestEditEligible $q)){throw 'Select a mapped reference quest with an unambiguous game ID and open an active character slot.'}
    $current=Current-Slot
    $pair=[string][int]$questPair.Checked
    $preview=Invoke-Engine -Arguments @('quest-edit-preview',$script:Working,[string]$current.number,[string]$q.Id,$desiredFlag,$desiredCount,$pair)
    if(-not $preview.changed){return}
    $lines=[System.Collections.Generic.List[string]]::new()
    foreach($change in @($preview.changes)){
        $before=if($change.before_flag){'Set'}else{'Unset'};$after=if($change.after_flag){'Set'}else{'Unset'}
        $lines.Add((Format-QuestbookText 'Quest {0}: flag {1} -> {2}; saved count {3} -> {4}' @(($($change.id)),($before),($after),($($change.before_count)),($($change.after_count)))))
    }
    $lines.Add('')
    $lines.Add('This changes only the listed flags/counts. Rewards, unlocks, availability, seen flags and category totals are preserved. This does not reproduce a full first clear or reverse story progression.')
    $lines.Add('Apply to the working copy? You can Undo edit before Save As.')
    if([HuntersCompanion.Messages]::Show(($lines -join "`r`n"),'Preview quest edit','YesNo','Question') -ne 'Yes'){return}
    Apply-Edit 'quest-edit' @([string]$q.Id,$desiredFlag,$desiredCount,$pair,'1',[string]$preview.input_sha256)
}
function Apply-QuestFlag([bool]$desired){Apply-QuestMappedEdit ([string][int]$desired) 'keep'}
function Edit-QuestCount {
    $info=Get-SelectedQuestInfo
    if(-not $info){throw 'Select a mapped base-game quest.'}
    $dialog=[Windows.Forms.Form]::new()
    try {
        $dialog.Text='Set saved quest count';$dialog.ClientSize=[Drawing.Size]::new(480,150);$dialog.StartPosition='CenterParent'
        $label=Add-Control $dialog Label "Quest $($info.id) saved count (flag preserved):" 15 15 450 30
        $value=Add-Control $dialog NumericUpDown '' 15 50 250 30
        $value.Minimum=0;$value.Maximum=[decimal]4294967295;$value.Value=[decimal]$info.count
        $ok=Add-Control $dialog Button 'Preview...' 280 50 175 32;$ok.DialogResult='OK';$dialog.AcceptButton=$ok
        $hint=Add-Control $dialog Label 'The preview lists every change, including an opted-in paired quest.' 15 95 450 45
        Set-QuestbookTree $dialog
        if($dialog.ShowDialog($form) -eq 'OK'){Apply-QuestMappedEdit 'keep' ($value.Value.ToString('0',[Globalization.CultureInfo]::InvariantCulture))}
    } finally {$dialog.Dispose()}
}
function Update-QuestActions {
    $selected=if($questList.SelectedItems.Count){$questList.SelectedItems[0].Tag}else{$null}
    $eligible=($questFlagTest.Checked -and (Test-QuestEditEligible $selected))
    $questComplete.Enabled=$eligible;$questIncomplete.Enabled=$eligible;$questRepair.Enabled=$eligible
    $benefit=Get-QuestBenefit $selected
    $info=Get-SelectedQuestInfo
    $questUnlock.Enabled=($null -ne $selected)
    $questUnlockStatus.Enabled=($null -ne $benefit -and $null -ne (Get-QuestState))
    $questUnlock.AccessibleDescription=Get-QuestUnlockBlockReason $selected
    $questPair.Enabled=($eligible -and $null -ne $info -and $info.paired_id -gt 0)
    if(-not $questPair.Enabled){$questPair.Checked=$false}
}
function Show-QuestDetails {
    if(-not $questList.SelectedItems.Count){$questDetails.Text=if($questList.Items.Count){'Select a quest first.'}else{'No quests match the current filters.'};Update-QuestActions;return}
    $q=$questList.SelectedItems[0].Tag
    $lines=[System.Collections.Generic.List[string]]::new()
    $lines.Add((Get-QuestbookQuestText $q 'Name'))
    $state=Get-QuestState
    $editReason=Get-QuestEditBlockReason $q $state $questFlagTest.Checked
    if($editReason){$lines.Add((Format-QuestbookText 'Flag / count edits: {0}' @((Get-QuestbookText $editReason))))}
    else{$lines.Add('Flag / count edits: ready for preview.')}
    $rewardReason=Get-FixedRewardEligibilityReason $q $state
    if($rewardReason){$lines.Add((Format-QuestbookText 'Fixed reward: {0}' @((Get-QuestbookText $rewardReason))))}
    else{$lines.Add('Fixed reward: candidate. Preview checks capacity, save identity and the reward receipt.')}
    $unlockReason=Get-QuestUnlockBlockReason $q
    if(-not [string]::IsNullOrEmpty($unlockReason)){$lines.Add((Format-QuestbookText 'Quest unlock requirements: {0}' @(($unlockReason))))}
    else{$lines.Add('Quest unlock: ready for preview. The loaded game character must also have this saved clear flag set.')}
    if(Test-ModQuest $q){
        $lines.Add((Format-QuestbookText 'MOD PACK: {0} v{1} | READ ONLY | installation not checked' @(($($q.ModPack)),($($q.ModVersion)))))
        $lines.Add((Format-QuestbookText 'Filename quest ID: {0} | Embedded header ID: {1}. This entry is not a base-game completion mapping.' @(($($q.Id)),($($q.HeaderId)))))
        $lines.Add('No completion, reward or unlock edits are available for this mod entry. This editor does not install the pack or its DLLs.')
    }
    $lines.Add((Format-QuestbookText 'Game ID: {0} | {1} | {2}' @(($($q.Id)),($($q.Rank)),($($q.Category)))))
    $lines.Add('Completion edits affect saved flags and counts only. Rewards and progression unlocks are not changed.')
    $info=Get-SelectedQuestInfo
    if($info -and $null -ne $info.flag){
        $flag=if($info.flag){'SET'}else{'CLEAR'}
        $lines.Add((Format-QuestbookText 'Saved completion flag: {0} | Saved count: {1}. These fields can disagree; neither proves reward receipt.' @(($flag),($($info.count)))))
        if($info.paired_id -gt 0){$lines.Add((Format-QuestbookText 'PAIRED QUEST: {0}. The game''s clear routine also marks that quest. This editor includes it only when Also edit the paired quest is checked.' @(($($info.paired_id)))))}
        if(-not (Test-QuestEditEligible $q)){$lines.Add('This row is read-only. Select its mapped reference row to edit; placeholder/conflicted identities remain blocked.')}
    }
    $benefit=Get-QuestBenefit $q
    if($benefit){
        $lines.Add((Format-QuestbookText 'Ingredient reward: {0}. Apply Quest Unlocks queues this one unlock after the character''s saved clear flag is set.' @(($($benefit.IngredientName)))))
        $lines.Add('Material rewards, payouts and progression effects are not granted by this action.')
    }
    if($q.Objective){$lines.Add((Format-QuestbookText 'Objective: {0}' @((Get-QuestbookQuestText $q 'Objective'))))}
    if($null -ne $q.Zenny){$lines.Add((Format-QuestbookText 'Listed base zenny: {0}. This is not a grant preview or a guaranteed net payout.' @(($($q.Zenny)))))}
    if($q.IdentityAmbiguous -or $q.DuplicateDefinitionId){$lines.Add('IDENTITY CONFLICT: filename/header disagreement or duplicate definitions; no save-editing identity is selected automatically.')}
    if($q.Placeholder){$lines.Add('Unavailable quest entry.')}
    if($null -eq $q.Id){$lines.Add('No supported game ID is available. This row is read-only.')}
    $rewardAnalysis=Get-QuestRewardAnalysis $q
    if($rewardAnalysis){foreach($line in @(Get-QuestRewardLines $rewardAnalysis)){$lines.Add($line)}}
    if(-not $rewardAnalysis -and @($q.ReferenceRewards).Count){
        $lines.Add('Possible rewards (information only; these items are not granted):')
        foreach($r in $q.ReferenceRewards){$lines.Add((Format-QuestbookText '  Group {0}: {1} x{2}; listed chance {3}%' @(($($r.Group)),($($r.ItemName)),($($r.Count)),($($r.ReferencePercent)))))}
    }
    if(-not $rewardAnalysis){foreach($pool in @($q.RewardPools)){
        $lines.Add((Format-QuestbookText 'Additional reward pool {0} (information only):' @(($($pool.Id)))))
        foreach($r in @($pool.Items)){
            $itemName=if([int]$r.ItemId -ge 0 -and [int]$r.ItemId -lt $script:Items.Count){$script:Items[[int]$r.ItemId].Name}else{'Unknown item'}
            $lines.Add((Format-QuestbookText '  {0} [item {1}] x{2}; raw weight {3}' @(($itemName),($($r.ItemId)),($($r.Count)),($($r.WeightRaw)))))
        }
    }
    }
    $questDetails.Text=$lines -join "`r`n"
    Update-QuestActions
}
function Fill-Quests {
    $previous=if($questList.SelectedItems.Count){[string]$questList.SelectedItems[0].Tag.Key}else{''}
    $filter=$questEligibility.SelectedIndex
    $state=if($filter -gt 0){Get-QuestState}else{$null}
    $script:QuestRowsUpdating=$true
    $questList.BeginUpdate()
    try{
    $questList.Items.Clear()
    $pattern=[regex]::Escape($questSearch.Text)
    foreach($q in @(Select-CompanionQuestRows (@($script:QuestDefinitions)+@($script:QuestModDefinitions)+@($script:QuestReferences)))){
        $isDefinition=([string]$q.Key).StartsWith('definition:')
        $isMod=Test-ModQuest $q
        if($questSource.SelectedIndex -eq 1 -and $isDefinition){continue}
        if($questSource.SelectedIndex -eq 2 -and -not $isDefinition){continue}
        if($questSource.SelectedIndex -eq 3 -and -not $isMod){continue}
        if($questSource.SelectedIndex -eq 4 -and ($isDefinition -or $null -eq $q.Id -or -not $script:QuestMappingIds.ContainsKey([int64]$q.Id))){continue}
        if($questSource.SelectedIndex -eq 5 -and $null -eq (Get-QuestBenefit $q)){continue}
        if($questCategory.SelectedIndex -gt 0 -and [string]$q.Category -ne [string]$questCategory.SelectedItem){continue}
        if($questRank.SelectedIndex -gt 0 -and [string]$q.Rank -ne [string]$questRank.SelectedItem){continue}
        if("$($q.Name) $(Get-QuestbookQuestText $q 'Name') $($q.Id) $($q.ReferenceId) $($q.ModPack)" -notmatch $pattern){continue}
        if(-not (Test-QuestEligibilityFilter $filter $q $state $questFlagTest.Checked)){continue}
        $displayName=if($isMod){"[$($q.ModPack)] $($q.Name)"}else{[string]$q.Name}
        $row=[Windows.Forms.ListViewItem]::new($displayName)
        if($isMod){$row.ForeColor=$script:QuestbookColors.Mod}
        [void]$row.SubItems.Add([string]$q.Id);[void]$row.SubItems.Add([string]$q.Rank);[void]$row.SubItems.Add([string]$q.Category);[void]$row.SubItems.Add('Unknown');[void]$row.SubItems.Add('Unknown')
        [void]$row.SubItems.Add($(if($isMod){(Format-QuestbookText 'MOD / READ ONLY: {0} v{1}' @(($($q.ModPack)),($($q.ModVersion))))}elseif($isDefinition){'Imported / read-only'}elseif($q.Placeholder){'Unavailable'}elseif($script:QuestMappingIds.ContainsKey([int64]$q.Id)){if(Get-QuestBenefit $q){'Flag / count; ingredient unlock'}else{'Flag / count editing'}}else{'Read-only'}))
        $row.Tag=$q;$row.ImageKey=if($isMod){'mod'}else{'book'};[void]$questList.Items.Add($row)
        if([string]$q.Key -eq $previous){$row.Selected=$true}
    }
    }finally{$questList.EndUpdate();$script:QuestRowsUpdating=$false}
    if($questList.Items.Count -and -not $questList.SelectedItems.Count){$questList.Items[0].Selected=$true}
    $questSummary.Text=(Format-QuestbookText '{0} unique quests shown. The most editable safe row is preferred. Completion flags do not grant rewards or unlock story progression.' @($questList.Items.Count))
    Refresh-QuestState -FromFill
}
function Read-QuestDefinitionReport([string]$path){
    if((Get-Item -LiteralPath $path).Length -gt 67108864){throw 'Import report is too large.'}
    $report=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if($report.Format -ne 'MHWI_QUEST_DEFINITIONS_V1'){throw 'Invalid quest-definition report.'}
    
    foreach($q in @($report.Quests)){
        if(-not ([string]$q.Key).StartsWith('definition:') -or [int64]$q.Id -lt 0 -or [int64]$q.Id -gt 99999999){throw 'Invalid quest identity in report.'}
        foreach($state in @('Completion','Availability')){Add-Member -InputObject $q -NotePropertyName $state -NotePropertyValue 'Unknown' -Force}
        foreach($support in @('CompletionSupport','UnlocksSupport')){Add-Member -InputObject $q -NotePropertyName $support -NotePropertyValue 'Unmapped' -Force}
        Add-Member -InputObject $q -NotePropertyName 'RewardsSupport' -NotePropertyValue 'Read-only' -Force
    }
    $script:QuestDefinitions=@($report.Quests);Fill-Quests
    return $report
}
function Read-ModQuestReport([string]$path){
    if((Get-Item -LiteralPath $path).Length -gt 67108864){throw 'Mod quest report is too large.'}
    $report=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
    if($report.Format -ne 'MHWI_MOD_QUEST_CATALOG_V1'){throw 'Invalid mod quest catalog.'}
    foreach($q in @($report.Quests)){
        if(-not ([string]$q.Key).StartsWith('definition:mod:') -or [int64]$q.Id -lt 0 -or [int64]$q.Id -gt 99999999){throw 'Invalid mod quest identity.'}
        Add-Member -InputObject $q -NotePropertyName IsModQuest -NotePropertyValue $true -Force
        foreach($state in @('Completion','Availability')){Add-Member -InputObject $q -NotePropertyName $state -NotePropertyValue 'Unknown' -Force}
        foreach($support in @('CompletionSupport','UnlocksSupport')){Add-Member -InputObject $q -NotePropertyName $support -NotePropertyValue 'Mod quest - read-only' -Force}
        Add-Member -InputObject $q -NotePropertyName RewardsSupport -NotePropertyValue 'Read-only' -Force
        if(-not $questCategory.Items.Contains([string]$q.Category)){[void]$questCategory.Items.Add([string]$q.Category)}
    }
    $script:QuestModDefinitions=@($report.Quests);Fill-Quests
}
$questUnlock.Add_Click({Run-Action {Review-QuestUnlockSelection}})
$questRepair.Add_Click({Run-Action {Edit-QuestCount}})
$questFlagTest.Add_CheckedChanged({Run-Action {Refresh-QuestState}})
$questComplete.Add_Click({Run-Action {Apply-QuestFlag $true}})
$questIncomplete.Add_Click({Run-Action {Apply-QuestFlag $false}})
$questSearch.Add_TextChanged({Run-Action {Fill-Quests}});$questCategory.Add_SelectedIndexChanged({Run-Action {Fill-Quests}});$questRank.Add_SelectedIndexChanged({Run-Action {Fill-Quests}});$questSource.Add_SelectedIndexChanged({Run-Action {Fill-Quests}})
$questEligibility.Add_SelectedIndexChanged({if(-not $script:QuestEligibilityUpdating){Run-Action {Fill-Quests}}})
$questList.Add_SelectedIndexChanged({if(-not $script:QuestRowsUpdating){Run-Action {$questPair.Checked=$false;Show-QuestDetails}}})
$slot.Add_SelectedIndexChanged({Run-Action {Refresh-QuestState}})
$questImport.Add_Click({Run-Action {
    $d=[Windows.Forms.FolderBrowserDialog]::new();$d.Description='Choose extracted game data containing questData_ID.mib, qID_eng.gmd and remData_ID.rem. Game archives are not extracted by this tool.'
    if($d.ShowDialog() -ne 'OK'){return}
    $reportFolder=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\Definitions';[IO.Directory]::CreateDirectory($reportFolder) | Out-Null
    $output=Join-Path $reportFolder ('Definitions-'+[guid]::NewGuid().ToString('N')+'.json')
    $report=Invoke-Engine -Arguments @('quest-definitions',$d.SelectedPath,$output)
    [void](Read-QuestDefinitionReport $output)
    [HuntersCompanion.Messages]::Show((Format-QuestbookText 'Imported {0} of {1} definitions; {2} issues.

Report: {3}
Use Load import report to reopen it later. Completion edits are available for supported base-game IDs.' @(($($report.ImportedDefinitions)),($($report.ScannedDefinitions)),($(@($report.Issues).Count)),($output))),'Quest definitions') | Out-Null
}})
$questLoadImport.Add_Click({Run-Action {
    $d=[Windows.Forms.OpenFileDialog]::new();$d.Filter=(Get-QuestbookFileFilter 'Quest definition reports|*.json');$d.Title=(Get-QuestbookText 'Load a previous quest-definition import report')
    if($d.ShowDialog() -eq 'OK'){[void](Read-QuestDefinitionReport $d.FileName)}
}})
$questExport.Add_Click({Run-Action {
    $d=[Windows.Forms.SaveFileDialog]::new();$d.Filter=(Get-QuestbookFileFilter 'Quest coverage JSON|*.json');$d.FileName='QuestCoverage.json';$d.OverwritePrompt=$false
    if($d.ShowDialog() -ne 'OK'){return};if(Test-Path -LiteralPath $d.FileName){throw 'Choose a new report filename.'}
    $saved=Get-QuestState
    $exportState=if($saved){[pscustomobject]@{active=$saved.active;input_sha256=$saved.input_sha256;quests=@($saved.ById.Values | Sort-Object id)}}else{$null}
    $payload=[pscustomobject]@{Format='MHWI_QUEST_COVERAGE_V1';CodeDerivedCompletionMappings=$script:QuestMappingIds.Count;GameplayValidatedFlagMappings=1;VerifiedRewardGrants=0;VerifiedUnlockMappings=0;CodeDerivedIngredientUnlockMappings=$script:QuestBenefitsById.Count;IngredientBenefits=@($script:QuestBenefitsById.Values|Sort-Object QuestId);SavedState=$exportState;Quests=@($script:QuestDefinitions)+@($script:QuestModDefinitions)+@($script:QuestReferences)}
    $bytes=[Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Depth 20))
    $f=[IO.File]::Open($d.FileName,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
}})
$bundledDefinitions=Join-Path $script:Root 'catalog\ExtractedQuestDefinitions.json'
if(Test-Path -LiteralPath $bundledDefinitions -PathType Leaf){
    $null=Read-QuestDefinitionReport $bundledDefinitions
}else{
    Fill-Quests
}
$bundledMods=Join-Path $script:Root 'catalog\ModQuestDefinitions.json'
if(Test-Path -LiteralPath $bundledMods -PathType Leaf){Read-ModQuestReport $bundledMods}
