﻿$script:RewardReceiptRoot=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\RewardReceipts'
$script:RewardSessionReceipts=@{}
$script:FixedRewardMap=@{364=@(592,1);452=@(592,2);683=@(221,1);684=@(221,1);694=@(873,1)}
function Get-RewardFileHash([string]$path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Get-RewardReceiptKey([string]$account,[int]$slotNumber,[string]$name,[int]$questId){
 $data=[Text.Encoding]::UTF8.GetBytes(($account+'|'+$slotNumber+'|'+[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($name))+'|'+$questId))
 $sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash($data))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
}
function Write-RewardReceipt($receipt,[string]$path,[bool]$create){
 [void][IO.Directory]::CreateDirectory((Split-Path -Parent $path))
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($receipt|ConvertTo-Json -Depth 10))
 if($create){
  $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
 }else{
  $temp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
  try{
   $stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
   try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
   [IO.File]::Replace($temp,$path,$path+'.bak')
  }finally{if(Test-Path -LiteralPath $temp){[IO.File]::Delete($temp)}}
 }
}
function Read-RewardReceipt([string]$path){
 if((Get-Item -LiteralPath $path).Length -gt 65536){throw 'The reward receipt is too large. Review it before continuing.'}
 $r=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
 if($r.format -ne 'MHWI_FIXED_REWARD_RECEIPT_V1'){throw 'The existing reward receipt has an unsupported format.'}
 return $r
}
function Get-FixedRewardPreview($q){
 if(-not $q -or $null -eq $q.Id -or -not $script:FixedRewardMap.ContainsKey([int]$q.Id) -or $q.Key -ne "game:$($q.Id)" -or $q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){throw 'Select one of the five supported base-game ingredient quests. Imported and mod entries are not eligible.'}
 $current=Current-Slot;$state=Get-QuestState
 if(-not $state -or -not $state.active -or -not $state.ById.ContainsKey([int64]$q.Id) -or -not $state.ById[[int64]$q.Id].flag){throw 'The opened character must have the saved clear flag for this quest set. Open your latest manual save.'}
 $hash=Get-RewardFileHash $script:Working
 if($state.input_sha256 -and $state.input_sha256 -ne $hash){throw 'The working save changed. Reopen the save before reviewing rewards.'}
 $pair=$script:FixedRewardMap[[int]$q.Id];$itemId=[int]$pair[0];$amount=[int]$pair[1]
 $analysis=Get-QuestRewardAnalysis $q
 if(-not $analysis -or @($analysis.Pools).Count -ne 1){throw 'The fixed reward analysis is unavailable.'}
 $pool=$analysis.Pools[0];$first=@($pool.Items|Where-Object {$_.Index -eq $pool.FirstSlotIndex})
 if($pool.Mode -ne 0 -or $first.Count -ne 1 -or $first[0].ItemId -ne $itemId -or $first[0].Count -ne $amount){throw 'The reward data does not match the supported fixed entry.'}
 $materials=@($current.inventory|Where-Object {[int]$_.category -eq 1})
 if($materials.Count -gt 1250){throw 'The material box has an invalid entry count.'}
 $seen=@{};foreach($entry in $materials){
  if([int64]$entry.amount -lt 1 -or [int64]$entry.amount -gt 9999 -or [int]$entry.id -le 0 -or $seen.ContainsKey([int]$entry.id)){throw 'The material box contains an invalid or duplicate entry. Review it before applying rewards.'}
  $seen[[int]$entry.id]=$true
 }
 $matches=@($materials|Where-Object {[int]$_.id -eq $itemId});$before=if($matches.Count){[int64]$matches[0].amount}else{0}
 if(9999-$before -lt $amount){throw 'The reward would exceed the 9,999 stack limit.'}
 if(-not $matches.Count -and $materials.Count -ge 1250){throw 'The material box is full.'}
 $snapshotFile=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.reward-snapshot.json')
 $snapshot=Invoke-Engine -Arguments @('quest-snapshot',$script:Working,$snapshotFile,[string]$current.number,[string]$q.Id)
 if($snapshot.input_sha256 -ne $hash -or $snapshot.account_fingerprint -notmatch '^[0-9a-fA-F]{64}$' -or $snapshot.character -cne $current.name -or [int]$snapshot.slot -ne [int]$current.number){throw 'The reward preview could not verify the account and character identity.'}
 $key=Get-RewardReceiptKey $snapshot.account_fingerprint $current.number $current.name $q.Id
 return [pscustomobject]@{QuestId=[int]$q.Id;QuestName=[string]$q.Name;Slot=[int]$current.number;Character=[string]$current.name;Account=[string]$snapshot.account_fingerprint;ItemId=$itemId;ItemName=[string]$script:Items[$itemId].Name;Amount=$amount;Before=$before;After=$before+$amount;FreeEntries=1250-$materials.Count;Hash=$hash;Working=[string]$script:Working;Key=$key;ReceiptPath=(Join-Path $script:RewardReceiptRoot ($key+'.json'))}
}
function Assert-FixedRewardOutput($before,$after,$p){
 if(-not $after.integrity -or @($before.slots).Count -ne 3 -or @($after.slots).Count -ne 3){throw 'Reward output integrity could not be verified.'}
 foreach($n in 0..2){
  $a=$before.slots[$n];$b=$after.slots[$n]
  foreach($property in @('number','name','hr','mr','equipment')){if(($a.$property|ConvertTo-Json -Depth 12 -Compress) -cne ($b.$property|ConvertTo-Json -Depth 12 -Compress)){throw 'Reward output changed unrelated character data.'}}
  $expected=@($a.inventory|ForEach-Object{[pscustomobject]@{id=[int]$_.id;amount=[int64]$_.amount;category=[int]$_.category}})
  if($n -eq $p.Slot-1){
   $expected=@($expected|Where-Object {-not ($_.id -eq $p.ItemId -and $_.category -eq 1)})
   $expected+= [pscustomobject]@{id=$p.ItemId;amount=[int64]$p.After;category=1}
  }
  $actual=@($b.inventory|ForEach-Object{[pscustomobject]@{id=[int]$_.id;amount=[int64]$_.amount;category=[int]$_.category}})
  $wanted=($expected|Sort-Object category,id,amount|ConvertTo-Json -Depth 8 -Compress)
  $observed=($actual|Sort-Object category,id,amount|ConvertTo-Json -Depth 8 -Compress)
  if($wanted -cne $observed){throw 'The reward output did not match the exact inventory preview.'}
 }
}
function Commit-FixedReward($p){
 $q=$script:QuestReferences|Where-Object {$_.Key -eq "game:$($p.QuestId)"}|Select-Object -First 1
 $fresh=Get-FixedRewardPreview $q
 if($fresh.Hash -ne $p.Hash -or $fresh.Key -ne $p.Key -or $fresh.Before -ne $p.Before -or $fresh.After -ne $p.After -or $fresh.Working -ne $p.Working){throw 'The character, quest, inventory or working save changed. Review a new preview.'}
 if(Test-Path -LiteralPath $p.ReceiptPath){throw 'This quest already has a reward receipt on this computer. Review the receipt before repeating the operation.'}
 $output=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
 $receipt=[ordered]@{format='MHWI_FIXED_REWARD_RECEIPT_V1';request_id=[guid]::NewGuid().ToString('N');method='save_copy_fixed_reward';state='started';created_utc=[DateTime]::UtcNow.ToString('o');account_fingerprint=$p.Account;slot=$p.Slot;character=$p.Character;quest_id=$p.QuestId;item_id=$p.ItemId;amount=$p.Amount;quantity_before=$p.Before;quantity_expected_after=$p.After;input_sha256=$p.Hash;output_sha256='';working_output=$output;native_game_calls=0;gameplay_reload_verified=$false;exports=@();error=''}
 Write-RewardReceipt $receipt $p.ReceiptPath $true
 try{
  $beforeState=Invoke-Engine -Arguments @('inspect',$script:Working)
  if((Get-RewardFileHash $script:Working) -ne $p.Hash){throw 'The working save changed before the edit.'}
  [void](Invoke-Engine -Arguments @('inventory',$script:Working,$output,[string]$p.Slot,[string]$p.ItemId,[string]$p.Amount))
  $afterState=Invoke-Engine -Arguments @('inspect',$output)
  Assert-FixedRewardOutput $beforeState $afterState $p
  if((Get-RewardFileHash $script:Working) -ne $p.Hash){throw 'The input save changed during the edit.'}
  $receipt.output_sha256=Get-RewardFileHash $output;$receipt.state='working_copy_verified'
  Write-RewardReceipt $receipt $p.ReceiptPath $false
 }catch{
  $receipt.state='failed_output_not_adopted';$receipt.error=$_.Exception.Message
  try{Write-RewardReceipt $receipt $p.ReceiptPath $false}catch{}
  throw
 }
 $script:History.Add($script:Working);$script:Working=$output;$script:State=$afterState
 $script:RewardSessionReceipts[$p.Key]=$p.ReceiptPath
 Refresh-Slot
 return $receipt
}
function Show-FixedRewardPreview {
 if(-not $questList.SelectedItems.Count){throw 'Select a quest first.'}
 $p=Get-FixedRewardPreview $questList.SelectedItems[0].Tag
 if(Test-Path -LiteralPath $p.ReceiptPath){Show-FixedRewardReceipt $p.ReceiptPath;return}
 $text="$($p.QuestName) [ID $($p.QuestId)]`r`n$(Get-QuestbookText 'Character'): $($p.Character) | $(Get-QuestbookText 'Slot'): $($p.Slot)`r`n`r`n$($p.ItemName) [ID $($p.ItemId)] +$($p.Amount)`r`n$($p.Before) → $($p.After) / 9999`r`n`r`n"+(Get-QuestbookText 'This deliberately adds the fixed first-slot reward to the working save. It may already have been received in-game. Random rewards, Zenny, rank points, quest flags and story progression are not included. Save As is required; the game process is not changed.')+"`r`n`r`n"+(Get-QuestbookText 'Apply this fixed reward supplement?')
 if([HuntersCompanion.Messages]::Show($text,(Get-QuestbookText 'Fixed Reward Preview'),'YesNo','Question') -ne 'Yes'){return}
 [void](Commit-FixedReward $p)
 [HuntersCompanion.Messages]::Show((Get-QuestbookText 'Fixed reward staged and verified. Use Save As to export the edited copy, then load it in-game and verify the material quantity.'),'MHWI Questbook')|Out-Null
}
function Record-FixedRewardExport([string]$path){
 if(-not $script:RewardSessionReceipts.Count){return}
 $workingHash=Get-RewardFileHash $script:Working;$exportHash=Get-RewardFileHash $path
 if($workingHash -ne $exportHash){throw 'The exported reward copy does not match the working file.'}
 $lineage=@($script:History)+@($script:Working)
 $inspection=Invoke-Engine -Arguments @('inspect',$path)
 foreach($receiptPath in @($script:RewardSessionReceipts.Values)){
  $r=Read-RewardReceipt $receiptPath
  if($r.working_output -notin $lineage){continue}
  $entries=@($inspection.slots[[int]$r.slot-1].inventory|Where-Object {$_.id -eq $r.item_id -and $_.category -eq 1})
  $amount=if($entries.Count -eq 1){[int64]$entries[0].amount}else{0}
  $phase=if($amount -eq [int64]$r.quantity_expected_after){'saved_copy_verified'}else{'exported_with_later_edits'}
  $r.state=$phase
  $r.exports=@($r.exports)+@([pscustomobject]@{path=$path;sha256=$exportHash;observed_quantity=$amount;verified_utc=[DateTime]::UtcNow.ToString('o')})
  if($r.exports.Count -gt 12){$r.exports=@($r.exports|Select-Object -Last 12)}
  Write-RewardReceipt $r $receiptPath $false
 }
}
function Show-FixedRewardReceipt([string]$path=''){
 if(-not $path){
  $candidates=@(Get-ChildItem -LiteralPath $script:RewardReceiptRoot -Filter '*.json' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending)
  if(-not $candidates.Count){[HuntersCompanion.Messages]::Show((Get-QuestbookText 'No fixed reward receipts were found.'),'MHWI Questbook')|Out-Null;return}
  $path=$candidates[0].FullName
 }
 $r=Read-RewardReceipt $path
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Reward Receipt';$dialog.ClientSize=[Drawing.Size]::new(820,520);$dialog.StartPosition='CenterParent'
  $text=Add-Control $dialog TextBox '' 20 20 780 420;$text.Multiline=$true;$text.ReadOnly=$true;$text.ScrollBars='Vertical';$text.Anchor='Top,Bottom,Left,Right'
  $phase=Get-QuestbookText $(switch($r.state){'started' {'Started — Review Required'};'working_copy_verified' {'Working Copy Verified'};'saved_copy_verified' {'Saved Copy Verified'};'exported_with_later_edits' {'Exported with Later Edits'};default {'Not Applied — Review Required'}})
  $text.Text=(Format-QuestbookText '{0}

{1}
{2}: {3} | {4}: {5}
{6}: {7}
{8}: {9} +{10}
{11} → {12}

' @(($(Get-QuestbookText 'Reward Receipt')),($phase),($(Get-QuestbookText 'Character')),($($r.character)),($(Get-QuestbookText 'Slot')),($($r.slot)),($(Get-QuestbookText 'Quest')),($($r.quest_id)),($(Get-QuestbookText 'Item')),($($r.item_id)),($($r.amount)),($($r.quantity_before)),($($r.quantity_expected_after))))+(Get-QuestbookText 'A saved-copy receipt verifies a file export, not an in-game reload. An interrupted receipt is never retried automatically. Receipts track this editor on this computer; they cannot prove whether older quest rewards were received.')+(Format-QuestbookText '

{0}' @(($path)))
  foreach($export in @($r.exports)){$text.AppendText("`r`n`r`n$($export.path)`r`n$(Get-QuestbookText 'Quantity'): $($export.observed_quantity)")}
  if($r.error){$text.AppendText("`r`n`r`n$($r.error)")}

  $close=Add-Control $dialog Button (Get-QuestbookText 'Close') 560 465 240 36;$close.DialogResult='OK';$close.Anchor='Bottom,Right'
  Set-QuestbookTree $dialog;$text.TextAlign='Left';[void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
