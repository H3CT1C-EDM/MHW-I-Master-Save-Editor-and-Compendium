﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Text;
namespace HuntersCompanion {
 public static class HeaderParchment {
  // Crop the transparent matte only. Keep the inked corner motifs and paper texture.
  public const int CropX=11,CropY=6,PaperWidth=995,PaperHeight=724;
  public static Bitmap Prepare(Image source,bool forHeadline) {
   var canvas=new Bitmap(PaperWidth,PaperHeight);
   using(var g=Graphics.FromImage(canvas)){
    g.Clear(Color.FromArgb(91,57,41));
    g.DrawImage(source,new Rectangle(0,0,PaperWidth,PaperHeight),new Rectangle(CropX,CropY,PaperWidth,PaperHeight),GraphicsUnit.Pixel);
   }
   if(forHeadline){
    // Remove the whole old inner rule, including its unequal original gap.
    for(int x=132;x<863;x++){
     double across=Math.Min(1,Math.Min(x-132,862-x)/12.0);
     Color above=canvas.GetPixel(x,17),below=canvas.GetPixel(x,35);
     for(int y=18;y<35;y++){
      Color pixel=canvas.GetPixel(x,y);
      double a=across*Math.Min(1,Math.Min(y-17,35-y)/3.0),t=(y-17)/18.0;
      canvas.SetPixel(x,y,Color.FromArgb(Blend(pixel.R,above.R,below.R,t,a),Blend(pixel.G,above.G,below.G,t,a),Blend(pixel.B,above.B,below.B,t,a)));
     }
    }
   }
   using(var g=Graphics.FromImage(canvas)){
    using(var p=new Pen(Color.FromArgb(83,91,47,31),1)){
     g.DrawLine(p,15,58,15,PaperHeight-48);g.DrawLine(p,PaperWidth-16,58,PaperWidth-16,PaperHeight-48);
    }
    using(var p=new Pen(Color.FromArgb(80,216,163,97),1)){
     g.DrawLine(p,18,65,18,PaperHeight-53);g.DrawLine(p,PaperWidth-19,65,PaperWidth-19,PaperHeight-53);
    }
   }
   return canvas;
  }
  public static RectangleF WordmarkBounds(Rectangle title,Size artwork){
   if(artwork.Width<=0||artwork.Height<=0)return title;
   float scale=Math.Min((float)title.Width/artwork.Width,(float)title.Height/artwork.Height);
   float w=artwork.Width*scale,h=artwork.Height*scale;
   return new RectangleF(title.Left+(title.Width-w)/2,title.Top+(title.Height-h)/2,w,h);
  }
  public static Bitmap Compose(Image paper,Size client,Rectangle title,Size artwork){
   var bitmap=new Bitmap(Math.Max(1,client.Width),Math.Max(1,client.Height));
   using(var g=Graphics.FromImage(bitmap)){
    g.Clear(Color.FromArgb(91,57,41));
    g.InterpolationMode=System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
    g.DrawImage(paper,new Rectangle(Point.Empty,bitmap.Size));
    g.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
    RectangleF mark=WordmarkBounds(title,artwork);
    float xs=(float)bitmap.Width/PaperWidth,ys=(float)bitmap.Height/PaperHeight;
    float clearance=Math.Max(10,Math.Min(24,mark.Height*0.25f));
    float left=Math.Min(mark.Left-clearance,bitmap.Width/2f),right=Math.Max(mark.Right+clearance,bitmap.Width/2f);
    Stroke(g,133*xs,left,22.5f*ys,26.5f*ys,ys);
    Stroke(g,right,862*xs,22.5f*ys,26.5f*ys,ys);
   }
   return bitmap;
  }
  static void Stroke(Graphics g,float from,float to,float upper,float lower,float scale){
   if(to<=from)return;
   using(var dark=new Pen(Color.FromArgb(158,103,55,37),Math.Max(1,scale*1.45f)))g.DrawLine(dark,from,upper,to,upper);
   using(var light=new Pen(Color.FromArgb(130,121,68,43),Math.Max(1,scale)))g.DrawLine(light,from,lower,to,lower);
  }
  static int Blend(int value,int upper,int lower,double t,double a){return (int)Math.Round(value*(1-a)+(upper*(1-t)+lower*t)*a);}
 }
 public static class NativeUi {
  [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern bool PostMessage(IntPtr window,uint message,IntPtr first,IntPtr second);
  public static void SetPauseLanguage(IntPtr window,int language){if(window!=IntPtr.Zero&&language>=0&&language<=4)PostMessage(window,0x8003,new IntPtr(language),IntPtr.Zero);}
 }
 public sealed class QuestClearHotkey : IDisposable {
  const int Home=0x24;
  const uint KeyUp=0x0002, Extended=0x0001, QueryLimitedInformation=0x1000;
  [StructLayout(LayoutKind.Sequential)] struct Input {
   public uint Type; public InputData Data;
  }
  [StructLayout(LayoutKind.Explicit)] struct InputData {
   [FieldOffset(0)] public KeyboardInput Key;
   [FieldOffset(0)] public MouseInput Mouse;
  }
  [StructLayout(LayoutKind.Sequential)] struct KeyboardInput {
   public ushort VirtualKey,Scan;public uint Flags,Time;public UIntPtr Extra;
  }
  [StructLayout(LayoutKind.Sequential)] struct MouseInput {
   public int X,Y;public uint MouseData,Flags,Time;public UIntPtr Extra;
  }
  [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint processId);
  [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint count,Input[] inputs,int size);
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint id);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr handle,int flags,StringBuilder name,ref int size);
  readonly Timer timer;
  readonly string exePath;
  readonly int key;
  internal sealed class KeyGate {
   bool armed;
   public bool Observe(bool down,bool eligible){
    if(!eligible){armed=false;return false;}
    if(!down){armed=true;return false;}
    bool fire=armed;armed=false;return fire;
   }
  }
  readonly KeyGate gate=new KeyGate();
  bool homeDown, disposed;
  IntPtr pulseWindow, previousWindow;
  long releaseAfter;
  public QuestClearHotkey(string executable,int trigger) {
   if(trigger<114||trigger>118)throw new ArgumentOutOfRangeException("trigger");
   exePath=System.IO.Path.GetFullPath(executable);key=trigger;
   timer=new Timer{Interval=25};timer.Tick+=Tick;timer.Start();
  }
  static bool Down(int key){return (GetAsyncKeyState(key)&0x8000)!=0;}
  bool IsExpectedGame(IntPtr window){
   uint id;
   if(window==IntPtr.Zero||GetWindowThreadProcessId(window,out id)==0||id==0)return false;
   IntPtr process=OpenProcess(QueryLimitedInformation,false,id);
   if(process==IntPtr.Zero)return false;
   try{
    var path=new StringBuilder(32768);int length=path.Capacity;
    return QueryFullProcessImageName(process,0,path,ref length)&&string.Equals(path.ToString(),exePath,StringComparison.OrdinalIgnoreCase);
   }finally{CloseHandle(process);}
  }
  static bool SendHome(bool up){
   var input=new Input{Type=1,Data=new InputData{Key=new KeyboardInput{VirtualKey=Home,Flags=Extended|(up?KeyUp:0u)}}};
   return SendInput(1,new[]{input},Marshal.SizeOf(typeof(Input)))==1;
  }
  void Tick(object sender,EventArgs args) {
   IntPtr window=GetForegroundWindow();
   long now=System.Diagnostics.Stopwatch.GetTimestamp();
   if(homeDown && (now>=releaseAfter||window!=pulseWindow)){if(SendHome(true))homeDown=false;}
   bool down=Down(key);
   if(window!=previousWindow){gate.Observe(false,false);previousWindow=window;}
   bool fire=gate.Observe(down,window!=IntPtr.Zero&&!Down(0x10)&&!Down(0x11)&&!Down(0x12));
   if(!fire || homeDown || Down(Home) || !IsExpectedGame(window) || GetForegroundWindow()!=window)return;
   if(SendHome(false)){
    homeDown=true;pulseWindow=window;releaseAfter=now+System.Diagnostics.Stopwatch.Frequency*140/1000;
   }
  }
  public void Dispose(){
   if(disposed)return;disposed=true;timer.Stop();timer.Dispose();
   if(homeDown){SendHome(true);homeDown=false;}
  }
 }
 public static class Messages {
  public static Func<string,string> Translate;
  static string T(string s){return Translate==null?s:Translate(s);}
  public static DialogResult Show(string text){return MessageBox.Show(T(text));}
  public static DialogResult Show(string text,string caption){return MessageBox.Show(T(text),T(caption));}
  public static DialogResult Show(string text,string caption,MessageBoxButtons buttons){return MessageBox.Show(T(text),T(caption),buttons);}
  public static DialogResult Show(string text,string caption,MessageBoxButtons buttons,MessageBoxIcon icon){return MessageBox.Show(T(text),T(caption),buttons,icon);}
 }
 public sealed class LocalizedToolTip : ToolTip {
  readonly System.Collections.Generic.Dictionary<Control,string> sources=new System.Collections.Generic.Dictionary<Control,string>();
  readonly System.Collections.Generic.Dictionary<Control,bool> parents=new System.Collections.Generic.Dictionary<Control,bool>();Control lastDisabled;
  void ObserveParent(Control parent){
   if(parent==null||parents.ContainsKey(parent))return;parents[parent]=true;
   parent.MouseMove+=(sender,e)=>{Control child=parent.GetChildAtPoint(e.Location,GetChildAtPointSkip.Invisible);string tip=child!=null&&!child.Enabled?GetToolTip(child):"";
    if(!string.IsNullOrEmpty(tip)){if(lastDisabled!=child){Hide(parent);lastDisabled=child;Show(tip,parent,new Point(e.X+12,e.Y+20),AutoPopDelay);}}
    else if(lastDisabled!=null){Hide(parent);lastDisabled=null;}
   };
   parent.MouseLeave+=(sender,e)=>{Hide(parent);lastDisabled=null;};parent.Disposed+=(sender,e)=>{parents.Remove(parent);lastDisabled=null;};
  }
  public new void SetToolTip(Control c,string text){if(!sources.ContainsKey(c))c.Disposed+=(s,e)=>{sources.Remove(c);if(lastDisabled==c)lastDisabled=null;};sources[c]=text;base.SetToolTip(c,Messages.Translate==null?text:Messages.Translate(text));ObserveParent(c.Parent);}
  public void RefreshLanguage(){foreach(var pair in sources)if(!pair.Key.IsDisposed)base.SetToolTip(pair.Key,Messages.Translate==null?pair.Value:Messages.Translate(pair.Value));}
 }
 public sealed class MusicPlayer : IDisposable {
  [DllImport("winmm.dll",CharSet=CharSet.Unicode)]static extern int mciSendString(string command,StringBuilder result,int length,IntPtr callback);
  [DllImport("winmm.dll",CharSet=CharSet.Unicode)]static extern bool mciGetErrorString(int error,StringBuilder text,int length);
  readonly string file;readonly string alias="hc"+Guid.NewGuid().ToString("N");bool opened;
  public MusicPlayer(string path){file=path;}
  void Command(string command){int error=mciSendString(command,null,0,IntPtr.Zero);if(error!=0){var text=new StringBuilder(512);mciGetErrorString(error,text,text.Capacity);throw new InvalidOperationException("Audio playback failed: "+text);}}
  public string State {get{if(!opened)return "stopped";var text=new StringBuilder(64);int error=mciSendString("status "+alias+" mode",text,text.Capacity,IntPtr.Zero);return error==0?text.ToString():"stopped";}}
  public bool IsPlaying {get{return State=="playing";}}
  public void Toggle(){
   if(!opened){if(file.IndexOf('"')>=0)throw new InvalidOperationException("Invalid audio path.");Command("open \""+file+"\" type waveaudio alias "+alias);opened=true;}
   string state=State;if(state=="playing")Command("pause "+alias);else if(state=="paused")Command("resume "+alias);else {Command("seek "+alias+" to start");Command("play "+alias);}
  }
  public void Dispose(){if(opened){mciSendString("close "+alias,null,0,IntPtr.Zero);opened=false;}}
 }
 public sealed class ParchmentText : Control {
  readonly VScrollBar scroll=new VScrollBar();
  bool drawFrame=false;
  int contentHeight, textWidth, wheelRemainder;
  public bool DrawFrame {get{return drawFrame;}set{drawFrame=value;Invalidate();}}
  readonly TextFormatFlags flags=TextFormatFlags.HorizontalCenter|TextFormatFlags.WordBreak|TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding;
  public ParchmentText(){
   SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.SupportsTransparentBackColor|ControlStyles.ResizeRedraw,true);
   BackColor=Color.Transparent;TabStop=true;AccessibleRole=AccessibleRole.StaticText;
   scroll.TabStop=false;scroll.Visible=false;scroll.ValueChanged+=(s,e)=>Invalidate();Controls.Add(scroll);
  }
  int MaximumOffset {get{return Math.Max(0,contentHeight+12-ClientSize.Height);}}
  void Measure(){
   if(scroll==null||Font==null)return;
   int width=Math.Max(20,ClientSize.Width-20);
   contentHeight=TextRenderer.MeasureText(Text??"",Font,new Size(width,32767),flags).Height;
   bool needed=MaximumOffset>0;int barWidth=SystemInformation.VerticalScrollBarWidth;
   textWidth=Math.Max(20,width-(needed?barWidth:0));
   if(needed)contentHeight=TextRenderer.MeasureText(Text??"",Font,new Size(textWidth,32767),flags).Height;
   int offset=Math.Min(scroll.Value,MaximumOffset);
   scroll.SetBounds(Math.Max(0,ClientSize.Width-barWidth),0,barWidth,ClientSize.Height);
   int page=Math.Max(1,ClientSize.Height-12);
   scroll.Maximum=MaximumOffset+page-1;scroll.LargeChange=page;scroll.SmallChange=Math.Max(1,Font.Height);
   scroll.Value=offset;scroll.Visible=needed;
   Invalidate();
  }
  void ScrollTo(int offset){scroll.Value=Math.Min(MaximumOffset,Math.Max(0,offset));}
  protected override void OnTextChanged(EventArgs e){base.OnTextChanged(e);if(scroll!=null){scroll.Value=0;Measure();}}
  protected override void OnSizeChanged(EventArgs e){base.OnSizeChanged(e);Measure();}
  protected override void OnFontChanged(EventArgs e){base.OnFontChanged(e);Measure();}
  protected override void OnMouseDown(MouseEventArgs e){Focus();base.OnMouseDown(e);}
  protected override void OnMouseWheel(MouseEventArgs e){
   if(MaximumOffset<=0){base.OnMouseWheel(e);return;}
   wheelRemainder+=e.Delta;int steps=wheelRemainder/120;wheelRemainder%=120;
   int lines=SystemInformation.MouseWheelScrollLines;
   if(lines!=0)ScrollTo(scroll.Value-steps*(lines<0?scroll.LargeChange:lines*scroll.SmallChange));
   var handled=e as HandledMouseEventArgs;if(handled!=null)handled.Handled=true;
  }
  protected override bool IsInputKey(Keys key){
   switch(key & Keys.KeyCode){case Keys.Up:case Keys.Down:case Keys.PageUp:case Keys.PageDown:case Keys.Home:case Keys.End:return true;}
   return base.IsInputKey(key);
  }
  protected override void OnKeyDown(KeyEventArgs e){
   int next=scroll.Value;
   switch(e.KeyCode){
    case Keys.Up:next-=scroll.SmallChange;break;case Keys.Down:next+=scroll.SmallChange;break;
    case Keys.PageUp:next-=scroll.LargeChange;break;case Keys.PageDown:next+=scroll.LargeChange;break;
    case Keys.Home:next=0;break;case Keys.End:next=MaximumOffset;break;
    default:base.OnKeyDown(e);return;
   }
   ScrollTo(next);e.Handled=true;
  }
  protected override void OnPaintBackground(PaintEventArgs e){var root=FindForm();if(root!=null&&root.BackgroundImage!=null)ParchmentCanvas.PaintRegion(this,e.Graphics,ClientRectangle,root,root.BackgroundImage);else base.OnPaintBackground(e);}
  protected override void OnPaint(PaintEventArgs e){
   base.OnPaint(e);
   var rect=new Rectangle(10,6-scroll.Value,Math.Max(20,textWidth),Math.Max(ClientSize.Height,contentHeight));
   TextRenderer.DrawText(e.Graphics,Text??"",Font,rect,ForeColor,flags);
   if(DrawFrame)using(var pen=new Pen(Color.FromArgb(140,112,61)))e.Graphics.DrawRectangle(pen,0,0,Math.Max(0,ClientSize.Width-1),Math.Max(0,ClientSize.Height-1));
  }
 }
 public static class ButtonTextFit {
  sealed class State { public Font Preferred;public Font Fitted;public bool Busy; }
  static readonly System.Collections.Generic.Dictionary<Button,State> states=new System.Collections.Generic.Dictionary<Button,State>();
  public static Font Preferred(Control control){var button=control as Button;State s;return button!=null&&states.TryGetValue(button,out s)?s.Preferred:control.Font;}
  public static void Attach(Button button){if(states.ContainsKey(button))return;var state=new State{Preferred=button.Font};states.Add(button,state);
   button.FontChanged+=(s,e)=>{if(state.Busy)return;if(!object.ReferenceEquals(button.Font,state.Fitted))state.Preferred=button.Font;Fit(button);};
   button.SizeChanged+=(s,e)=>Fit(button);button.TextChanged+=(s,e)=>Fit(button);
   button.Disposed+=(s,e)=>{states.Remove(button);if(state.Fitted!=null)state.Fitted.Dispose();};Fit(button);
  }
  public static void Fit(Button b){State s;if(!states.TryGetValue(b,out s)||s.Busy||b.IsDisposed)return;s.Busy=true;try{
   int image=b.Image==null?0:(b.TextImageRelation==TextImageRelation.Overlay?32:b.Image.Width+8);
   int width=Math.Max(8,b.ClientSize.Width-b.Padding.Horizontal-image-10),height=Math.Max(8,b.ClientSize.Height-b.Padding.Vertical-2);
   float size=s.Preferred.SizeInPoints;Font fitted=null;
   for(;size>=8.5f;size-=0.25f){var f=new Font(s.Preferred.FontFamily,size,s.Preferred.Style);var measure=TextRenderer.MeasureText(b.Text,f,new Size(width,32767),TextFormatFlags.WordBreak|TextFormatFlags.NoPrefix|TextFormatFlags.NoPadding);if(measure.Height<=height&&measure.Width<=width){fitted=f;break;}f.Dispose();}
   if(fitted==null)fitted=new Font(s.Preferred.FontFamily,8.5f,s.Preferred.Style);
   ApplyFittedFont(b,s,fitted);
  }finally{s.Busy=false;}}
  static void ApplyFittedFont(Button button,State state,Font candidate){
   Font previous=state.Fitted;
   try{
    // WinForms can keep its current Font when an equivalent one is assigned.
    if(!button.Font.Equals(candidate))button.Font=candidate;
   }finally{
    Font active=button.Font;
    state.Fitted=object.ReferenceEquals(active,candidate)?candidate:
                 object.ReferenceEquals(active,previous)?previous:null;
    if(!object.ReferenceEquals(active,candidate))candidate.Dispose();
    if(previous!=null&&!object.ReferenceEquals(active,previous))previous.Dispose();
   }
  }
 }
 public sealed class ParchmentListView : ListView {
  public ParchmentListView(){DoubleBuffered=true;BorderStyle=BorderStyle.None;}
 }
 public sealed class RememberedComboBox : ComboBox {
  [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern IntPtr SendMessage(IntPtr h,int m,IntPtr w,IntPtr l);
  object topItem;int topIndex;bool remembered;
  protected override void OnDropDownClosed(EventArgs e){if(IsHandleCreated){int i=SendMessage(Handle,0x15b,IntPtr.Zero,IntPtr.Zero).ToInt32();if(i>=0&&i<Items.Count){topIndex=i;topItem=Items[i];remembered=true;}}base.OnDropDownClosed(e);}
  protected override void OnDropDown(EventArgs e){base.OnDropDown(e);if(remembered&&IsHandleCreated)BeginInvoke((Action)(()=>{if(IsDisposed||!DroppedDown||Items.Count==0)return;int i=topItem==null?-1:Items.IndexOf(topItem);if(i<0)i=Math.Min(topIndex,Items.Count-1);SendMessage(Handle,0x15c,new IntPtr(Math.Max(0,i)),IntPtr.Zero);}));}
 }
 public static class ParchmentCanvas {
  sealed class Cache {public Bitmap Bitmap;public Size Size;public Image Source;}
  static readonly System.Collections.Generic.Dictionary<Form,Cache> caches=new System.Collections.Generic.Dictionary<Form,Cache>();
  static Bitmap Texture(Form root,Image image){
   Cache cache;if(!caches.TryGetValue(root,out cache)){cache=new Cache();caches.Add(root,cache);root.FormClosed+=(s,e)=>{Cache old;if(caches.TryGetValue(root,out old)){if(old.Bitmap!=null)old.Bitmap.Dispose();caches.Remove(root);}};}
   Size size=root.ClientSize;
   if(cache.Bitmap==null||cache.Size!=size||!object.ReferenceEquals(cache.Source,image)){if(cache.Bitmap!=null)cache.Bitmap.Dispose();cache.Bitmap=new Bitmap(Math.Max(1,size.Width),Math.Max(1,size.Height));using(Graphics graphics=Graphics.FromImage(cache.Bitmap))graphics.DrawImage(image,new Rectangle(Point.Empty,size));cache.Size=size;cache.Source=image;}
   return cache.Bitmap;
  }
  public static void PaintRegion(Control control,Graphics graphics,Rectangle bounds,Form root,Image image){
   if(root.IsDisposed||image==null)return;Point at=root.PointToClient(control.PointToScreen(Point.Empty));var state=graphics.Save();try{graphics.SetClip(bounds);graphics.DrawImageUnscaled(image.Size==root.ClientSize?image:Texture(root,image),-at.X,-at.Y);}finally{graphics.Restore(state);}
  }
  public static void Attach(Control control,Form root){
   control.BackgroundImage=null;
   control.Paint+=(sender,e)=>PaintRegion(control,e.Graphics,e.ClipRectangle,root,root.BackgroundImage);
  }
 }
}
