﻿function Select-CompanionQuestRows($quests){
 $chosen=[Collections.Specialized.OrderedDictionary]::new();$scores=@{}
 foreach($q in $quests){
  if($null -eq $q){continue}
  $isMod=$q.IsModQuest -eq $true -or ([string]$q.Key).StartsWith('definition:mod:') -or ([string]$q.Key).StartsWith('mod:') -or -not [string]::IsNullOrEmpty([string]$q.ModPack)
  $id=[string]$q.Id
  $identity=if($isMod){'mod|'+$q.ModPack+'|'+$q.ModVersion+'|'+$id+'|'+$q.HeaderId}elseif($id -match '^\d+$'){'base|'+$id}else{'source|'+$q.Key}
  $score=10
  if(-not $q.Placeholder -and -not $q.IdentityAmbiguous -and -not $q.DuplicateDefinitionId){$score+=20}
  if([string]$q.Key -eq ('game:'+$id)){$score+=20;if($script:QuestMappingIds.ContainsKey([int64]$q.Id) -and -not $q.Placeholder){$score+=100}}
  if([string]$q.Name -and [string]$q.Name -notin @('Unavailable','Invalid Message')){$score+=10}
  if(-not $chosen.Contains($identity) -or $score -gt $scores[$identity]){$chosen[$identity]=$q;$scores[$identity]=$score}
 }
 foreach($q in $chosen.Values){$q}
}
function Prepare-CompanionUserInterface {
 # Keep legacy actions available in source, outside the normal user layout.
 foreach($control in @($importIcons,$installBridge,$questImport,$questLoadImport,$questExport)){$control.Visible=$false;$control.Enabled=$false}
 $markFound.SetBounds(15,574,515,32);$journalBatch.SetBounds(545,574,515,32)
 $questSummary.SetBounds(15,52,1045,32)
 $script:QuestHowTo=Add-Control $questTab Label '1. Select a mapped quest and enable edits. 2. Set flag/count, review, Save As, then load that copy in-game. 3. For supported ingredients: Apply Quest Unlocks, solo expedition, account key, return, save and reload. Flags alone do not grant rewards or story unlocks.' 15 88 1045 64
 $questList.SetBounds(15,160,1045,155);$questDetails.SetBounds(15,325,1045,150)
 $questComplete.SetBounds(15,485,185,36);$questIncomplete.SetBounds(210,485,185,36);$questRepair.SetBounds(405,485,165,36);$questPair.SetBounds(585,485,475,36)
 $questFlagTest.SetBounds(15,527,540,32);$questUnlockStatus.SetBounds(565,527,235,32);$rewardReceipt.SetBounds(810,527,250,32)
 $fixedReward.SetBounds(15,574,335,36);$script:experimentalPayout.SetBounds(365,574,345,36);$questUnlock.SetBounds(725,574,335,36)
 $eqnote.Text='Base fields export weapon slots. Saved augment/awakening effects appear below; bonus slots are separate and preserved.'
 $eqnote.Height=42
 $apply.SetBounds(15,365,170,38);$slotExport.SetBounds(195,365,215,38);$weaponQueue.SetBounds(420,365,195,38);$masterAugments.SetBounds(625,365,208,38)
 $script:EquipmentEffects=[HuntersCompanion.ParchmentText]::new();$script:EquipmentEffects.SetBounds(15,453,1045,147);$script:EquipmentEffects.Font=$script:QuestbookFont;$script:EquipmentEffects.ForeColor=$script:QuestbookColors.Ink;$script:EquipmentEffects.DrawFrame=$false;$script:EquipmentEffects.Text='Select equipment to read its saved augments and awakened abilities.';$eqtab.Controls.Add($script:EquipmentEffects)
 foreach($c in @($eqtab.Controls)){if($c -is [Windows.Forms.Label] -and $c.Top -eq 430){$c.Visible=$false}}
 # Export fields stay explicitly base-only; the bonus report is read-only.
}
function Set-CompanionUserTooltips {
 $tips=@(
  @($slotExport,'Queue base weapon slot levels for this weapon ID. Installing the export affects every copy of that ID. Saved augments and awakenings are preserved and reported separately.'),
  @($weaponQueue,'Review or remove queued base weapon slot edits, then export them together. Install the exported game tables while the game is closed; restart the game to load them.'),
  @($accountStatus,'Read the latest bridge journal. Queue one request, load the matching character in a solo expedition, press the configured account key once, then return, save and reload. Confirm matching item, quantity and slot; native_calls_returned=1 alone does not prove persistence.'),
  @($bridgeInstall,'Install the account bridge while the game is closed. It is required for live account-item acquisition and supported ingredient unlock requests, not ordinary offline inventory/save edits.'),
  @($questFlagTest,'Enable the mapped flag/count controls for a supported base-game row. Review each change and use Save As. This does not grant rewards, make every quest available, or complete story progression.'),
  @($questComplete,'Set this mapped quest''s saved clear flag. The preview lists affected IDs. Save As, then load that copy in-game. Materials, Zenny, rank points, ingredients and story unlocks are not granted.'),
  @($questIncomplete,'Clear this mapped quest''s saved clear flag. This does not undo story progress, remove previously collected rewards, or relock ingredients. Review the preview before saving.'),
  @($questRepair,'Change the explicit saved completion count for this mapped quest. The count and clear flag are separate; neither proves reward receipt. This action preserves the clear flag.'),
  @($questPair,'Include the paired quest only when available. Review both IDs in the preview. Leave unchecked to edit only the selected mapped quest.'),
  @($questUnlock,'Queue an ingredient unlock for one of the five supported base-game quests. Its real saved clear flag must already be set on the loaded character. Use the configured account key in a solo expedition, return normally, save and reload. No materials, Zenny, rank or story progress are granted.'),
  @($fixedReward,'Preview one of the five supported fixed material supplements, including exact quantity and capacity. A clear flag does not prove you have not already collected it. Review the receipt and Save As; broader random rewards are not generated.'),
  @($script:experimentalPayout,'Preview manual item, Zenny, HR XP and MR XP additions. Experimental; a backup is made before Apply. Does not simulate native quest results.'),
  @($script:legacyAugments,'Edit an existing stock High Rank augmentation on a rarity 6–8 weapon. Mixed records and awakening edits are excluded.'),
  @($rewardReceipt,'Inspect this editor''s grant receipt and its staged/exported/verification state. An interrupted receipt is not retried automatically; a file export is not in-game reload verification.'),
  @($questSource,'Filter the displayed canonical quest rows. Duplicate IDs prefer the most editable safe base-game row; different quest IDs and different mod packs remain separate.'),
  @($markFound,'Change only the selected account item''s discovery flag. Use Acquire for an in-game bridge request; discovery alone does not grant its reward or unlock an ingredient.')
 )
 foreach($pair in $tips){$script:QuestbookTips.SetToolTip($pair[0],$pair[1]);$pair[0].AccessibleDescription=Get-QuestbookText $pair[1]}
}
