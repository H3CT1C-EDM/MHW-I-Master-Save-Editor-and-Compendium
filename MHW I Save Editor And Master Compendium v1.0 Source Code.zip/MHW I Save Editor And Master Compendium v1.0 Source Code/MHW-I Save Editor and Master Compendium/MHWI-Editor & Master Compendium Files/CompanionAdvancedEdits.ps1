﻿$script:ExperimentalPayoutReceipts=@{}
function Invoke-CompanionAdvanced([string[]]$Arguments) {
 $si=[Diagnostics.ProcessStartInfo]::new()
 $si.FileName=Join-Path $script:Root 'tools/AdvancedEdits.exe'
 $si.Arguments=($Arguments | ForEach-Object {
  if($_.Contains('"')){throw 'A command argument contains an unsupported quote.'}
  '"'+($_ -replace '(\\+)$','$1$1')+'"'
 }) -join ' '
 $si.UseShellExecute=$false;$si.CreateNoWindow=$true
 $si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
 $p=[Diagnostics.Process]::Start($si)
 try {
  $out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
  $p.WaitForExit()
  if($p.ExitCode -ne 0){throw $err.Result.Trim()}
  return $out.Result | ConvertFrom-Json
 }finally{$p.Dispose()}
}
function Confirm-AdvancedEdit([string]$title,[string]$preview){
 $d=[Windows.Forms.Form]::new()
 try{
  $d.Text=Get-QuestbookText $title;$d.ClientSize=[Drawing.Size]::new(770,470)
  $view=Add-Control $d TextBox '' 20 20 730 380
  $view.Multiline=$true;$view.ReadOnly=$true;$view.ScrollBars='Vertical';$view.Text=$preview
  $yes=Add-Control $d Button 'Back Up and Apply' 20 415 475 36;$yes.DialogResult='OK'
  $no=Add-Control $d Button 'Cancel' 510 415 240 36;$no.DialogResult='Cancel';$d.CancelButton=$no
  Set-QuestbookTree $d
  return $d.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK
 }finally{$d.Dispose()}
}
function New-AdvancedEditBackup([string]$working,[string]$hash){
 $root=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal/ExperimentalBackups'
 [void][IO.Directory]::CreateDirectory($root)
 $path=Join-Path $root ('SAVEDATA1000-'+[datetime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N')+'.bak')
 [IO.File]::Copy($working,$path,$false)
 if((Get-RewardFileHash $path) -cne $hash){throw 'The backup did not match the preview. Nothing was applied.'}
 return $path
}
function Get-ExperimentalQuestCandidates($q){
 $ids=[Collections.Generic.HashSet[int]]::new()
 if(-not $q -or $q.Placeholder -or $q.IdentityAmbiguous -or $q.DuplicateDefinitionId){return}
 foreach($entry in @($q.ReferenceRewards)){
  if(-not $entry){continue}
  if($entry.ItemId){[void]$ids.Add([int]$entry.ItemId);continue}
  if($entry.ItemName){
   $matches=@($script:Items|Where-Object {$_.Name -ceq $entry.ItemName})
   if($matches.Count -eq 1){[void]$ids.Add([int]$matches[0].Id)}
  }
 }
 $analysis=Get-QuestRewardAnalysis $q
 foreach($pool in (@($q.RewardPools)+@($analysis.Pools))){
  if(-not $pool -or $pool.IdentityVerified -eq $false){continue}
  foreach($entry in @($pool.Items)){if($entry -and $entry.ItemId){[void]$ids.Add([int]$entry.ItemId)}}
 }
 foreach($id in @($ids|Sort-Object)){
  if($id -gt 0 -and $id -lt $script:Items.Count){
   $item=$script:Items[$id]
   if([int]$item.Id -eq $id -and [int]$item.Category -in (0,1,3,4) -and -not $script:ItemAnnotations[$id]){ '{0}  {1}' -f $id,$item.Name }
  }
 }
}
function Get-ExperimentalPayoutPlan([string]$itemText,$current){
 $boxes=@{0=200;1=1250;3=200;4=500};$added=@{};$lines=@{};$plan=[Collections.Generic.List[object]]::new()
 foreach($row in ($itemText -split '\r?\n')){
  if(-not $row.Trim()){continue}
  if($row -notmatch '^\s*([0-9]{1,5})\s*[:x,]\s*([0-9]{1,4})\s*$'){throw 'Enter one item per line as ID:quantity, for example 20:2.'}
  $id=[int]$Matches[1];$qty=[int]$Matches[2]
  if($id -lt 1 -or $id -ge $script:Items.Count -or $qty -lt 1 -or $lines.ContainsKey($id)){throw 'Invalid or duplicate item ID or quantity.'}
  $lines[$id]=$true
  if($lines.Count -gt 24){throw 'Choose up to 24 different items per transaction.'}
  $item=$script:Items[$id];$type=[int]$item.Category
  if([int]$item.Id -ne $id -or -not $boxes.ContainsKey($type) -or $script:ItemAnnotations[$id]){throw "Item $id is not supported for manual payout."}
  $box=@($current.inventory|Where-Object {[int]$_.category -eq $type})
  $matches=@($box|Where-Object {[int]$_.id -eq $id})
  if($matches.Count -gt 1){throw "Item $id has duplicate stacks in the opened save."}
  $before=if($matches.Count){[long]$matches[0].amount}else{0L}
  if($before -lt 0 -or $before+$qty -gt 9999){throw "Item $id would exceed the editor's 9,999 stack limit."}
  if(-not $matches.Count){
   $added[$type]=1+[int]$added[$type]
   if($box.Count+$added[$type] -gt $boxes[$type]){throw "The destination box for item $id is full."}
  }
  $plan.Add([pscustomobject]@{Id=$id;Quantity=$qty;Name=$item.Name;Before=$before;After=$before+$qty;Category=$type})
 }
 return $plan.ToArray()
}
function Show-ExperimentalQuestPayout {
 $current=Current-Slot
 if(-not $current -or -not $script:Working -or -not $current.name){throw 'Open a save and select a character first.'}
 $working=$script:Working;$n=[int]$current.number
 $profile=Invoke-CompanionAdvanced @('payout-profile',$working,[string]$n)
 if([int]$profile.slot -ne $n){throw 'Payout profile identity did not match.'}
 $q=if($questList.SelectedItems.Count){$questList.SelectedItems[0].Tag}else{$null}
 $questLabel=if($q){"$($q.Name) [ID $($q.Id)]"}else{'No quest selected'}
 $d=[Windows.Forms.Form]::new()
 try{
  $d.Text=Get-QuestbookText 'Experimental Quest Payouts';$d.ClientSize=[Drawing.Size]::new(810,640)
  [void](Add-Control $d Label 'Experimental: the game may ignore or clamp these changes. A backup is made before Apply. Use a save copy. This manually adds selected amounts; it does not roll rewards, complete quests, prove collection, or recalculate rank.' 20 14 770 100)
  $reference=if($q -and $null -ne $q.Zenny){$questLabel+'  |  Listed base Zenny: '+$q.Zenny}else{$questLabel}
  [void](Add-Control $d Label $reference 20 116 770 32)
  [void](Add-Control $d Label 'Possible item IDs for reference only' 20 154 360 30)
  [void](Add-Control $d Label 'Add items by ID:quantity (one per line)' 415 154 375 30)
  $list=Add-Control $d TextBox '' 20 185 370 215;$list.Multiline=$true;$list.ReadOnly=$true;$list.ScrollBars='Vertical'
  $list.Text=(@(Get-ExperimentalQuestCandidates $q) -join "`r`n")
  if(-not $list.Text){$list.Text=Get-QuestbookText 'No supported item IDs listed. You can enter known item IDs manually.'}
  $items=Add-Control $d TextBox '' 415 185 375 215;$items.Multiline=$true;$items.ScrollBars='Vertical'
  $fields=@('Zenny','HR XP','MR XP');$controls=@()
  for($i=0;$i -lt 3;$i++){
   $y=410+$i*47
   [void](Add-Control $d Label ($fields[$i]+' (+'+(Get-QuestbookText 'Amount')+')') 20 $y 420 36)
   $v=Add-Control $d NumericUpDown '' 470 $y 320 36;$v.Maximum=99999999;$controls+=@($v)
  }
  $ok=Add-Control $d Button 'Preview Changes...' 20 571 500 39;$ok.DialogResult='OK'
  $no=Add-Control $d Button 'Cancel' 545 571 245 39;$no.DialogResult='Cancel';$d.CancelButton=$no
  Set-QuestbookTree $d
  if($d.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK){return}
  $plan=@(Get-ExperimentalPayoutPlan $items.Text $current)
  $deltas=@($controls|ForEach-Object {[long]$_.Value})
 }finally{$d.Dispose()}
 $fields=@('zenny','hr_xp','mr_xp')
 $expected=@{}
 $summary=@('EXPERIMENTAL • This may not work in-game. A verified backup will be written first.','Character: '+$current.name+'  |  Slot: '+$n,'Quest reference: '+$questLabel,'')
 for($i=0;$i -lt 3;$i++){
  $f=$fields[$i];$before=[long]$profile.$f;$expected[$f]=$before+$deltas[$i]
  if($deltas[$i] -and $expected[$f] -gt 99999999){throw "$f would exceed the editor's saved-field limit."}
  $summary+=("{0}: {1} → {2}" -f $f,$before,$expected[$f])
 }
 foreach($item in $plan){$summary+=("{0} [ID {1}]: {2} → {3}" -f $item.Name,$item.Id,$item.Before,$item.After)}
 if(-not $plan.Count -and -not ($deltas|Where-Object {$_ -gt 0})){throw 'No payout additions were selected.'}
 if(-not (Confirm-AdvancedEdit 'Review Experimental Payout' ($summary -join "`r`n"))){return}
 $active=Current-Slot
 if($script:Working -ne $working -or [int]$active.number -ne $n -or $active.name -cne $current.name -or (Get-RewardFileHash $working) -cne $profile.source_hash){throw 'The selected character or working save changed. Reopen the preview.'}
 $backup=New-AdvancedEditBackup $working $profile.source_hash
 $receiptPath=$backup+'.payout.json'
 $receipt=[ordered]@{format='MHWI_EXPERIMENTAL_PAYOUT_V1';state='pending';slot=$n;character=$current.name;quest_reference=$questLabel;source_hash=$profile.source_hash;items=$plan;fields_after=$expected;backup=$backup;verified_in_game=$false}
 Write-RewardReceipt $receipt $receiptPath $true
 $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
 try{
  $arguments=@('payout-apply',$working,[string]$n,[string]$profile.source_hash,$next)+@($deltas|ForEach-Object {[string]$_})
  foreach($item in $plan){$arguments+=@([string]$item.Id,[string]$item.Quantity)}
  $result=Invoke-CompanionAdvanced $arguments
  if(-not $result.verified_roundtrip -or [int]$result.slot -ne $n -or $result.source_hash -cne $profile.source_hash -or [int]$result.hr -ne [int]$profile.hr -or [int]$result.mr -ne [int]$profile.mr){throw 'Payout output identity verification failed.'}
  foreach($field in $fields){if([long]$result.$field -ne $expected[$field]){throw 'Payout output did not match the preview.'}}
  $state=Invoke-Engine -Arguments @('inspect',$next)
  if(-not $state.integrity -or $state.slots[$n-1].name -cne $current.name){throw 'Payout output could not be verified by the editor.'}
  foreach($item in $plan){
   $match=@($state.slots[$n-1].inventory|Where-Object {[int]$_.id -eq $item.Id -and [int]$_.category -eq $item.Category})
   if($match.Count -ne 1 -or [long]$match[0].amount -ne $item.After){throw 'Item output did not match the preview.'}
  }
  $receipt.state='written_and_read_back_in_working_copy';$receipt.output_hash=Get-RewardFileHash $next
  Write-RewardReceipt $receipt $receiptPath $false
  $script:ExperimentalPayoutReceipts[$receipt.output_hash]=$receiptPath
  $script:History.Add($working);$script:Working=$next;$script:State=$state;Refresh-Slot
 }catch{
  if($receipt.state -eq 'pending'){$receipt.state='interrupted_or_failed';try{Write-RewardReceipt $receipt $receiptPath $false}catch{}}
  throw
 }
 [void][HuntersCompanion.Messages]::Show("Staged in the working copy. Use Save As to export, then verify in-game. No automatic replay.`r`n`r`nBackup: $backup`r`nReceipt: $receiptPath",'Experimental Quest Payouts')
}
function Record-ExperimentalPayoutExport([string]$path){
 if(-not $script:ExperimentalPayoutReceipts.Count){return}
 $hash=Get-RewardFileHash $script:Working
 $receiptPath=$script:ExperimentalPayoutReceipts[$hash]
 if(-not $receiptPath){return}
 if((Get-RewardFileHash $path) -cne $hash){throw 'The exported copy did not match the payout working copy.'}
 $r=Get-Content -LiteralPath $receiptPath -Raw -Encoding UTF8|ConvertFrom-Json
 if($r.format -ne 'MHWI_EXPERIMENTAL_PAYOUT_V1' -or $r.output_hash -cne $hash){throw 'The experimental receipt identity changed.'}
 $r.state='exported_copy_verified'
 $r | Add-Member -NotePropertyName exported_file -NotePropertyValue $path -Force
 Write-RewardReceipt $r $receiptPath $false
}
function Show-CompanionLegacyAugments {
 $sel=$equipList.SelectedItem
 if(-not $sel -or [int]$sel.Record.category -ne 1){throw 'Select an already-augmented High Rank weapon.'}
 $working=$script:Working;$n=[int](Current-Slot).number;$index=[int]$sel.Record.index
 $type=[int]$sel.Record.type
 if($type -lt 0 -or $type -ge $script:CompanionWeaponTables.Count){throw 'Unsupported weapon class.'}
 $ext=if($type -ge 11){'.wp_dat_g'}else{'.wp_dat'}
 $file=$script:CompanionWeaponTables[$type]+$ext
 $override=Get-NativePcTarget (Get-EquipmentTableRoot) ('equip/'+$file)
 $stock=Join-Path $script:Root ('data/common/equip/'+$file)
 if((Test-Path -LiteralPath $override) -and (Get-NativePcHash $override) -cne (Get-NativePcHash $stock)){throw 'Legacy augment editing requires the stock table for this weapon class.'}
 $profile=Invoke-CompanionAdvanced @('legacy-profile',$working,[string]$n,[string]$index)
 if([int]$profile.slot -ne $n -or [int]$profile.index -ne $index -or [int]$profile.id -ne [int]$sel.Record.id -or [int]$profile.type -ne $type -or [int]$profile.capacity -notin (1..3)){throw 'Legacy augment identity verification failed.'}
 $d=[Windows.Forms.Form]::new()
 try{
  $d.Text=Get-QuestbookText 'Edit High Rank Augments';$d.ClientSize=[Drawing.Size]::new(760,365)
  [void](Add-Control $d Label ([string]$sel.Label) 20 15 720 36)
  [void](Add-Control $d Label 'Existing High Rank augments only. Awakening and mixed-format records are excluded. This edit makes a backup and spends no materials.' 20 55 720 61)
  $choices=@();$names=@('None')
  for($i=1;$i -le 5;$i++){$names+=Get-CompanionEffectWords $script:EquipmentEffectNames.LegacyAugments.([string]$i) 'Names'}
  for($i=0;$i -lt [int]$profile.capacity;$i++){
   $combo=Add-Control $d ComboBox '' 20 (125+50*$i) 720 40
   $combo.DropDownStyle='DropDownList';[void]$combo.Items.AddRange([object[]]@($names|ForEach-Object {Get-QuestbookText $_}))
   $combo.SelectedIndex=[int]$profile.augments[$i];$choices+=@($combo)
  }
  $ok=Add-Control $d Button 'Preview Changes...' 20 305 460 38;$ok.DialogResult='OK'
  $no=Add-Control $d Button 'Cancel' 500 305 240 38;$no.DialogResult='Cancel';$d.CancelButton=$no
  Set-QuestbookTree $d
  if($d.ShowDialog($form) -ne [Windows.Forms.DialogResult]::OK){return}
  $values=@($choices|ForEach-Object {[int]$_.SelectedIndex}|Where-Object {$_ -gt 0})
 }finally{$d.Dispose()}
 if(-not $values.Count){throw 'Select at least one High Rank augment.'}
 while($values.Count -lt 3){$values+=0}
 if(($values -join ',') -eq ($profile.augments -join ',')){return}
 if(@($sel.Record.decos|Where-Object {$_ -ge 0}).Count -and @($values|Where-Object {$_ -eq 4}).Count -lt @($profile.augments|Where-Object {$_ -eq 4}).Count){throw 'Remove fitted jewels before reducing the Slot Upgrade level.'}
 $summary=@($sel.Label,'')
 for($i=0;$i -lt 3;$i++){$summary+=("{0}: {1} → {2}" -f ($i+1),$names[$profile.augments[$i]],$names[$values[$i]])}
 if(-not (Confirm-AdvancedEdit 'Review High Rank Augments' ($summary -join "`r`n"))){return}
 $active=Get-CompanionEquipmentSession
 if($active.Working -ne $working -or $active.Slot -ne $n){throw 'The selected character changed. Reopen the preview.'}
 if((Test-Path -LiteralPath $override) -and (Get-NativePcHash $override) -cne (Get-NativePcHash $stock)){throw 'The weapon table changed since the preview.'}
 $backup=New-AdvancedEditBackup $working $profile.source_hash
 $next=Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')
 $result=Invoke-CompanionAdvanced (@('legacy-apply',$working,[string]$n,[string]$index,[string]$profile.source_hash,$next)+@($values|ForEach-Object {[string]$_}))
 if(-not $result.verified_roundtrip -or [int]$result.slot -ne $n -or [int]$result.index -ne $index -or [int]$result.id -ne [int]$profile.id -or [int]$result.type -ne $type -or ($result.augments -join ',') -ne ($values -join ',')){throw 'Legacy augment output did not match the preview.'}
 Complete-CompanionEquipmentEdit $next
 [void][HuntersCompanion.Messages]::Show("Staged in the working copy. Use Save As to export.`r`n`r`nBackup: $backup",'Edit High Rank Augments')
}
$script:experimentalPayout=Add-Control $questTab Button 'Experimental Payouts...' 350 574 375 36
$script:experimentalPayout.Add_Click({Run-Action {Show-ExperimentalQuestPayout}})
$script:legacyAugments=Add-Control $eqtab Button 'Edit High Rank Augments...' 625 410 435 34
$script:legacyAugments.Enabled=$false
$script:legacyAugments.Add_Click({Run-Action {Show-CompanionLegacyAugments}})
