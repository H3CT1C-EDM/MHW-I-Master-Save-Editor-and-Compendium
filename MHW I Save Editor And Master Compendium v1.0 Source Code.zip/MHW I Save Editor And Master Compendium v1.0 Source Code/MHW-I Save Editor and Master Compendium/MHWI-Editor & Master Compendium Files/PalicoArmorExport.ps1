$script:ApateTablePath='equip/otomoArmor.oam_dat'
$script:ApateBaseSha='857E2F32CDABF42BA446DCC8277D301699297397C3578CAEA939FA96A82858DA'
$script:ApateTableSha='B02BBF8E5CF13757715FAA72034265014933BE4AFFBE3C2C4A66609F473347B9'
$script:ApateGameSha='C2EBBBD2C49F216D484E31A5219BED419EB1E5E7D206D02CBA040A3AB79D90EA'

function Write-PalicoArmorTable([string]$output) {
 $source=Join-Path $script:Root 'data/common/equip/otomoArmor.oam_dat'
 if((Get-NativePcHash $source) -ne $script:ApateBaseSha){throw 'The bundled vanilla Palico armor table did not pass verification.'}
 $data=[IO.File]::ReadAllBytes($source)
 for($row=0;$row -lt 323;$row++){
  $offset=10+42*$row
  if($data[$offset+8]){
   $low=(($row % 161) -lt 20) -or ($row -ge 52 -and $row -le 56) -or ($row -ge 61 -and $row -le 62)
   $data[$offset+8]=if($data[$offset+12] -ge 8){130}elseif($low){20}else{60}
  }
  for($j=27;$j -le 31;$j++){$data[$offset+$j]=2}
 }
 [IO.File]::WriteAllBytes($output,$data)
 if((Get-NativePcHash $output) -ne $script:ApateTableSha){throw 'The generated Palico armor table did not pass verification.'}
}

function Install-BuiltInPalicoArmor([string]$root) {
 Assert-GameClosed
 if((Get-NativePcHash (Join-Path $root 'MonsterHunterWorld.exe')) -ne $script:ApateGameSha){
  throw 'APATE was checked against the Steam 15.23.00 executable. The selected game does not match it.'
 }
 $relative=$script:ApateTablePath
 $target=Get-NativePcTarget $root $relative
 $before=Get-NativePcHash $target
 if($before -eq $script:ApateTableSha){return $false}
 if($before){throw 'A different Palico armor table is already installed. Nothing was replaced.'}
 $stage=New-NativePcStage $root
 try {
  $output=Join-Path $stage 'otomoArmor.oam_dat'
  Write-PalicoArmorTable $output
  [void](Install-NativePcTables $root @([pscustomobject]@{Relative=$relative;Before='';Stage=$output}))
  return $true
 }finally{Remove-Item -LiteralPath $stage -Recurse -Force}
}

function Show-ApateInstaller {
 Assert-GameClosed
 $root=Get-GameFolder
 $answer=[HuntersCompanion.Messages]::Show("Install the APATE-compatible Palico armor table in this game folder?`r`n$root",'Install Palico Armor (APATE)','OKCancel')
 if($answer -ne 'OK'){return}
 $installed=Install-BuiltInPalicoArmor $root
 $message=if($installed){'APATE installed. Restart the game and check the Palico armor stats.'}else{'APATE is already installed. No files were changed.'}
 [HuntersCompanion.Messages]::Show($message,'Install Palico Armor (APATE)')|Out-Null
}
