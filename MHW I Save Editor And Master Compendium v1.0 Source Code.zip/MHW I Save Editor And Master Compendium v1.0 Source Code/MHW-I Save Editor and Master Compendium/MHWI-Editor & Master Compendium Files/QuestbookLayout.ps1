﻿function Get-QuestbookContentBounds([double]$width){
    $marginScale=[Math]::Max(1.0,[Math]::Min(1.5,$width/1120.0))
    $left=[int][Math]::Round(42*$marginScale);$right=[int][Math]::Round($width-$left)
    return [pscustomobject]@{Left=$left;Right=$right;Width=$right-$left}
}

function Get-QuestbookBottomInset([int]$clientHeight){
    return [int][Math]::Max(31,[Math]::Min(48,[Math]::Ceiling($clientHeight*0.046)))
}
function Get-QuestbookLayoutRect($rect,[double]$width,[double]$height){
    $content=Get-QuestbookContentBounds ([Math]::Max(400,$width)+24)
    $sx=$content.Width/1045.0
    $sy=([Math]::Max(400,$height)-60)/591
    return [pscustomobject]@{
        X=[int][Math]::Round($content.Left-12+($rect.X-15)*$sx)
        Y=[int][Math]::Round(30+($rect.Y-15)*$sy)
        Width=[int][Math]::Round($rect.Width*$sx)
        Height=[int][Math]::Round($rect.Height*$sy)
        FontScale=[Math]::Max(1.0,[Math]::Min(1.5,[Math]::Min($sx,$sy)))
    }
}
function Get-QuestbookScaledFont([Drawing.Font]$font,[double]$scale){
    
    $scale=[Math]::Floor($scale*20)/20
    $key=$font.Name+'|'+$font.SizeInPoints+'|'+$font.Style+'|'+$scale
    if(-not $script:QuestbookScaledFonts.ContainsKey($key)){
        $new=[Drawing.Font]::new($font.FontFamily,[single]($font.SizeInPoints*$scale),$font.Style)
        $script:QuestbookScaledFonts[$key]=$new
        $script:QuestbookFonts.Add($new)
    }
    return $script:QuestbookScaledFonts[$key]
}
function Get-QuestbookChromeMetrics([double]$scale){
    $s=[Math]::Min(1.22,$scale)
    return [pscustomobject]@{HeaderTop=8;HeaderHeight=[int](54*$s);ToolbarTop=([int](54*$s)+14);ToolbarHeight=[int](30*$s);StatusTop=([int](84*$s)+16);StatusHeight=[int](24*$s);NavigationTop=([int](108*$s)+20);NavigationHeight=[int](39*$s)}
}
function Update-QuestbookParchment {
    $size=$form.ClientSize
    $title=$script:QuestbookHeader.Controls['CompanionHeadline']
    if($size.Width -lt 1 -or $size.Height -lt 1 -or -not $title){return}
    $rect=$title.Bounds;$rect.Offset($script:QuestbookHeader.Left,$script:QuestbookHeader.Top)
    $art=if($title -is [Windows.Forms.PictureBox] -and $title.Image){$title.Image.Size}else{[Drawing.Size]::new(390,56)}
    $key="$size|$rect|$art"
    if($script:QuestbookParchmentKey -eq $key){return}
    if(-not $script:QuestbookImages.ContainsKey('parchment-title-base')){
        $paper=Get-QuestbookImage 'questbook'
        if(-not $paper){return}
        $script:QuestbookImages['parchment-title-base']=[HuntersCompanion.HeaderParchment]::Prepare($paper,$true)
    }
    $old=$script:QuestbookImages['parchment-main']
    $bitmap=[HuntersCompanion.HeaderParchment]::Compose($script:QuestbookImages['parchment-title-base'],$size,$rect,$art)
    $form.BackgroundImage=$bitmap
    $script:QuestbookImages['parchment-main']=$bitmap
    $script:QuestbookParchmentKey=$key
    if($old){$old.Dispose()}
}
function Update-QuestbookLayout {
    if($script:QuestbookResizing -or $form.WindowState -eq 'Minimized'){return}
    $script:QuestbookResizing=$true
    $form.SuspendLayout()
    try {
        
        $width=[Math]::Max(900,$form.ClientSize.Width)
        $content=Get-QuestbookContentBounds $width;$contentLeft=$content.Left;$contentWidth=$content.Width;$contentRight=$content.Right;$toolbarScale=$contentWidth/1045.0
        $actualHeight=[int]$form.ClientSize.Height
        $height=[Math]::Max(1,$actualHeight)
        $bottomInset=Get-QuestbookBottomInset $actualHeight
        $scale=[Math]::Max(1.0,[Math]::Min(1.5,[Math]::Min($width/1120.0,$height/852.0)))
        $chrome=Get-QuestbookChromeMetrics $scale
        $chromeScale=[Math]::Min(1.22,$scale)
        $script:QuestbookHeader.SetBounds(0,$chrome.HeaderTop,$width,$chrome.HeaderHeight)
        foreach($entry in $script:QuestbookHeaderLayout){
            $r=$entry.Rect;$c=$entry.Control
            $c.Font=Get-QuestbookScaledFont $entry.Font $chromeScale
            $c.SetBounds([int]($r.X*$chromeScale),[int]($r.Y*$chromeScale),[int]($r.Width*$chromeScale),[int]($r.Height*$chromeScale))
        }
        foreach($entry in $script:QuestbookHeaderLayout){if($entry.Control.Name -in @('CompanionHeadline','CompanionSubtitle')){$entry.Control.Left=$contentLeft;$entry.Control.Width=$contentWidth}}
        $script:QuestbookEdition.Left=$contentRight-$script:QuestbookEdition.Width
        foreach($entry in $script:QuestbookRootLayout){
            $c=$entry.Control;$r=$entry.Rect
            $c.Font=Get-QuestbookScaledFont $entry.Font $chromeScale
            if($c -is [Windows.Forms.ComboBox]){$c.ItemHeight=[int](25*$chromeScale)}
            $rowTop=if($c -eq $status){$chrome.StatusTop}else{$chrome.ToolbarTop}
            $rowHeight=if($c -eq $status){$chrome.StatusHeight}else{$chrome.ToolbarHeight}
            $c.SetBounds([int]($contentLeft+($r.X-15)*$toolbarScale),$rowTop,[int]($r.Width*$toolbarScale),$rowHeight)
            if($c -is [Windows.Forms.ComboBox]){$c.Top+=[int][Math]::Floor(($rowHeight-$c.Height)/2.0)}
        }
        $optionsButton.SetBounds($contentRight-[int](123*$chromeScale),$chrome.ToolbarTop,[int](123*$chromeScale),$open.Height)
        $slot.Width=[Math]::Max(120,$optionsButton.Left-$slot.Left-10)
        $status.Left=$contentLeft;$status.Width=$contentWidth
        $top=$chrome.NavigationTop;$navHeight=$chrome.NavigationHeight
        $script:QuestbookNavigation.SetBounds($contentLeft,$top,$contentWidth,$navHeight)
        $script:QuestbookPageHost.SetBounds(12,$top+$navHeight,$width-24,[Math]::Max(1,$height-$top-$navHeight-12))
        $tabs.Font=Get-QuestbookScaledFont $script:QuestbookBold $scale
        $tabs.ItemSize=[Drawing.Size]::new(200,$navHeight)
        
        $tabs.SetBounds(0,0,$script:QuestbookPageHost.Width,$script:QuestbookPageHost.Height)
        $display=$tabs.DisplayRectangle
        $left=$display.X;$upper=$display.Y
        $right=$tabs.ClientSize.Width-$display.Right;$bottom=$tabs.ClientSize.Height-$display.Bottom
        $tabs.SetBounds(-$left,-$upper,$script:QuestbookPageHost.Width+$left+$right,$script:QuestbookPageHost.Height+$upper+$bottom)
        $script:QuestbookNavigationScale=$chromeScale;Update-QuestbookNavigation $chromeScale
        foreach($entry in $script:QuestbookPageLayout){
            $c=$entry.Control;$parent=$c.Parent
            if($c -eq $script:GuideBrowser){
                $usableHeight=[Math]::Min($tabs.DisplayRectangle.Height,$height-$top-$navHeight)
                $c.SetBounds($contentLeft-12,0,$contentWidth,[Math]::Max(1,$usableHeight-$bottomInset));continue
            }
            $r=Get-QuestbookLayoutRect $entry.Rect $tabs.DisplayRectangle.Width $tabs.DisplayRectangle.Height
            $fontScale=$r.FontScale
            $compact=($parent -eq $inv -and $entry.Rect.Y -lt 290)
            if($compact){
                $r.Y=30+[int][Math]::Round(($r.Y-30)*0.77)
                $r.Height=[Math]::Max(24,[int][Math]::Round($r.Height*0.76))
                $fontScale=[Math]::Min(1.07,$fontScale)
            }elseif($c -eq $box){
                $reclaimed=[int][Math]::Round(($r.Y-30)*0.23)
                $r.Y-=$reclaimed;$r.Height+=$reclaimed
            }
            $c.Font=Get-QuestbookScaledFont $entry.Font $fontScale
            if($c -is [Windows.Forms.ComboBox]){$c.ItemHeight=if($compact){[int](21*$fontScale)}else{[int](28*$fontScale)}}
            if($c -is [Windows.Forms.TextBox] -and -not $c.Multiline){$c.AutoSize=$true}
            $c.SetBounds($r.X,$r.Y,$r.Width,$(if($c -is [Windows.Forms.Button]){[Math]::Max($(if($compact){24}else{30}),$r.Height)}else{$r.Height}))
            
            if($c -is [Windows.Forms.ComboBox] -or $c -is [Windows.Forms.NumericUpDown] -or ($c -is [Windows.Forms.TextBox] -and -not $c.Multiline)){
                $c.Top=$r.Y+[int][Math]::Floor(($r.Height-$c.Height)/2.0)
            }
            if($c -is [Windows.Forms.ListView] -or $c -is [HuntersCompanion.ParchmentText] -or ($c -is [Windows.Forms.TextBox] -and $c.Multiline)){
                $paneBottom=[Math]::Min($parent.ClientSize.Height,$height-$top-$navHeight)-$bottomInset
                $c.Height=[Math]::Min($c.Height,[Math]::Max(1,$paneBottom-$c.Top))
            }
            if($c -is [Windows.Forms.ListView] -and $entry.Columns.Count){
                $usable=[Math]::Max(1,$c.ClientSize.Width-[Windows.Forms.SystemInformation]::VerticalScrollBarWidth-2)
                $sum=($entry.Columns | Measure-Object -Sum).Sum
                $used=0
                for($i=0;$i -lt $entry.Columns.Count;$i++){
                    $colWidth=if($i -eq $entry.Columns.Count-1){$usable-$used}else{[int][Math]::Floor($usable*$entry.Columns[$i]/$sum)}
                    $c.Columns[$i].Width=[Math]::Max(30,$colWidth);$used+=$colWidth
                }
            }
        }
        if($harvestVersion -and $bridgeInstall){$harvestVersion.Top=$bridgeInstall.Top+[int][Math]::Floor(($bridgeInstall.Height-$harvestVersion.Height)/2)}
        Update-QuestbookParchment
        Update-CompanionGuideBackground
        $script:QuestbookPageHost.Invalidate()
    }finally{$form.ResumeLayout($true);$script:QuestbookResizing=$false}
}
function Initialize-QuestbookLayout($header,$edition){
    $script:QuestbookHeader=$header;$script:QuestbookEdition=$edition
    $script:QuestbookScaledFonts=@{};$script:QuestbookPageLayout=@();$script:QuestbookRootLayout=@()
    $script:QuestbookResizing=$false
    $script:QuestbookHeaderLayout=@()
    foreach($c in $header.Controls){$script:QuestbookHeaderLayout+=@([pscustomobject]@{Control=$c;Rect=$c.Bounds;Font=[HuntersCompanion.ButtonTextFit]::Preferred($c)})}
    $form.AutoScaleMode='None'
    $form.AutoScroll=$false;$form.AutoScrollMinSize=[Drawing.Size]::Empty
    $tabs.BackColor=$script:QuestbookColors.Paper
    Initialize-QuestbookNavigation
    
    $qty.Width=70
    foreach($c in @($open,$save,$undo,$slot,$status,$optionsButton)){
        $script:QuestbookRootLayout+=@([pscustomobject]@{Control=$c;Rect=$c.Bounds;Font=[HuntersCompanion.ButtonTextFit]::Preferred($c)})
    }
    foreach($page in $tabs.TabPages){
        foreach($c in $page.Controls){
            $columns=@();if($c -is [Windows.Forms.ListView]){$columns=@($c.Columns | ForEach-Object {$_.Width})}
            $script:QuestbookPageLayout+=@([pscustomobject]@{Control=$c;Rect=$c.Bounds;Font=[HuntersCompanion.ButtonTextFit]::Preferred($c);Columns=$columns})
        }
    }
    $script:QuestbookResizeTimer=[Windows.Forms.Timer]::new();$script:QuestbookResizeTimer.Interval=80
    $script:QuestbookResizeTimer.Add_Tick({$script:QuestbookResizeTimer.Stop();Update-QuestbookLayout;$form.Invalidate($true)})
    $form.Add_ClientSizeChanged({$script:QuestbookResizeTimer.Stop();if($form.WindowState -ne 'Minimized'){$script:QuestbookResizeTimer.Start()}})
    $form.Add_FormClosed({$script:QuestbookResizeTimer.Dispose()})
    $tabs.Add_SelectedIndexChanged({
        if($script:QuestbookNavigation){Update-QuestbookNavigation $script:QuestbookNavigationScale;$script:QuestbookNavigation.Invalidate($true)}
        if($tabs.SelectedTab){$tabs.SelectedTab.Invalidate($true)}
    })
    $form.Add_Shown({Update-QuestbookLayout})
    Update-QuestbookLayout
}
function Get-QuestbookDialogRect($rect,[double]$baseWidth,[double]$baseHeight,[double]$width,[double]$height){
    $sx=($width-30)/($baseWidth-30);$sy=($height-30)/($baseHeight-30)
    return [pscustomobject]@{X=[int][Math]::Round(15+($rect.X-15)*$sx);Y=[int][Math]::Round(15+($rect.Y-15)*$sy);Width=[int][Math]::Round($rect.Width*$sx);Height=[int][Math]::Round($rect.Height*$sy);Scale=[Math]::Max(1.0,[Math]::Min(1.35,[Math]::Min($sx,$sy)))}
}
function Initialize-QuestbookDialog($dialog){
    if([object]::ReferenceEquals($dialog,$form)){return}
    $dialog.AutoScaleMode='None'
    try{[Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'Instance,NonPublic').SetValue($dialog,$true,$null)}catch{}
    $dialog.Add_Shown({param($sender,$event)
        $sender.MinimumSize=$sender.Size
        $state=[pscustomobject]@{Form=$sender;Width=$sender.ClientSize.Width;Height=$sender.ClientSize.Height;Entries=@();Busy=$false}
        foreach($child in $sender.Controls){
            $columns=@();if($child -is [Windows.Forms.ListView]){$columns=@($child.Columns|ForEach-Object{$_.Width})}
            $state.Entries+=@([pscustomobject]@{Control=$child;Rect=$child.Bounds;Font=[HuntersCompanion.ButtonTextFit]::Preferred($child);Columns=$columns});$child.Anchor='Top,Left'
        }
        $timer=[Windows.Forms.Timer]::new();$timer.Interval=80
        $timer.Add_Tick({
            $timer.Stop();if($state.Busy -or $state.Form.IsDisposed -or $state.Form.WindowState -eq 'Minimized'){return};$state.Busy=$true;$state.Form.SuspendLayout()
            try{
                foreach($entry in $state.Entries){
                    $c=$entry.Control;$r=Get-QuestbookDialogRect $entry.Rect $state.Width $state.Height $state.Form.ClientSize.Width $state.Form.ClientSize.Height
                    $c.Font=Get-QuestbookScaledFont $entry.Font $r.Scale;$c.SetBounds($r.X,$r.Y,$r.Width,$(if($c -is [Windows.Forms.Button]){[Math]::Max($(if($compact){24}else{30}),$r.Height)}else{$r.Height}))
                    if($c -is [Windows.Forms.ComboBox] -or $c -is [Windows.Forms.NumericUpDown] -or ($c -is [Windows.Forms.TextBox] -and -not $c.Multiline)){$c.Top=$r.Y+[int](($r.Height-$c.Height)/2)}
                    if($entry.Columns.Count){$sum=($entry.Columns|Measure-Object -Sum).Sum;$available=[Math]::Max(1,$c.ClientSize.Width-20);$used=0;for($i=0;$i -lt $entry.Columns.Count;$i++){$v=if($i -eq $entry.Columns.Count-1){$available-$used}else{[int]($available*$entry.Columns[$i]/$sum)};$c.Columns[$i].Width=[Math]::Max(20,$v);$used+=$v}}
                }
            }finally{$state.Form.ResumeLayout($true);$state.Form.Invalidate($true);$state.Busy=$false}
        }.GetNewClosure())
        $sender.Add_ClientSizeChanged({$timer.Stop();$timer.Start()}.GetNewClosure())
        $sender.Add_FormClosed({$timer.Dispose()}.GetNewClosure())
    })
}
