function Get-NativePcTarget([string]$root,[string]$relative) {
 if($relative -notmatch '^(?:item/skillGemParam\.sgpa|equip/otomoArmor\.oam_dat|equip/new_limit_break\.(?:new_lb|new_lbr)|equip/[a-zA-Z0-9_]+\.(?:am_dat|wp_dat|wp_dat_g))$'){throw 'Unexpected nativePC file path.'}
 $path=$root
 $parts=@('nativePC','common')+($relative -split '/')
 foreach($part in $parts){
  $path=Join-Path $path $part
  $item=Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
  if($item -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "The mod destination contains a link: $path"}
 }
 return $path
}
function Get-NativePcHash([string]$path) {
 if(Test-Path -LiteralPath $path -PathType Leaf){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
 if(Test-Path -LiteralPath $path){throw "Expected a file: $path"}
 return ''
}
function Install-NativePcTables([string]$root,$changes) {
 Assert-GameClosed
 $backupRoot=Join-Path $root ('QuestbookBackups/nativePC-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N').Substring(0,8))
 $committed=[Collections.Generic.List[object]]::new()
 try {
  foreach($c in $changes){
   $target=Get-NativePcTarget $root $c.Relative
   if((Get-NativePcHash $target) -ne $c.Before){throw "The installed table changed during preparation: $($c.Relative)"}
   if(-not (Get-NativePcHash $c.Stage)){throw "Missing prepared table: $($c.Relative)"}
  }
  foreach($c in $changes){
   $target=Get-NativePcTarget $root $c.Relative
   if((Get-NativePcHash $target) -ne $c.Before){throw "The installed table changed during installation: $($c.Relative)"}
   $expected=Get-NativePcHash $c.Stage
   if($expected -eq $c.Before){continue}
   [void][IO.Directory]::CreateDirectory((Split-Path -Parent $target))
   $backup=Join-Path $backupRoot $c.Relative
   if($c.Before){
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $backup))
    [IO.File]::Replace($c.Stage,$target,$backup)
   }else{[IO.File]::Move($c.Stage,$target)}
   $committed.Add([pscustomobject]@{Target=$target;Backup=$backup;Before=$c.Before})
   if((Get-NativePcHash $target) -ne $expected){throw "Installed table verification failed: $($c.Relative)"}
  }
 }catch{
  $failure=$_
  for($i=$committed.Count-1;$i -ge 0;$i--){
   $c=$committed[$i]
   if($c.Before){[IO.File]::Copy($c.Backup,$c.Target,$true)}else{[IO.File]::Delete($c.Target)}
  }
  throw $failure
 }
 return $backupRoot
}
function New-NativePcStage([string]$root) {
 $dir=Join-Path $root ('.questbook-stage-'+[guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($dir)
 return $dir
}
function Install-AnyJewel {
 Assert-GameClosed;$root=Get-GameFolder
 $answer=[HuntersCompanion.Messages]::Show("Install Any Jewel Fits into this game's nativePC folder?`r`n$root",'Install Any Jewel Fits','OKCancel')
 if($answer -ne 'OK'){return}
 $stage=New-NativePcStage $root
 try{
  $relative='item/skillGemParam.sgpa';$target=Get-NativePcTarget $root $relative
  $before=Get-NativePcHash $target;$output=Get-NativePcTarget $stage $relative
  if($before){[void][IO.Directory]::CreateDirectory((Split-Path -Parent $output));[IO.File]::Copy($target,$output,$false)}
  [void](Invoke-Engine -Arguments @('export-any',$stage))
  $backup=Install-NativePcTables $root @([pscustomobject]@{Relative=$relative;Before=$before;Stage=$output})
  Show-NativePcInstalled $root $backup
 }finally{Remove-Item -LiteralPath $stage -Recurse -Force}
}
function Show-NativePcInstalled([string]$root,[string]$backup) {
 $text="Installed in $(Join-Path $root 'nativePC'). Restart Monster Hunter: World to load the changes."
 if(Test-Path -LiteralPath $backup){$text+="`r`nPrevious files: $backup"}
 [HuntersCompanion.Messages]::Show($text,'Game data installed')|Out-Null
}
