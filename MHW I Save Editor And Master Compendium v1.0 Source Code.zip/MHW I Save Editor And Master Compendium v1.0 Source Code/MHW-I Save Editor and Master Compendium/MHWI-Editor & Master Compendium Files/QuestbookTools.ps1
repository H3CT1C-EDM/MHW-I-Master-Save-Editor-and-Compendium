﻿$script:JournalRefreshTimer=[Windows.Forms.Timer]::new();$script:JournalRefreshTimer.Interval=160
$script:JournalSaveTimer=[Windows.Forms.Timer]::new();$script:JournalSaveTimer.Interval=450
$script:JournalRefreshTimer.Add_Tick({$script:JournalRefreshTimer.Stop();Run-Action {Fill-Catalog;Request-JournalSave}})
$script:JournalSaveTimer.Add_Tick({$script:JournalSaveTimer.Stop();Save-JournalPreferences})
function Request-JournalRefresh {if($script:JournalInitializing){return};$script:JournalRefreshTimer.Stop();$script:JournalRefreshTimer.Start()}
function Request-JournalSave {if($script:JournalInitializing){return};$script:JournalSaveTimer.Stop();$script:JournalSaveTimer.Start()}
$script:ToolSettingsPath=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\options.json'
$script:ToolSettings=@{Language='en';GamePath='';Hotkey='F10';PauseKey='F11'}
if(Test-Path -LiteralPath $script:ToolSettingsPath){try{$v=Get-Content -LiteralPath $script:ToolSettingsPath -Raw -Encoding UTF8|ConvertFrom-Json;foreach($k in @('Language','GamePath','Hotkey','PauseKey','QuestClearKey')){if($v.$k){$script:ToolSettings[$k]=[string]$v.$k}};if($v.Harvest){$script:ToolSettings['Harvest']=$v.Harvest}}catch{}}
function Save-ToolSettings {
 $dir=Split-Path -Parent $script:ToolSettingsPath;[void][IO.Directory]::CreateDirectory($dir)
 $tmp=$script:ToolSettingsPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 [IO.File]::WriteAllText($tmp,($script:ToolSettings|ConvertTo-Json),[Text.Encoding]::UTF8)
 if(Test-Path -LiteralPath $script:ToolSettingsPath){[IO.File]::Replace($tmp,$script:ToolSettingsPath,$script:ToolSettingsPath+'.bak')}else{[IO.File]::Move($tmp,$script:ToolSettingsPath)}
}
function Find-GameFolder {
 $candidates=[Collections.Generic.List[string]]::new()
 if($script:ToolSettings.GamePath){$candidates.Add($script:ToolSettings.GamePath)}
 try{
  $steam=(Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
  $candidates.Add((Join-Path $steam 'steamapps\common\Monster Hunter World'))
  $vdf=Join-Path $steam 'steamapps\libraryfolders.vdf'
  if(Test-Path -LiteralPath $vdf){foreach($m in [regex]::Matches([IO.File]::ReadAllText($vdf),'"path"\s*"([^"]+)"')){$candidates.Add((Join-Path ($m.Groups[1].Value.Replace('\\','\')) 'steamapps\common\Monster Hunter World'))}}
 }catch{}
 foreach($path in $candidates){if(Test-Path -LiteralPath (Join-Path $path 'MonsterHunterWorld.exe')){return [IO.Path]::GetFullPath($path)}}
 return ''
}
function Get-GameFolder {
 param([switch]$RequireLoader)
 $path=$gamePath.Text.Trim()
 if(-not $path -or -not (Test-Path -LiteralPath (Join-Path $path 'MonsterHunterWorld.exe') -PathType Leaf)){throw 'Choose the folder containing MonsterHunterWorld.exe.'}
 if($RequireLoader -and -not (Test-Path -LiteralPath (Join-Path $path 'AsteraLoader\AsteraLoader.dll'))){throw 'Astera Loader is not installed in the selected game folder.'}
 return [IO.Path]::GetFullPath($path)
}
function Assert-GameClosed {if(Get-Process MonsterHunterWorld -ErrorAction SilentlyContinue){throw 'Close Monster Hunter: World before installing or changing game files.'}}
function Write-VerifiedPlugin([string]$source,[string]$destination) {
 $dir=Split-Path -Parent $destination;[void][IO.Directory]::CreateDirectory($dir)
 $tmp=Join-Path $dir ([guid]::NewGuid().ToString('N')+'.tmp')
 try{
  [IO.File]::Copy($source,$tmp,$false)
  if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $tmp -Algorithm SHA256).Hash){throw 'The copied plugin failed verification.'}
  if(Test-Path -LiteralPath $destination){
   $backup=Join-Path (Split-Path -Parent (Split-Path -Parent $dir)) ('QuestbookBackups\'+[guid]::NewGuid().ToString('N'))
   [void][IO.Directory]::CreateDirectory($backup)
   [IO.File]::Replace($tmp,$destination,(Join-Path $backup ([IO.Path]::GetFileName($destination))))
  }else{[IO.File]::Move($tmp,$destination)}
 }finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp -Force}}
}
function Install-AccountBridge {
 Assert-GameClosed;$root=Get-GameFolder -RequireLoader;$folder=Join-Path $root 'AsteraLoader\plugins\mhwi_account_bridge'
 $bad=Join-Path $root 'AsteraLoader\plugins\AccountBridge'
 if(Test-Path -LiteralPath $bad){
  $backup=Join-Path $root ('AsteraLoader\QuestbookBackups\AccountBridge-'+[guid]::NewGuid().ToString('N'))
  [void][IO.Directory]::CreateDirectory((Split-Path -Parent $backup));[IO.Directory]::Move($bad,$backup)
 }
 Write-VerifiedPlugin (Join-Path $script:Root 'AccountBridge\mhwi_account_bridge.dll') (Join-Path $folder 'mhwi_account_bridge.dll')
 [IO.File]::WriteAllText((Join-Path $folder 'AccountBridge.ini'),"[AccountBridge]`r`nHotkey=$($bridgeKey.SelectedItem)`r`n",[Text.Encoding]::ASCII)
 $script:ToolSettings.GamePath=$root;$script:ToolSettings.Hotkey=[string]$bridgeKey.SelectedItem;Save-ToolSettings
 [HuntersCompanion.Messages]::Show((Get-QuestbookText 'Account Bridge Installed')+(Format-QuestbookText '
{0}
{1}' @(($folder),($($bridgeKey.SelectedItem)))),'MHWI Questbook')|Out-Null
}
function Install-FieldHarvest {
 Assert-GameClosed;$root=Get-GameFolder -RequireLoader
 $name=if($harvestVersion.SelectedIndex -eq 0){'fieldharvest_selected'}else{'fieldharvest_field'}
 $other=if($name -eq 'fieldharvest_selected'){'fieldharvest_field'}else{'fieldharvest_selected'}
 $otherPath=Join-Path $root ('AsteraLoader\plugins\'+$other)
 if(Test-Path -LiteralPath $otherPath){$backup=Join-Path $root ('AsteraLoader\QuestbookBackups\'+$other+'-'+[guid]::NewGuid().ToString('N'));[void][IO.Directory]::CreateDirectory((Split-Path -Parent $backup));[IO.Directory]::Move($otherPath,$backup)}
 $folder=Join-Path $root ('AsteraLoader\plugins\'+$name)
 Write-VerifiedPlugin (Join-Path $script:Root ("plugins\$name\$name.dll")) (Join-Path $folder ($name+'.dll'))
 $ini="[FieldHarvest]`r`nEnabled=1`r`nCollectionRadiusUnits=$([int]$harvestRadius.Value)`r`nMaxTargets=$([int]$harvestTargets.Value)`r`nCommitsPerFrame=$([int]$harvestCommits.Value)`r`nBatchTimeoutSeconds=$([int]$harvestTimeout.Value)`r`nCollectFish=$([int]$harvestFish.Checked)`r`nCollectWildlife=$([int]$harvestWildlife.Checked)`r`nCollectTracks=$([int]$harvestTracks.Checked)`r`n"
 $config=Join-Path $folder 'FieldHarvest.ini'
 if(Test-Path -LiteralPath $config){[IO.File]::Copy($config,$config+'.bak',$true)}
 [IO.File]::WriteAllText($config,$ini,[Text.Encoding]::ASCII)
 $script:ToolSettings.GamePath=$root;$script:ToolSettings['Harvest']=@{Variant=$harvestVersion.SelectedIndex;Radius=[int]$harvestRadius.Value;Targets=[int]$harvestTargets.Value;Commits=[int]$harvestCommits.Value;Timeout=[int]$harvestTimeout.Value;Fish=$harvestFish.Checked;Wildlife=$harvestWildlife.Checked;Tracks=$harvestTracks.Checked};Save-ToolSettings
 [HuntersCompanion.Messages]::Show((Get-QuestbookText 'FieldHarvest Installed')+(Format-QuestbookText '
{0}' @(($folder))),'MHWI Questbook')|Out-Null
}
function Publish-CompanionBridgeRequest([string]$folder,[string]$request){
 $destination=Join-Path $folder 'request.txt'
 if(Test-Path -LiteralPath $destination){throw 'A bridge request is already waiting. Check Account Request Status and finish that request first.'}
 $temporary=Join-Path $folder ('.questbook-'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $bytes=[Text.Encoding]::ASCII.GetBytes($request+"`r`n")
  $file=[IO.File]::Open($temporary,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
  try{$file.Write($bytes,0,$bytes.Length);$file.Flush($true)}finally{$file.Dispose()}
  try{[IO.File]::Move($temporary,$destination)}
  catch{if(Test-Path -LiteralPath $destination){throw 'A bridge request is already waiting. Check Account Request Status and finish that request first.'};throw}
 }finally{if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Force}}
}
function Get-QuestUnlockResults([string]$folder,[long]$questId,[int]$slotNumber){
 foreach($file in Get-ChildItem -LiteralPath $folder -Filter '*.quest-unlock-result.txt' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending){
  if($file.Length -gt 65536){continue}
  try{
   $raw=[IO.File]::ReadAllText($file.FullName);$fields=ConvertFrom-StringData $raw
   if([string]$fields.quest_id -ne [string]$questId -or [string]$fields.slot -ne [string]$slotNumber){continue}
   [pscustomobject]@{Name=$file.Name;Written=$file.LastWriteTime;Fields=$fields}
  }catch{continue}
 }
}
function Show-QuestUnlockStatus($quest) {
 if(-not (Get-QuestBenefit $quest)){throw 'Select one of the supported base-game ingredient quests.'}
 $current=Current-Slot
 $folder=Join-Path (Get-GameFolder -RequireLoader) 'AsteraLoader\plugins\mhwi_account_bridge'
 if(-not (Test-Path -LiteralPath $folder -PathType Container)){throw 'Install the updated account bridge in Game Data Exports first.'}
 $matches=@(Get-QuestUnlockResults $folder $quest.Id $current.number | Select-Object -First 8)
 $lines=[Collections.Generic.List[string]]::new()
 $lines.Add("$($quest.Name) [ID $($quest.Id)] | Slot $($current.number)")
 $pending=Join-Path $folder 'request.txt'
 if(Test-Path -LiteralPath $pending -PathType Leaf){
  try{$queued=[IO.File]::ReadAllText($pending).Trim();if($queued -eq "MHWI_QUEST_UNLOCK_V1 $($current.number) $($quest.Id)"){$lines.Add('This quest request is waiting for the configured in-game hotkey.')}else{$lines.Add('A different bridge request is pending.')}}catch{$lines.Add('A bridge request is pending.')}
 }
 if(-not $matches.Count){$lines.Add('No matching quest unlock result was found.')}
 foreach($report in $matches){
  $data=$report.Fields
  $result=if($data.quest_unlock_verified -ne '1'){'Bridge verification not reported'}elseif($data.ingredient_unlocked_before -eq '0' -and $data.ingredient_unlocked_after -eq '1'){'Ingredient changed from locked to unlocked'}elseif($data.ingredient_unlocked_before -eq '1' -and $data.ingredient_unlocked_after -eq '1'){'Ingredient was already unlocked; no change'}else{'Bridge result recorded'}
  $lines.Add("$($report.Written.ToString('g')) — $result")
  $lines.Add($report.Name)
 }
 $lines.Add('These are bridge results, not reload verification. Return normally, save, reload, and check the canteen.')
 [HuntersCompanion.Messages]::Show(($lines -join "`r`n"),(Get-QuestbookText 'Quest Unlock Status'),'OK','Information')|Out-Null
}
function Show-AccountStatus {
 $root=Get-GameFolder -RequireLoader;$folder=Join-Path $root 'AsteraLoader\plugins\mhwi_account_bridge'
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Account Request Status';$dialog.ClientSize=[Drawing.Size]::new(870,650)
  [void](Add-Control $dialog Label 'Queue a request, load the same character in a solo expedition, and press the configured account key once. Check the newest matching item/quantity/slot result below. Native calls returned is not save verification: return normally, save, reload, then check the reward in-game.' 15 15 840 105)
  $text=Add-Control $dialog TextBox '' 15 130 840 435;$text.Multiline=$true;$text.ReadOnly=$true;$text.ScrollBars='Both';$text.TextAlign='Left';$text.Anchor='Top,Bottom,Left,Right'
  $lines=[Collections.Generic.List[string]]::new();$lines.Add($folder)
  $statusPath=Join-Path $folder 'status.txt';if(Test-Path -LiteralPath $statusPath){$lines.Add([IO.File]::ReadAllText($statusPath))}
  $summary=Get-ChildItem -LiteralPath $folder -Filter '*.batch-completed.txt' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1
  if($summary){$lines.Add([IO.File]::ReadAllText($summary.FullName))}
  $unlock=Get-ChildItem -LiteralPath $folder -Filter '*.unlock-result.txt' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1
  if($unlock){$lines.Add($unlock.Name+"`r`n"+[IO.File]::ReadAllText($unlock.FullName))}
  $questReport=Get-ChildItem -LiteralPath $folder -Filter '*.quest-unlock-result.txt' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 1
  if($questReport){$lines.Add($questReport.Name+"`r`n"+[IO.File]::ReadAllText($questReport.FullName))}
  $reports=@(Get-ChildItem -LiteralPath $folder -Filter '*.result.txt' -ErrorAction SilentlyContinue|Sort-Object LastWriteTime -Descending|Select-Object -First 10)
  if(-not $reports.Count){$lines.Add((Get-QuestbookText 'No completed account requests were found.'))}
  foreach($file in $reports){
   $raw=[IO.File]::ReadAllText($file.FullName);$fields=ConvertFrom-StringData $raw
   $lines.Add((Format-QuestbookText '{0}
{1}: {2} | {3}: {4} | {5}: {6}
{7}: {8}
{9}: {10} -> {11}
{12}: {13} -> {14}
{15} | {16}

{17}' @(($($file.Name)),($(Get-QuestbookText 'Item')),($($fields.item)),($(Get-QuestbookText 'Amount')),($($fields.amount)),($(Get-QuestbookText 'Slot')),($($fields.slot)),($(Get-QuestbookText 'Native Calls Returned')),($($fields.native_calls_returned)),($(Get-QuestbookText 'Queue')),($($fields.queue_before)),($($fields.queue_after)),($(Get-QuestbookText 'Captures')),($($fields.captures_before)),($($fields.captures_after)),($($fields.receipt_path)),($($fields.hotkey)),($raw))))
  }
  if(Test-Path -LiteralPath (Join-Path $folder 'request.txt')){$lines.Add((Get-QuestbookText 'A request is waiting for the in-game hotkey.'))}
  $text.Text=$lines -join "`r`n`r`n"
  $openFolder=Add-Control $dialog Button (Get-QuestbookText 'Open Journal Folder') 15 595 260 36;$openFolder.Anchor='Bottom,Left';$openFolder.Add_Click({if(Test-Path -LiteralPath $folder){[Diagnostics.Process]::Start('explorer.exe',$folder)|Out-Null}}.GetNewClosure())
  $close=Add-Control $dialog Button (Get-QuestbookText 'Close') 595 595 260 36;$close.DialogResult='OK';$close.Anchor='Bottom,Right'
  $how=Add-Control $dialog Button 'How to Use' 305 595 260 36;$how.Add_Click({Show-CompanionTutorial 'account'})
  Set-QuestbookTree $dialog;$text.TextAlign='Left';[void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
$script:WeaponEdits=[Collections.Specialized.OrderedDictionary]::new()
function Add-WeaponSlotEdit {
 if(-not $equipList.SelectedItem -or [int]$equipList.SelectedItem.Record.category -ne 1){throw 'Select a weapon first.'}
 $e=$equipList.SelectedItem;$key="$($e.Record.type):$($e.Record.id)";$values=@($sizeSpins|ForEach-Object{[int]$_.Value})
 $script:WeaponEdits[$key]=[pscustomobject]@{Type=[int]$e.Record.type;Id=[int]$e.Record.id;Name=[string]$e.Meta.Name;Sizes=$values}
 $weaponQueue.Text='Review Weapon Edits'+(Format-QuestbookText ' ({0})' @(($($script:WeaponEdits.Count))))
}
. (Join-Path $script:Root 'NativePcInstall.ps1')
function Export-WeaponBatch($edits) {
 Assert-GameClosed;$root=Get-GameFolder;$stage=New-NativePcStage $root
 $before=@{}
 try{
  $equip=Join-Path $root 'nativePC/common/equip'
  if(Test-Path -LiteralPath $equip){
   foreach($file in Get-ChildItem -LiteralPath $equip -File | Where-Object {$_.Extension -in @('.wp_dat','.wp_dat_g')}){
    $rel='equip/'+$file.Name;$target=Get-NativePcTarget $root $rel;$before[$rel]=Get-NativePcHash $target;$out=Get-NativePcTarget $stage $rel
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $out));[IO.File]::Copy($target,$out,$false)
   }
  }
  foreach($edit in $edits){[void](Invoke-Engine -Arguments @('export-slots',$stage,[string]$edit.Type,[string]$edit.Id,[string]$edit.Sizes[0],[string]$edit.Sizes[1],[string]$edit.Sizes[2]))}
  $changes=@(Get-ChildItem -LiteralPath (Join-Path $stage 'nativePC/common/equip') -File | Where-Object {$_.Extension -in @('.wp_dat','.wp_dat_g')} | ForEach-Object {
   $rel='equip/'+$_.Name
   [pscustomobject]@{Relative=$rel;Before=[string]$before[$rel];Stage=$_.FullName}
  })
  $backup=Install-NativePcTables $root $changes
  Show-NativePcInstalled $root $backup
 }finally{Remove-Item -LiteralPath $stage -Recurse -Force}
}
function Show-WeaponEdits {
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Review Weapon Edits';$dialog.ClientSize=[Drawing.Size]::new(850,530)
  $rows=Add-Control $dialog ListView '' 15 15 820 425;$rows.View='Details';$rows.FullRowSelect=$true;$rows.MultiSelect=$true;$rows.Anchor='Top,Bottom,Left,Right'
  [void]$rows.Columns.Add((Get-QuestbookText 'Weapon'),540);[void]$rows.Columns.Add((Get-QuestbookText 'Slot Levels'),230)
  foreach($key in $script:WeaponEdits.Keys){$v=$script:WeaponEdits[$key];$row=[Windows.Forms.ListViewItem]::new($v.Name+" [ID $($v.Id)]");[void]$row.SubItems.Add(($v.Sizes -join ' / '));$row.Tag=$key;[void]$rows.Items.Add($row)}
  $queue=$script:WeaponEdits
  $removeRows=Add-Control $dialog Button (Get-QuestbookText 'Remove Selected') 15 460 240 38;$removeRows.Add_Click({foreach($row in @($rows.SelectedItems)){$queue.Remove($row.Tag);$rows.Items.Remove($row)};$weaponQueue.Text='Review Weapon Edits'+(Format-QuestbookText ' ({0})' @(($($queue.Count))))}.GetNewClosure())
  $export=Add-Control $dialog Button (Get-QuestbookText 'Install All Weapon Edits') 485 460 350 38
  $export.Add_Click({Run-Action {if(-not $queue.Count){throw 'Queue at least one weapon edit first.'};Export-WeaponBatch @($queue.Values);$queue.Clear();$rows.Items.Clear();$weaponQueue.Text=Get-QuestbookText 'Review Weapon Edits'}}.GetNewClosure())
  Set-QuestbookTree $dialog;Enable-QuestbookList $rows;[void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
$slotExport.Text='Queue Weapon Slot Edit'
$weaponQueue=Add-Control $eqtab Button 'Review Weapon Edits' 530 365 300 38;$weaponQueue.Add_Click({Run-Action {Show-WeaponEdits}})
$optionsButton=Add-Control $form Button 'Options' 950 12 145 32
foreach($c in @($modtab.Controls)){if($c -is [Windows.Forms.Label]){$modtab.Controls.Remove($c);$c.Dispose()}}
$anyExport.SetBounds(15,72,335,40)
. (Join-Path $script:Root 'EquipmentSlotExport.ps1')
$maximumSlotsExport=Add-Control $modtab Button 'Install Maximum Decoration Slots' 365 72 340 40
$maximumSlotsExport.Add_Click({Run-Action {Export-MaximumDecorationSlots}})
. (Join-Path $script:Root 'PalicoArmorExport.ps1')
$apateInstall=Add-Control $modtab Button 'Install Palico Armor (APATE)' 720 72 340 40
$apateInstall.Add_Click({Run-Action {Show-ApateInstaller}})
$script:QuestbookTips.SetToolTip($apateInstall,'Installs the APATE-compatible Palico armor table. The game must be closed. Existing Palico armor mods are preserved.')
$script:QuestbookTips.SetToolTip($maximumSlotsExport,'Exports three level-4 decoration slots for weapons and armor. Augment capacity is unchanged.')
$script:QuestbookTips.SetToolTip($anyExport,'Any jewel may fit an existing slot. Skills are unchanged; no new slots are created.')
[void](Add-Control $modtab Label 'Choose one decoration mod for normal use. These two change different tables; other mods that edit the same tables as your choice need a merge.' 15 113 1045 45)
[void](Add-Control $modtab Label 'Game install folder (Steam auto-detects when available)' 15 5 1045 22)
[void](Add-Control $modtab Label 'Optional Plugins (Astera Loader required)' 15 177 1045 32)
$gamePath=Add-Control $modtab TextBox (Find-GameFolder) 15 29 870 34
$gameBrowse=Add-Control $modtab Button 'Choose Game Folder' 900 29 160 34
$gameBrowse.Add_Click({$d=[Windows.Forms.FolderBrowserDialog]::new();try{if($d.ShowDialog($form) -eq 'OK'){$gamePath.Text=$d.SelectedPath;$script:ToolSettings.GamePath=$d.SelectedPath;Save-ToolSettings}}finally{$d.Dispose()}})
$bridgeInstall=Add-Control $modtab Button 'Install Account Bridge' 15 224 240 38;$bridgeInstall.Add_Click({Run-Action {Install-AccountBridge}})
$harvestVersion=Add-Control $modtab ComboBox '' 270 227 330 32;$harvestVersion.DropDownStyle='DropDownList';[void]$harvestVersion.Items.AddRange([object[]]@('FieldHarvest: Selected Target','FieldHarvest: Nearby Field'));$harvestVersion.SelectedIndex=0
$harvestInstall=Add-Control $modtab Button 'Install FieldHarvest' 620 224 440 38;$harvestInstall.Add_Click({Run-Action {Install-FieldHarvest}})
[void](Add-Control $modtab Label 'Radius' 15 280 100 30);$harvestRadius=Add-Control $modtab NumericUpDown '' 120 280 120 32;$harvestRadius.Minimum=100;$harvestRadius.Maximum=5000;$harvestRadius.Value=1000
[void](Add-Control $modtab Label 'Target Limit' 255 280 135 30);$harvestTargets=Add-Control $modtab NumericUpDown '' 400 280 100 32;$harvestTargets.Minimum=1;$harvestTargets.Maximum=128;$harvestTargets.Value=32
[void](Add-Control $modtab Label 'Per Frame' 515 280 125 30);$harvestCommits=Add-Control $modtab NumericUpDown '' 650 280 85 32;$harvestCommits.Minimum=1;$harvestCommits.Maximum=16;$harvestCommits.Value=1
[void](Add-Control $modtab Label 'Timeout (s)' 750 280 170 30);$harvestTimeout=Add-Control $modtab NumericUpDown '' 930 280 130 32;$harvestTimeout.Minimum=1;$harvestTimeout.Maximum=120;$harvestTimeout.Value=30
$harvestFish=Add-Control $modtab CheckBox 'Collect Fish' 15 330 280 32;$harvestFish.Checked=$true
$harvestWildlife=Add-Control $modtab CheckBox 'Collect Wildlife' 325 330 350 32;$harvestWildlife.Checked=$true
$harvestTracks=Add-Control $modtab CheckBox 'Collect Tracks' 720 330 340 32;$harvestTracks.Checked=$true
if($script:ToolSettings.Harvest){try{$h=$script:ToolSettings.Harvest;$harvestVersion.SelectedIndex=[int]$h.Variant;$harvestRadius.Value=[decimal]$h.Radius;$harvestTargets.Value=[decimal]$h.Targets;$harvestCommits.Value=[decimal]$h.Commits;$harvestTimeout.Value=[decimal]$h.Timeout;$harvestFish.Checked=[bool]$h.Fish;$harvestWildlife.Checked=[bool]$h.Wildlife;$harvestTracks.Checked=[bool]$h.Tracks}catch{}}
[void](Add-Control $modtab Label 'The Field version is experimental; some features may not work yet. Choose one version and close the game before installing. The other version is backed up outside the plugins folder.' 15 378 1045 65)
[void](Add-Control $modtab Label 'Account Request Key' 15 464 230 32)
$bridgeKey=Add-Control $modtab ComboBox '' 260 464 150 32;$bridgeKey.DropDownStyle='DropDownList';[void]$bridgeKey.Items.AddRange([object[]]@('F9','F10'));$bridgeKey.SelectedItem=$script:ToolSettings.Hotkey;if($bridgeKey.SelectedIndex -lt 0){$bridgeKey.SelectedIndex=1}
$bridgeKey.Add_SelectedIndexChanged({$script:ToolSettings.Hotkey=[string]$bridgeKey.SelectedItem;Run-Action {Save-ToolSettings}})
$accountStatus=Add-Control $modtab Button 'Account Request Status' 430 464 330 38;$accountStatus.Add_Click({Run-Action {Show-AccountStatus}})
$canteenAcquire=Add-Control $modtab Button 'Acquire All Canteen Account Items' 15 520 515 44
$canteenAcquire.Add_Click({Run-Action {
 $current=Current-Slot;$root=Get-GameFolder -RequireLoader;$folder=Join-Path $root 'AsteraLoader\plugins\mhwi_account_bridge'
 if(-not (Test-Path -LiteralPath (Join-Path $folder 'mhwi_account_bridge.dll'))){throw 'Install the updated account bridge first.'}
 Publish-CompanionBridgeRequest $folder "MHWI_CANTEEN_V1 $($current.number)"
 [HuntersCompanion.Messages]::Show((Get-QuestbookText 'Canteen Request Queued')+(Format-QuestbookText '
36 x 1 | {0}: {1}
{2}
' @(($(Get-QuestbookText 'Slot')),($($current.number)),($($bridgeKey.SelectedItem))))+(Get-QuestbookText 'Enter a solo expedition, press the configured key once, wait for completion, then return and save.'),'MHWI Questbook')|Out-Null
}})
$canteenUnlock=Add-Control $modtab Button 'Unlock Acquired Ingredients' 545 520 515 44
$canteenUnlock.Add_Click({Run-Action {
 $current=Current-Slot;$root=Get-GameFolder -RequireLoader;$folder=Join-Path $root 'AsteraLoader\plugins\mhwi_account_bridge'
 if(-not (Test-Path -LiteralPath (Join-Path $folder 'mhwi_account_bridge.dll'))){throw 'Install the updated account bridge first.'}
 Publish-CompanionBridgeRequest $folder "MHWI_CANTEEN_UNLOCK_V1 $($current.number)"
 [HuntersCompanion.Messages]::Show((Get-QuestbookText 'Ingredient Unlock Request Queued')+(Format-QuestbookText '
{0}: {1}
{2}
' @(($(Get-QuestbookText 'Slot')),($($current.number)),($($bridgeKey.SelectedItem))))+(Get-QuestbookText 'Unlocks the 36 acquired ingredient sources without adding account items. Enter a solo expedition, press the configured key once, then return and save.'),'MHWI Questbook')|Out-Null
}})
[void](Add-Control $modtab Label 'Canteen batch: 36 collectible account items, one each. Quest and delivery unlocks are separate.' 15 575 1045 30)
. (Join-Path $script:Root 'QuestbookPause.ps1')
. (Join-Path $script:Root 'QuestClearShortcut.ps1')
function Update-QuestbookOptionsMusic($ui) {
 if(-not $ui -or $ui.Dialog.IsDisposed){return}
 $playing=$script:CompanionMusic.IsPlaying
 $ui.Music.Text=if($playing){'❚❚'}else{'▶'}
 $label=if($playing){'Pause Music'}else{'Play Music'}
 $ui.Music.AccessibleName=Get-QuestbookText $label
 $script:QuestbookTips.SetToolTip($ui.Music,$label)
}
function Apply-QuestbookOptions($ui) {
 $selectedKey=[string]$ui.PauseKey.SelectedItem
 if($ui.PauseEnabled.Checked -and $script:QuestClearShortcut -and $selectedKey -eq $script:ToolSettings.QuestClearKey){throw 'Disable the Whole Quest Clear shortcut or choose a different Pause key.'}
 Set-QuestbookPauseSession $ui.PauseEnabled.Checked $selectedKey
 $script:ToolSettings.PauseKey=$selectedKey
 $script:ToolSettings.Language=$ui.Codes[$ui.Language.SelectedIndex]
 Save-ToolSettings
 Apply-QuestbookLanguage
 $ui.Dialog.Close()
}
function Show-QuestbookOptions {
 $musicTimer=$null;$dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Options';$dialog.ClientSize=[Drawing.Size]::new(760,700);$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
  [void](Add-Control $dialog Label (Get-QuestbookText 'Language') 20 20 180 35)
  $language=Add-Control $dialog ComboBox '' 210 20 530 38;$language.DropDownStyle='DropDownList'
  foreach($v in @('English','简体中文','日本語','한국어','Русский')){[void]$language.Items.Add($v)}
  $codes=@('en','zh-CN','ja','ko','ru');$language.SelectedIndex=[Math]::Max(0,[array]::IndexOf($codes,$script:ToolSettings.Language))
  [void](Add-Control $dialog Label (Get-QuestbookText 'Language changes apply to the interface and available game text. Untranslated custom content keeps its source text.') 20 70 720 60)
  $pauseEnabled=Add-Control $dialog CheckBox (Get-QuestbookText 'Enable Pause — I Am Playing Offline') 20 140 720 45
  $pauseEnabled.Checked=Test-QuestbookPauseRunning
  [void](Add-Control $dialog Label (Get-QuestbookText 'Pause Hotkey') 20 190 180 35)
  $pauseKey=Add-Control $dialog ComboBox '' 210 190 530 38;$pauseKey.DropDownStyle='DropDownList'
  [void]$pauseKey.Items.AddRange([object[]]@('F11','F6','F7','Ctrl+Shift+P','Ctrl+Alt+P'))
  $pauseKey.SelectedItem=$script:ToolSettings.PauseKey;if($pauseKey.SelectedIndex -lt 0){$pauseKey.SelectedIndex=0}
  [void](Add-Control $dialog Label (Get-QuestbookText 'Focus the game to pause; press the same key again to resume. Keep this editor open. The entire process freezes. Offline status cannot be detected automatically; disconnect from online play first.') 20 240 720 90)
  $pauseStatus=Add-Control $dialog Label '' 20 335 720 50
  $pauseStatus.Text=Get-QuestbookText $(if(Test-QuestbookPauseRunning){'Pause Controller Is Running'}else{'Pause Is Disabled'})
  $about=Add-Control $dialog Button 'About / Credits' 20 400 720 44
  $about.Add_Click({Run-Action {Show-CompanionAbout}})
  $tutorial=Add-Control $dialog Button 'MHWI:MC Guide' 20 458 720 44
  $tutorial.Add_Click({Run-Action {Show-CompanionTutorial}})
  $follow=Add-Control $dialog Button 'Follow H3CT1C Music!' 20 516 650 44
  $follow.Add_Click({Run-Action {Open-CompanionLink 'https://www.soundcloud.com/h3ct1c'}})
  $music=Add-Control $dialog Button '▶' 684 516 56 44
  $musicTimer=[Windows.Forms.Timer]::new();$musicTimer.Interval=300
  $cancel=Add-Control $dialog Button (Get-QuestbookText 'Close') 20 630 340 44;$cancel.DialogResult='Cancel'
  $ok=Add-Control $dialog Button (Get-QuestbookText 'Apply') 400 630 340 44
  $ui=[pscustomobject]@{Dialog=$dialog;Music=$music;Language=$language;Codes=$codes;PauseEnabled=$pauseEnabled;PauseKey=$pauseKey}
  $dialog.Tag=$ui;$music.Tag=$ui;$ok.Tag=$ui
  $musicTimer.Add_Tick({Update-QuestbookOptionsMusic $script:QuestbookOptionsDialog})
  $music.Add_Click({param($sender,$event) Run-Action {$script:CompanionMusic.Toggle();Update-QuestbookOptionsMusic $sender.Tag}})
  $ok.Add_Click({param($sender,$event) Run-Action {Apply-QuestbookOptions $sender.Tag}})
  $script:QuestbookOptionsDialog=$ui
  Update-QuestbookOptionsMusic $ui;$musicTimer.Start()
  Set-QuestbookTree $dialog;Enable-QuestbookCombo $language 'book';Enable-QuestbookCombo $pauseKey 'hunter'
  $music.Font=$script:MusicIconFont
  $dialog.CancelButton=$cancel;[void]$dialog.ShowDialog($form)
 }finally{if($musicTimer){$musicTimer.Stop();$musicTimer.Dispose()};$script:QuestbookOptionsDialog=$null;$dialog.Dispose()}
}
$optionsButton.Add_Click({Run-Action {Show-QuestbookOptions}})
function Initialize-QuestbookPolish {
 $buffer=[Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'Instance,NonPublic')
 foreach($control in @($form,$tabs,$script:QuestbookPageHost,$script:QuestbookNavigation,$box,$questList)+@($tabs.TabPages)){try{$buffer.SetValue($control,$true,$null)}catch{}}
 foreach($combo in @($journalOwned,$journalSort,$journalFamily,$journalMonster,$journalRank,$journalRegion,$journalSource,$journalAffinity,$journalRarity,$journalRecent,$catalog,$equipList,$harvestVersion,$bridgeKey)){
  $combo.FlatStyle='Standard';$combo.DropDownWidth=[Math]::Max(360,$combo.Width)
 }
 Enable-QuestbookCombo $harvestVersion 'export';Enable-QuestbookCombo $bridgeKey 'hunter'
 foreach($parent in @($form)+@($tabs.TabPages)){
  $parent.Add_Paint({param($sender,$event)
   $pen=[Drawing.Pen]::new($script:QuestbookColors.Teal,1.5)
   try{foreach($child in $sender.Controls){if($child -is [Windows.Forms.ComboBox] -and $child.Visible){$rect=$child.Bounds;$rect.Inflate(1,1);$event.Graphics.DrawRectangle($pen,$rect)}}}finally{$pen.Dispose()}
  })
 }
 $form.Add_FormClosing({param($sender,$event)
  try{Stop-QuestbookPause}catch{$event.Cancel=$true;[HuntersCompanion.Messages]::Show($_.Exception.Message,'MHWI Questbook')|Out-Null}
 })
 $form.Add_FormClosing({param($sender,$event) if($event.Cancel){return};$script:JournalRefreshTimer.Stop();$script:JournalSaveTimer.Stop();Save-JournalPreferences})
 $form.Add_FormClosed({$script:JournalRefreshTimer.Dispose();$script:JournalSaveTimer.Dispose()})
}

