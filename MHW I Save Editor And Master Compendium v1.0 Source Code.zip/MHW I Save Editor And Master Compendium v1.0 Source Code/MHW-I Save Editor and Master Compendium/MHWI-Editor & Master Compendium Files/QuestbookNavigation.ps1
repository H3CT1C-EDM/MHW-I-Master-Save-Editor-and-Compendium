﻿function Get-QuestbookNavigationRects([int]$width,[int]$count){
    for($i=0;$i -lt $count;$i++){
        $left=[int][Math]::Floor($width*$i/[double]$count)
        $right=[int][Math]::Floor($width*($i+1)/[double]$count)
        [pscustomobject]@{X=$left;Width=$right-$left}
    }
}
function Update-QuestbookNavigation([double]$scale){
    $rects=@(Get-QuestbookNavigationRects $script:QuestbookNavigation.ClientSize.Width $tabs.TabCount)
    for($i=0;$i -lt $script:QuestbookNavigationButtons.Count;$i++){
        $button=$script:QuestbookNavigationButtons[$i];$selected=$tabs.SelectedIndex -eq $i
        $button.SetBounds($rects[$i].X,0,$rects[$i].Width,$script:QuestbookNavigation.ClientSize.Height)
        $button.Font=Get-QuestbookScaledFont $script:QuestbookBold $scale
        $button.BackColor=if($selected){[Drawing.Color]::FromArgb(82,125,112)}else{$script:QuestbookColors.Teal}
        $button.ForeColor=if($selected){$script:QuestbookColors.Light}else{$script:QuestbookColors.Light}
        $button.FlatAppearance.MouseOverBackColor=if($selected){[Drawing.Color]::FromArgb(65,105,94)}else{$script:QuestbookColors.Hover}
        $button.FlatAppearance.MouseDownBackColor=if($selected){$script:QuestbookColors.Selected}else{$script:QuestbookColors.Selected}
        $tone=if($selected){'ink'}else{'gold'};$size=[int](20*$scale)
        $key='navigation_'+$i+'_'+$tone+'_'+$size
        if(-not $script:QuestbookImages.ContainsKey($key)){
            $image=Get-QuestbookImage ($script:QuestbookTabIcons[$i]+'_'+$tone)
            if($image){$script:QuestbookImages[$key]=[Drawing.Bitmap]::new($image,[Drawing.Size]::new($size,$size))}
        }
        if($script:QuestbookImages.ContainsKey($key)){$button.Image=$script:QuestbookImages[$key]}
        $button.TextImageRelation='Overlay';$button.ImageAlign='MiddleLeft';$button.TextAlign='MiddleCenter'
        $button.AccessibleDescription=if($selected){'Selected page'}else{'Open page'}
    }
}
function Initialize-QuestbookNavigation {
    $script:QuestbookNavigation=[Windows.Forms.Panel]::new()
    $script:QuestbookNavigation.BackColor=$script:QuestbookColors.Teal
    $script:QuestbookPageHost=[Windows.Forms.Panel]::new()
    $script:QuestbookPageHost.BackColor=$script:QuestbookColors.Paper
    $script:QuestbookPageHost.Controls.Add($tabs)
    $form.Controls.Add($script:QuestbookPageHost)
    $form.Controls.Add($script:QuestbookNavigation)
    $script:QuestbookNavigationButtons=@()
    for($i=0;$i -lt $tabs.TabCount;$i++){
        $button=[Windows.Forms.Button]::new();$button.Text=$tabs.TabPages[$i].Text;$button.Tag=$i
        Set-QuestbookControl $button
        $button.Add_Click({param($sender,$event) $tabs.SelectedIndex=[int]$sender.Tag})
        $button.Add_Paint({param($sender,$event)
            $bounds=$sender.ClientRectangle
            $hover=$bounds.Contains($sender.PointToClient([Windows.Forms.Control]::MousePosition))
            $back=if($hover -and [Windows.Forms.Control]::MouseButtons -eq [Windows.Forms.MouseButtons]::Left){$sender.FlatAppearance.MouseDownBackColor}elseif($hover){$sender.FlatAppearance.MouseOverBackColor}else{$sender.BackColor}
            $brush=[Drawing.SolidBrush]::new($back)
            try{$event.Graphics.FillRectangle($brush,$bounds)}finally{$brush.Dispose()}
            if($sender.Image){$size=$sender.Image.Width;$event.Graphics.DrawImage($sender.Image,8,[int](($bounds.Height-$size)/2),$size,$size)}
            $textBounds=[Drawing.Rectangle]::new(32,2,[Math]::Max(1,$bounds.Width-40),[Math]::Max(1,$bounds.Height-4))
            $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::WordBreak -bor [Windows.Forms.TextFormatFlags]::NoPrefix -bor [Windows.Forms.TextFormatFlags]::NoPadding
            $measured=[Windows.Forms.TextRenderer]::MeasureText($sender.Text,$sender.Font,[Drawing.Size]::new($textBounds.Width,32767),$flags)
            $textBounds.Height=[Math]::Min($bounds.Height-4,$measured.Height);$textBounds.Y=[int](($bounds.Height-$textBounds.Height)/2)
            [Windows.Forms.TextRenderer]::DrawText($event.Graphics,$sender.Text,$sender.Font,$textBounds,$sender.ForeColor,$flags)
            $pen=[Drawing.Pen]::new($script:QuestbookColors.Gold)
            try{$event.Graphics.DrawRectangle($pen,0,0,$bounds.Width-1,$bounds.Height-1)}finally{$pen.Dispose()}
            if($sender.Focused){$focus=$bounds;$focus.Inflate(-3,-3);[Windows.Forms.ControlPaint]::DrawFocusRectangle($event.Graphics,$focus)}
        })
        $script:QuestbookNavigation.Controls.Add($button)
        $script:QuestbookNavigationButtons+=@($button)
    }
    $script:QuestbookNavigation.BringToFront()
}
