﻿function Get-MaximumDecorationTable([byte[]]$bytes,$profile) {
 if($bytes.Length -lt 10){throw 'Unsupported equipment table header.'}
 $count=[BitConverter]::ToUInt32($bytes,6);$stride=[int]$profile.EntrySize;$offset=[int]$profile.SlotOffset
 if($count -gt 100000 -or $bytes.Length -ne (10+[long]$count*$stride)){throw 'Unsupported equipment table layout. No files were changed.'}
 $copy=[byte[]]$bytes.Clone()
 for($i=0;$i -lt $count;$i++){
  $start=10+$i*$stride
  if($stride -eq 60 -and $copy[$start+10] -gt 4){continue}
  $p=$start+$offset
  if($copy[$p] -gt 3 -or $copy[$p+1] -gt 4 -or $copy[$p+2] -gt 4 -or $copy[$p+3] -gt 4){throw 'An equipment row uses an unsupported slot layout. No files were changed.'}
  $copy[$p]=3;$copy[$p+1]=4;$copy[$p+2]=4;$copy[$p+3]=4
 }
 return ,$copy
}
function Export-MaximumDecorationSlots {
 Assert-GameClosed;$root=Get-GameFolder
 $answer=[HuntersCompanion.Messages]::Show("Install three level-4 decoration slots on weapons and armor? Existing table edits are preserved where compatible. Unequip extra jewels before reverting.`r`n$root",'Install Maximum Decoration Slots','OKCancel')
 if($answer -ne 'OK'){return}
 $profiles=Get-Content -LiteralPath (Join-Path $script:Root 'catalog/EquipmentTableProfiles.json') -Raw|ConvertFrom-Json
 $stage=New-NativePcStage $root
 try{
  $changes=@(Get-ChildItem -LiteralPath (Join-Path $script:Root 'data/common/equip') -File | Where-Object {$_.Extension -in @('.wp_dat','.wp_dat_g','.am_dat')} | ForEach-Object {
   $source=$_;$rel='equip/'+$source.Name;$target=Get-NativePcTarget $root $rel
   $before=Get-NativePcHash $target;$input=if($before){$target}else{$source.FullName}
   $bytes=[IO.File]::ReadAllBytes($input);$original=[IO.File]::ReadAllBytes($source.FullName)
   if($bytes.Length -ne $original.Length -or [BitConverter]::ToUInt32($bytes,0) -ne [BitConverter]::ToUInt32($original,0) -or [BitConverter]::ToUInt16($bytes,4) -ne [BitConverter]::ToUInt16($original,4)){throw 'An installed equipment table has an unsupported format. No tables were changed.'}
   $output=Join-Path $stage $source.Name
   [IO.File]::WriteAllBytes($output,(Get-MaximumDecorationTable $bytes $profiles.($source.Extension.TrimStart('.'))))
   [pscustomobject]@{Relative=$rel;Before=$before;Stage=$output}
  })
  $backup=Install-NativePcTables $root $changes
  Show-NativePcInstalled $root $backup
 }finally{Remove-Item -LiteralPath $stage -Recurse -Force}
}
function Get-EquipmentTableRoot {
 try{return Get-GameFolder}catch{return $script:Root}
}
$script:ArmorSlotCacheKey='';$script:ArmorSlotCache=@{}
function Read-CompanionArmorExportSlots([int]$type,[int]$id) {
 $path=Get-NativePcTarget (Get-EquipmentTableRoot) 'equip/armor.am_dat'
 if(-not (Test-Path -LiteralPath $path)){$path=Join-Path $script:Root 'data\common\equip\armor.am_dat'}
 $file=Get-Item -LiteralPath $path;$key=$file.FullName+'|'+$file.Length+'|'+$file.LastWriteTimeUtc.Ticks
 if($key -ne $script:ArmorSlotCacheKey){
  $bytes=[IO.File]::ReadAllBytes($file.FullName)
  if($bytes.Length -lt 10 -or $bytes.Length -ne (10+[long][BitConverter]::ToUInt32($bytes,6)*60)){throw 'Unsupported armor table layout.'}
  $cache=@{}
  for($p=10;$p -lt $bytes.Length;$p+=60){
   $part=[int]$bytes[$p+10];if($part -gt 4){continue};$group=[BitConverter]::ToUInt16($bytes,$p+53);$entryKey="$part`:$group"
   $sizes=@([int]$bytes[$p+31],[int]$bytes[$p+32],[int]$bytes[$p+33]);if(@($sizes|Where-Object {$_ -gt 4}).Count){throw 'Unsupported armor slot level.'}
   if($cache.ContainsKey($entryKey) -and ($cache[$entryKey] -join ',') -ne ($sizes -join ',')){throw 'Ambiguous armor slot identity.'};$cache[$entryKey]=$sizes
  }
  $script:ArmorSlotCache=$cache;$script:ArmorSlotCacheKey=$key
 }
 $entryKey="$type`:$id";if(-not $script:ArmorSlotCache.ContainsKey($entryKey)){throw 'Armor slot identity was not found.'};return ,$script:ArmorSlotCache[$entryKey]
}
