﻿
$script:QuestbookColors=@{
    Ink=[Drawing.ColorTranslator]::FromHtml('#182A22')
    Muted=[Drawing.ColorTranslator]::FromHtml('#30392B')
    Paper=[Drawing.ColorTranslator]::FromHtml('#F4E8CE')
    PaperAlt=[Drawing.ColorTranslator]::FromHtml('#EDE0C0')
    Input=[Drawing.ColorTranslator]::FromHtml('#FFF7E5')
    Teal=[Drawing.ColorTranslator]::FromHtml('#203D38')
    Hover=[Drawing.ColorTranslator]::FromHtml('#365D50')
    Selected=[Drawing.ColorTranslator]::FromHtml('#335E4E')
    Gold=[Drawing.ColorTranslator]::FromHtml('#D8BA7A')
    Light=[Drawing.ColorTranslator]::FromHtml('#FFF5DB')
    Disabled=[Drawing.ColorTranslator]::FromHtml('#C9BEA5')
    Mod=[Drawing.ColorTranslator]::FromHtml('#8A3E1E')
}
$script:QuestbookImages=@{}
$script:QuestbookFonts=[Collections.Generic.List[Drawing.Font]]::new()
$script:QuestbookStyled=[Collections.Generic.HashSet[object]]::new()
$script:QuestbookFont=[Drawing.Font]::new('Palatino Linotype',10.5,[Drawing.FontStyle]::Regular)
$script:QuestbookBold=[Drawing.Font]::new('Palatino Linotype',10.5,[Drawing.FontStyle]::Bold)
$script:QuestbookTitle=[Drawing.Font]::new('Georgia',23,[Drawing.FontStyle]::Regular)
$script:QuestbookSmall=[Drawing.Font]::new('Palatino Linotype',10,[Drawing.FontStyle]::Regular)
foreach($font in @($script:QuestbookFont,$script:QuestbookBold,$script:QuestbookTitle,$script:QuestbookSmall)){$script:QuestbookFonts.Add($font)}
$script:QuestbookTips=[HuntersCompanion.LocalizedToolTip]::new()
$script:QuestbookTips.AutoPopDelay=12000
function Get-QuestbookImage([string]$name){
    if(-not $script:QuestbookImages.ContainsKey($name)){
        $path=Join-Path $script:Root ("theme\"+$name+'.png')
        if(-not (Test-Path -LiteralPath $path -PathType Leaf)){return $null}
        $source=[Drawing.Image]::FromFile($path)
        try {$script:QuestbookImages[$name]=[Drawing.Bitmap]::new($source)}finally{$source.Dispose()}
    }
    return $script:QuestbookImages[$name]
}
function Set-QuestbookButtonState($button){
    $primary=$button.Name -eq 'QuestbookPrimary'
    $button.BackColor=if(-not $button.Enabled){$script:QuestbookColors.Disabled}elseif($primary){$script:QuestbookColors.Gold}else{$script:QuestbookColors.Teal}
    $button.ForeColor=if(-not $button.Enabled){$script:QuestbookColors.Muted}elseif($primary){$script:QuestbookColors.Ink}else{$script:QuestbookColors.Light}
    $button.Invalidate()
}
function Set-QuestbookControl($control){
    if(-not $script:QuestbookStyled.Add($control)){return}
    $control.Add_Disposed({param($sender,$event) [void]$script:QuestbookStyled.Remove($sender)})
    $control.Font=$script:QuestbookFont
    $control.ForeColor=$script:QuestbookColors.Ink
    if($control -is [Windows.Forms.Form]){
        $control.StartPosition=if([object]::ReferenceEquals($control,$form)){'CenterScreen'}else{'CenterParent'}
        Initialize-QuestbookDialog $control
        $control.BackColor=$script:QuestbookColors.Paper
        $paper=Get-QuestbookImage 'questbook'
        if($paper -and -not $script:QuestbookImages.ContainsKey('parchment-bleed')){
            $script:QuestbookImages['parchment-bleed']=[HuntersCompanion.HeaderParchment]::Prepare($paper,$false)
        }
        $control.BackgroundImage=$script:QuestbookImages['parchment-bleed']
        $control.BackgroundImageLayout='Stretch'
    }elseif($control -is [Windows.Forms.TabPage]){
        $control.UseVisualStyleBackColor=$false
        $control.BackColor=$script:QuestbookColors.Paper
        $control.BackgroundImage=$script:QuestbookImages['parchment-bleed']
        $control.BackgroundImageLayout='Stretch'
    }elseif($control -is [Windows.Forms.Button]){
        $control.FlatStyle='Flat';$control.UseVisualStyleBackColor=$false
        $control.FlatAppearance.BorderColor=$script:QuestbookColors.Gold
        $control.FlatAppearance.BorderSize=1
        $control.FlatAppearance.MouseOverBackColor=$script:QuestbookColors.Hover
        $control.FlatAppearance.MouseDownBackColor=$script:QuestbookColors.Selected
        $control.Font=$script:QuestbookBold
        $control.Cursor=[Windows.Forms.Cursors]::Hand
        $control.Padding=[Windows.Forms.Padding]::new(2,0,2,0)
        [HuntersCompanion.ButtonTextFit]::Attach($control)
        $control.TextAlign='MiddleCenter';$control.ImageAlign='MiddleCenter';$control.AutoEllipsis=$false; $control.UseMnemonic=$false
        Set-QuestbookButtonState $control
        $control.Add_EnabledChanged({param($sender,$event) Set-QuestbookButtonState $sender})
        if($control.Text){$script:QuestbookTips.SetToolTip($control,$control.Text)}
    }elseif($control -is [Windows.Forms.ComboBox]){
        $control.FlatStyle='Standard';$control.BackColor=$script:QuestbookColors.Input
        $control.ForeColor=$script:QuestbookColors.Ink
        $control.ItemHeight=26;$control.IntegralHeight=$false;$control.MaxDropDownItems=12
    }elseif($control -is [Windows.Forms.TextBox]){
        $control.AutoSize=$false;$control.BorderStyle='FixedSingle';$control.TextAlign='Center'
        $control.BackColor=$script:QuestbookColors.Input
        $control.ForeColor=$script:QuestbookColors.Ink
    }elseif($control -is [Windows.Forms.NumericUpDown]){
        $control.TextAlign='Center';$control.BorderStyle='FixedSingle';$control.BackColor=$script:QuestbookColors.Input
        $control.ForeColor=$script:QuestbookColors.Ink
    }elseif($control -is [Windows.Forms.CheckBox]){
        $control.BackColor=[Drawing.Color]::Transparent
        $control.UseVisualStyleBackColor=$false
    }elseif($control -is [Windows.Forms.Label]){
        $control.BackColor=[Drawing.Color]::Transparent
        $control.ForeColor=$script:QuestbookColors.Ink
        $control.Font=$script:QuestbookBold
        $control.TextAlign='MiddleCenter'
        $control.AutoEllipsis=$false
    }elseif($control -is [Windows.Forms.ListView]){
        $control.BackColor=$script:QuestbookColors.Paper
        $control.ForeColor=$script:QuestbookColors.Ink
        $control.BorderStyle='None';$control.GridLines=$false
    }
}
function Set-QuestbookTree($parent){
    Set-QuestbookControl $parent
    foreach($child in $parent.Controls){Set-QuestbookTree $child}
}
function Get-QuestbookComboColors($sender,$event){
    $selected=($event.State -band [Windows.Forms.DrawItemState]::Selected) -ne 0
    $back=if($selected){$script:QuestbookColors.Selected}else{$script:QuestbookColors.Input}
    $fore=if(-not $sender.Enabled){$script:QuestbookColors.Muted}elseif($selected){$script:QuestbookColors.Light}else{$script:QuestbookColors.Ink}
    return [pscustomobject]@{Back=$back;Fore=$fore;Selected=$selected}
}
function Enable-QuestbookCombo($combo,[string]$icon){
    
    if($combo.DrawMode -ne [Windows.Forms.DrawMode]::Normal){return}
    $combo.DrawMode='OwnerDrawFixed';$combo.ItemHeight=28
    $combo.Name='QuestbookCombo_'+$icon
    $combo.Add_DrawItem({param($sender,$event)
        $colors=Get-QuestbookComboColors $sender $event
        $brush=[Drawing.SolidBrush]::new($colors.Back)
        try {$event.Graphics.FillRectangle($brush,$event.Bounds)}finally{$brush.Dispose()}
        if($event.Index -ge 0 -and $event.Index -lt $sender.Items.Count){
            $entry=$sender.Items[$event.Index]
            $text=if($sender.DisplayMember){[string]$entry.($sender.DisplayMember)}else{[string]$entry}
            $name=$sender.Name.Substring('QuestbookCombo_'.Length)
            $tone=if($colors.Selected){'gold'}else{'ink'}
            $image=Get-QuestbookImage ($name+'_'+$tone)
            $iconSize=[int](22*[Math]::Max(1.0,[Math]::Min(1.5,$sender.Font.SizeInPoints/9.5)))
            if($image){$event.Graphics.DrawImage($image,$event.Bounds.X+5,$event.Bounds.Y+[int](($event.Bounds.Height-$iconSize)/2),$iconSize,$iconSize)}
            $rect=[Drawing.Rectangle]::new($event.Bounds.X+$iconSize+11,$event.Bounds.Y,$event.Bounds.Width-$iconSize-13,$event.Bounds.Height)
            $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::EndEllipsis -bor [Windows.Forms.TextFormatFlags]::NoPrefix
            [Windows.Forms.TextRenderer]::DrawText($event.Graphics,(Get-QuestbookText $text),$sender.Font,$rect,$colors.Fore,$flags)
        }

    })
}
function Enable-QuestbookList($list){
    $list.OwnerDraw=$true;$list.GridLines=$false;$list.BorderStyle='None'
    $list.Add_DrawColumnHeader({param($sender,$event)
        $brush=[Drawing.SolidBrush]::new($script:QuestbookColors.Teal)
        try {$event.Graphics.FillRectangle($brush,$event.Bounds)}finally{$brush.Dispose()}
        $pen=[Drawing.Pen]::new($script:QuestbookColors.Gold)
        try {$event.Graphics.DrawLine($pen,$event.Bounds.Left,$event.Bounds.Bottom-1,$event.Bounds.Right,$event.Bounds.Bottom-1)}finally{$pen.Dispose()}
        $rect=[Drawing.Rectangle]::new($event.Bounds.X+8,$event.Bounds.Y,$event.Bounds.Width-10,$event.Bounds.Height)
        $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::EndEllipsis -bor [Windows.Forms.TextFormatFlags]::NoPrefix
        $headerFont=Get-QuestbookScaledFont $script:QuestbookBold ($sender.Font.SizeInPoints/9.5)
        $caption=Get-QuestbookText $event.Header.Text
        if($sender -eq $box -and $event.ColumnIndex -eq $script:JournalHeaderColumn){
            $caption+=if($script:JournalHeaderDescending){' ▼'}else{' ▲'}
        }
        [Windows.Forms.TextRenderer]::DrawText($event.Graphics,$caption,$headerFont,$rect,$script:QuestbookColors.Light,$flags)
    })
    $list.Add_DrawItem({param($sender,$event)
        if($sender.View -ne [Windows.Forms.View]::Details){$event.DrawDefault=$true}
    })
    $list.Add_DrawSubItem({param($sender,$event)
        $selected=$event.Item.Selected
        $back=if($selected){$script:QuestbookColors.Selected}elseif($event.ItemIndex%2){$script:QuestbookColors.PaperAlt}else{$script:QuestbookColors.Paper}
        $fore=if($selected){$script:QuestbookColors.Light}else{$event.Item.ForeColor}
        if($fore.IsEmpty){$fore=$script:QuestbookColors.Ink}
        if($selected -and $sender -eq $box -and $event.Item.Tag){$fore=Get-CompanionItemColor $script:Items[[int]$event.Item.Tag.id] $fore}
        $brush=[Drawing.SolidBrush]::new($back)
        try {$event.Graphics.FillRectangle($brush,$event.Bounds)}finally{$brush.Dispose()}
        $left=$event.Bounds.X+8
        if($event.ColumnIndex -eq 0){
            $thumbnail=$null
            if($sender -eq $box -and $event.Item.Tag){$thumbnail=Get-Thumbnail (Get-ThumbnailKey $event.Item.Tag)}
            elseif($sender.SmallImageList -and $event.Item.ImageIndex -ge 0 -and $event.Item.ImageIndex -lt $sender.SmallImageList.Images.Count){$thumbnail=$sender.SmallImageList.Images[$event.Item.ImageIndex]}
            if($thumbnail){$event.Graphics.DrawImage($thumbnail,$left,$event.Bounds.Y+[int](($event.Bounds.Height-22)/2),22,22);$left+=29}
        }
        $rect=[Drawing.Rectangle]::new($left,$event.Bounds.Y,[Math]::Max(0,$event.Bounds.Right-$left-5),$event.Bounds.Height)
        $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::EndEllipsis -bor [Windows.Forms.TextFormatFlags]::NoPrefix
        $displayText=Get-QuestbookText $event.SubItem.Text
        if($event.ColumnIndex -eq 0 -and $sender -eq $questList -and -not $event.Item.Tag.ModPack){$displayText=Get-QuestbookQuestText $event.Item.Tag 'Name'}
        elseif($event.ColumnIndex -eq 0 -and $sender -eq $box){$displayText=Get-QuestbookGameText $event.SubItem.Text 'item_name'}
        [Windows.Forms.TextRenderer]::DrawText($event.Graphics,$displayText,$sender.Font,$rect,$fore,$flags)
        if($event.Item.Focused -and $event.ColumnIndex -eq 0){
            $pen=[Drawing.Pen]::new($script:QuestbookColors.Gold,2)
            try {$event.Graphics.DrawLine($pen,$event.Bounds.Left+1,$event.Bounds.Top+2,$event.Bounds.Left+1,$event.Bounds.Bottom-2)}finally{$pen.Dispose()}
        }
    })
}
function Set-QuestbookButtonIcon($button,[string]$name){
    $tone=if($button.Name -eq 'QuestbookPrimary'){'ink'}else{'gold'}
    $image=Get-QuestbookImage ($name+'_'+$tone)
    if(-not $image){return}
    $key=$name+'_button_'+$tone
    if(-not $script:QuestbookImages.ContainsKey($key)){$script:QuestbookImages[$key]=[Drawing.Bitmap]::new($image,[Drawing.Size]::new(18,18))}
    $button.Image=$script:QuestbookImages[$key]
    $button.TextImageRelation='ImageBeforeText'
}
function Complete-QuestbookTheme {
    Set-QuestbookTree $form
    $form.Text='MHW:I Save Editor & Master Compendium'
    $script:QuestbookAppIcon=[Drawing.Icon]::new((Join-Path $script:Root 'Questbook.ico'))
    $form.Icon=$script:QuestbookAppIcon
    $form.StartPosition='CenterScreen'
    $form.AutoScroll=$false;$form.AutoScrollMinSize=[Drawing.Size]::Empty
    $form.MinimumSize=[Drawing.Size]::new(940,780)
    $area=[Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $form.ClientSize=[Drawing.Size]::new([Math]::Min(1120,$area.Width-40),[Math]::Min(852,$area.Height-80))
    
    foreach($control in @($open,$save,$undo,$slot,$status,$tabs,$optionsButton)){$control.Top+=68}
    $tabs.Height+=24
    $tabs.Font=$script:QuestbookBold
    $tabs.DrawMode='OwnerDrawFixed';$tabs.SizeMode='Fixed';$tabs.ItemSize=[Drawing.Size]::new(210,40)
    $inv.Text='Item Box';$eqtab.Text='Equipment & Jewels';$modtab.Text='Game Data Exports';$questTab.Text='Quest Journal'
    $script:QuestbookTabIcons=@('inventory','equipment','export','book','hunter','book')
    $tabs.Add_DrawItem({param($sender,$event)
        if($event.Index -lt 0 -or $event.Index -ge $sender.TabPages.Count){return}
        $selected=$event.Index -eq $sender.SelectedIndex
        $back=if($selected){$script:QuestbookColors.Paper}else{$script:QuestbookColors.Teal}
        $fore=if($selected){$script:QuestbookColors.Ink}else{$script:QuestbookColors.Light}
        $brush=[Drawing.SolidBrush]::new($back)
        try {$event.Graphics.FillRectangle($brush,$event.Bounds)}finally{$brush.Dispose()}
        $tone=if($selected){'ink'}else{'gold'}
        $icon=Get-QuestbookImage ($script:QuestbookTabIcons[$event.Index]+'_'+$tone)
        $iconSize=[int](24*[Math]::Max(1.0,[Math]::Min(1.5,$sender.ItemSize.Height/40.0)))
        if($icon){$event.Graphics.DrawImage($icon,$event.Bounds.X+12,$event.Bounds.Y+[int](($event.Bounds.Height-$iconSize)/2),$iconSize,$iconSize)}
        $rect=[Drawing.Rectangle]::new($event.Bounds.X+$iconSize+20,$event.Bounds.Y,$event.Bounds.Width-$iconSize-24,$event.Bounds.Height)
        $flags=[Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [Windows.Forms.TextFormatFlags]::VerticalCenter -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::EndEllipsis -bor [Windows.Forms.TextFormatFlags]::NoPrefix
        [Windows.Forms.TextRenderer]::DrawText($event.Graphics,$sender.TabPages[$event.Index].Text,$sender.Font,$rect,$fore,$flags)
        $pen=[Drawing.Pen]::new($script:QuestbookColors.Gold,2)
        try {$event.Graphics.DrawLine($pen,$event.Bounds.Left,$event.Bounds.Bottom-1,$event.Bounds.Right,$event.Bounds.Bottom-1)}finally{$pen.Dispose()}
    })
    $header=[Windows.Forms.Panel]::new();$header.SetBounds(0,0,1120,58);$header.BackColor=[Drawing.Color]::Transparent
    $header.BackgroundImage=$null
    $crest=[Windows.Forms.PictureBox]::new();$crest.SetBounds(24,12,31,31);$crest.SizeMode='Zoom';$crest.BackColor=[Drawing.Color]::Transparent;$crest.Image=Get-QuestbookImage 'commission';$header.Controls.Add($crest)
    $wordmark=Get-QuestbookImage 'companion-wordmark'
    if($wordmark){
        $title=[Windows.Forms.PictureBox]::new();$title.SizeMode='Zoom';$title.Image=$wordmark
    }else{
        $title=[Windows.Forms.Label]::new();$title.TextAlign='MiddleCenter';$title.Text="Hunters Companion`r`nMonster Hunter World: Iceborne | Save Editor & Master Compendium";$title.Font=$script:QuestbookBold;$title.ForeColor=$script:QuestbookColors.Ink
    }
    $title.SetBounds(78,0,850,54);$title.Name='CompanionHeadline';$title.AccessibleName='Hunters Companion — Monster Hunter World: Iceborne | Save Editor & Master Compendium';$title.BackColor=[Drawing.Color]::Transparent;$header.Controls.Add($title)
    $edition=[Windows.Forms.Label]::new();$edition.Visible=$false;$header.Controls.Add($edition)
    $form.Controls.Add($header);$header.BringToFront()
    $save.Name='QuestbookPrimary';Set-QuestbookButtonState $save
    $save.FlatAppearance.MouseOverBackColor=$script:QuestbookColors.PaperAlt
    $save.FlatAppearance.MouseDownBackColor=$script:QuestbookColors.Paper
    $save.FlatAppearance.BorderColor=$script:QuestbookColors.Teal
    $status.ForeColor=$script:QuestbookColors.Ink
    $questDetails.BackColor=[Drawing.Color]::Transparent
    $questDetails.Font=$script:QuestbookFont
    foreach($pair in @(@($slot,'hunter'),@($filter,'inventory'),@($questCategory,'book'),@($questRank,'hunter'),@($questSource,'book'))){Enable-QuestbookCombo $pair[0] $pair[1]}
    foreach($button in @($open,$questImport,$questLoadImport,$questExport)){Set-QuestbookButtonIcon $button 'book'}
    foreach($button in @($save,$installBridge,$importIcons)){Set-QuestbookButtonIcon $button 'inventory'}
    foreach($button in @($apply,$slotExport,$anyExport)){Set-QuestbookButtonIcon $button 'equipment'}
    foreach($button in @($questComplete,$questIncomplete,$questRepair)){Set-QuestbookButtonIcon $button 'book'}
    Enable-QuestbookList $box;Enable-QuestbookList $questList
    $script:QuestbookTips.SetToolTip($questComplete,'Set the saved completion flag; preserve rewards and unlocks')
    $script:QuestbookTips.SetToolTip($questIncomplete,'Clear the saved completion flag; preserve story progression')
    $script:QuestbookTips.SetToolTip($questRepair,'Edit the explicit saved quest count; preserve the completion flag')
    $script:QuestbookTips.SetToolTip($questImport,'Import extracted game quest definitions (read-only metadata)')
    $script:QuestbookTips.SetToolTip($questLoadImport,'Load a previously exported quest-definition report')
    $search.AccessibleName='Search inventory by item name or ID'
    $script:QuestbookTips.SetToolTip($search,'Search inventory by item name or ID')
    $script:QuestbookTips.SetToolTip($questSearch,'Search quests by title, game ID, reference ID or mod-pack name')
    $script:QuestbookTips.SetToolTip($slot,'Choose the character whose working save you want to edit')
    $script:QuestbookTips.SetToolTip($questPair,'Opt in to both paired IDs. The preview lists each affected quest.')
    Initialize-QuestbookLayout $header $edition
}
function Dispose-QuestbookTheme {
    $script:QuestbookTips.Dispose()
    if($script:QuestbookAppIcon){$script:QuestbookAppIcon.Dispose()}
    foreach($image in $script:QuestbookImages.Values){$image.Dispose()}
    foreach($font in $script:QuestbookFonts){$font.Dispose()}
    $script:QuestbookStyled.Clear()
}
