﻿function Get-CompanionArmorTables {
 $base=Join-Path $script:Root 'data/common/equip'
 $armorOverride=Get-NativePcTarget (Get-EquipmentTableRoot) 'equip/armor.am_dat'
 $capOverride=Join-Path (Split-Path -Parent $armorOverride) 'arm_upgrade.arm_up'
 foreach($path in @($armorOverride,$capOverride)){
  $item=Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
  if($item -and (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.PSIsContainer)){throw 'The installed armor table path is not a regular file.'}
 }
 $armor=if(Test-Path -LiteralPath $armorOverride -PathType Leaf){$armorOverride}else{Join-Path $base 'armor.am_dat'}
 $caps=if(Test-Path -LiteralPath $capOverride -PathType Leaf){$capOverride}else{Join-Path $base 'arm_upgrade.arm_up'}
 return @($armor,$caps)
}
function Invoke-CompanionArmorProgress([string[]]$Arguments) {
 $si=[Diagnostics.ProcessStartInfo]::new()
 $si.FileName=Join-Path $script:Root 'tools/ArmorProgress.exe'
 $si.Arguments=($Arguments | ForEach-Object {
  if($_.Contains('"')){throw 'An argument contains an unsupported quote.'}
  '"'+($_ -replace '(\\+)$','$1$1')+'"'
 }) -join ' '
 $si.UseShellExecute=$false;$si.CreateNoWindow=$true
 $si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
 $p=[Diagnostics.Process]::Start($si)
 try {
  $out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync()
  $p.WaitForExit()
  if($p.ExitCode -ne 0){throw $err.Result.Trim()}
  return $out.Result | ConvertFrom-Json
 } finally {$p.Dispose()}
}
function Get-CompanionArmorTargetPoints($profile,[int]$target) {
 if($target -eq [int]$profile.level){return [long]$profile.points}
 if($target -ge 1 -and $target -le $profile.level_points.Count){return [long]$profile.level_points[$target-1]}
 return [long]-1
}
function Get-CompanionArmorDefense($profile,[int]$level) {
 return [long]$profile.base_defense + 2L*($level-1)
}
function Show-CompanionArmorProgress {
 $selection=$equipList.SelectedItem
 if(-not $selection -or [int]$selection.Record.category -ne 0 -or [int]$selection.Record.type -notin (0..4)){throw 'Select a hunter armor piece first.'}
 $save=$script:Working;$charSlot=[int](Current-Slot).number
 $index=[int]$selection.Record.index;$part=[int]$selection.Record.type;$id=[int]$selection.Record.id
 $identity=@([string]$charSlot,[string]$index,[string]$part,[string]$id)
 $tables=@(Get-CompanionArmorTables)
 $profile=Invoke-CompanionArmorProgress (@('profile',$save)+$tables+$identity)
 if([int]$profile.slot -ne $charSlot -or [int]$profile.index -ne $index -or [int]$profile.id -ne $id -or [int]$profile.part -ne $part){throw 'Armor profile identity check failed.'}
 $dialog=[Windows.Forms.Form]::new()
 try {
  $dialog.Text=Get-QuestbookText 'Edit Armor Level and Cap';$dialog.ClientSize=[Drawing.Size]::new(720,460)
  [void](Add-Control $dialog Label ([string]$selection.Label) 20 15 680 36)
  [void](Add-Control $dialog Label (Format-QuestbookText 'Current level: {0}  |  Upgrade points: {1}  |  Rarity: {2}' @($profile.level,$profile.points,$profile.rarity)) 20 55 680 35)
  $cap=Add-Control $dialog CheckBox 'Unlock augmented armor cap' 25 100 670 36;$cap.Checked=[bool]$profile.augmented
  [void](Add-Control $dialog Label 'Target armor level' 25 150 400 34)
  $level=Add-Control $dialog NumericUpDown '' 455 150 220 34;$level.Minimum=1;$level.Maximum=999;$level.Value=[int]$profile.level
  [void](Add-Control $dialog Label 'Cumulative armor upgrade points' 25 195 400 34)
  $points=Add-Control $dialog TextBox '' 455 195 220 34;$points.ReadOnly=$true;$points.Text=[string]$profile.points
  $defense=Add-Control $dialog Label '' 25 236 670 29
  $delta=Add-Control $dialog Label '' 25 267 670 29
  $hint=Add-Control $dialog Label '' 25 298 670 44
  [void](Add-Control $dialog Label 'The Smithy may show a lower cap until you advance the story. This save edit does not spend Zenny, armor spheres, or materials.' 25 346 670 52)
  $commit=Add-Control $dialog Button 'Apply to working save' 25 409 410 35
  $cancel=Add-Control $dialog Button 'Cancel' 460 409 235 35;$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel
  $currentDefense=Get-CompanionArmorDefense $profile ([int]$profile.level)
  # A closure has its own module scope; keep the original editor command bindings.
  $targetPointsCommand=Get-Command Get-CompanionArmorTargetPoints -CommandType Function
  $defenseCommand=Get-Command Get-CompanionArmorDefense -CommandType Function
  $formatCommand=Get-Command Format-QuestbookText -CommandType Function
  $textCommand=Get-Command Get-QuestbookText -CommandType Function
  $runCommand=Get-Command Run-Action -CommandType Function
  $sessionCommand=Get-Command Get-CompanionEquipmentSession -CommandType Function
  $newPathCommand=Get-Command New-CompanionArmorWorkingPath -CommandType Function
  $tablesCommand=Get-Command Get-CompanionArmorTables -CommandType Function
  $writerCommand=Get-Command Invoke-CompanionArmorProgress -CommandType Function
  $completeCommand=Get-Command Complete-CompanionEquipmentEdit -CommandType Function
  $refresh={
   $ceiling=if($cap.Checked){[int]$profile.augmented_ceiling}else{[int]$profile.base_ceiling}
   $target=[int]$level.Value
   $known=& $targetPointsCommand $profile $target
   $points.Text=if($known -ge 0){[string]$known}else{'—'}
   $targetDefense=if($known -ge 0 -and $target -le $ceiling){& $defenseCommand $profile $target}else{'—'}
   $defense.Text=& $formatCommand 'Piece defense: {0} → {1}' @($currentDefense,$targetDefense)
   $delta.Text=if($known -ge 0 -and $target -le $ceiling){
    & $formatCommand 'Change in saved upgrade points: {0:+0;-0;0}' @($known-[long]$profile.points)
   }else{''}
   $hint.Text=if($known -lt 0){& $textCommand 'Choose a target within the supported level range.'}elseif($target -gt $ceiling){& $formatCommand 'Ceiling for this cap: level {0}. Lower the target level.' @($ceiling)}else{& $formatCommand 'Ceiling for this cap: level {0}.' @($ceiling)}
   $commit.Enabled=$known -ge 0 -and $target -le $ceiling -and ($target -ne [int]$profile.level -or $cap.Checked -ne [bool]$profile.augmented)
  }.GetNewClosure()
  $level.Add_ValueChanged($refresh)
  $cap.Add_CheckedChanged($refresh)
  $commit.Add_Click({& $runCommand {
   $active=& $sessionCommand
   if($active.Working -ne $save -or $active.Slot -ne $charSlot){throw 'The selected save changed. Reopen the armor editor.'}
   $total=[uint32]0
   if($points.Text -notmatch '^[0-9]+$' -or -not [uint32]::TryParse($points.Text,[ref]$total) -or $total -gt [int]::MaxValue){throw 'Enter a valid cumulative upgrade point total.'}
   $chosenLevel=[int]$level.Value;$raised=[int][bool]$cap.Checked
   $next=& $newPathCommand
   $receipt=& $writerCommand (@('apply',$save)+@(& $tablesCommand)+$identity+@($next,[string]$profile.source_hash,[string]$chosenLevel,[string]$total,[string]$raised))
   if(-not $receipt.verified_roundtrip -or [int]$receipt.slot -ne $charSlot -or [int]$receipt.index -ne $index -or [int]$receipt.id -ne $id -or [int]$receipt.part -ne $part -or [int]$receipt.level -ne $chosenLevel -or [uint32]$receipt.points -ne $total -or [bool]$receipt.augmented -ne [bool]$raised){throw 'Armor edit result did not match the requested values.'}
   & $completeCommand $next
   $dialog.DialogResult='OK';$dialog.Close()
  }}.GetNewClosure())
  Set-QuestbookTree $dialog
  & $refresh
  [void]$dialog.ShowDialog($form)
 } finally {$dialog.Dispose()}
}
function New-CompanionArmorWorkingPath {return Join-Path $script:Session ([guid]::NewGuid().ToString('N')+'.bin')}
$script:armorProgressButton=Add-Control $eqtab Button 'Edit Armor Level / Cap...' 843 365 217 38
$script:armorProgressButton.Enabled=$false
$script:armorProgressButton.Add_Click({Run-Action {Show-CompanionArmorProgress}})
