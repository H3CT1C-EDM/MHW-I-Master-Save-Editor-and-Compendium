﻿$script:MusicIconFont=[Drawing.Font]::new('Segoe UI Symbol',15,[Drawing.FontStyle]::Bold)
$script:QuestbookFonts.Add($script:MusicIconFont)
$script:CompanionMusic=[HuntersCompanion.MusicPlayer]::new((Join-Path $script:Root 'audio\H3CT1C-F4M4S.wav'))
function Open-CompanionLink([string]$url){
 $allowed=@('https://www.soundcloud.com/h3ct1c')
 if($url -notin $allowed){throw 'This link is not available.'}
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$url;$info.UseShellExecute=$true
 [void][Diagnostics.Process]::Start($info)
}
function Show-CompanionAbout {
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'About / Credits';$dialog.ClientSize=[Drawing.Size]::new(900,660);$dialog.StartPosition='CenterParent'
  $heading=Add-Control $dialog Label 'Hunters Companion' 20 15 860 45;$heading.Font=$script:QuestbookTitle
  $description=Add-Control $dialog Label 'Freeware • Noncommercial' 20 65 860 32
  $text=[HuntersCompanion.ParchmentText]::new();$text.SetBounds(20,110,860,470);$text.Font=$script:QuestbookFont;$text.ForeColor=$script:QuestbookColors.Ink;$text.DrawFrame=$false;$dialog.Controls.Add($text)
  $lines=[Collections.Generic.List[string]]::new()
  foreach($key in @('Unofficial fan utility. Not affiliated with, endorsed by, or sponsored by Capcom.','Monster Hunter, Monster Hunter: World, Monster Hunter World: Iceborne, and related marks belong to CAPCOM CO., LTD. and their respective rights holders.','Game developer and publisher: Capcom. Game-derived artwork, icons, text, models, maps, and data remain the property of Capcom and/or their respective owners. All rights reserved.','Original music: H3CT1C — F4M4S. Included with permission from the artist. Rights to original editor artwork and other third-party material remain with their creators.','Acknowledgments')){$lines.Add((Get-QuestbookText $key));$lines.Add('')}
  $credits=@(
   'EnderHDMC / MHWISaveEditor — upstream save editor and save structures.',
   'AsteriskAmpersand — earlier save editor and Python rewrite.',
   'LEGENDFF / mhw-Savecrypt — reference save encryption/decryption.',
   'Synthlight / MHW-Editor — game-table templates and reference editor.',
   'TanukiSharp / MHWSaveUtils / MHWMasterDataUtils — research references; their stated restrictions are not waived by this credit.',
   'pascalbehmenburg / MHW — save-format research reference.',
   'Gathering Hall Studios / Carlos Fernandez / MHWorldData contributors — monster, item, location, translation and image reference data.',
   'Ezekial711 / AniBullet / MonsterHunterWorldModding contributors — file IDs, quest formats and reverse-engineering documentation.',
   'Marcus101RR — save-structure tables. hzh / HTOS, Ahmed / alfizari, Radu / Radu13, Anna, Narugakuruga — acknowledgments retained from the upstream editor.',
   'fresch / mhw_armor_edit, Asterisk, Kiranico, Poedb, MHWG, LartTyler — data-source acknowledgments retained by MHWorldData.',
   'wowodot / Astera Loader / FieldHarvest contributors, SharpPluginLoader contributors — plugin interfaces and bundled FieldHarvest components.',
   'Mbed TLS contributors; kokke / tiny-AES-c; LLVM libc++ / libc++abi and MinGW contributors — bundled component notices are retained.',
   'Blacktuna13; HTPandemoniun; Guiding Lands Monster Quests pack contributors — supplied mod quest definitions. Inclusion in the catalog is not endorsement or installation.',
   'TheCrazyT; Aradi147; ChaosFred; Fusion86 / Cirilla; Ambytes; Emanem; Monster Hunter modding and translation communities — research references and upstream acknowledgments.',
   'Hunterpedia — published map artwork and coordinate reference layers. Original game imagery belongs to Capcom and the respective rights holders.',
   'The Nerd Stash and Monster Hunter Wiki contributors — Castle Schrade siege layout, location references, and World/Iceborne character and equipment renders. GameWith and PowerPyx — field notes and mechanics references.',
   'MHVuze / WorldChunkTool; JodoZT / MHWNoChunk and MHWTexConvertor; Fexty12573 / MHW GUI Editor — native extraction, texture, and layout references.',
   'mastx2024 — SimpleQuestComplete and OneTouchGathering. The original plugins are not bundled.',
   'kassent — Quest Unlocker, a research reference. The mod is not bundled.',
   'PCGamingWiki contributors — Steam save location reference.',
   'lazywalker / zukan-assets; Monster Hunter Wiki / Fandom contributors — additional game icon sources and processing.',
   'Fextralife contributors — map screenshots, builds, and additional World monster renders; Kiranico, Game8, High Ground Gaming, Game Rant and GamesFuze — guide references; Clarity 1.8 contributors — supplied description comparison.',
   'WATERFORCE99 — All Palico Armors Treated Equally (APATE), reference for the built-in compatible export.',
   'H3CT1C — project direction, testing, and original music.'
  )
  foreach($credit in $credits){$lines.Add((Get-QuestbookText $credit));$lines.Add('')}
  $lines.Add('© CAPCOM CO., LTD. ALL RIGHTS RESERVED.')
  $lines.Add((Get-QuestbookText 'Licenses: MHWorldData build code and selected plugins use MIT terms; Mbed TLS and runtime-library notices are preserved; tiny-AES-c is public-domain/Unlicense. Other upstream material may have separate or unverified terms. Read the original notices.'))
  $text.Text=$lines -join "`r`n"
  $licenses=Add-Control $dialog Button 'Third-Party Licenses' 20 600 410 40
  $licenses.Add_Click({Run-Action {$info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=Join-Path $script:Root 'LICENSES';$info.UseShellExecute=$true;[void][Diagnostics.Process]::Start($info)}})
  $close=Add-Control $dialog Button 'Close' 470 600 410 40;$close.DialogResult='Cancel';$dialog.CancelButton=$close
  Set-QuestbookTree $dialog;$heading.Font=$script:QuestbookTitle
  [void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
$form.Add_FormClosed({$script:CompanionMusic.Dispose()})
