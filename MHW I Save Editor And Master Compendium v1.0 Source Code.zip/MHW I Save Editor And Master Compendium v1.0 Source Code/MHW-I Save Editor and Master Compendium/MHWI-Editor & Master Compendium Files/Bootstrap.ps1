﻿$ErrorActionPreference='Stop'
$startupLog=$null
function Write-HunterStartupLog([string]$message){
 if(-not $startupLog){return}
 try{
  [IO.File]::AppendAllText($startupLog,([DateTimeOffset]::Now.ToString('o')+' '+$message+[Environment]::NewLine),[Text.Encoding]::UTF8)
 }catch{}
}
$bootWords=$null
try{
 $code='en';$options=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\options.json'
 if(Test-Path -LiteralPath $options){$settings=Get-Content -LiteralPath $options -Raw -Encoding UTF8|ConvertFrom-Json;if($settings.Language -in @('en','zh-CN','ja','ko','ru')){$code=[string]$settings.Language}}
 $bootWords=Get-Content -LiteralPath (Join-Path $PSScriptRoot ('locales\'+$code+'.json')) -Raw -Encoding UTF8|ConvertFrom-Json
}catch{}
function Get-BootstrapText([string]$text){if($bootWords -and $bootWords.PSObject.Properties[$text.ToLowerInvariant()]){return [string]$bootWords.($text.ToLowerInvariant())};return $text}
$mutex=[Threading.Mutex]::new($false,'Local\MHWI_HuntersCompanion');$owned=$false;$splash=$null;$image=$null
try {
 try{$owned=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$owned=$true}
 if($owned){
  try{
   $logDir=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal'
   [void][IO.Directory]::CreateDirectory($logDir)
   $logPath=Join-Path $logDir 'startup.log'
   [IO.File]::WriteAllText($logPath,'',[Text.Encoding]::UTF8)
   $startupLog=$logPath
  }catch{}
  Write-HunterStartupLog 'Starting Stage 34c.'
 }
 Add-Type -AssemblyName System.Windows.Forms
 Add-Type -AssemblyName System.Drawing
 [Windows.Forms.Application]::EnableVisualStyles()
 if(-not $owned){[void][Windows.Forms.MessageBox]::Show((Get-BootstrapText 'The editor is already starting or running.'),'MHW:I Save Editor & Master Compendium');return}
 $splash=[Windows.Forms.Form]::new();$splash.FormBorderStyle='None';$splash.StartPosition='CenterScreen';$splash.ShowInTaskbar=$true;$splash.Text='MHW:I Save Editor & Master Compendium — Loading';$splash.ClientSize=[Drawing.Size]::new(560,600)
 $image=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'theme\loading-splash.png'))
 $picture=[Windows.Forms.PictureBox]::new();$picture.SetBounds(0,0,560,560);$picture.Image=$image;$picture.SizeMode='Zoom';$splash.Controls.Add($picture)
 $label=[Windows.Forms.Label]::new();$label.SetBounds(0,560,560,40);$label.Text=Get-BootstrapText 'LOADING…';$label.TextAlign='MiddleCenter';$label.BackColor=[Drawing.Color]::FromArgb(32,61,56);$label.ForeColor=[Drawing.Color]::FromArgb(255,244,218);$label.Font=[Drawing.Font]::new('Segoe UI',12,[Drawing.FontStyle]::Bold);$splash.Controls.Add($label)
 $splash.Show();$splash.Refresh();[Windows.Forms.Application]::DoEvents()
 Write-HunterStartupLog 'Splash shown. Initializing editor controls.'
 & (Join-Path $PSScriptRoot 'JewelsEditor.ps1') -LoadingSplash $splash -StartupTrace {param($message) Write-HunterStartupLog $message}
 Write-HunterStartupLog 'Editor closed.'
}catch{
 $failure=$_
 Write-HunterStartupLog ('Startup failed: '+$failure.Exception.ToString()+[Environment]::NewLine+$failure.ScriptStackTrace)
 if($splash -and -not $splash.IsDisposed){$splash.Hide()}
 $details=(Get-BootstrapText 'The editor could not start.')+"`r`n`r`n"+$failure.Exception.Message
 if($startupLog){$details+="`r`n`r`n"+$startupLog}
 if('System.Windows.Forms.MessageBox' -as [type]){
  [void][Windows.Forms.MessageBox]::Show($details,'MHW:I Save Editor & Master Compendium',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)
 }else{[Console]::Error.WriteLine($details)}
 exit 1
}finally{
 if($splash){$splash.Dispose()};if($image){$image.Dispose()};if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()
}
