﻿$script:LanguageStrings=@{};$script:GameStrings=@{};$script:GameContexts=@{};$script:LanguageBusy=$false;$script:LocalizationReady=$false
$script:LocalizedControls=@{};$script:TextOrigins=@{};$script:LocalizationRegistered=[Collections.Generic.HashSet[object]]::new()
function Get-CompanionTextKey([string]$text){return [regex]::Replace($text,'\s+',' ').Trim().ToLowerInvariant()}
function Resolve-CompanionText([string]$text){
 if(-not $text){return $text};if($script:ToolSettings.Language -eq 'en'){return $text};$key=Get-CompanionTextKey $text
 if($script:LanguageStrings.ContainsKey($key)){return [string]$script:LanguageStrings[$key]}
 if($script:GameStrings.ContainsKey($key)){return [string]$script:GameStrings[$key]}
 return $text
}
function Get-QuestbookGameText([string]$text,[string]$scope=''){
 $contextKey=Get-CompanionTextKey $text
 if($scope -and $script:GameContexts.ContainsKey($scope) -and $script:GameContexts[$scope].ContainsKey($contextKey)){return [string]$script:GameContexts[$scope][$contextKey]}
 $key=Get-CompanionTextKey $text
 if($script:GameStrings.ContainsKey($key)){return [string]$script:GameStrings[$key]}
 return $text
}
function Get-QuestbookQuestText($quest,[string]$field='Name'){
 $source=[string]$quest.$field
 if([string]$quest.Key -ne ('game:'+[string]$quest.Id)){return $source}
 return Get-QuestbookGameText $source ('quest:'+[string]$quest.Id)
}
function Get-CompanionListText([string]$text){return ((@($text -split ',\s*'|ForEach-Object {Resolve-CompanionText $_})) -join ', ')}
function Render-CompanionEntry($entry){
 if($entry -is [string]){return Get-QuestbookText $entry}
 $key=[string]$entry.Key;$arguments=[object[]]@($entry.Args);$format=Resolve-CompanionText $key
 $indexes=@()
 if($key -match '^\{0\} \[(ID|equipment|item)'){$indexes=@(0)}
 elseif($key.StartsWith('  Group ')){$indexes=@(1)}
 elseif($key.StartsWith('Family:')){$indexes=@(0,2,3,4,5)}
 elseif($key.StartsWith('Ingredient reward:') -or $key.StartsWith('Objective:')){$indexes=@(0)}
 elseif($key.StartsWith('Game ID:')){$indexes=@(1,2)}
 elseif($key -eq '{0}: {1} -> {2}' -or $key -eq '{0}: type {1}, ID {2}'){$indexes=@(0)}
 elseif($key.StartsWith('Quest {0}: flag')){$indexes=@(1,2)}
 elseif($key.StartsWith('{0} [ID {1}]') -and $key.Contains('Ingredient reward:')){$indexes=@(0,2)}
 elseif($key.StartsWith('Saved completion flag:')){$indexes=@(0)}
 foreach($i in $indexes){if($i -lt $arguments.Count -and $arguments[$i] -is [string]){$arguments[$i]=Get-CompanionListText $arguments[$i]}}
 try{return [string]::Format([Globalization.CultureInfo]::CurrentCulture,$format,$arguments)}catch{return [string]::Format([Globalization.CultureInfo]::InvariantCulture,$key,[object[]]@($entry.Args))}
}
function Format-QuestbookText([string]$key,[object[]]$arguments){
 $entry=[pscustomobject]@{Key=$key;Args=[object[]]@($arguments)};$text=Render-CompanionEntry $entry
 $script:TextOrigins[$text]=$entry
 return $text
}
function Get-QuestbookText([string]$text){
 if($null -eq $text){return ''}
 if($script:TextOrigins.ContainsKey($text)){return Render-CompanionEntry $script:TextOrigins[$text]}
 $translated=Resolve-CompanionText $text
 if($translated -ne $text){$script:TextOrigins[$translated]=[pscustomobject]@{Key=$text;Args=@()};return $translated}
 if($text.Contains("`n")){return ((@($text -split '\r?\n'|ForEach-Object {Get-QuestbookText $_})) -join "`r`n")}
 if($text -match '^(Review Weapon Edits)( \(\d+\))$'){return (Resolve-CompanionText $Matches[1])+$Matches[2]}
 if($text -match '^(.*?) \[ID (\d+); ([^\]]+)\]$'){return (Get-QuestbookGameText $Matches[1])+' ['+(Resolve-CompanionText 'ID')+' '+$Matches[2]+'; '+(Resolve-CompanionText $Matches[3])+']'}
 if($text.StartsWith('Audio playback failed:')){return (Resolve-CompanionText 'Audio playback failed:')+' '+$text.Substring('Audio playback failed:'.Length).Trim()}
 if($text -match '^(.*?) — (.+)$'){return $Matches[1]+' — '+(Resolve-CompanionText $Matches[2])}
 return $text
}
function Register-CompanionControl($control){
 if(-not $script:LocalizationRegistered.Add($control)){return}
 $translatable=$control -is [Windows.Forms.Button] -or $control -is [Windows.Forms.Label] -or $control -is [Windows.Forms.CheckBox] -or $control -is [Windows.Forms.TabPage] -or $control -is [Windows.Forms.Form] -or $control -is [HuntersCompanion.ParchmentText] -or ($control -is [Windows.Forms.TextBox] -and $control.ReadOnly)
 if($translatable){
  $script:LocalizedControls[$control]=if($script:TextOrigins.ContainsKey($control.Text)){$script:TextOrigins[$control.Text]}else{[string]$control.Text}
  $control.Add_TextChanged({param($sender,$event)
   if(-not $script:LanguageBusy){$entry=if($script:TextOrigins.ContainsKey($sender.Text)){$script:TextOrigins[$sender.Text]}else{[string]$sender.Text};$script:LocalizedControls[$sender]=$entry;$translated=Render-CompanionEntry $entry;if($sender -is [Windows.Forms.Button]){$translated=$translated.ToUpperInvariant()};if($sender.Text -ne $translated){$script:LanguageBusy=$true;try{$sender.Text=$translated}finally{$script:LanguageBusy=$false}}}
  })
  $display=Render-CompanionEntry $script:LocalizedControls[$control];if($control -is [Windows.Forms.Button]){$display=$display.ToUpperInvariant()}
  $previousBusy=$script:LanguageBusy;$script:LanguageBusy=$true
  try{$control.Text=$display}finally{$script:LanguageBusy=$previousBusy}
 }
 $control.Add_Disposed({param($sender,$event) [void]$script:LocalizedControls.Remove($sender);[void]$script:LocalizationRegistered.Remove($sender)})
 foreach($child in $control.Controls){Register-CompanionControl $child}
}
function Register-QuestbookLanguage($parent){Register-CompanionControl $parent}
function Apply-QuestbookLanguage {
 $code=$script:ToolSettings.Language;if($code -notin @('en','zh-CN','ja','ko','ru')){$code='en'}
 $data=Get-Content -LiteralPath (Join-Path $script:Root ('locales\'+$code+'.json')) -Raw -Encoding UTF8|ConvertFrom-Json
 $script:LanguageStrings=@{};foreach($property in $data.PSObject.Properties){$script:LanguageStrings[(Get-CompanionTextKey $property.Name)]=[string]$property.Value}
 $script:GameStrings=@{};$path=Join-Path $script:Root ('locales\game-'+$code+'.json')
 if(Test-Path -LiteralPath $path){$game=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json;foreach($property in $game.PSObject.Properties){$script:GameStrings[$property.Name]=[string]$property.Value}}
 $script:GameContexts=@{};$contextPath=Join-Path $script:Root ('locales\contexts-'+$code+'.json')
 if(Test-Path -LiteralPath $contextPath){$contexts=Get-Content -LiteralPath $contextPath -Raw -Encoding UTF8|ConvertFrom-Json;foreach($scope in $contexts.PSObject.Properties){$values=@{};foreach($value in $scope.Value.PSObject.Properties){$values[$value.Name]=[string]$value.Value};$script:GameContexts[$scope.Name]=$values}}
 $script:LanguageBusy=$true
 try{
  foreach($control in @($script:LocalizedControls.Keys)){if(-not $control.IsDisposed){$display=Render-CompanionEntry $script:LocalizedControls[$control];$control.Text=if($control -is [Windows.Forms.Button]){$display.ToUpperInvariant()}else{$display}}}
  for($i=0;$i -lt $tabs.TabCount;$i++){$script:QuestbookNavigationButtons[$i].Text=$tabs.TabPages[$i].Text.ToUpperInvariant()}
  if($script:QuestbookTips){$script:QuestbookTips.RefreshLanguage()}
  if(Get-Command Update-QuestEligibilityLabels -ErrorAction SilentlyContinue){Update-QuestEligibilityLabels}
  if(Get-Command Set-CompanionUserTooltips -ErrorAction SilentlyContinue){Set-CompanionUserTooltips};Update-CompanionGuideLanguage;Set-CompanionPauseLanguage;if($equipList -and $equipList.SelectedItem -and (Get-Command Show-CompanionEquipmentEffects -ErrorAction SilentlyContinue)){Show-CompanionEquipmentEffects $equipList.SelectedItem};if($questList -and $questList.SelectedItems.Count -and (Get-Command Show-QuestDetails -ErrorAction SilentlyContinue)){Show-QuestDetails};$form.Invalidate($true)
 }finally{$script:LanguageBusy=$false}
}
function Initialize-QuestbookLocalization {
 Register-CompanionControl $form
 [HuntersCompanion.Messages]::Translate=[Func[string,string]]{param($text) Get-QuestbookText $text}
 $script:LocalizationReady=$true;Apply-QuestbookLanguage
}

function Get-QuestbookFileFilter([string]$filter){
 $parts=$filter.Split('|');for($i=0;$i -lt $parts.Count;$i+=2){$parts[$i]=Get-QuestbookText $parts[$i]};return $parts -join '|'
}
