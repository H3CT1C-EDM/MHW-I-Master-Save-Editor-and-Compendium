﻿function Show-CompanionTutorial([string]$topic='start'){
 $code=$script:ToolSettings.Language;if($code -notin @('en','zh-CN','ja','ko','ru')){$code='en'}
 $help=Get-Content -LiteralPath (Join-Path $script:Root ('help\'+$code+'.json')) -Raw -Encoding UTF8|ConvertFrom-Json
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text='MHWI:MC Guide';$dialog.ClientSize=[Drawing.Size]::new(980,720);$dialog.StartPosition='CenterParent'
  $heading=Add-Control $dialog Label 'MHWI:MC Guide' 20 15 940 45;$heading.Font=$script:QuestbookTitle
  $topics=Add-Control $dialog ComboBox '' 20 75 940 40;$topics.DropDownStyle='DropDownList';$topics.DisplayMember='Title';$topics.DropDownWidth=940
  foreach($section in $help.Sections){[void]$topics.Items.Add($section)}
  $body=[HuntersCompanion.ParchmentText]::new();$body.SetBounds(20,135,940,500);$body.Font=$script:QuestbookFont;$body.ForeColor=$script:QuestbookColors.Ink;$body.DrawFrame=$false;$dialog.Controls.Add($body)
  $topics.Add_SelectedIndexChanged({$body.Text=[string]$topics.SelectedItem.Body}.GetNewClosure())
  $index=0;for($i=0;$i -lt $topics.Items.Count;$i++){if($topics.Items[$i].Id -eq $topic){$index=$i;break}};$topics.SelectedIndex=$index
  $close=Add-Control $dialog Button 'Close' 340 660 300 40;$close.DialogResult='Cancel';$dialog.CancelButton=$close
  Set-QuestbookTree $dialog;$heading.Font=$script:QuestbookTitle;Enable-QuestbookCombo $topics 'book';[void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
