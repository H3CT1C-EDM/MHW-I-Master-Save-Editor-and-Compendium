$script:BatchPresetPath=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal/batch-presets.json'
$script:BuiltInBatchPresets=[ordered]@{
 'Healing supplies'=@(1,2,3,4,5,6,7)
 'Capture and traps'=@(59,60,64,77,80,81,84)
 'Crafting ingredients'=@(32,33,38,39,42,43,46,52,77)
 'Mining materials'=@(205,206,207,208,209,1030)
 'Bone materials'=@(226,232,236,237,238,239)
 'Common jewels'=@(730,739,741,764,808)
}
function Read-BatchPresets([string]$path){
 if(-not (Test-Path -LiteralPath $path)){return}
 if((Get-Item -LiteralPath $path).Length -gt 524288){throw 'The Batch Add presets file is too large.'}
 $data=Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
 if($data.version -ne 1 -or @($data.presets).Count -gt 50){throw 'The Batch Add presets file is invalid.'}
 $names=@{}
 foreach($entry in @($data.presets)){
  $name=[string]$entry.name
  $ids=@($entry.ids)
  if($name -ne $name.Trim() -or $name.Length -lt 1 -or $name.Length -gt 60 -or $name -match '[\x00-\x1f]' -or $names.ContainsKey($name) -or $ids.Count -lt 1 -or $ids.Count -gt 128){throw 'The Batch Add presets file is invalid.'}
  $seen=@{}
  foreach($id in $ids){
   $n=0
   if(-not [int]::TryParse([string]$id,[ref]$n) -or $n -lt 1 -or $seen.ContainsKey($n)){throw 'The Batch Add presets file is invalid.'}
   $seen[$n]=$true
  }
  $names[$name]=$true
  [pscustomobject]@{Name=$name;Ids=[int[]]$ids;BuiltIn=$false}
 }
}
function Write-BatchPresets([string]$path,$presets){
 if(@($presets).Count -gt 50){throw 'You can save up to 50 custom presets.'}
 $dir=Split-Path -Parent $path
 [void][IO.Directory]::CreateDirectory($dir)
 $temp=Join-Path $dir ([guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $data=[ordered]@{version=1;presets=@(foreach($preset in $presets){@{name=$preset.Name;ids=@($preset.Ids)}})}
  [IO.File]::WriteAllText($temp,($data|ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
  $null=Read-BatchPresets $temp
  if(Test-Path -LiteralPath $path){[IO.File]::Replace($temp,$path,(Join-Path $dir 'batch-presets.previous.json'))}else{[IO.File]::Move($temp,$path)}
 }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Add-BatchPresetItems($pending,$catalog,$ids){
 $new=[Collections.Generic.List[object]]::new()
 $seen=@{}
 foreach($id in $ids){
  if(-not $catalog.ContainsKey([int]$id)){throw (Format-QuestbookText 'Item ID {0} is unavailable for Batch Add. The queue was not changed.' @($id))}
  $key=[string]$id
  if(-not $pending.Contains($key) -and -not $seen.ContainsKey($key)){$new.Add($catalog[[int]$id]);$seen[$key]=$true}
 }
 if($pending.Count+$new.Count -gt 128){throw 'You can queue up to 128 different item IDs.'}
 foreach($item in $new){$pending.Add([string]$item.Id,$item)}
}
function Get-SelectedBatchPreset($ui){
 $index=$ui.Preset.SelectedIndex
 if($index -ge 0 -and $index -lt $ui.Presets.Count){return $ui.Presets[$index]}
}
function Update-BatchPresetChoices($ui){
 $ui.Preset.Items.Clear()
 $ui.Presets=@(foreach($name in $script:BuiltInBatchPresets.Keys){
  [pscustomobject]@{Label=(Get-QuestbookText $name);Name=$name;Ids=$script:BuiltInBatchPresets[$name];BuiltIn=$true}
 })
 try{
  $ui.Presets+=@(foreach($p in @(Read-BatchPresets $script:BatchPresetPath)){
   [pscustomobject]@{Label=$p.Name;Name=$p.Name;Ids=$p.Ids;BuiltIn=$false}
  })
 }finally{
  foreach($p in $ui.Presets){[void]$ui.Preset.Items.Add([string]$p.Label)}
  $ui.Preset.SelectedIndex=0
 }
}
function Save-JournalBatchPreset($ui){
 if(-not $ui.Pending.Count){throw 'Queue items before saving a preset.'}
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Save Batch Add preset';$dialog.ClientSize=[Drawing.Size]::new(500,135);$dialog.StartPosition='CenterParent'
  [void](Add-Control $dialog Label 'Name this preset. It saves the item list only.' 15 10 470 30)
  $name=Add-Control $dialog TextBox '' 15 48 470 30;$name.MaxLength=60
  $save=Add-Control $dialog Button 'Save preset' 310 90 175 32;$save.DialogResult='OK';$dialog.AcceptButton=$save
  Set-QuestbookTree $dialog;$dialog.ActiveControl=$name
  if($dialog.ShowDialog($ui.Dialog) -ne 'OK'){return}
  $label=$name.Text.Trim()
  if(-not $label -or $label -match '[\x00-\x1f]'){throw 'Enter a valid preset name.'}
  $existing=@(Read-BatchPresets $script:BatchPresetPath)
  if($script:BuiltInBatchPresets.Contains($label) -or $label -in @($existing | ForEach-Object Name)){throw 'A preset with that name already exists.'}
  $custom=[pscustomobject]@{Name=$label;Ids=@($ui.Pending.Values | ForEach-Object Id)}
  Write-BatchPresets $script:BatchPresetPath ($existing+@($custom))
  Update-BatchPresetChoices $ui;$ui.Preset.SelectedIndex=$ui.Preset.Items.Count-1
 }finally{$dialog.Dispose()}
}
function Remove-JournalBatchPreset($ui){
 $preset=Get-SelectedBatchPreset $ui
 if(-not $preset -or $preset.BuiltIn){return}
 $message=Format-QuestbookText 'Delete the preset "{0}"? Your current queue will stay as it is.' @($preset.Name)
 if([HuntersCompanion.Messages]::Show($message,'Delete preset','YesNo','Question') -ne 'Yes'){return}
 $remaining=@(Read-BatchPresets $script:BatchPresetPath | Where-Object Name -ne $preset.Name)
 Write-BatchPresets $script:BatchPresetPath $remaining
 Update-BatchPresetChoices $ui
}
