﻿$script:PauseProcess=$null
$script:PauseSessionKey=''
function Test-QuestbookPauseRunning {
 if(-not $script:PauseProcess){return $false}
 try{$script:PauseProcess.Refresh();return -not $script:PauseProcess.HasExited}catch{return $false}
}
function Stop-QuestbookPause {
 if(-not (Test-QuestbookPauseRunning)){return}
 if(-not $script:PauseProcess.CloseMainWindow() -or -not $script:PauseProcess.WaitForExit(3500)){
  throw 'The pause controller is still running. Use its Resume and Disable button before closing the editor or changing the pause key.'
 }
 $script:PauseProcess.Dispose();$script:PauseProcess=$null;$script:PauseSessionKey=''
}
function Get-QuestbookPauseGamePath {
 $folder=if($gamePath -and $gamePath.Text){$gamePath.Text.Trim()}else{$script:ToolSettings.GamePath}
 if(-not $folder){$folder=Find-GameFolder}
 if(-not $folder){throw 'Choose the game folder in Game Data Exports before enabling offline pause.'}
 $path=[IO.Path]::GetFullPath((Join-Path $folder 'MonsterHunterWorld.exe'))
 if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw 'Choose the folder containing MonsterHunterWorld.exe.'}
 return $path
}
function Set-QuestbookPauseSession([bool]$enabled,[string]$key){
 if($key -notin @('F11','F6','F7','Ctrl+Shift+P','Ctrl+Alt+P')){throw 'Select a supported pause key.'}
 if(-not $enabled){Stop-QuestbookPause;return}
 $game=Get-QuestbookPauseGamePath
 $identity=$game+'|'+$key
 if((Test-QuestbookPauseRunning) -and $script:PauseSessionKey -eq $identity){return}
 Stop-QuestbookPause
 $helper=Join-Path $script:Root 'tools\QuestbookPause.exe'
 if(-not (Test-Path -LiteralPath $helper)){throw 'The offline pause controller is missing. Extract the full package again.'}
 $statusDir=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MHWIFieldJournal\Pause'
 [void][IO.Directory]::CreateDirectory($statusDir)
 $status=Join-Path $statusDir ([guid]::NewGuid().ToString('N')+'.txt')
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$helper;$info.UseShellExecute=$false
 $info.Arguments='--owner '+$PID+' --game "'+$game+'" --key "'+$key+'" --status "'+$status+'" --offline-confirmed yes --lang "'+$script:ToolSettings.Language+'"'
 $process=[Diagnostics.Process]::Start($info)
 $script:PauseProcess=$process;$script:PauseSessionKey=$identity
 $deadline=[DateTime]::UtcNow.AddSeconds(4)
 do{
  $process.Refresh()
  if($process.HasExited){
   $reason=if(Test-Path -LiteralPath $status){[IO.File]::ReadAllText($status)}else{'The pause controller could not start (exit '+$process.ExitCode+').'}
   $process.Dispose();$script:PauseProcess=$null;$script:PauseSessionKey='';throw $reason
  }
  if((Test-Path -LiteralPath $status) -and [IO.File]::ReadAllText($status).StartsWith('Ready.')){return}
  Start-Sleep -Milliseconds 50
 }while([DateTime]::UtcNow -lt $deadline)
 Stop-QuestbookPause
 throw 'The pause controller did not report ready. Check its window before trying again.'
}
function Set-CompanionPauseLanguage {
 if(-not (Test-QuestbookPauseRunning)){return}
 $script:PauseProcess.Refresh();$codes=@('en','zh-CN','ja','ko','ru');$index=[Math]::Max(0,[array]::IndexOf($codes,$script:ToolSettings.Language))
 [HuntersCompanion.NativeUi]::SetPauseLanguage($script:PauseProcess.MainWindowHandle,$index)
}
