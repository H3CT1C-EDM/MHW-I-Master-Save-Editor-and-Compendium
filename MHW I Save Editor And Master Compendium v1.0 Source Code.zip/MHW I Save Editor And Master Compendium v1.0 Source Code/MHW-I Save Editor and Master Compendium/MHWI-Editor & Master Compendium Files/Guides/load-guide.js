(function(){'use strict';
window.GAME_TEXT={};window.GAME_SCOPES={};
var loaded=Object.create(null),pending=Object.create(null);
function load(path,done){
 if(loaded[path]){done(true);return;}
 if(pending[path]){pending[path].push(done);return;}
 pending[path]=[done];
 var script=document.createElement('script');
 function finish(ok){
  var callbacks=pending[path];delete pending[path];
  if(ok)loaded[path]=true;
  else if(script.parentNode)script.parentNode.removeChild(script);
  callbacks.forEach(function(cb){cb(ok);});
 }
 script.onload=function(){finish(true);};
 script.onerror=function(){finish(false);};
 script.src=path;document.head.appendChild(script);
}
window.GuideLoad=function(files,done){
 function next(i){if(i===files.length){done(true);return;}load(files[i],function(ok){if(ok)next(i+1);else done(false);});}
 next(0);
};
}());
