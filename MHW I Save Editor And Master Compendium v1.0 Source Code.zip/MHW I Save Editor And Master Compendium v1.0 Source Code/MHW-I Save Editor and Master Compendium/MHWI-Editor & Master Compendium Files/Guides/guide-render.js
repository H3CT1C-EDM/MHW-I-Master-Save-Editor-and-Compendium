(function(){'use strict';
function escape(x){return String(x==null?'':x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function t(s){return window.GuideI18n?window.GuideI18n.text(s):s;}
function records(kind,x){
 var d=window.HC_RENDERS||{}, exact=d.pieces&&d.pieces[x.id];
 if(kind==='monster')return {images:(d.monsters||{})[x.id],label:'Monster model render'};
 if(kind==='Weapon')return {images:(d.weapons||{})[x.id],label:'Weapon model render'};
 if(kind==='Armor Sets')return {images:(d.sets||{})[x.name_en],label:'Full armor set render'};
 if(kind==='Armor'){
  if(exact)return {images:exact,label:'Armor piece render'};
  var matched=(x.sets||[]).filter(function(n){return !!(d.sets||{})[n];});
  if(matched.length===1)return {images:d.sets[matched[0]],label:'Full set shown',set:matched[0]};
 }
 return {};
}
function hero(kind,x,icon,heading,name,extra){
 var r=records(kind,x), rows=r.images?(Array.isArray(r.images)?r.images:[r.images]):[];
 rows=rows.filter(function(v){return /^images\/renders\/\d+\.png$/.test(v.path);});
 var lead='<div class="render-identity">'+(icon?'<img class="render-icon" alt="" src="'+escape(icon)+'">':'')+'<div><div class="eyebrow">'+escape(heading)+'</div><h1>'+escape(name)+'</h1>'+(extra||'')+'</div></div>';
 if(!rows.length)return '<div class="hero guide-hero">'+lead+'</div>';
 var label=t(r.label)+(r.set?' · '+t(r.set):'');
 return '<div class="hero guide-hero render-hero">'+lead+'<figure class="render-portrait" aria-label="'+escape(label)+'"><div class="render-images">'+rows.map(function(v){
  var variant=v.variant&&v.variant!=='Unspecified'?t(v.variant):'';
  return '<div class="render-variant"><div class="render-frame"><img class="guide-model" src="'+escape(v.path)+'" alt="'+escape(name+' · '+label+(variant?' · '+variant:''))+'"></div>'+(variant?'<span>'+escape(variant)+'</span>':'')+'</div>';
 }).join('')+'</div><figcaption>'+escape(label)+'</figcaption></figure></div>';
}
window.GuideRender={hero:hero,records:records};
}());
