(function(){'use strict';
var elements=['fire','water','thunder','ice','dragon'], ailments=['poison','sleep','paralysis','blast','stun'];
var physical=['cut','impact','shot','ko'];
function title(s){return s.charAt(0).toUpperCase()+s.slice(1);}
function value(s){return s===null||s===undefined||s===''?'—':s;}
function build(m,mode,rank,itemCell){
 var hitKeys=mode==='element-hitzones'?elements:physical;
 if(mode==='hitzones'||mode==='element-hitzones')return {columns:['Part / State'].concat(hitKeys.map(function(k){return k==='ko'?'KO':title(k);})),rows:(m.hitzones||[]).map(function(r){return [r.hitzone_en].concat(hitKeys.map(function(k){return value(r[k]);}));})};
 if(mode==='drops')return {columns:['Rank','Material','Method','Quantity','Chance'],rows:(m.rewards||[]).filter(function(r){return !rank||r.rank===rank;}).map(function(r){return [value(r.rank),itemCell(r.item_en),value(r.condition_en),value(r.stack),value(r.percentage)==='—'?'—':r.percentage+'%'];})};
 var keys=mode==='ailments'?ailments:elements;
 return {columns:['Form'].concat(keys.map(title)),rows:(m.weaknesses||[]).map(function(r){return [value(r.alt_description||r.form)].concat(keys.map(function(k){return value(r[k]);}));})};
}
window.MonsterCompare={build:build};
}());
