(function(){'use strict';var code='en',templates=[],working=false;
function key(s){return String(s||'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'').toLowerCase();}
function regex(s){return s.replace(/[.*+?^$()|[\]\\]/g,'\\$&');}
function literal(text){var normalized=key(text),ui=(window.UI_TEXT||{})[code]||{},game=(window.GAME_TEXT||{})[code]||{};var direct=ui[normalized]||game[normalized];if(direct)return direct;var parts=String(text).split(', ');if(parts.length>1)return parts.map(literal).join(', ');return text;}
function translate(text){var direct=literal(text);if(direct!==text)return direct;var normalized=String(text||'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'');
 for(var i=0;i<templates.length;i++){var item=templates[i],m=item.re.exec(normalized);if(m){var values={};item.args.forEach(function(n,j){values[n]=literal(m[j+1]);});return item.output.replace(/\{(\d+)\}/g,function(s,n){return values[n]===undefined?s:values[n];});}}
 var bullets=normalized.split(' · ');if(bullets.length>1)return bullets.map(translate).join(' · ');
 var colon=normalized.indexOf(': ');if(colon>0){var label=normalized.slice(0,colon),value=normalized.slice(colon+2);if(literal(label)!==label)return literal(label)+': '+literal(value);}
 var parts=normalized.split(' — ');if(parts.length===2)return parts[0]+' — '+literal(parts[1]);
 return text;}
function compile(){templates=[];var en=(window.UI_TEXT||{}).en||{},ui=(window.UI_TEXT||{})[code]||{};
 Object.keys(en).forEach(function(k){var source=en[k];if(!/\{\d+\}/.test(source)||!/[a-z]{3}/i.test(source))return;var args=[],pattern='',last=0,match,re=/\{(\d+)\}/g;while((match=re.exec(source))){pattern+=regex(source.slice(last,match.index))+'(.+?)';args.push(match[1]);last=match.index+match[0].length;}pattern+=regex(source.slice(last));templates.push({re:new RegExp('^'+pattern+'$','i'),args:args,output:ui[k]||source});});
 templates.sort(function(a,b){return b.re.source.length-a.re.source.length;});}
function node(n){if(n.nodeType===3){if(!n.parentNode||/^(SCRIPT|STYLE|TEXTAREA)$/.test(n.parentNode.tagName))return;var parent=n.parentNode,explicit=parent.getAttribute&&parent.getAttribute('data-source'),scope=parent.getAttribute&&parent.getAttribute('data-context');var source=explicit!==null&&explicit!==undefined?explicit:(n.hcSource===undefined?n.nodeValue:n.hcSource);n.hcSource=source;var scoped=scope&&((((window.GAME_SCOPES||{})[code]||{})[scope]||{})[key(source)]);var translated=scoped||translate(source);if(n.nodeValue!==translated)n.nodeValue=translated;return;}
 if(n.nodeType!==1)return;['placeholder','title','aria-label'].forEach(function(a){if(n.hasAttribute(a)){var prop='hc_'+a.replace(/-/g,'_');if(n[prop]===undefined)n[prop]=n.getAttribute(a);var result=String(n[prop]).split('\n').map(translate).join('\n');if(n.getAttribute(a)!==result)n.setAttribute(a,result);}});var children=n.childNodes;for(var i=0;i<children.length;i++)node(children[i]);}
function render(){if(working)return;working=true;try{node(document.body);}finally{working=false;}}
window.GuideI18n={set:function(language){code=language||'en';compile();render();},text:translate,key:key,render:render};
var observer=new MutationObserver(function(records){if(working)return;working=true;try{records.forEach(function(record){Array.prototype.forEach.call(record.addedNodes,node);});}finally{working=false;}});observer.observe(document.body,{childList:true,subtree:true});compile();render();
}());
