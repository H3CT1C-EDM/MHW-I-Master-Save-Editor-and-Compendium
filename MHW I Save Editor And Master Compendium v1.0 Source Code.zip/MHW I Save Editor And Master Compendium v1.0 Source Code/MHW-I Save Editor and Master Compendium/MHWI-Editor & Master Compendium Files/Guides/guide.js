(function(){'use strict';
var D=window.COMPENDIUM,lang='en',selectedMonster=null,selectedItem=null,scale=1,panX=15,panY=15,drag=null,itemPage=0,itemPageSize=100,itemsReady=false,mapsReady=false,activeTab='monsters',compareStarted=false,wantedLanguage='en',itemById=Object.create(null),itemSearchCache=Object.create(null);
function el(id){return document.getElementById(id);}function esc(s){return String(s===undefined||s===null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function val(id){return el(id).value;}function lower(s){return String(s||'').toLowerCase();}function has(s,q){return lower(s).indexOf(lower(q))>=0;}function array(a){return a||[];}function context(scope,english){var dict=(((window.GAME_SCOPES||{})[lang]||{})[scope]||{}),key=String(english||'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'').toLowerCase();return dict[key]||english;}
function local(scope,english){var result=context(scope,english);return result!==english?result:(window.GuideI18n?GuideI18n.text(english):english);}
function searchable(scope,english){return String(english||'')+' '+local(scope,english);}
function text(obj,field){var suffix=lang==='zh-CN'?'zh':lang,english=(obj.translations&&obj.translations[field+'_en'])||obj[field+'_en']||'',scope=(obj.habitats?'monster_':'item_')+(field==='description'?'description':'name'),translated=context(scope,english);return translated!==english?translated:(obj.translations&&obj.translations[field+'_'+suffix])||obj[field+'_'+suffix]||english;}
function hunterNotes(m){var notes=(window.HUNTER_NOTES||{})[lower(m.name_en)],note=notes&&(notes[lang]||notes.en);return note?'<section class="hunterNotes"><h2>Hunter’s Notes</h2><p>'+esc(note)+'</p></section>':'';}

function itemImage(i){return i.image||'../theme/inventory_ink.png';}
var itemImages=D.itemIcons;
function itemCell(name){return {itemName:name};}
function cell(value){if(value&&typeof value==='object'&&Object.prototype.hasOwnProperty.call(value,'itemName')){if(!value.itemName)return '—';var item=itemImages[lower(value.itemName)],label=local('item_name',value.itemName);return '<span class="item-ref"><img alt="" src="'+esc(item||'../theme/inventory_ink.png')+'">'+esc(label)+'</span>';}return esc(value===''?'—':value);}
function unique(values){var seen={},r=[];values.forEach(function(v){if(v&&!seen[v]){seen[v]=true;r.push(v);}});return r.sort();}
function options(id,values,label){el(id).innerHTML='<option value="">'+esc(label)+'</option>'+unique(values).map(function(v){return '<option value="'+esc(v)+'">'+esc(v)+'</option>';}).join('');}
function debounce(fn){var timer;return function(){clearTimeout(timer);timer=setTimeout(fn,140);};}
function table(columns,rows){if(!rows.length)return '<p class="empty">No records supplied for this section.</p>';return '<div class="tablewrap"><table><thead><tr>'+columns.map(function(c){return '<th>'+esc(c)+'</th>';}).join('')+'</tr></thead><tbody>'+rows.map(function(r){return '<tr>'+r.map(function(c){return '<td>'+cell(c)+'</td>';}).join('')+'</tr>';}).join('')+'</tbody></table></div>';}
function pills(values){return '<div class="pills">'+values.map(function(v){return '<span class="pill">'+esc(v)+'</span>';}).join('')+'</div>';}
function image(m,large){return m.iconAvailable===false?'../theme/hunter_ink.png':'images/monster/'+encodeURIComponent(m.id)+'.png';}
window.guideLocal=local;window.showGuideTab=showTab;window.selectGuideItem=function(id){
 showTab('items');
 function show(){var item=itemById[String(id)];if(!item)return;el('itemSearch').value='';el('categoryFilter').value='';el('rarityFilter').value='';el('itemRegion').value='';itemPage=Math.floor(D.items.indexOf(item)/itemPageSize);selectedItem=item;fillItems();}
 if(itemsReady)show();else GuideLoad(['items-data.js','native-reference-data.js','item-quest-sources.js'],function(ok){if(ok&&activeTab==='items')show();});
};
function activate(name){Array.prototype.forEach.call(document.querySelectorAll('.page'),function(p){p.className='page'+(p.id===name?' active':'');});}
function loading(){el('guideLoadingStatus').textContent=GuideI18n.text('Loading guide…');activate('guideLoading');}
function failed(name){if(activeTab===name)el('guideLoadingStatus').textContent=GuideI18n.text('This guide could not load. Select its tab to retry.');}
function showTab(name){
 activeTab=name;
 Array.prototype.forEach.call(document.querySelectorAll('#tabs button'),function(b){b.className=b.getAttribute('data-tab')===name?'active':'';});
 if(name==='items'&&!itemsReady){
  loading();GuideLoad(['items-data.js','native-reference-data.js','item-quest-sources.js'],function(ok){
   if(!ok){failed(name);return;}
   if(!itemsReady){itemsReady=true;D.items.forEach(function(i){itemById[String(i.id)]=i;});fillItems();}
   if(activeTab===name)activate(name);
  });return;
 }
 if(!el(name)){
  loading();GuideLoad(['reference-data.js','guide-articles.js','guiding-data.js','native-reference-data.js','offline-tables.js','reference.js'],function(ok){
   if(!ok){failed(name);return;}
   if(activeTab===name){activate(name);window.openGuideReference(name);}
  });return;
 }
 activate(name);
 if(name==='monsters'&&val('monsterViewMode')==='compare')renderMonsterCompare();
 if(name==='maps'){if(!mapsReady){mapsReady=true;map();}else fitMap();}
 if(window.openGuideReference)window.openGuideReference(name);
}
Array.prototype.forEach.call(document.querySelectorAll('#tabs button'),function(b){b.onclick=function(){showTab(b.getAttribute('data-tab'));};});
function compareMonsterOptions(){
 var rows=D.monsters.slice().sort(function(a,b){return text(a,'name').localeCompare(text(b,'name'));});
 ['compareLeft','compareRight'].forEach(function(id){
  var control=el(id),old=control.value;
  control.innerHTML=rows.map(function(m){return '<option value="'+esc(m.id)+'" data-source="'+esc(m.name_en)+'" data-context="monster_name">'+esc(text(m,'name'))+'</option>';}).join('');
  if(old)control.value=old;
 });
}
function renderMonsterCompare(){
 var mode=val('compareMode'),rank=val('compareRank');
 el('compareRank').disabled=mode!=='drops';
 var note=(mode==='hitzones'||mode==='element-hitzones')?'Hitzone rows retain their listed part and state. Scroll each table for all values.':mode==='drops'?'Drop chances are listed per method and rank. They are not combined.':'Weakness ratings run from 0 to 3. Each form has its own row.';
 // Replace the text node so the language observer tracks the new English source.
 el('compareNote').innerHTML=esc(note);
 ['compareLeft','compareRight'].forEach(function(id){
  var m=D.monsters.filter(function(row){return String(row.id)===val(id);})[0];
  if(!m){el(id+'Detail').innerHTML='';return;}
  var result=MonsterCompare.build(m,mode,rank,itemCell);
  el(id+'Detail').innerHTML='<div class="hero"><img alt="" src="'+esc(image(m,true))+'"><h2>'+esc(text(m,'name'))+'</h2></div>'+table(result.columns,result.rows);
 });
}
function setMonsterView(){
 var comparing=val('monsterViewMode')==='compare';
 el('monsterSingle').className='monster-view'+(comparing?'':' active');
 el('monsterCompare').className='monster-view'+(comparing?' active':'');
 if(!comparing)return;
 compareMonsterOptions();
 if(!compareStarted){
  compareStarted=true;
  if(selectedMonster)el('compareLeft').value=String(selectedMonster.id);
  if(val('compareRight')===val('compareLeft')&&el('compareRight').options.length>1){
   el('compareRight').selectedIndex=el('compareLeft').selectedIndex===0?1:0;
  }
 }
 renderMonsterCompare();
}
el('monsterViewMode').onchange=setMonsterView;
['compareLeft','compareRight','compareMode','compareRank'].forEach(function(id){el(id).onchange=renderMonsterCompare;});
function monsterMatches(m){var query=val('monsterSearch'),weak=val('weaknessFilter'),hab=val('habitatFilter');return has(text(m,'name')+' '+m.name_en+' '+JSON.stringify(m.ailments)+' '+JSON.stringify(m.habitats)+' '+m.habitats.map(function(h){return local('location',h.map_en);}).join(' '),query)&&(!val('sizeFilter')||m.size===val('sizeFilter'))&&(!hab||m.habitats.some(function(h){return h.map_en===hab;}))&&(!weak||m.weaknesses.some(function(w){return Number(w[weak])===3;}));}
function fillMonsters(){var rows=D.monsters.filter(monsterMatches);el('monsterCount').innerText=rows.length+' monsters';el('monsterList').innerHTML=rows.map(function(m){return '<button class="result'+(selectedMonster===m?' selected':'')+'" data-id="'+esc(m.id)+'"><img alt="" src="'+image(m,false)+'">'+esc(text(m,'name'))+'</button>';}).join('')||'<p class="empty">No matching monsters.</p>';Array.prototype.forEach.call(el('monsterList').querySelectorAll('button'),function(b){b.onclick=function(){selectMonster(b.getAttribute('data-id'));};});if(rows.indexOf(selectedMonster)<0){if(rows.length)selectMonster(rows[0].id);else el('monsterDetail').innerHTML='<p class="empty">Clear a filter to broaden the search.</p>';}}
function bindPanels(parent){Array.prototype.forEach.call(parent.querySelectorAll('.subnav button'),function(b){b.onclick=function(){Array.prototype.forEach.call(parent.querySelectorAll('.subnav button'),function(x){x.className=x===b?'active':'';});Array.prototype.forEach.call(parent.querySelectorAll('.panel'),function(x){x.className='panel'+(x.id===b.getAttribute('data-panel')?' active':'');});};});}
function selectMonster(id){var m=D.monsters.filter(function(x){return String(x.id)===String(id);})[0];if(!m)return;selectedMonster=m;Array.prototype.forEach.call(el('monsterList').querySelectorAll('button'),function(b){b.className='result'+(b.getAttribute('data-id')===String(id)?' selected':'');});
var ailments=[];m.ailments.forEach(function(a){Object.keys(a).forEach(function(k){if(k!=='base_name_en'&&a[k]&&a[k]!=='0')ailments.push(k.replace(/_/g,' ')+(a[k]!=='1'?' ('+a[k]+')':''));});});
var weakness=m.weaknesses.map(function(w){return '<h3>'+esc(w.form||'Normal')+(w.alt_description?' · '+esc(w.alt_description):'')+'</h3><div class="bars">'+['fire','water','thunder','ice','dragon','poison','sleep','paralysis','blast','stun'].map(function(k){var n=w[k];return '<div class="bar">'+esc(k.charAt(0).toUpperCase()+k.slice(1))+'<div class="rating" title="'+esc(n)+' of 3">'+(n===''?'Unknown':new Array(Math.max(0,Math.min(3,Number(n)))+1).join('★')+new Array(4-Math.max(0,Math.min(3,Number(n)))).join('☆'))+'</div></div>';}).join('')+'</div>';}).join('')||'<p class="empty">Weakness ratings are unavailable.</p>';
var tactics=[];['cut','impact','shot'].forEach(function(k){var rows=m.hitzones.filter(function(h){return h[k]!=='';}).sort(function(a,b){return Number(b[k])-Number(a[k]);});if(rows.length)tactics.push('Highest listed '+k+' hitzone: '+rows[0].hitzone_en+' ('+rows[0][k]+'). Values may depend on the listed body state.');});
var traps=['pitfall_trap','shock_trap','vine_trap'].map(function(k){return k.replace(/_/g,' ')+': '+(m[k]===''||m[k]===undefined?'Unknown':m[k]);});
el('monsterDetail').innerHTML=GuideRender.hero('monster',m,image(m,true),'Field Guide · '+m.size,text(m,'name'),pills(unique(m.habitats.map(function(h){return local('location',h.map_en);}))))+'<div class="subnav"><button class="active" data-panel="overview">Overview</button><button data-panel="hitzones">Hitzones &amp; Breaks</button><button data-panel="drops">Drops</button><button data-panel="habitats">Locations</button></div><div id="overview" class="panel active"><p class="lede">'+esc(text(m,'description')||'No ecology description is supplied.')+'</p><h2>Weaknesses</h2><p class="note">0–3 stars: higher ratings indicate greater susceptibility. Forms can differ; hitzones provide more detail.</p>'+weakness+hunterNotes(m)+'<h2>Combat Notes</h2><p>'+esc(ailments.length?'Inflicted effects: '+unique(ailments).join(', ')+'.':'No inflicted-effect records are supplied.')+'</p><p>'+esc(traps.join(' · '))+'</p><h3>Hitzone-Based Planning</h3>'+tactics.map(function(t){return '<p>'+esc(t)+'</p>';}).join('')+'<p class="note">These planning notes are derived from hitzone values. A complete named attack list and move-by-move strategy are not supplied by this dataset.</p></div><div id="hitzones" class="panel"><h2>Hitzone Values</h2>'+table(['Part / State','Cut','Impact','Shot','Fire','Water','Thunder','Ice','Dragon','KO'],m.hitzones.map(function(h){return [h.hitzone_en,h.cut,h.impact,h.shot,h.fire,h.water,h.thunder,h.ice,h.dragon,h.ko];}))+'<h2>Part Breaks</h2>'+table(['Part','Flinch','Wound','Sever','Extract'],m.breaks.map(function(x){return [x.part_en,x.flinch,x.wound,x.sever,x.extract];}))+'</div><div id="drops" class="panel"><h2>Materials &amp; Rewards</h2><select id="dropRank" aria-label="Reward rank"><option value="">All ranks</option><option value="LR">LR</option><option value="HR">HR</option><option value="MR">MR</option></select><div id="dropTable"></div></div><div id="habitats" class="panel"><h2>Possible Locations</h2>'+table(['Region','Start','Roaming Areas','Rest'],m.habitats.map(function(h){return [local('location',h.map_en),h.start_area,h.move_area,h.rest_area];}))+'<p class="note">Possible habitats are not guaranteed spawns. Quest and expedition conditions may change availability.</p></div>';
function drops(){el('dropTable').innerHTML=table(['Rank','Material','Method','Quantity','Chance'],m.rewards.filter(function(r){return !val('dropRank')||r.rank===val('dropRank');}).map(function(r){return [r.rank,itemCell(r.item_en),r.condition_en,r.stack,r.percentage===''?'Unknown':r.percentage+'%'];}));}drops();el('dropRank').onchange=drops;bindPanels(el('monsterDetail'));}
function itemMatches(i){var q=val('itemSearch'),cat=val('categoryFilter'),rar=val('rarityFilter'),region=val('itemRegion');
 if((cat&&i.category!==cat)||(rar&&String(i.rarity)!==rar)||(region&&!i.gathering.some(function(g){return g.base_name_en===region;})&&!array(i.gathering_tables).some(function(g){return g[0]===region;})))return false;
 if(!q)return true;
 var id=String(i.id),v=itemSearchCache[id];
 if(!v){v=text(i,'name')+' '+i.name_en+' '+array(i.game_ids).join(' ')+' '+JSON.stringify(i.rewards)+' '+i.rewards.map(function(r){return local('monster_name',r.base_name_en);}).join(' ')+' '+i.gathering.map(function(g){return local('location',g.base_name_en);}).join(' ');itemSearchCache[id]=v;}
 return has(v,q);
}
function itemColor(i){return i.annotation?(i.annotation.kind==='mod'?'yellow':'red'):'';}
function fillItems(){var rows=D.items.filter(itemMatches);itemPage=Math.max(0,Math.min(itemPage,Math.ceil(rows.length/itemPageSize)-1));el('itemCount').innerText=rows.length+' item records · Page '+(itemPage+1)+' / '+Math.max(1,Math.ceil(rows.length/itemPageSize));el('itemList').innerHTML=rows.slice(itemPage*itemPageSize,(itemPage+1)*itemPageSize).map(function(i){return '<button class="result '+itemColor(i)+(selectedItem===i?' selected':'')+'" title="'+esc(i.annotation?i.annotation.reason:(i.imageMatchByClass?'Reference icon matched by type and color; no PC inventory ID mapping is supplied.':''))+'" data-id="'+esc(i.id)+'"><img alt="" src="'+esc(itemImage(i))+'">'+esc(text(i,'name'))+'</button>';}).join('')||'<p class="empty">No matching items.</p>';Array.prototype.forEach.call(el('itemList').querySelectorAll('button'),function(b){b.onclick=function(){selectItem(b.getAttribute('data-id'));};});var pageRows=rows.slice(itemPage*itemPageSize,(itemPage+1)*itemPageSize);
 if(pageRows.length)selectItem((pageRows.indexOf(selectedItem)>=0?selectedItem:pageRows[0]).id);
 else{selectedItem=null;el('itemDetail').innerHTML='<p class="empty">Clear a filter to broaden the search.</p>';}}
function gatheringYieldTables(i){
 var rows=array(i.gathering_tables);
 if(!rows.length)return '';
 return '<h2>Gathering Yield Table References</h2><p class="note">Hunterpedia yield table IDs do not identify map areas or pin positions.</p>'+table(['Region','Table ID','Rank','Quantity','Chance'],rows.map(function(r){return [local('location',r[0]),r[1],r[2],r[3],r[4]];}));
}
function itemQuestSources(i){
 var index=window.ITEM_QUEST_SOURCES||{},rows=[],seen={};
 array(i.game_ids).forEach(function(id){array(index[id]).forEach(function(r){
  var key=r.join('|');if(seen[key])return;seen[key]=true;
  rows.push([local('quest:'+r[0],r[1]),r[0],r[2],r[3],r[4]]);
 });});
 if(!rows.length)return '';
 return '<h2>Quest Reward Sources</h2><p class="note">These are listed reward-pool entries. They do not guarantee a drop or show its odds.</p>'+table(['Quest','Game ID','Rank','Pool ID','Quantity'],rows);
}
function selectItem(id){var i=itemById[String(id)];if(!i)return;selectedItem=i;Array.prototype.forEach.call(el('itemList').querySelectorAll('button'),function(b){var row=itemById[b.getAttribute('data-id')];b.className='result '+itemColor(row)+(b.getAttribute('data-id')===String(id)?' selected':'');});el('itemDetail').innerHTML='<div class="hero"><img class="item-hero" alt="" src="'+esc(itemImage(i))+'"><div><div class="eyebrow">Item Reference</div><h1 class="'+itemColor(i)+'">'+esc(text(i,'name'))+'</h1>'+pills([i.category||'Unclassified','Rarity '+(i.rarity||'Unknown')].concat(array(i.game_ids).map(function(x){return 'Game ID '+x;})))+'</div></div>'+(i.annotation?'<p class="warning" title="'+esc(i.annotation.reason)+'">'+esc(i.annotation.reason)+'</p>':'')+'<p class="lede">'+esc(text(i,'description')||(i.category==='Furniture'?roomDescription(i)||GuideI18n.text('Room decoration or customization reference. Availability depends on the room and game unlocks; this entry does not prove ownership.'):(i.annotation?GuideI18n.text(i.annotation.reason):'No description is supplied for this game record.')))+'</p>'+table(['Carry Limit','Buy Price','Sell Price','Account Points'],[[i.carry_limit||'Unknown',i.buy_price||'Not listed',i.sell_price||'Not listed',i.points||'Not listed']])+'<h2>Gathering Sources</h2>'+table(['Region','Area','Rank','Quantity','Chance','Nodes'],i.gathering.map(function(g){return [local('location',g.base_name_en),g.area,g.rank||'Not specified',g.stack,g.percentage===''?'Unknown':g.percentage+'%',g.nodes];}))+gatheringYieldTables(i)+'<h2>Monster Sources</h2>'+table(['Monster','Rank','Method','Quantity','Chance'],i.rewards.map(function(r){return [local('monster_name',r.base_name_en),r.rank,r.condition_en,r.stack,r.percentage===''?'Unknown':r.percentage+'%'];}))+itemQuestSources(i)+safariSources(i)+'<h2>Crafting</h2>'+table(['First Ingredient','Second Ingredient','Quantity'],i.crafting.map(function(x){return [itemCell(x.first),itemCell(x.second),x.quantity];}))+'<p class="note">Table prices do not prove shop availability. Zero is a table value, not a promise that an item can be purchased.</p>'+'<h2>Used in Recipes</h2>'+table(['Result','First Ingredient','Second Ingredient','Quantity'],array(i.used_in_recipes).map(function(x){return [itemCell(x.result),itemCell(x.first),itemCell(x.second),x.quantity];}))+'<h2>Equipment Crafting Uses</h2>'+table(['Category','Equipment','Quantity','Method'],array(i.used_in_equipment).slice(0,100).map(function(x){return [x.kind,local('equipment_name',x.name),x.quantity,x.method];}))+(array(i.used_in_equipment).length>100?'<p class="note">'+esc(GuideI18n.text('Showing the first 100 equipment recipes.'))+'</p>':'')+(i.clarity_sources?'<h2>Confirmed Source Highlights</h2><p>'+esc(i.clarity_sources.monsters.map(function(n){return local('monster_name',n);}).concat(i.clarity_sources.regions.map(function(n){return local('location',n);})).join(' · '))+'</p>':'');}
var safariByItem;
function roomDescription(i){var data=window.NATIVE_REFERENCE_DATA,kind=data&&data.roomTypes[String(i.id)];return kind?GuideI18n.text('Room customization: {0}.').replace('{0}',GuideI18n.text(kind)):'';}
function safariSources(i){
 var data=window.NATIVE_REFERENCE_DATA;
 if(!data)return '';
 if(!safariByItem){
  safariByItem={};
  data.safari.forEach(function(pool){pool.rewards.forEach(function(r){(safariByItem[r.guide_id]||(safariByItem[r.guide_id]=[])).push([pool,r]);});});
 }
 var entries=safariByItem[String(i.id)];
 return entries?'<h2>Tailraider Safari Sources</h2>'+table(['Region','Rank','Route','Quantity','Weight'],entries.map(function(pair){return [GuideI18n.text(pair[0].region),GuideI18n.text(pair[0].rank),pair[0].stars+'★ · '+GuideI18n.text(pair[0].route),pair[1].quantity,pair[1].weight];})):'';
}
function areaNumbers(raw){var a=[];String(raw||'').replace(/(\d+)\s*[～~–-]\s*(\d+)/g,function(m,x,y){for(var n=Number(x);n<=Math.min(Number(y),30);n++)a.push(n);return '';}).replace(/\d+/g,function(n){a.push(Number(n));return '';});return unique(a.map(String));}
function transform(){el('mapCanvas').style.transform='translate('+panX+'px,'+panY+'px) scale('+scale+')';}
var MAP_CAMPS={
 'Hoarfrost Reach':{'1':'Southern Camp','5':'Western Camp','7':'Central Camp','12':'Shipwreck Camp','15':'Northeast Camp'},
 'Guiding Lands':{'1':'Western Camp','3':'Eastern Camp'},
 'Castle Schrade':{'1':'Base Camp'}
};
var MAP_ZONES={
 'Everstream':[['','Siege site','Zorah Magdaros']],
 'Great Ravine':[['','Siege route','Zorah Magdaros']],
 'Arena':[['','Arena floor','']],
 'Special Arena':[['','Hunting arena','']],
 'Confluence of Fates':[['','Encounter grounds',"Xeno'jiiva"]],
 'Caverns of El Dorado':[['1','Caverns entrance','Kulve Taroth'],['2','First combat chamber','Kulve Taroth'],['3','Volcanic chamber','Kulve Taroth'],['4','Final chamber','Kulve Taroth']],
 'Origin Isle':[['0','Camp approach',''],['','Encounter grounds','Shara Ishvalda']],
 'Guiding Lands':[['','Forest region',''],['','Wildspire region',''],['','Coral region',''],['','Rotten region',''],['','Volcanic region',''],['','Tundra region','']],
 'Secluded Valley':[['1','Upper level',"Safi'jiiva"],['2','Middle level',"Safi'jiiva"],['3','Lower level',"Safi'jiiva"]],
 'Seliana Supply Cache':[['','Defense arena','Velkhana']],
 'Castle Schrade':[['1','Base camp',''],['2','Castle ruins','Fatalis']]
};
function mapLocation(name){
 var base=D.locations.filter(function(l){return l.name_en===name;})[0];
 if(!base)return null;
 var camps=base.camps.slice(),known=MAP_CAMPS[name]||{};
 Object.keys(known).forEach(function(n){if(!camps.some(function(c){return String(c.area)===n;}))camps.push({name_en:known[n],area:n});});
 return {name_en:name,camps:camps,gathering:base.gathering,monsters:base.monsters};
}
function zoneCards(loc){
 var query=val('mapSearch'),zones=(MAP_ZONES[loc.name_en]||[]).map(function(z){return {area:z[0],name:z[1],monster:z[2],camp:false};});
 loc.camps.forEach(function(c){if(!zones.some(function(z){return z.area===String(c.area)&&z.name.toLowerCase()===c.name_en.toLowerCase();}))zones.push({area:String(c.area),name:c.name_en,monster:'',camp:true});});
 return zones.filter(function(z){return !query||has(z.name+' '+z.monster+' '+local('monster_name',z.monster)+' Area '+z.area,query);}).map(function(z){
  var title=(z.area?GuideI18n.text('Area')+' '+z.area+' · ':'')+GuideI18n.text(z.name),monster=z.monster&&local('monster_name',z.monster);
  var row=z.monster&&D.monsters.filter(function(m){return m.name_en===z.monster;})[0];
  return '<div class="zone-card"><span class="zone-icon" aria-hidden="true">'+(z.camp?'▲':row?'<img alt="" src="'+esc(image(row,true))+'">':z.monster?'⚔':'◆')+'</span><span><strong>'+esc(title)+'</strong>'+(monster?'<br>'+esc(monster):'')+'</span></div>';
 }).join('');
}
function drawAreaIndex(loc){
 var cards=zoneCards(loc),canvas=el('mapCanvas');
 canvas.style.width='800px';canvas.style.height='520px';
 canvas.innerHTML='<div class="zone-index"><h2>'+esc(local('location',loc.name_en))+'</h2><p>'+esc(GuideI18n.text('Area index · schematic, not to scale'))+'</p><div class="zone-grid">'+(cards||'<p class="empty">'+esc(GuideI18n.text('No matching areas.'))+'</p>')+'</div></div>';
}
function areaAtlas(){var loc=mapLocation(val('mapSelect'));if(!loc)return;if(MAP_ZONES[loc.name_en]){drawAreaIndex(loc);el('mapCount').innerText=local('location',loc.name_en)+' · '+GuideI18n.text('Area Index');return;}var areas={},query=val('mapSearch');function area(n){if(!areas[n])areas[n]={g:[],m:[],c:[]};return areas[n];}
loc.gathering.forEach(function(g){area(g.area).g.push(g);});loc.camps.forEach(function(c){area(c.area).c.push(c);});loc.monsters.forEach(function(m){areaNumbers(m.move_area+','+m.start_area+','+m.rest_area).forEach(function(n){area(n).m.push(m);});});
var keys=Object.keys(areas).sort(function(a,b){return Number(a)-Number(b);}),shown=0,html='';keys.forEach(function(n){var a=areas[n],search='Area '+n+' '+JSON.stringify(a)+' '+a.m.map(function(m){return searchable('monster_name',m.name);}).join(' ')+' '+a.g.map(function(g){return searchable('item_name',g.item);}).join(' ')+' '+a.c.map(function(c){return local('location',c.name_en);}).join(' ');if(query&&!has(search,query))return;var x=shown%4*310,y=Math.floor(shown/4)*255;shown++;html+='<div class="map-area" style="left:'+x+'px;top:'+y+'px"><h3>Area '+esc(n)+'</h3>';a.m.forEach(function(m){if(query&&!has(searchable('monster_name',m.name)+' Area '+n,query)&&!has('Area '+n,query))return;html+='<span class="marker" title="'+esc(local('monster_name',m.name)+' · '+GuideI18n.text('Start')+': '+(m.start_area||GuideI18n.text('Unknown'))+' · '+GuideI18n.text('Roaming Areas')+': '+m.move_area+' · '+GuideI18n.text('Rest')+': '+(m.rest_area||GuideI18n.text('Unknown')))+'"><img alt="Monster" src="'+image(m,false)+'">'+esc(local('monster_name',m.name))+'</span>';});if(a.g.length)html+='<span class="marker" title="'+esc(a.g.map(function(g){return local('item_name',g.item)+' · '+(g.rank||'All listed ranks')+' · '+g.percentage+'% · '+g.nodes+' nodes';}).join('\n'))+'"><span class="gatherIcon">◆</span>'+a.g.length+' gathering entries</span>';a.c.forEach(function(c){html+='<span class="marker" title="'+esc(c.name_en)+'"><span class="campIcon">▲</span>'+esc(c.name_en)+'</span>';});html+='</div>';});el('mapCanvas').innerHTML=html||'<p class="empty">No numbered area records are available for this selection. See the region notes below.</p>';el('mapCanvas').style.height=Math.ceil(shown/4)*255+'px';el('mapCount').innerText=local('location',loc.name_en)+' · '+shown+' areas · '+loc.gathering.length+' gathering rows · '+loc.monsters.length+' monster habitat rows';panX=15;panY=15;scale=.8;transform();}
function fitMap(){var canvas=el('mapCanvas'),viewport=el('mapViewport'),width=parseFloat(canvas.style.width)||1280,height=parseFloat(canvas.style.height)||800;scale=Math.max(.15,Math.min(2.5,Math.min((viewport.clientWidth-24)/width,(viewport.clientHeight-24)/height)));panX=Math.max(12,(viewport.clientWidth-width*scale)/2);panY=Math.max(12,(viewport.clientHeight-height*scale)/2);transform();}
function mapPins(loc,art){
 var query=val('mapSearch');
 return (art.pins||[]).map(function(pin){
  var area=String(pin.area),areaLabel=GuideI18n.text('Area')+' '+area;
  var monsters=loc.monsters.filter(function(m){return areaNumbers([m.move_area,m.start_area,m.rest_area].join(',')).indexOf(area)>=0;});
  var gathering=loc.gathering.filter(function(g){return String(g.area)===area;});
  var camps=loc.camps.filter(function(c){return String(c.area)===area;});
  var names=unique(monsters.map(function(m){return local('monster_name',m.name);}));
  var camp=pin.kind==='camp',caption=camp?camps.map(function(c){return local('location',c.name_en);}).join(', '):areaLabel;
  if(camp&&!caption)return '';
  var details=camp?caption+' · '+areaLabel:areaLabel+' — '+(names.length?names.join(', '):GuideI18n.text('No monster habitat records.'));if(pin.areaReference)details+=' · '+GuideI18n.text('Area reference, not a spawn point');if(!camp&&gathering.length)details+=' · '+unique(gathering.map(function(g){return local('item_name',g.item);})).slice(0,12).join(', ');
  var hay=details+' Area '+area+' '+monsters.map(function(m){return searchable('monster_name',m.name);}).join(' ')+' '+gathering.map(function(g){return searchable('item_name',g.item);}).join(' ');
  return '<button type="button" class="mapPin'+(camp?' campPin':'')+(query&&!has(hay,query)?' subdued':'')+'" style="left:'+pin.x+'px;top:'+pin.y+'px" title="'+esc(details)+'" aria-label="'+esc(details)+'" data-map-pin="true">'+(camp?'▲':area+(gathering.length?'<span class="map-gather" aria-hidden="true">◆</span>':''))+'</button>';
 }).join('');
}
// Area-level references are kept separate from calibrated map pins.
var MAP_FIELD_NOTES={
 'Wildspire Waste':[
  ['Area 5 · Floors 2 and 3','The same area number is used on both floors. The upper part includes gathering for Ivy, Honey and Flashbugs. A capture confirms the upper floor, but its clean artwork and pins are still missing.']
 ],
 'Hoarfrost Reach':[
  ['Area 17 · Floor 2','The southwest area is marked on Floor 2 using a matching in-game map capture. The marker identifies the area, not a spawn point.']
 ],
 'Guiding Lands':[
  ['Camps · Areas 1 and 3','First Western Camp is in Area 1. Eastern Camp is in Area 3. The published map layer shows gathering positions, without assigning unverified loot or availability.']
 ],
 'Secluded Valley':[
  ['Area 1 · Upper level','Use the two environmental rockfalls or the breakable ground to create openings against Safi’jiiva.'],
  ['Area 2 · Middle level','Use standing rock cover against Sapphire of the Emperor. The Point of No Return recon stops here.'],
  ['Area 3 · Lower level','In the Safi’jiiva siege, cover can break and gas pockets can be detonated. Alatreon quests use a different version of the lowest arena.']
 ],
 'Castle Schrade':[
  ['Area 1 · Base camp','The starting camp overlooks the arena.'],
  ['Area 2 · Castle ruins','The opening cannons are on the southwest platform. Later, the Roaming Ballista runs on the east side, and the barricade and Dragonator are toward the north.']
 ]
};
function mapFieldNotes(name,query){
 var rows=(MAP_FIELD_NOTES[name]||[]).filter(function(row){return !query||has(name+' '+row.join(' '),query);});
 if(!rows.length)return '';
 return '<h3>'+esc(GuideI18n.text('Field Notes'))+'</h3>'+table(['Area','Notes'],rows.map(function(row){return row.map(function(text){return GuideI18n.text(text);});}));
}
var SCHRADE_LANDMARKS=[
 ['Dragonator',400,150],['Phase 3 barricade',400,81],['Northeast cannon',548,183],
 ['Western ballista',195,279],['Eastern binder',600,259],['Roaming Ballista track',541,328],
 ['Opening cannons',282,480],['Southeast ballista',548,464]
];
function drawSchradeSchematic(query){
 var canvas=el('mapCanvas');
 canvas.style.width='800px';canvas.style.height='620px';
 canvas.innerHTML='<img class="geographic-map" draggable="false" alt="'+esc(GuideI18n.text('Castle Schrade siege schematic, not to scale'))+'" src="images/maps/schrade-siege-layout.svg" width="800" height="620">'+SCHRADE_LANDMARKS.map(function(p){
  var name=GuideI18n.text(p[0]),hidden=query&&!has(p[0]+' '+name+' Area 2',query);
  return '<button type="button" class="mapPin'+(hidden?' subdued':'')+'" data-map-pin="true" style="left:'+p[1]+'px;top:'+p[2]+'px" title="'+esc(name)+'" aria-label="'+esc(name)+'">◆</button>';
 }).join('');
 el('mapCount').innerHTML=esc(GuideI18n.text('Castle Schrade siege schematic, not to scale'));
}
function getMapLayers(name){
 var layers=((window.MAP_ART||{})[name]||[]).slice(), extra=(window.MAP_REFERENCE_LAYERS||{})[name];
 if(extra){if(extra.defaultArt)layers.unshift(extra);else layers.push(extra);}
 return layers;
}
function mapReferencePins(art,query){
 return (art.referencePins||[]).map(function(pin){
  var camp=pin.kind==='camp', name=camp?local('location',pin.label):GuideI18n.text(pin.label);
  var zone=pin.area?GuideI18n.text('Area')+' '+pin.area:pin.zone||'', parts=[name,zone,pin.asset||''].filter(Boolean);
  var details=parts.join(' · '),missed=query&&!has([pin.label,details].join(' '),query);
  return '<button type="button" class="mapPin '+(camp?'campPin':'referenceNode')+(missed?' subdued':'')+'" data-map-pin="true"'+(!camp&&!query||missed?' tabindex="-1"':'')+' style="left:'+pin.left+'%;top:'+pin.top+'%" title="'+esc(details)+'" aria-label="'+esc(details)+'">'+(camp?'▲':'')+'</button>';
 }).join('');
}
function map(){var name=val('mapSelect'),loc=mapLocation(name);if(!loc)return;var artwork=getMapLayers(name),floor=el('mapFloor'),same=floor.getAttribute('data-region')===name,previous=same?floor.value:'';floor.setAttribute('data-region',name);el('mapDisplay').options[2].disabled=name!=='Castle Schrade';if(!same)el('mapDisplay').value=artwork.some(function(a){return !!(a.pins||a.defaultArt);})?'art':'atlas';
 floor.innerHTML=artwork.map(function(a,i){return '<option value="'+i+'">'+esc(GuideI18n.text(a.label))+'</option>';}).join('');floor.value=previous;if(floor.selectedIndex<0&&artwork.length)floor.selectedIndex=0;floor.disabled=val('mapDisplay')!=='art'||artwork.length<2;
 if(val('mapDisplay')==='siege'&&name==='Castle Schrade'){drawSchradeSchematic(val('mapSearch'));}
 else if(val('mapDisplay')==='art'&&artwork.length){var a=artwork[Number(floor.value)||0];el('mapCanvas').style.width=a.width+'px';el('mapCanvas').style.height=a.height+'px';el('mapCanvas').innerHTML='<img class="geographic-map" draggable="false" alt="'+esc(local('location',name)+' — '+GuideI18n.text(a.label))+'" src="'+esc(a.path)+'" width="'+a.width+'" height="'+a.height+'">'+mapPins(loc,a)+mapReferencePins(a,val('mapSearch'));el('mapCount').innerText=local('location',name)+' · '+GuideI18n.text(a.label)+' · '+loc.gathering.length+' gathering rows · '+loc.monsters.length+' monster habitat rows'+(a.referencePins?' · '+a.referencePins.length+' '+GuideI18n.text('Published pins'):'');}
 else{el('mapCanvas').style.width='1280px';areaAtlas();if(!artwork.length&&val('mapDisplay')==='art')el('mapCount').innerText+=' · '+GuideI18n.text('Map artwork not yet available');}
 var info=(window.REGION_INFO||{})[name],query=val('mapSearch'),matches=[];loc.gathering.forEach(function(g){if(!query||has(searchable('item_name',g.item)+' Area '+g.area,query))matches.push(local('item_name',g.item)+' — '+GuideI18n.text('Area')+' '+g.area);});
 var quests=((window.MAP_QUESTS||{})[name]||[]).filter(function(q){return !query||has(q.name_en+' '+local('quest:'+q.id,q.name_en)+' '+q.monsters.map(function(m){return searchable('monster_name',m);}).join(' '),query);});
 var currentLayer=val('mapDisplay')==='art'&&artwork[Number(floor.value)||0];
 el('mapRegionInfo').innerHTML=(currentLayer&&currentLayer.source?'<p class="map-credit">Map source: Hunterpedia · Capcom game artwork</p>':'')+(info?'<h2>'+esc(local('location',name))+'</h2><p>'+esc(GuideI18n.text(info))+'</p>':'')+mapFieldNotes(name,query)+(val('mapDisplay')==='siege'&&name==='Castle Schrade'?'<h3>Siege landmarks</h3><p>'+esc(SCHRADE_LANDMARKS.map(function(p){return GuideI18n.text(p[0]);}).filter(function(p){return !query||has(p,query);}).join(' · '))+'</p>':'')+'<h3>'+esc(GuideI18n.text('Camps'))+'</h3>'+table(['Camp','Area'],loc.camps.map(function(c){return [local('location',c.name_en),c.area];}))+(query?'<h3>'+esc(GuideI18n.text('Gathering Sources'))+'</h3><p>'+esc(unique(matches).join(' · ')||GuideI18n.text('No matching gathering records. Try Area Details for habitats and camps.'))+'</p>':'')+'<h3>'+esc(GuideI18n.text('Quest References'))+'</h3>'+table(['Quest','Rank','Monsters'],quests.map(function(q){return [local('quest:'+q.id,q.name_en),q.rank,q.monsters.map(function(m){return local('monster_name',m);}).join(', ')];}));fitMap();}
window.REGION_INFO={
 'Ancient Forest':'A multi-level forest with shoreline, caverns, canopy, and wyvern nesting grounds.',
 'Wildspire Waste':'A desert and wetland region with dunes, marshes, and underground caverns.',
 'Coral Highlands':'Vertical coral formations connected by slopes, vines, and updrafts.',
 'Rotten Vale':'A layered bone valley with hazardous effluvium in its lower areas.',
 "Elder's Recess":'A volcanic and crystalline region; hot areas may require heat protection.',
 'Hoarfrost Reach':'An Iceborne hunting region with snowfields, caves, and hot springs. Cold conditions consume stamina faster.',
 'Guiding Lands':'An endgame expedition region with separate biome levels. Monsters and materials depend on biome level and tempered state.',
 'Everstream':'A special Zorah Magdaros quest location with siege facilities; standard expedition gathering records do not apply.',
 'Great Ravine':'A story location used during the Zorah Magdaros encounter; not a normal free-roaming expedition region.',
 'Arena':'An arena challenge location. Equipment, items, and objectives may be fixed by the selected arena quest.',
 'Special Arena':'A quest arena with siege facilities and environmental traps. Quest availability depends on progression and captures.',
 'Confluence of Fates':"Xeno'jiiva's special quest location, with separate combat phases.",
 'Caverns of El Dorado':'The Kulve Taroth quest region. Siege and Master Rank quest rules differ; access and monsters are quest-specific.',
 'Origin Isle':"Shara Ishvalda's special quest location. The arena changes between combat phases.",
 'Secluded Valley':"Safi'jiiva's multi-stage quest region. Siege and recon objectives have different rules.",
 'Seliana Supply Cache':'A fortified special quest location with siege equipment; available tools depend on the quest phase.',
 'Castle Schrade':'The Fatalis quest arena. Siege facilities and safe areas change as the encounter progresses.'
};
el('mapDisplay').onchange=map;el('mapFloor').onchange=map;
el('zoomIn').onclick=function(){scale=Math.min(2.5,scale*1.2);transform();};el('zoomOut').onclick=function(){scale=Math.max(.3,scale/1.2);transform();};el('fitMap').onclick=fitMap;var viewport=el('mapViewport');viewport.onmousedown=function(e){e=e||window.event;var target=e.target||e.srcElement;if(target&&(target.getAttribute('data-map-pin')||(target.parentNode&&target.parentNode.getAttribute&&target.parentNode.getAttribute('data-map-pin'))))return;drag={x:e.clientX,y:e.clientY,px:panX,py:panY};viewport.className='dragging';if(viewport.setCapture)viewport.setCapture();e.preventDefault();};document.onmousemove=function(e){if(!drag)return;e=e||window.event;panX=drag.px+e.clientX-drag.x;panY=drag.py+e.clientY-drag.y;transform();};document.onmouseup=function(){drag=null;viewport.className='';if(viewport.releaseCapture)viewport.releaseCapture();};viewport.addEventListener('wheel',function(e){var old=scale;scale=Math.max(.3,Math.min(2.5,scale*(e.deltaY<0?1.12:1/1.12)));var r=viewport.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;panX=x-(x-panX)*scale/old;panY=y-(y-panY)*scale/old;transform();e.preventDefault();},false);
options('habitatFilter',D.locations.map(function(x){return x.name_en;}),'All habitats');options('categoryFilter',D.itemCategories,'All categories');options('itemRegion',D.locations.map(function(x){return x.name_en;}),'All regions');for(var r=1;r<=12;r++)el('rarityFilter').innerHTML+='<option>'+r+'</option>';el('mapSelect').innerHTML=D.locations.map(function(l){return '<option value="'+esc(l.name_en)+'">'+esc(l.name_en)+'</option>';}).join('');
['monsterSearch','sizeFilter','weaknessFilter','habitatFilter'].forEach(function(id){el(id)[id==='monsterSearch'?'oninput':'onchange']=debounce(fillMonsters);});['itemSearch','categoryFilter','itemRegion','rarityFilter'].forEach(function(id){el(id)[id==='itemSearch'?'oninput':'onchange']=debounce(function(){itemPage=0;fillItems();});});el('mapSelect').onchange=map;el('mapSearch').oninput=debounce(map);
window.setGuideBackground=function(w,h,x,y){var sx=w/995,sy=h/724;document.body.style.backgroundSize=(1024*sx)+'px '+(736*sy)+'px';document.body.style.backgroundPosition=(-x-11*sx)+'px '+(-y-6*sy)+'px';document.body.style.backgroundRepeat='no-repeat';};
function refreshLocationOptions(){['habitatFilter','itemRegion','mapSelect'].forEach(function(id){Array.prototype.forEach.call(el(id).options,function(option){if(option.value){option.setAttribute('data-source',option.value);option.setAttribute('data-context','location');option.text=local('location',option.value);}});});}
window.setGuideLanguage=function(code){
  wantedLanguage=/^(en|ja|ko|ru|zh-CN)$/.test(code)?code:'en';
  var requested=wantedLanguage;
  GuideLoad(requested==='en'?[]:['language-'+requested+'.js'],function(ok){
   if(!ok||requested!==wantedLanguage||lang===requested)return;
   lang=requested;itemSearchCache=Object.create(null);restoreGuideControls();GuideI18n.set(lang);refreshLocationOptions();
   fillMonsters();if(selectedMonster)selectMonster(selectedMonster.id);
   if(activeTab==='monsters'&&val('monsterViewMode')==='compare'){compareMonsterOptions();renderMonsterCompare();}
   if(itemsReady)fillItems();
   if(mapsReady){var oldScale=scale,oldX=panX,oldY=panY;map();scale=oldScale;panX=oldX;panY=oldY;transform();}
   if(window.setGuideReferenceLanguage)window.setGuideReferenceLanguage(lang);
   GuideI18n.render();
  });
 };
 window.guideLanguage=function(){return lang;};
var staticSelectSources={},staticButtonSources=[];
['sizeFilter','weaknessFilter','habitatFilter','categoryFilter','itemRegion','rarityFilter','mapSelect','monsterViewMode','compareMode','compareRank'].forEach(function(id){Array.prototype.forEach.call(el(id).options,function(option){if(!option.hasAttribute('value'))option.setAttribute('value',option.textContent);});staticSelectSources[id]=el(id).innerHTML;});
Array.prototype.forEach.call(document.querySelectorAll('#tabs button,#prevItems,#nextItems,#fitMap'),function(button){staticButtonSources.push({element:button,text:button.textContent});});
function restoreGuideControls(){Object.keys(staticSelectSources).forEach(function(id){var select=el(id),value=select.value;select.innerHTML=staticSelectSources[id];select.value=value;});staticButtonSources.forEach(function(source){source.element.textContent=source.text;});}
el('prevItems').onclick=function(){itemPage=Math.max(0,itemPage-1);fillItems();};el('nextItems').onclick=function(){itemPage++;fillItems();};fillMonsters();
window.GuideTest={data:D,monsterMatches:monsterMatches,itemMatches:itemMatches,areaNumbers:areaNumbers,showTab:showTab};
}());
