﻿$script:QuestClearDllSha='FF7137B5842B3913B24BF04D8B4527187E3A3FC10618A6CDC2824ED12840C4C2'
$script:QuestClearExeSha='C2EBBBD2C49F216D484E31A5219BED419EB1E5E7D206D02CBA040A3AB79D90EA'
$script:QuestClearKeys=@{'F3'=114;'F4'=115;'F5'=116;'F6'=117;'F7'=118}
$script:QuestClearShortcut=$null
function Test-QuestClearPayload([string]$path,[string]$sha){
 return ((Test-Path -LiteralPath $path -PathType Leaf) -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -eq $sha)
}
function Get-QuestClearGame {
 $root=Get-GameFolder -RequireLoader
 $exe=Join-Path $root 'MonsterHunterWorld.exe'
 if(-not (Test-QuestClearPayload $exe $script:QuestClearExeSha)){throw 'This game executable does not match the supported 15.23.00 build. Quest Clear was not enabled.'}
 return $root
}
function Get-QuestClearPluginPath([string]$root){
 return Join-Path $root 'nativePC/plugins/SimpleQuestComplete.dll'
}
function Install-QuestClearArchive([string]$root,[string]$archive){
 $destination=Get-QuestClearPluginPath $root
 $directory=Split-Path -Parent $destination
 foreach($path in @((Join-Path $root 'nativePC'),$directory,$destination)){
  $existing=Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
  if($existing -and ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "The plugin path contains a link: $path"}
 }
 if(Test-Path -LiteralPath $destination){
  if(Test-QuestClearPayload $destination $script:QuestClearDllSha){return $false}
  throw 'A different SimpleQuestComplete.dll is already installed. It was not replaced.'
 }
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $zip=[IO.Compression.ZipFile]::OpenRead($archive);$temp=$null
 try {
  $entries=@($zip.Entries | Where-Object {$_.FullName -ceq 'nativePC/plugins/SimpleQuestComplete.dll'})
  if($entries.Count -ne 1 -or $entries[0].Length -ne 175616){throw 'Choose the original SimpleQuestComplete 0.1.4 ZIP. The expected DLL was not found.'}
  $memory=[IO.MemoryStream]::new();$source=$entries[0].Open()
  try {
   $buffer=[byte[]]::new(16384)
   while(($read=$source.Read($buffer,0,$buffer.Length)) -gt 0){
    if($memory.Length+$read -gt 175616){throw 'The DLL is larger than expected.'}
    $memory.Write($buffer,0,$read)
   }
   $bytes=$memory.ToArray()
  }finally{$source.Dispose();$memory.Dispose()}
  $hasher=[Security.Cryptography.SHA256]::Create()
  try{$sha=([BitConverter]::ToString($hasher.ComputeHash($bytes))).Replace('-','')}finally{$hasher.Dispose()}
  if($sha -ne $script:QuestClearDllSha){throw 'This DLL does not match the inspected SimpleQuestComplete 0.1.4 file. Nothing was installed.'}
  [void][IO.Directory]::CreateDirectory($directory)
  $temp=Join-Path $directory ('.questclear-'+[guid]::NewGuid().ToString('N')+'.tmp')
  [IO.File]::WriteAllBytes($temp,$bytes)
  if(-not (Test-QuestClearPayload $temp $script:QuestClearDllSha)){throw 'The copied DLL failed verification.'}
  [IO.File]::Move($temp,$destination)
  return $true
 }finally{$zip.Dispose();if($temp -and (Test-Path -LiteralPath $temp)){Remove-Item -LiteralPath $temp -Force}}
}
function Find-QuestClearArchive {
 $profile=[Environment]::GetFolderPath('UserProfile')
 $paths=@((Join-Path $script:Root 'Mods'))
 if($profile){$paths+=Join-Path $profile 'Downloads'}
 $archives=@(foreach($path in $paths){
  if(Test-Path -LiteralPath $path -PathType Container){
   Get-ChildItem -LiteralPath $path -File -Filter 'SimpleQuestComplete 0.1.4*.zip' -ErrorAction SilentlyContinue
  }
 })
 if($archives.Count -eq 1){return $archives[0].FullName}
 return $null
}
function Stop-QuestClearShortcut {
 if($script:QuestClearShortcut){$script:QuestClearShortcut.Dispose();$script:QuestClearShortcut=$null}
}
function Show-QuestClearTools {
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text='Whole Quest Clear';$dialog.ClientSize=[Drawing.Size]::new(710,380)
  [void](Add-Control $dialog Label 'Install the original SimpleQuestComplete 0.1.4 ZIP with the game closed. The editor checks Mods and Downloads first. The original Home key remains active. Use on a test save in a solo quest.' 18 12 674 86)
  $install=Add-Control $dialog Button 'Install from local ZIP...' 18 112 674 38
  [void](Add-Control $dialog Label 'Additional hotkey' 18 170 245 34)
  $keys=Add-Control $dialog ComboBox '' 270 170 422 36;$keys.DropDownStyle='DropDownList'
  [void]$keys.Items.AddRange([object[]]@('F3','F4','F5','F6','F7'))
  $keys.SelectedItem=if($script:ToolSettings.QuestClearKey -in $script:QuestClearKeys.Keys){$script:ToolSettings.QuestClearKey}else{'F5'}
  if($keys.SelectedIndex -lt 0){$keys.SelectedIndex=2}
  $enable=Add-Control $dialog Button 'Enable for this editor session' 18 218 430 38
  $disable=Add-Control $dialog Button 'Disable shortcut' 460 218 232 38
  $status=Add-Control $dialog Label '' 18 267 674 56
  $status.Text=if($script:QuestClearShortcut){"Active: $($script:ToolSettings.QuestClearKey). Keep the editor open."}else{'Shortcut off. Home still works through the original plugin.'}
  $close=Add-Control $dialog Button 'Close' 18 330 674 36;$close.DialogResult='Cancel';$dialog.CancelButton=$close
  $install.Tag=$dialog
  $install.Add_Click({param($sender,$event) Run-Action {
   Assert-GameClosed;$root=Get-QuestClearGame
   $plugin=Get-QuestClearPluginPath $root
   if(Test-QuestClearPayload $plugin $script:QuestClearDllSha){
    [HuntersCompanion.Messages]::Show('This exact DLL is already installed.','Whole Quest Clear')|Out-Null
    return
   }
   $archive=Find-QuestClearArchive
   if(-not $archive){
    $picker=[Windows.Forms.OpenFileDialog]::new()
    try{
     $picker.Filter='SimpleQuestComplete ZIP (*.zip)|*.zip';$picker.CheckFileExists=$true
     if($picker.ShowDialog($sender.Tag) -ne 'OK'){return}
     $archive=$picker.FileName
    }finally{$picker.Dispose()}
   }
   $installed=Install-QuestClearArchive $root $archive
   $message=if($installed){'Installed the verified DLL. Start the game to load it.'}else{'This exact DLL is already installed.'}
   [HuntersCompanion.Messages]::Show($message,'Whole Quest Clear')|Out-Null
  }})
  $enable.Tag=[pscustomobject]@{Keys=$keys;Status=$status}
  $enable.Add_Click({param($sender,$event) Run-Action {
   $ui=$sender.Tag;$key=[string]$ui.Keys.SelectedItem
   if(-not $script:QuestClearKeys.ContainsKey($key)){throw 'Choose a shortcut key.'}
   if($key -eq $script:ToolSettings.PauseKey){throw 'Choose a different key from the offline Pause hotkey.'}
   $root=Get-QuestClearGame;$plugin=Get-QuestClearPluginPath $root
   if(-not (Test-QuestClearPayload $plugin $script:QuestClearDllSha)){throw 'Install the original 0.1.4 DLL from your ZIP first.'}
   Stop-QuestClearShortcut
   $script:ToolSettings.QuestClearKey=$key;Save-ToolSettings
   $script:QuestClearShortcut=[HuntersCompanion.QuestClearHotkey]::new((Join-Path $root 'MonsterHunterWorld.exe'),[int]$script:QuestClearKeys[$key])
   $ui.Status.Text="Active: $key. Keep the editor open."
  }})
  $disable.Tag=$status
  $disable.Add_Click({param($sender,$event) Stop-QuestClearShortcut;$sender.Tag.Text='Shortcut off. Home still works through the original plugin.'})
  Set-QuestbookTree $dialog
  [void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
$questClearTools=Add-Control $modtab Button 'Whole Quest Clear...' 775 464 285 38
$questClearTools.Add_Click({Run-Action {Show-QuestClearTools}})
$form.Add_FormClosed({Stop-QuestClearShortcut})
