﻿$script:EquipmentEffectCache=@{};$script:EquipmentEffectCacheKey=''
$script:EquipmentEffectNames=Get-Content -LiteralPath (Join-Path $script:Root 'catalog\EquipmentEffects.json') -Raw -Encoding UTF8|ConvertFrom-Json
function Get-CompanionEffectWords($record,[string]$field){
 $words=$record.$field;$code=$script:ToolSettings.Language
 if($words.PSObject.Properties[$code]){return [string]$words.$code};return [string]$words.en
}
function Read-CompanionEquipmentEffects {
 $current=Current-Slot;$file=Get-Item -LiteralPath $script:Working
 $key=$script:Working+'|'+$file.LastWriteTimeUtc.Ticks+'|'+$file.Length+'|'+$current.number
 if($key -eq $script:EquipmentEffectCacheKey){return}
 $path=Join-Path $script:Root 'tools\EquipmentDetails.exe'
 $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=$path;$start.Arguments='"'+$script:Working+'" '+$current.number;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.StandardOutputEncoding=[Text.Encoding]::UTF8
 $process=[Diagnostics.Process]::Start($start)
 try{$json=$process.StandardOutput.ReadToEnd();$errorText=$process.StandardError.ReadToEnd();$process.WaitForExit();if($process.ExitCode -ne 0){throw $errorText};$data=$json|ConvertFrom-Json;if(-not $data.read_only -or [int]$data.slot -ne [int]$current.number){throw 'Equipment detail identity check failed.'}
  $cache=@{};foreach($entry in $data.equipment){$cache[[int]$entry.index]=$entry};$script:EquipmentEffectCache=$cache;$script:EquipmentEffectCacheKey=$key
 }finally{$process.Dispose()}
}
$script:CompanionWeaponTables=@('l_sword','sword','w_sword','tachi','hammer','whistle','lance','g_lance','s_axe','c_axe','rod','bow','hbg','lbg')
$script:CompanionWeaponRarityCache=@{}
$script:CompanionMrFields=@('attack_increase','affinity_increase','defense_increase','slot_upgrade','health_regen','element_status_effect_up')

function Get-CompanionMrRules {
 $rules=Get-Content -LiteralPath (Join-Path $script:Root 'catalog/MrAugmentRules.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $root=Get-EquipmentTableRoot
 foreach($table in $rules.table_hashes.PSObject.Properties){
  $path=Get-NativePcTarget $root ('equip/'+$table.Name)
  $hash=Get-NativePcHash $path
  if($hash -and $hash -ne $table.Value){
   throw (Format-QuestbookText 'The installed {0} changes Master Rank augment rules. This editor supports the stock tables only.' @($table.Name))
  }
 }
 return $rules
}

function Get-CompanionMrCost($rules,[int]$rarity,[int[]]$levels) {
 if($rarity -notin (10..12) -or $levels.Count -ne $script:CompanionMrFields.Count){return -1}
 $total=0
 for($i=0;$i -lt $levels.Count;$i++){
  $field=$rules.fields.($script:CompanionMrFields[$i])
  $level=$levels[$i]
  if($level -lt 0 -or $level -gt [int]$field.max_levels.([string]$rarity)){return -1}
  $total+=[int]$field.costs[$level]
 }
 return $total
}

function Read-CompanionWeaponRarity([string]$path,[bool]$ranged,[int]$id) {
 $file=Get-Item -LiteralPath $path -ErrorAction Stop
 $key=$file.FullName+'|'+$file.Length+'|'+$file.LastWriteTimeUtc.Ticks
 $cached=$script:CompanionWeaponRarityCache[$file.FullName]
 if(-not $cached -or $cached.Key -ne $key){
  $stride=if($ranged){69}else{66};$idOffset=if($ranged){59}else{56};$rarityOffset=if($ranged){24}else{20}
  if($file.Length -lt 10 -or $file.Length -gt 4194304){throw 'Unsupported weapon table layout.'}
  $bytes=[IO.File]::ReadAllBytes($file.FullName)
  if($bytes.Length -lt 10 -or $bytes.Length -ne (10+[long][BitConverter]::ToUInt32($bytes,6)*$stride)){throw 'Unsupported weapon table layout.'}
  $rows=@{}
  for($offset=10;$offset -lt $bytes.Length;$offset+=$stride){
   $rowId=[int][BitConverter]::ToUInt16($bytes,$offset+$idOffset)
   $rarity=1+[int]$bytes[$offset+$rarityOffset]
   if($rows.ContainsKey($rowId) -and $rows[$rowId] -ne $rarity){$rows[$rowId]=0}else{$rows[$rowId]=$rarity}
  }
  $cached=@{Key=$key;Rows=$rows};$script:CompanionWeaponRarityCache[$file.FullName]=$cached
 }
 return [int]$cached.Rows[$id]
}
function Get-CompanionMrAugmentEligibility($entry) {
 $result=[pscustomobject]@{Enabled=$false;Reason='Select a weapon to check MR augment eligibility.';Arguments=@();Rarity=0}
 if(-not $entry){return $result}
 if([int]$entry.category -ne 1){$result.Reason='MR weapon augments do not apply to armor.';return $result}
 $type=[int]$entry.type
 $result.Reason='This weapon has no verified rank. MR editing is unavailable.'
 if($type -lt 0 -or $type -ge $script:CompanionWeaponTables.Count){return $result}
 $ranged=$type -ge 11;$extension=if($ranged){'.wp_dat_g'}else{'.wp_dat'}
 $file=$script:CompanionWeaponTables[$type]+$extension
 try{
  $rarity=Read-CompanionWeaponRarity (Join-Path $script:Root ('data/common/equip/'+$file)) $ranged ([int]$entry.id)
  if($rarity -lt 1 -or $rarity -gt 12){return $result}
  $result.Rarity=$rarity
  $override=Get-NativePcTarget (Get-EquipmentTableRoot) ('equip/'+$file)
  if(Test-Path -LiteralPath $override){
   if((Read-CompanionWeaponRarity $override $ranged ([int]$entry.id)) -ne $rarity){
    $result.Reason='The installed weapon table changes this weapon''s rarity or identity. MR editing is blocked.'
    return $result
   }
  }
 }catch{$result.Reason='The weapon table could not be verified. MR editing is blocked.';return $result}
 $legacy=@($entry.augments | Where-Object {[uint32]$_ -ne 0}).Count -gt 0
 if($rarity -lt 10){
  $result.Reason=if($legacy){'Rarity {0} uses saved High Rank augments. MR editing requires rarity 10–12.'}else{'Rarity {0} is outside this MR editor''s supported range (10–12).'}
  $result.Arguments=@($rarity);return $result
 }
 if($legacy){$result.Reason='This rarity {0} weapon has legacy augment IDs. The editor will not convert them to MR augments.';$result.Arguments=@($rarity);return $result}
 $present=[int]$entry.extra_slots
 foreach($field in $script:CompanionMrFields){$present+=[int]$entry.$field}
 if(-not $present){$result.Reason='Apply one Master Rank augment in the Smithy, save, and reopen the save to enable editing.';return $result}
 $result.Enabled=$true;$result.Reason='Ready to edit saved Master Rank augments.'
 return $result
}
function Format-CompanionMrEligibility($result) {
 if($result.Arguments.Count){return Format-QuestbookText $result.Reason $result.Arguments}
 return Get-QuestbookText $result.Reason
}
function Reset-CompanionMrEligibility {
 if($masterAugments){$masterAugments.Enabled=$false}
 if($script:legacyAugments){$script:legacyAugments.Enabled=$false}
 if($script:EquipmentEffects){$script:EquipmentEffects.Text=Get-QuestbookText 'Select a weapon to check MR augment eligibility.'}
}

function Show-CompanionEquipmentEffects($selected){
 if(-not $script:EquipmentEffects){return}
 Reset-CompanionMrEligibility
 if(-not $selected){return}
 try{
  Read-CompanionEquipmentEffects;$index=[int]$selected.Record.index
  if(-not $script:EquipmentEffectCache.ContainsKey($index)){throw 'No saved equipment details were found.'}
  $entry=$script:EquipmentEffectCache[$index]
  if([int]$entry.id -ne [int]$selected.Record.id -or [int]$entry.type -ne [int]$selected.Record.type -or [int]$entry.category -ne [int]$selected.Record.category){throw 'Equipment detail identity check failed.'}
  $lines=[Collections.Generic.List[string]]::new();$lines.Add((Get-QuestbookText 'Saved Augments and Awakened Abilities — Read Only'))
  $eligibility=Get-CompanionMrAugmentEligibility $entry
  $masterAugments.Enabled=$eligibility.Enabled
  if($script:legacyAugments -and $eligibility.Rarity -in (6..8)){
   $legacy=@($entry.augments|Where-Object {$_ -ne 0})
   $other=@($script:CompanionMrFields|Where-Object {[int]$entry.$_ -ne 0})
   $script:legacyAugments.Enabled=($legacy.Count -ge 1 -and $legacy.Count -le (9-$eligibility.Rarity) -and
    -not @($legacy|Where-Object {$_ -notin (1..5)}).Count -and -not $other.Count -and -not $entry.extra_slots -and
    -not @($entry.awakens|Where-Object {$_ -ne 0}).Count)
  }
  $lines.Add((Get-QuestbookText 'MR Augment Editor')+': '+(Format-CompanionMrEligibility $eligibility))
  $lines.Add((Get-QuestbookText 'Base slot levels')+': '+(@(0..2|ForEach-Object {$selected.Meta.("Cap$_")}) -join ' / '));$count=0
  foreach($id in $entry.augments){if([uint32]$id -eq 0){continue};$count++;$name=$script:EquipmentEffectNames.LegacyAugments.([string]$id)
   if($name){$lines.Add((Get-QuestbookText 'Augment')+': '+(Get-CompanionEffectWords $name 'Names')+' — '+(Get-CompanionEffectWords $name 'Descriptions'))}else{$lines.Add((Get-QuestbookText 'Unknown saved augment ID')+': '+$id)}
  }
  foreach($field in $script:EquipmentEffectNames.MasterAugments.PSObject.Properties){$level=[int]$entry.($field.Name);if($level -eq 0){continue};$count++;$name=$field.Value.Levels.([string]$level)
   if($name){$lines.Add((Get-CompanionEffectWords $name 'Names')+' — '+(Get-CompanionEffectWords $name 'Descriptions'))}else{$lines.Add((Get-QuestbookText $field.Value.Title)+': '+$level+' ('+(Get-QuestbookText 'Saved level; effect not mapped')+')')}
  }
  foreach($id in $entry.awakens){if([uint16]$id -eq 0){continue};$count++;$name=$script:EquipmentEffectNames.Awakenings.([string]$id)
   if($name){$lines.Add((Get-QuestbookText 'Awakened ability')+': '+(Get-CompanionEffectWords $name 'Names')+' — '+(Get-CompanionEffectWords $name 'Descriptions'))}else{$lines.Add((Get-QuestbookText 'Unknown saved awakening ID')+': '+$id)}
  }
  $legacySlotLevel=@($entry.augments|Where-Object {[uint32]$_ -eq 4}).Count
  if($legacySlotLevel){$lines.Add((Get-QuestbookText 'Legacy augment slot level')+': '+$legacySlotLevel)}
  if([int]$entry.slot_upgrade -gt 0){$lines.Add((Get-QuestbookText 'Master Rank augment slot level')+': '+$entry.slot_upgrade)}
  foreach($id in $entry.awakens){if([int]$id -ge 37 -and [int]$id -le 40){$lines.Add((Get-QuestbookText 'Additional awakening slot level')+': '+([int]$id-36))}}
  if(-not $count){$lines.Add((Get-QuestbookText 'No saved augments or awakened abilities.'))}
  if(@($entry.custom_upgrades|Where-Object {$_ -ne 0}).Count){$lines.Add((Get-QuestbookText 'Custom upgrades (saved IDs)')+': '+($entry.custom_upgrades -join ' / '))}
  $lines.Add('');$lines.Add((Get-QuestbookText 'Bonus slot effects are listed separately from base export slots. Final stat totals and slot ordering are not inferred. These saved upgrades are not changed by this report.'))
  $script:EquipmentEffects.Text=$lines -join "`r`n"
 }catch{$masterAugments.Enabled=$false;$script:EquipmentEffects.Text=(Get-QuestbookText 'Equipment details could not be read. No save data was changed.')+"`r`n"+$_.Exception.Message}
}

function Get-CompanionEquipmentSession {return [pscustomobject]@{Working=$script:Working;Slot=[int](Current-Slot).number}}
function Complete-CompanionEquipmentEdit([string]$path) {
 $newState=Invoke-Engine -Arguments @('inspect',$path);$script:History.Add($script:Working);$script:Working=$path;$script:State=$newState;Refresh-Slot
}
function Show-CompanionMasterAugments {
 $selected=$equipList.SelectedItem;if(-not $selected){throw 'Select equipment first.'}
 Read-CompanionEquipmentEffects;$entry=$script:EquipmentEffectCache[[int]$selected.Record.index]
 if(-not $entry -or [int]$entry.id -ne [int]$selected.Record.id -or [int]$entry.type -ne [int]$selected.Record.type -or [int]$entry.category -ne [int]$selected.Record.category){throw 'Equipment detail identity check failed.'}
 $eligibility=Get-CompanionMrAugmentEligibility $entry
 if(-not $eligibility.Enabled){throw (Format-CompanionMrEligibility $eligibility)}
 $fields=$script:CompanionMrFields
 $rules=Get-CompanionMrRules
 $rarity=[int]$eligibility.Rarity
 $capacity=[int]$rules.max_capacity.([string]$rarity)
 $sessionFolder=$script:Session;$rootPath=$script:Root;$inputPath=$script:Working;$character=[int](Current-Slot).number;$index=[int]$entry.index;$expected=(Get-FileHash -LiteralPath $inputPath -Algorithm SHA256).Hash.ToLowerInvariant()
 $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=Join-Path $rootPath 'tools\EquipmentTools.exe';$start.Arguments='augment-profile "'+$inputPath+'" '+$character+' '+$index;$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
 $process=[Diagnostics.Process]::Start($start)
 try{$json=$process.StandardOutput.ReadToEnd();$failure=$process.StandardError.ReadToEnd();$process.WaitForExit();if($process.ExitCode -ne 0){throw $failure};$profile=$json|ConvertFrom-Json}finally{$process.Dispose()}
 if($capacity -le 0 -or [int]$profile.capacity -ne $capacity){throw 'Equipment detail identity check failed.'}
 if((Get-CompanionMrCost $rules $rarity @($fields | ForEach-Object {[int]$entry.$_})) -lt 0){
  throw (Get-QuestbookText 'This weapon has saved augment levels outside the stock rules for its rarity.')
 }
 $dialog=[Windows.Forms.Form]::new()
 try{
  $dialog.Text=Get-QuestbookText 'Edit Master Rank Augments';$dialog.ClientSize=[Drawing.Size]::new(740,560)
  $title=Add-Control $dialog Label ([string]$selected.Meta.Name) 20 15 700 45
  [void](Add-Control $dialog Label 'Rarity 10–12 weapons already augmented in-game only. Extra Slots III will be applied. Saved levels, awakenings, custom upgrades, and decorations are preserved.' 20 65 700 85)
  $spins=@();$labels=@('Attack Increase','Affinity Increase','Defense Increase','Slot Upgrade','Health Regen','Element / Status Effect Up')
  for($i=0;$i -lt 6;$i++){
   [void](Add-Control $dialog Label $labels[$i] 30 (165+$i*43) 430 34)
   $spin=Add-Control $dialog NumericUpDown '' 480 (165+$i*43) 225 34
   $spin.Minimum=0;$spin.Maximum=[int]$rules.fields.($fields[$i]).max_levels.([string]$rarity)
   $spin.Value=[int]$entry.($fields[$i]);$spins+=@($spin)
  }
  $budget=Add-Control $dialog Label '' 20 430 700 55
  $confirm=Add-Control $dialog Button 'Preview Changes...' 20 500 450 38
  $cancel=Add-Control $dialog Button 'Cancel' 490 500 230 38;$cancel.DialogResult='Cancel';$dialog.CancelButton=$cancel
  # A closure has its own module scope; keep the original editor command bindings.
  $costCommand=Get-Command Get-CompanionMrCost -CommandType Function
  $formatCommand=Get-Command Format-QuestbookText -CommandType Function
  $textCommand=Get-Command Get-QuestbookText -CommandType Function
  $runCommand=Get-Command Run-Action -CommandType Function
  $sessionCommand=Get-Command Get-CompanionEquipmentSession -CommandType Function
  $rulesCommand=Get-Command Get-CompanionMrRules -CommandType Function
  $completeCommand=Get-Command Complete-CompanionEquipmentEdit -CommandType Function
  $updateBudget={
   $levels=@($spins | ForEach-Object {[int]$_.Value})
   $cost=& $costCommand $rules $rarity $levels
   $budget.Text=& $formatCommand 'Rarity {0}  |  Augment slots used: {1} / {2}' @($rarity,$cost,$capacity)
   $confirm.Enabled=($cost -ge 0 -and $cost -le $capacity)
   $budget.ForeColor=if($confirm.Enabled){[Drawing.Color]::FromArgb(23,44,37)}else{[Drawing.Color]::FromArgb(160,30,30)}
  }.GetNewClosure()
  foreach($spin in $spins){$spin.Add_ValueChanged($updateBudget)};& $updateBudget
  $confirm.Add_Click({& $runCommand {
   $active=& $sessionCommand;if($active.Working -ne $inputPath -or $active.Slot -ne $character){throw 'The selected character changed. Reopen the equipment editor.'}
   $levels=@($spins | ForEach-Object {[int]$_.Value})
   $cost=& $costCommand $rules $rarity $levels
   if($cost -lt 0 -or $cost -gt $capacity){throw (& $textCommand 'Selected augments exceed the supported levels or capacity.')}
   $values=@(3)+$levels
   $lines=@((& $formatCommand 'Rarity {0}  |  Augment slots used: {1} / {2}' @($rarity,$cost,$capacity)),((& $textCommand 'Extra Slots')+': '+$entry.extra_slots+' → 3'))
   for($j=0;$j -lt 6;$j++){$lines+=((& $textCommand $labels[$j])+': '+$entry.($fields[$j])+' → '+$values[$j+1])}
   $answer=[HuntersCompanion.Messages]::Show(($lines -join "`r`n"),(& $textCommand 'Apply Augment Changes?'),[Windows.Forms.MessageBoxButtons]::OKCancel,[Windows.Forms.MessageBoxIcon]::Information)
   if($answer -ne [Windows.Forms.DialogResult]::OK){return}
   [void](& $rulesCommand)
   $next=Join-Path $sessionFolder ([guid]::NewGuid().ToString('N')+'.bin')
   $start=[Diagnostics.ProcessStartInfo]::new();$start.FileName=Join-Path $rootPath 'tools\EquipmentTools.exe'
   $arguments=@('apply-mr',$inputPath,$next,[string]$character,[string]$index,$expected)+@($values|ForEach-Object {[string]$_})
   $start.Arguments=($arguments|ForEach-Object {'"'+$_+'"'}) -join ' ';$start.UseShellExecute=$false;$start.CreateNoWindow=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
   $process=[Diagnostics.Process]::Start($start)
   try{$result=$process.StandardOutput.ReadToEnd();$failure=$process.StandardError.ReadToEnd();$process.WaitForExit();if($process.ExitCode -ne 0){throw $failure};$receipt=$result|ConvertFrom-Json;if(-not $receipt.verified_roundtrip -or [int]$receipt.slot -ne $character -or [int]$receipt.index -ne $index){throw 'Equipment detail identity check failed.'}}finally{$process.Dispose()}
   & $completeCommand $next;$dialog.DialogResult='OK';$dialog.Close()
  }}.GetNewClosure())
  Set-QuestbookTree $dialog;& $updateBudget;[void]$dialog.ShowDialog($form)
 }finally{$dialog.Dispose()}
}
$masterAugments=Add-Control $eqtab Button 'Edit MR Augments...' 845 365 215 38
$masterAugments.Enabled=$false
$masterAugments.Add_Click({Run-Action {Show-CompanionMasterAugments}})
