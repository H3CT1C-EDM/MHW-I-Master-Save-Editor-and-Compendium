#!/usr/bin/env python3
"""Create Win32 .res RT_ICON and RT_GROUP_ICON records from an ICO file.
Uses only Python's standard library. The output can be linked with lld-link.
"""
import pathlib
import struct
import sys

def padding(b):
    return b + b'\0' * ((-len(b)) % 4)

def resource(type_id, name_id, data):
    # IMAGE_RESOURCE_DATA_ENTRY as a COFF .res record.
    rest = struct.pack('<HHHHIHHII', 0xffff, type_id, 0xffff, name_id,
                       0, 0x1030, 0x0409, 0, 0)
    header = struct.pack('<II', len(data), 8 + len(rest)) + rest
    return padding(header) + padding(data)

def main():
    if len(sys.argv) != 3:
        raise SystemExit('Usage: python make_icon_res.py image.ico out.res')
    ico = pathlib.Path(sys.argv[1]).read_bytes()
    resv, kind, count = struct.unpack_from('<HHH', ico)
    if resv or kind != 1 or count < 1:
        raise ValueError('Not a valid ICO file')
    out = bytearray(resource(0, 0, b''))
    group = bytearray(struct.pack('<HHH', 0, 1, count))
    for index in range(count):
        off = 6 + index * 16
        w, h, colors, res, planes, depth, size, dataoffset = struct.unpack_from('<BBBBHHII', ico, off)
        if dataoffset + size > len(ico):
            raise ValueError('Truncated ICO image')
        group += struct.pack('<BBBBHHIH', w, h, colors, res, planes, depth, size, index + 1)
        out += resource(3, index + 1, ico[dataoffset:dataoffset+size])
    out += resource(14, 1, bytes(group))
    pathlib.Path(sys.argv[2]).write_bytes(out)
    print(f'Wrote {len(out)} bytes, {count} icon frames')

if __name__ == '__main__':
    main()
