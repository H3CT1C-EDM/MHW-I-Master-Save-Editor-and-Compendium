/*
 * MHW:I Save Editor & Master Compendium - transparent portable launcher
 * Windows x64, no C runtime dependency and no hidden execution.
 * This is a native launcher for the *existing PowerShell application*,
 * not a port of its PowerShell implementation.
 */

typedef unsigned long DWORD;
typedef unsigned short WORD;
typedef int BOOL;
typedef void *HANDLE;
typedef void *LPVOID;
typedef const void *LPCVOID;
typedef unsigned short WCHAR;
typedef WCHAR *LPWSTR;
typedef const WCHAR *LPCWSTR;
typedef unsigned long long UINT_PTR;

#define TRUE 1
#define FALSE 0
#define INVALID_FILE_ATTRIBUTES ((DWORD)0xFFFFFFFFUL)
#define FILE_ATTRIBUTE_DIRECTORY 0x10UL
#define INFINITE ((DWORD)0xFFFFFFFFUL)
#define MB_OK 0x00000000U
#define MB_ICONERROR 0x00000010U
#define MB_ICONINFORMATION 0x00000040U
#define CAP 32768

/* Windows SDK-compatible Win32 structures, in their documented field order. */
typedef struct _STARTUPINFOW {
    DWORD cb;
    LPWSTR lpReserved;
    LPWSTR lpDesktop;
    LPWSTR lpTitle;
    DWORD dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    unsigned char *lpReserved2;
    HANDLE hStdInput, hStdOutput, hStdError;
} STARTUPINFOW;
typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
} PROCESS_INFORMATION;

__declspec(dllimport) DWORD __stdcall GetModuleFileNameW(HANDLE, LPWSTR, DWORD);
__declspec(dllimport) unsigned int __stdcall GetSystemDirectoryW(LPWSTR, unsigned int);
__declspec(dllimport) DWORD __stdcall GetFileAttributesW(LPCWSTR);
__declspec(dllimport) BOOL __stdcall CreateProcessW(
    LPCWSTR, LPWSTR, LPVOID, LPVOID, BOOL, DWORD, LPVOID, LPCWSTR,
    STARTUPINFOW *, PROCESS_INFORMATION *);
__declspec(dllimport) DWORD __stdcall WaitForSingleObject(HANDLE, DWORD);
__declspec(dllimport) BOOL __stdcall GetExitCodeProcess(HANDLE, DWORD *);
__declspec(dllimport) BOOL __stdcall CloseHandle(HANDLE);
__declspec(dllimport) void __stdcall ExitProcess(DWORD);
__declspec(dllimport) int __stdcall MessageBoxW(HANDLE, LPCWSTR, LPCWSTR, unsigned int);

static WCHAR exe_path[CAP];
static WCHAR data_dir[CAP];
static WCHAR bootstrap[CAP];
static WCHAR ps_path[CAP];
static WCHAR cmd_line[CAP];
static STARTUPINFOW startup;
static PROCESS_INFORMATION process;
static const WCHAR window_title[] = L"MHW:I Save Editor & Master Compendium";

static DWORD length(const WCHAR *s) {
    DWORD n = 0;
    while (n < CAP && s[n]) ++n;
    return n;
}
static BOOL append(WCHAR *dst, const WCHAR *suffix) {
    DWORD n = length(dst), k = length(suffix), i;
    if (n >= CAP || k >= CAP || k >= CAP - n) return FALSE;
    for (i = 0; i <= k; ++i) dst[n + i] = suffix[i];
    return TRUE;
}
static BOOL copy(WCHAR *dst, const WCHAR *source) {
    dst[0] = 0;
    return append(dst, source);
}
static BOOL is_existing_file(const WCHAR *p) {
    DWORD attrs = GetFileAttributesW(p);
    return attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY) == 0;
}
static void error_msg(const WCHAR *body) {
    MessageBoxW((HANDLE)0, body, window_title, MB_OK | MB_ICONERROR);
}
static int launch(void) {
    DWORD got, n, exit_code = 1;
    got = GetModuleFileNameW((HANDLE)0, exe_path, CAP);
    if (got == 0 || got >= CAP - 100) {
        error_msg(L"Cannot determine the launcher location. Install to a shorter local path.");
        return 2;
    }
    n = got;
    while (n && exe_path[n - 1] != L'\\' && exe_path[n - 1] != L'/') --n;
    if (!n) {
        error_msg(L"Could not locate the application's folder.");
        return 2;
    }
    exe_path[n] = 0;
    if (!copy(data_dir, exe_path) ||
        !append(data_dir, L"MHWI-Editor & Master Compendium Files") ||
        !copy(bootstrap, data_dir) ||
        !append(bootstrap, L"\\Bootstrap.ps1")) {
        error_msg(L"The installation path is too long.");
        return 2;
    }
    if (!is_existing_file(bootstrap)) {
        error_msg(L"Cannot find the application files. Keep this EXE beside the folder named:\n\nMHWI-Editor & Master Compendium Files\n\nDo not move the launcher into that folder.");
        return 3;
    }
    got = GetSystemDirectoryW(ps_path, CAP);
    if (!got || got >= CAP - 90 ||
        !append(ps_path, L"\\WindowsPowerShell\\v1.0\\powershell.exe") ||
        !is_existing_file(ps_path)) {
        error_msg(L"Windows PowerShell 5.1 is required by this edition of the editor but was not found.");
        return 4;
    }
    /* Do not run a hidden console or use -ExecutionPolicy Bypass.
       Process-local RemoteSigned allows only scripts permitted by Windows policy.
       If download-zone markers prohibit unsigned scripts, launch will fail
       rather than silently evading the policy. */
    if (!copy(cmd_line, L"\"") || !append(cmd_line, ps_path) ||
        !append(cmd_line, L"\" -NoLogo -NoProfile -STA -ExecutionPolicy RemoteSigned -File \"") ||
        !append(cmd_line, bootstrap) || !append(cmd_line, L"\"")) {
        error_msg(L"The PowerShell command exceeds the Windows limit.");
        return 5;
    }
    startup.cb = sizeof(startup);
    if (!CreateProcessW(ps_path, cmd_line, (LPVOID)0, (LPVOID)0,
                        FALSE, 0, (LPVOID)0, data_dir, &startup, &process)) {
        error_msg(L"Could not launch Windows PowerShell. Verify that Windows PowerShell 5.1 is installed and allowed by your system policy.");
        return 6;
    }
    WaitForSingleObject(process.hProcess, INFINITE);
    if (!GetExitCodeProcess(process.hProcess, &exit_code)) exit_code = 7;
    CloseHandle(process.hThread);
    CloseHandle(process.hProcess);
    if (exit_code != 0) {
        error_msg(L"Windows PowerShell could not complete editor startup.\n\n"
                  L"Read the error message in the PowerShell window. "
                  L"If the archive was downloaded, Windows may have marked its scripts as Internet-origin; unsigned scripts can be blocked by RemoteSigned.\n\n"
                  L"The startup.log in %LOCALAPPDATA%\\MHWIFieldJournal may belong to an EARLIER run if the bootstrap never started.\n\n"
                  L"A verified signing certificate and publisher review are recommended. "
                  L"No system security settings were disabled.");
    }
    return (int)exit_code;
}

void __stdcall WinMainCRTStartup(void) {
    ExitProcess((DWORD)launch());
}
