@echo off
setlocal
rem Build the portable native Windows x64 launcher. No project-specific DLLs are compiled.
set "SRC=%~dp0"
set "OUT=%SRC%..\..\MHW-I Save Editor and Master Compendium.exe"
set "ICON=%SRC%..\..\MHWI-Editor & Master Compendium Files\Questbook.ico"
set "BUILD=%SRC%_build"
where clang.exe >nul 2>nul || (echo Install LLVM with clang.exe in PATH. & exit /b 1)
where lld-link.exe >nul 2>nul || (echo Install LLVM with lld-link.exe in PATH. & exit /b 1)
where py.exe >nul 2>nul
if not errorlevel 1 (
  set "PYTHON=py -3"
) else (
  where python.exe >nul 2>nul || (echo Install Python 3 in PATH. & exit /b 1)
  set "PYTHON=python"
)
if not exist "%BUILD%" mkdir "%BUILD%" || exit /b 1
%PYTHON% "%SRC%make_icon_res.py" "%ICON%" "%BUILD%\icon.res" || exit /b 1
%PYTHON% "%SRC%make_windows_version_resource.py" "%BUILD%\version.res" || exit /b 1
lld-link /lib /def:"%SRC%kernel32.def" /machine:x64 /out:"%BUILD%\kernel32.lib" || exit /b 1
lld-link /lib /def:"%SRC%user32.def" /machine:x64 /out:"%BUILD%\user32.lib" || exit /b 1
clang -target x86_64-pc-windows-msvc -O2 -ffreestanding -fno-stack-protector -fno-builtin -c "%SRC%Launcher.c" -o "%BUILD%\Launcher.obj" || exit /b 1
lld-link /nologo /Brepro /subsystem:windows /entry:WinMainCRTStartup /nodefaultlib /machine:x64 /out:"%OUT%" "%BUILD%\Launcher.obj" "%BUILD%\icon.res" "%BUILD%\version.res" "%BUILD%\kernel32.lib" "%BUILD%\user32.lib" || exit /b 1
echo Built "%OUT%"
exit /b 0
