#!/usr/bin/env python3
"""Create Windows VERSIONINFO Win32 .res from Python stdlib. Portable and reproducible.
Exposes branding via Explorer Properties > Details, NOT Authenticode Publisher.
"""
from __future__ import annotations
import pathlib
import struct
import sys

COMPANY = 'H3CT1C | Frank Sidor | Nihilist Kvlt Mods'
PRODUCT = 'MHW:I Save Editor & Master Compendium'
FILE_DESCRIPTION = 'MHW:I Save Editor & Master Compendium — Portable Launcher'
VERSION = (1, 0, 1, 0)

def align4(data: bytes) -> bytes:
    return data + b'\0' * (-len(data) % 4)

def unicodez(text: str) -> bytes:
    return text.encode('utf-16le') + b'\0\0'

def block(name: str, value: bytes=b'', children: tuple[bytes, ...]=(), type_id:int=1, value_length:int|None=None)->bytes:
    header = bytearray(b'\0\0\0\0' + struct.pack('<H', type_id) + unicodez(name))
    header = bytearray(align4(header))
    header += value
    header = bytearray(align4(header))
    for child in children:
        header += child
    if value_length is None:
        value_length = len(value)//2 if type_id else len(value)
    struct.pack_into('<HH', header, 0, len(header), value_length)
    return bytes(header)

def make_version() -> bytes:
    # VS_FIXEDFILEINFO: https://learn.microsoft.com/windows/win32/menurc/vs-fixedfileinfo
    fixed = struct.pack('<13I',
        0xFEEF04BD, 0x00010000, (VERSION[0]<<16)|VERSION[1], (VERSION[2]<<16)|VERSION[3],
        (VERSION[0]<<16)|VERSION[1], (VERSION[2]<<16)|VERSION[3],
        0x3F, 0, 0x00040004, 0x1, 0, 0, 0)
    values = {
        'CompanyName': COMPANY,
        'FileDescription': FILE_DESCRIPTION,
        'FileVersion': '.'.join(map(str,VERSION)),
        'InternalName': 'MHWI_Portable_Launcher',
        'LegalCopyright': 'Copyright (c) 2026 Frank Sidor',
        'OriginalFilename': 'MHW-I Save Editor and Master Compendium.exe',
        'ProductName': PRODUCT,
        'ProductVersion': '.'.join(map(str,VERSION)),
        'Comments': 'Brand: H3CT1C / Nihilist Kvlt Mods. Verification of publisher requires Authenticode code signing.',
    }
    string_entries = tuple(block(k, unicodez(v)) for k,v in values.items())
    string_file_info = block('StringFileInfo',children=(block('040904B0',children=string_entries),))
    translation = block('Translation',struct.pack('<HH',0x0409,1200),type_id=0, value_length=4)
    var_file_info = block('VarFileInfo',children=(translation,))
    return block('VS_VERSION_INFO',fixed, (string_file_info,var_file_info),type_id=0,value_length=len(fixed))

def resource(type_id: int, name_id: int, data: bytes) -> bytes:
    rest = struct.pack('<HHHHIHHII',0xFFFF,type_id,0xFFFF,name_id,0,0x1030,0x0409,0,0)
    return align4(struct.pack('<II',len(data),8+len(rest))+rest)+align4(data)

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit('Usage: python make_windows_version_resource.py output_version.res')
    out = pathlib.Path(sys.argv[1])
    out.write_bytes(resource(0,0,b'') + resource(16, 1, make_version()))
    print('Saved VERSIONINFO resource:',out,'bytes=',out.stat().st_size)
