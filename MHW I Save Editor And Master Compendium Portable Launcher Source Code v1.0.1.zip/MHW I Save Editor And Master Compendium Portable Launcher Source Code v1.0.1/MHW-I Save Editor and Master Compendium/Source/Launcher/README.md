# MHW:I native launcher — source and verified branding

**Release candidate:** Windows x64 launcher v1.0.1 (November 6, 2026).

## Build

Open a Windows Command Prompt with LLVM `clang.exe` and `lld-link.exe` plus Python 3 available on `PATH` and run `Source\Launcher\build.cmd`. The script compiles `Launcher.c`, embeds the original `Questbook.ico`, and embeds VERSIONINFO metadata using `make_windows_version_resource.py`.

`CompanyName` in Windows Explorer → Properties → Details is exactly:

    H3CT1C | Frank Sidor | Nihilist Kvlt Mods

This field is **informational**. It is not Authenticode code signing. SmartScreen's "Publisher" field remains "Unknown publisher" until the EXE has a trusted code-signing signature. A real signature will display the identity verified by the certificate issuer; that subject is not necessarily the full branded CompanyName string. A signed EXE can still trigger SmartScreen while reputation is established.

## Behavior and restrictions

The EXE uses the folder containing itself to locate the adjacent `MHWI-Editor & Master Compendium Files\Bootstrap.ps1`. The editor itself remains a Windows PowerShell 5.1 / Windows Forms application. The launcher uses `-ExecutionPolicy RemoteSigned` for this process and does **not** bypass operating-system policy, disable Windows Defender, remove Internet-origin markers, or suppress SmartScreen. The PowerShell console is intentionally visible if an error occurs. No hard-coded workstation paths are embedded.

A nonzero exit now describes a common failure mode, and warns that `startup.log` could be from a prior successful session if the PowerShell script did not launch. The screenshot supplied from November 6, 2026 shows an unsigned/unknown-publisher SmartScreen prompt; the supplied old startup.log shows a previous successful launch and is **not** evidence for the later failure.

## Supply-chain steps for an actual signed public release

1. Obtain a CA-validated Authenticode code-signing certificate or use Microsoft Artifact Signing with verified identity; **do not** rely on self-signed certificates to convince consumers or SmartScreen.
2. Rebuild launcher **before signing**. Check file properties and source. Security-scan the entire package, including existing native helpers.
3. Sign and timestamp the launcher EXE plus all bundled EXEs and DLLs that your publisher is authorized to distribute, using a legitimate signing service. See `Documentation/CODE_SIGNING_AND_SMARTSCREEN.md`.
4. Authenticode-sign all shipped `.ps1` scripts with an appropriate trusted code-signing certificate. PowerShell `RemoteSigned` can then allow Internet-marked scripts if the publisher is trusted and machine policy permits them.
5. Any signing changes bytes, so regenerate all integrity manifests **after signing** and before creating the final ZIP. Verify the signatures, hashes, and script execution on a clean Windows test PC.
6. Submit test evidence, provenance/source and any erroneous detection to Microsoft and Nexus Mods. Signed files can still face SmartScreen warnings until reputation accumulates.

## Reproducibility limits

`/Brepro` is enabled; identical tool versions and inputs produce the same launcher output. This package does not contain a public publisher certificate. Runtime use on Windows 10/11 has not been tested in this Linux build environment. Original sources for `ArmorProgress.exe` and `AdvancedEdits.exe` remain unavailable from the archived Stage 45/47 packages; do not represent those as rebuilt.
