# Rebuilding — what is and is not possible from this archive

## Editor source

The editor is a Windows PowerShell 5.1 WinForms application, **not** a single C++ or C# GUI program. The shipped `.ps1` scripts and `CompanionControls.cs` are source. Offline guide JavaScript and localized/readable catalog JSON files are present as source/reviewable data.

A source-only archive intentionally omits many installed assets, thumbnails, audio, binary game-reference tables and the native DLL/EXE helper files. Consequently this folder alone is **not executable**. Compare it against the runtime ZIP; do not merge these source files into another game installation without preserving its asset dependencies.

## Launcher

Windows 10/11 x64 + LLVM `clang.exe` and `lld-link.exe` + Python 3. Run `MHW-I Save Editor and Master Compendium\Source\Launcher\build.cmd` from Command Prompt (with toolchain on `PATH`). The build requires `Questbook.ico`, included at the expected relative path, and writes an **unsigned** `.exe` in the application root. It can be compared with the release binary, but byte-identical reproduction depends on exact compiler/tool versions and inputs. The EXE uses version resource `CompanyName = H3CT1C | Frank Sidor | Nihilist Kvlt Mods`; metadata is not a verified Authenticode signature.

## Native helper projects — seven of nine

See each project-specific `NativeSources/RecoveredProjects/*/BUILD.md` or `BUILD_FROM_STAGE*.md` (Windows/host commands are documented). Historical Zig 0.14.1 and/or Python 3 are used in the original notes, often C++17 `x86_64-windows-gnu`. Source trees were copied directly from recovered stage archives and compared with historical hashes. **We have not rerun any compiler or validated output equivalence to the 9 shipped PE files.**

- `MHWJewelsEngine.exe`: archived source in `NativeSources/RecoveredProjects/MHWJewelsEngine/`.
- `EquipmentDetails.exe`: archived source in `NativeSources/RecoveredProjects/EquipmentDetails/`.
- `EquipmentTools.exe`: archived source in `NativeSources/RecoveredProjects/EquipmentTools/`.
- `QuestbookPause.exe`: archived source in `NativeSources/RecoveredProjects/QuestbookPause/`.
- `mhwi_account_bridge.dll`: archived source in `NativeSources/RecoveredProjects/AccountBridge/`.
- `fieldharvest_selected.dll` and `fieldharvest_field.dll`: same archived `NativeSources/RecoveredProjects/FieldHarvest/` source with `FIELD_SWEEP=0` or `FIELD_SWEEP=1`.

### Not reproducible from the archived source

The exact original C++ implementation and build project for `ArmorProgress.exe` and `AdvancedEdits.exe` have not been found. Only the related PowerShell integration scripts (`CompanionArmorProgress.ps1`, `CompanionAdvancedEdits.ps1`) are available in this source pack; those are **not** substitutes for the missing native binaries. No claim of full binary reproducibility should be made to Nexus. See `NativeSources/MissingOriginalSource/`.

## Code signing and release process

All shipped executables must be checked/signed by the legitimate copyright holder with a publicly trusted code-signing credential if available; PowerShell scripts may require separate Authenticode signing. Signing changes file hashes, so regenerate release manifests *after* signing. The code here is unsigned and not a production installer.
