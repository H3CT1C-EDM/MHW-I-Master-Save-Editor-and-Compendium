# Startup flow and security distinctions

## Portable EXE launch

The native launcher uses Windows PowerShell 5.1 with `-ExecutionPolicy RemoteSigned`. It does not modify the system-wide PowerShell policy or disable Defender. Internet-origin marking may block unsigned scripts; the user verified the install worked after unblocking a trusted ZIP before extraction. This does not replace proper code signing.

1. Startup entrypoint: `MHW-I Save Editor and Master Compendium.exe` compiled from `Source/Launcher/Launcher.c`.
2. Windows PowerShell 5.1 runs `Bootstrap.ps1` in a single-threaded apartment (`-STA`).
3. `Bootstrap.ps1` loads WinForms, shows splash and calls `JewelsEditor.ps1`.
4. `JewelsEditor.ps1` loads editor components and uses `MHWJewelsEngine.exe` for some save handling.
5. Optional Account Bridge/FieldHarvest DLLs are game plugins, not required to open a normal editor UI.
6. Additional tools are separate helper processes invoked by explicit editor features.

The code may use file I/O and game-process integration as a modding editor. Those operations must be reviewed against published Nexus rules. Do not assert that downloaded code is safe solely because it is readable.

## Binary and source parity

The file hashes in `Evidence/RUNTIME_SOURCE_HASHES.csv` were computed from the release archive, then those exact bytes were copied into this source package. No refactoring was performed. The launcher source represents only this release variant. See `Evidence/BINARY_TO_SOURCE_MAP.csv` for original compiled binary names, hashes and source availability.
